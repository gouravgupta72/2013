//
//  FundCardViewController.h
//  CoreMoney
// Class used for create Fund View
#import <UIKit/UIKit.h>

@interface FundCardViewController : UIViewController

@end
