//
//  FundCardViewController.m
//  CoreMoney
// Class used for create Fund View
#import "FundCardViewController.h"

@interface FundCardViewController ()

@end

@implementation FundCardViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        addNavigationBar(FUND_CARD_TITLE, NAV_SLIDE, self);
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// when tap on cancel bar button then call this method. that send to controll on previuos view
-(void) openBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
