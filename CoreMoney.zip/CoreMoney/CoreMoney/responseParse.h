//
//  responseParse.h
//

#import <Foundation/Foundation.h>

@protocol ParsedDelegate;
@interface responseParse : NSObject
{
    id <ParsedDelegate>delegate;
}
@property(nonatomic,assign) id <ParsedDelegate>delegate;

+ (responseParse*)sharedParseManager;

-(void)parseSetSensorResponse:(id)jsonData;

-(BOOL)parseRegistrationResponse:(id)jsonData;

-(BOOL)parseLoginResponse:(id)jsonData;

-(NSMutableArray *)parseGetStore:(id)jsonData;

-(void)parseResetPasswordResponse:(id)jsonData;

@end

@protocol ParsedDelegate <NSObject>

@end