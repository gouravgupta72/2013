//
//  CardListDetailViewController.m

// Class for Card List Detail View.

#import "CardListDetailViewController.h"
#import "HomeCell.h"
#import "TransactionViewController.h"
#import "UserProfileViewController.h"
#import "AutoMaticViewController.h"
#import "FundCardViewController.h"
#import "ExpenseRulesViewController.h"

@interface CardListDetailViewController ()

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(void) openSlide;
-(void) openBack;
-(void) addObjectToArray:(NSString *) imgName Label:(NSString *)lblString;
-(void) fillDetail;
-(void) resetView;
-(void) getRequest;

@end

@implementation CardListDetailViewController
BOOL flag = NO; // To check wheter Fund Card occur in the list
@synthesize ProductId;


// Initilize Card Detail view
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
        if (!cellArray)
        {
            cellArray = [[NSMutableArray alloc] init];
        }else
        {
            [cellArray removeAllObjects];
        }
        addNavigationBar(CARD_LIST_DETAIL_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        
        if ([AdminAccessInfo AdminAcess].transactionHistoryValue == TRANSACTIONHISTORY)
        {
            [self addObjectToArray:@"img_Card_detail_transaction" Label:@"Transactions"];
        }
        
        [self addObjectToArray:@"img_administration_home" Label:@"Profile"];
        if ([AdminAccessInfo AdminAcess].loadCard == LOADCARD)
        {
            [self addObjectToArray:@"img_Card_detail_fundCard" Label:@"Fund Card"];
        }
        if ([AdminAccessInfo AdminAcess].scheduleCard == SCHEDULECARD)
        {
            [self addObjectToArray:@"img_Card_detail_AutoMaticFund" Label:@"Automatic Funding"];
        }
        if ([AdminAccessInfo AdminAcess].expenseRules == EXPENSERULES)
        {
            [self addObjectToArray:@"img_Card_detail_ExpenceRules" Label:@"Expense Rules"];
        }
//        [self addObjectToArray:@"img_Card_detail_transaction" Label:@"Transactions"];
//        [self addObjectToArray:@"img_administration_home" Label:@"Profile"];
//        [self addObjectToArray:@"img_Card_detail_fundCard" Label:@"Fund Card"];
//        [self addObjectToArray:@"img_Card_detail_AutoMaticFund" Label:@"Automatic Funding"];
//        [self addObjectToArray:@"img_Card_detail_ExpenceRules" Label:@"Expense Rules"];
        
    }
    return self;
}

// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
        //        self.scrollUpperView.frame=CGRectMake(0,IS_IPAD?20:23, 320, IS_IPAD?170:170);
    }
}

// Pop to previous View
-(void)openBack
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    [self.navigationController popViewControllerAnimated:YES];
}

// initialize cellarray
-(void) addObjectToArray:(NSString *) imgName Label:(NSString *)lblString
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:imgName forKey:@"imgName"];
    [dict setObject:languageSelectedStringForKey(lblString) forKey:@"lblString"];
    
    [cellArray addObject:dict];
    [dict release];
}

- (void)viewDidLoad
{
    [AppDelegate sharedAppDelegate].classType=CARD_LIST_DETAIL_PAGE;
    self.tblCardList.backgroundColor=[UIColor clearColor];
//    if(IS_IOS7)
//    {
//        if (IS_IPAD) {
//            self.mySubView.frame = CGRectMake(0,50 , 320, 460);
//        }else
//        {
//        self.mySubView.frame = CGRectMake(0,60 , 320, 460);
//        }
//    }
//    else if(IS_IPAD)
//        self.mySubView.frame = CGRectMake(0,20 , 320, 460);
//    else
//        self.mySubView.frame = CGRectMake(0,0 , 320, 460);
    
    self.mySubView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0 , 320, 460);
    
  
    [self.view addSubview:self.mySubView];
    self.scrollUpperView.delegate = self;
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated
{
    
    if (isFirstTime)
    {
        [self resetView];
    }else
    {
        [self fillDetail];
    }
    [self setScrollViewLeftRightIndicator];
    [AppDelegate sharedAppDelegate].classType=CARD_LIST_DETAIL_PAGE;
    
    [[AppDelegate sharedAppDelegate] removeLoadingView];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)resetView
{
    for (UIView *subview in self.scrollUpperView.subviews)
    {
        if ([subview isKindOfClass:[CardDetailView class]])
        {
            if (subview.tag==[AppDelegate sharedAppDelegate].CardDetailPageIndex)
            {
                CardDetailView *view=(CardDetailView *)subview;
                
                CardDetailClass *dataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
                
                view.lblName.text=[NSString stringWithFormat:@"%@%@%@",checkISNullStrings(dataObj.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@ ",dataObj.FIRSTNAME],checkISNullStrings(dataObj.LASTNAME)?@"":[NSString stringWithFormat:@"%@ ",dataObj.LASTNAME],checkISNullStrings(dataObj.CustomAccountID)?@"":[NSString stringWithFormat:@","]];

                
                view.lblAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dataObj.AVAILABLEBALANCE))];
                
                view.lblEmployeeId.frame=CGRectMake(CGRectGetMaxX(view.lblName.frame), view.lblEmployeeId.frame.origin.y,300-view.lblName.frame.size.width, view.lblEmployeeId.frame.size.height);
                
                view.lblEmployeeId.text=[NSString stringWithFormat:@"%@",checkISNullStrings(dataObj.CustomAccountID)?@"":[NSString stringWithFormat:@"%@",dataObj.CustomAccountID]];
                
                
                view.lblCardNo.text=[NSString stringWithFormat:@"%@",ChangeCardNumber(dataObj.CARDNUMBER)];
                
                view.lblStatus.text=CardStatusValue(dataObj.STATUS_CARDACCOUNT);
                
                
                view.lblCurrentBalance.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dataObj.CURRENTBALANCE))];
                
                view.lblLastTxnAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dataObj.LastTransfer))];
                
                view.lblTime.text=[NSString stringWithFormat:@"%@",checkISNullStrings(dataObj.LastTransactionDate)?@"":dataObj.LastTransactionDate];
                
                break;
            }
        }
    }
}
// Fill Data on view
-(void)fillDetail
{
    
    for (UIView *subview in self.scrollUpperView.subviews)
    {
        if ([subview isKindOfClass:[CardDetailView class]])
        {
            [subview removeFromSuperview];
        }
    }

    int xpos=0;
    for (int i=0; i<[[AppDelegate sharedAppDelegate].arrCardDetailArray count]; i++)
    {
        viewObj=[[CardDetailView alloc]initWithDetailViewFrame:CGRectMake(xpos, 0, 320, 170)];
        [self.scrollUpperView addSubview:viewObj];
        [viewObj release];
        
        CardDetailClass *dataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:i];
        viewObj.tag=i;
        
        viewObj.lblName.text=[NSString stringWithFormat:@"%@%@%@",checkISNullStrings(dataObj.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@ ",dataObj.FIRSTNAME],checkISNullStrings(dataObj.LASTNAME)?@"":[NSString stringWithFormat:@"%@ ",dataObj.LASTNAME],checkISNullStrings(dataObj.CustomAccountID)?@"":[NSString stringWithFormat:@","]];
        
        
        viewObj.lblName.frame=CGRectMake(viewObj.lblName.frame.origin.x, viewObj.lblName.frame.origin.y, getTextWidth(viewObj.lblName.text, viewObj.lblName.font), viewObj.lblName.frame.size.height);
        
        viewObj.lblEmployeeId.frame=CGRectMake(CGRectGetMaxX(viewObj.lblName.frame), viewObj.lblEmployeeId.frame.origin.y,300-viewObj.lblName.frame.size.width, viewObj.lblEmployeeId.frame.size.height);
        
        viewObj.lblEmployeeId.text=[NSString stringWithFormat:@"%@",checkISNullStrings(dataObj.CustomAccountID)?@"":[NSString stringWithFormat:@"%@",dataObj.CustomAccountID]];
        

        
        viewObj.lblAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dataObj.AVAILABLEBALANCE))];
        
        viewObj.lblCardNo.text=[NSString stringWithFormat:@"%@",ChangeCardNumber(dataObj.CARDNUMBER)];
        
        viewObj.lblStatus.text=CardStatusValue(dataObj.STATUS_CARDACCOUNT);
        
        
        viewObj.lblCurrentBalance.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dataObj.CURRENTBALANCE))];
        
        viewObj.lblLastTxnAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dataObj.LastTransfer))];
        
        viewObj.lblTime.text=[NSString stringWithFormat:@"%@",checkISNullStrings(dataObj.LastTransactionDate)?@"":dataObj.LastTransactionDate];
        
        xpos=CGRectGetMaxX(viewObj.frame);
        
    }
    [self.scrollUpperView setContentSize:CGSizeMake(xpos, 0)];
    [self.scrollUpperView setContentOffset:CGPointMake(320*[AppDelegate sharedAppDelegate].CardDetailPageIndex, 0)];
    
    if ([AppDelegate sharedAppDelegate].CardDetailPageIndex==0)
    {
        self.leftview.hidden=YES;
    }
    if ([[AppDelegate sharedAppDelegate].arrCardDetailArray count]==1) {
        self.leftview.hidden=YES;
        self.rightview.hidden=YES;
    }
    
}

- (void)dealloc
{
    [_scrollUpperView release];
    [_hearedView release];
    [_myHeaderImage release];
    [_leftview release];
    [_rightview release];
    [_mySubView release];
    [cellArray release];
    [super dealloc];
}

- (void)viewDidUnload {
    [self setScrollUpperView:nil];
    [self setHearedView:nil];
    [self setMyHeaderImage:nil];
    [self setLeftview:nil];
    [self setRightview:nil];
    [self setMySubView:nil];
    [super viewDidUnload];
}

-(void) setScrollViewLeftRightIndicator
{
    float fltContentOffsetX = self.scrollUpperView.contentOffset.x;
    float fltContentSizeWidth = self.scrollUpperView.contentSize.width;
    CGFloat pageWidth =self.scrollUpperView.frame.size.width;
    
    (fltContentSizeWidth - (fltContentOffsetX + pageWidth) <= 0) ? (self.rightview.hidden = YES):(self.rightview.hidden = NO);
    fltContentOffsetX > 0 ? (self.leftview.hidden = NO) : (self.leftview.hidden = YES);
    
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    [self setScrollViewLeftRightIndicator];

}

// Method used to get the index of the selected view.
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat pageWidth =self.scrollUpperView.frame.size.width;
    int  indexNumber = floor((self.scrollUpperView.contentOffset.x - pageWidth / 3) / pageWidth) + 1;
    if (indexNumber==0) {
        self.leftview.hidden=YES;
        self.rightview.hidden=NO;
    }
    else if (indexNumber == [[AppDelegate sharedAppDelegate].arrCardDetailArray count]-1)
    {
        self.leftview.hidden=NO;
        self.rightview.hidden=YES;
    }
    else{
        self.leftview.hidden=NO;
        self.rightview.hidden=NO;
    }
    [AppDelegate sharedAppDelegate].CardDetailPageIndex=indexNumber;
    [self setScrollViewLeftRightIndicator];
}

-(void)getRequest
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    switch (cardDetailButtonType) {
        case CARDS_TRANSACTION_BUTTON:
        {
            int BatchSize=50;
            CardDetailClass * cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            [SystemConfiguration sharedSystemConfig].dbbServiceName=TransactionHistory_Request;
            [SystemConfiguration sharedSystemConfig].deCIASTxnFilter=@"0";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deCIAClientID=%@&deCIAAccountNumber=%@&deANAProductID=%@&deCIASFromDate=&deCIASToDate=&deCIASTxnFilter=%@&deCIASTxnBatchSize=%@&deCIASTxnPageIndex=0&de_TranId_TH=&deCIASTxnHistoryType=0&deCIAMaximumTxnAmount=&deCIAminimumTxnAmount=&deCIAMerchantSearch=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,cardDataObj.CLIENTID,cardDataObj.ACCOUNTNUMBER,cardDataObj.PRODUCTID,[SystemConfiguration sharedSystemConfig].deCIASTxnFilter,[NSString stringWithFormat:@"%d",BatchSize],[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCHTransactionHistory];
        }
            break;
            
        case CARDS_PROFILE_BUTTON:
        {
            
            
            [SystemConfiguration sharedSystemConfig].dbbServiceName=Card_holder_Detail_Request;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
                        
           CardDetailClass *CardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deTCIVRPrimaryAccountNumber=%@&deTCIVRAccountNumber=%@&deTCIVRANI=&deTCIVRDNS=&deBSAcctid_New=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, CardDataObj.CARDNUMBER,CardDataObj.ACCOUNTNUMBER,CardDataObj.BSAcctID,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCardholderDetail];
        }
            break;
            
        case CARDS_AUTOMATIC_FUNDING_BUTTON:
        {
            switch (autoMaticfundReqType) {
                  
                case LowBalanceSearch:
                {
                    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
                    [SystemConfiguration sharedSystemConfig].dbbServiceName=Search_LowBalance_REquest;
                    CardDetailClass *cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
                    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deBAAccountAcctId=%@&deBTSFlag=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.BSAcctID,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBALowBalanceFundingSearch];
                    
                }
                    break;
                    
                case SchedulingSearch:
                {
                    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
                    [SystemConfiguration sharedSystemConfig].dbbServiceName=Search_Schedule_funding_Request;
                    CardDetailClass *cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
                    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deBAAccountAcctId=%@&deBTSFlag=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.BSAcctID,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBAScheduleFundingSearch];
                    
                }
                    break;
                    
                    
                    
                default:
                    break;
            }

            
            
        }
            break;
            
        case CARD_STATE_CODE:
        {
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            [SystemConfiguration sharedSystemConfig].dbbServiceName=getStateCode;
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=1&dbbServiceName=%@&deCIALutID=State&deCIALutCode=US&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcState];
            
        }
            break;

        case CARDS_EXPENSE_RULE_BUTTON:
        {
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            [SystemConfiguration sharedSystemConfig].dbbServiceName=Expense_rules_req;
            CardDetailClass *cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deAccountID_AS=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.ADMIN_NUMBER,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcViewAccountSpendParameter];
            
            
        }
            break;
           
        default:
            break;
    }
    
    
    [DataReq release];
}

-(void)getResponce:(id)jsonData
{
    
    switch (cardDetailButtonType)
    {
        case CARDS_TRANSACTION_BUTTON:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    TransactionViewController *obj=[[TransactionViewController alloc] initWithNibName:@"TransactionViewController" bundle:nil trasactionData:jsonData isAlertRequest:NO];
                    
                    [self.navigationController pushViewController:obj animated:YES];

                    [obj release];
                }else
                {
                    showAlertScreen(@"No Records", @"There is no record found.");
                }


            }else
            {
                showAlertScreen(nil, jsonData);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
                case CARDS_PROFILE_BUTTON:
                {
                    [[AppDelegate sharedAppDelegate] removeLoadingView];
                   UserProfileDataClass * obj  = (UserProfileDataClass *)jsonData;
                    
                    if(obj != nil){
                        
                    UserProfileViewController *clvc = [[UserProfileViewController alloc] initWithNibName:@"UserProfileViewController" bundle:nil userProfileData:obj];
                    
                    [self.navigationController pushViewController:clvc animated:YES];
                     
                    [clvc release];
                    }
                    else{
                        
                    }
                        
                }
            break;
            
        case CARDS_AUTOMATIC_FUNDING_BUTTON:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            switch (autoMaticfundReqType) {
                    
                case LowBalanceSearch:
                {
                    
                    lowBalanceSearchObj = (lowBalanceSearchDataClass *) jsonData;
                    autoMaticfundReqType = SchedulingSearch;
                    [[AppDelegate sharedAppDelegate] addloadingView];
                    [self getRequest];
                }
                    break;
                    
                case SchedulingSearch:
                {
                    
                    ScheduleFundingSearchDataClass *obj = (ScheduleFundingSearchDataClass *) jsonData;
                    AutoMaticViewController *fcvc = [[AutoMaticViewController alloc] initWithNibName:@"AutoMaticViewController" bundle:nil CardData:nil];
                    fcvc.lowBalancingObj = lowBalanceSearchObj;
                    fcvc.schedulingObj = obj;
                    [self.navigationController pushViewController:fcvc animated:YES];
                    [fcvc release];

                    
                }
                    break;
                    
                default:
                    break;
            }
            
        }
            break;
            case CARD_STATE_CODE:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            if ([jsonData count]>0)
            {
                stateArray=jsonData;
            }
            cardDetailButtonType=CARDS_PROFILE_BUTTON;
            [self getRequest];
        }
            break;
            case CARDS_EXPENSE_RULE_BUTTON:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            ExpenseRulesViewController *fcvc = [[ExpenseRulesViewController alloc] initWithNibName:@"ExpenseRulesViewController" bundle:nil CardData:jsonData];
            [self.navigationController pushViewController:fcvc animated:YES];
            [fcvc release];
        }
            break;
            
        
        default:
            break;
    }
    
    
}
#pragma mark- Table View Delegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 52;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [cellArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	NSMutableDictionary *dict = [cellArray objectAtIndex:indexPath.row];
    
   
        static NSString *CellIdentifier = @"Cell";
        HomeCell *cell = (HomeCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[[HomeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        }
    
        
        cell.lblName.text=[dict objectForKey:@"lblString"];
        cell.cellImage.image=[UIImage imageNamed:[dict objectForKey:@"imgName"]];
        cell.lblName.textColor=[UIColor blackColor];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
//    NSLog(@"%@",cell.lblName);
    if ([cell.lblName.text isEqual:@"Transactions"] && [AdminAccessInfo AdminAcess].transactionHistoryValue != TRANSACTIONHISTORY) {
        cell.lblName.textColor=[UIColor grayColor];
    }
    if ([cell.lblName.text isEqual:@"Fund Card"] && [AdminAccessInfo AdminAcess].loadCard != LOADCARD)
    {
        cell.lblName.textColor=[UIColor grayColor];
    }
    if ([cell.lblName.text isEqual:@"Automatic Funding"] && [AdminAccessInfo AdminAcess].scheduleCard != SCHEDULECARD)
    {
        cell.lblName.textColor=[UIColor grayColor];
    }
    if ([cell.lblName.text isEqual:@"Expense Rules"] && [AdminAccessInfo AdminAcess].expenseRules != EXPENSERULES) {
        cell.lblName.textColor=[UIColor grayColor];
    }    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    int rowSelected = indexPath.row;
    
    // If index Value based on Transaction History is 115 then user can view the transaction page
    if ([AdminAccessInfo AdminAcess].transactionHistoryValue != TRANSACTIONHISTORY && rowSelected > -1) {
        rowSelected ++;
    }
    
    /* if index value is 121 then user can operate fund card.Else Fund card option will be invisible for that user
     */
    if ([AdminAccessInfo AdminAcess].loadCard != LOADCARD && rowSelected>1) {
        rowSelected++;
    }
    
    // if index value is 148 then user can operate Automatic funding.
    if ([AdminAccessInfo AdminAcess].scheduleCard != SCHEDULECARD && rowSelected > 2) {
        rowSelected++;
    }
    
    
    switch (rowSelected)
    {
        case CARDS_TRANSACTION_BUTTON:
        {
            if ([AdminAccessInfo AdminAcess].transactionHistoryValue == TRANSACTIONHISTORY)
            {
                [[AppDelegate sharedAppDelegate] addloadingView];                
                isFirstTime=YES;
                cardDetailButtonType = CARDS_TRANSACTION_BUTTON;
                [self getRequest];
            }
        }
            break;
        case CARDS_PROFILE_BUTTON:
        {
            [[AppDelegate sharedAppDelegate] addloadingView];
            isFirstTime=YES;
            cardDetailButtonType = CARDS_PROFILE_BUTTON;
            [self getRequest];
            
        }
            break;
        case CARDS_FUND_BUTTON:
        {
            if ([AdminAccessInfo AdminAcess].loadCard == LOADCARD)
            {
                [[AppDelegate sharedAppDelegate] addloadingView];
                isFirstTime=YES;
                cardDetailButtonType = CARDS_FUND_BUTTON;
                FundCardViewController *fcvc = [[FundCardViewController alloc] initWithNibName:@"FundCardViewController" bundle:nil CardData:nil];
                [self.navigationController pushViewController:fcvc animated:YES];
                [fcvc release];
            }
        }
            break;
        case CARDS_AUTOMATIC_FUNDING_BUTTON:
        {
            if ([AdminAccessInfo AdminAcess].scheduleCard == SCHEDULECARD)
            {
                [[AppDelegate sharedAppDelegate] addloadingView];
                isFirstTime=YES;
                cardDetailButtonType = CARDS_AUTOMATIC_FUNDING_BUTTON;
                autoMaticfundReqType = LowBalanceSearch;
                [self getRequest];
            }
            
        }
            break;
        case CARDS_EXPENSE_RULE_BUTTON:
        {
            if ([AdminAccessInfo AdminAcess].expenseRules == EXPENSERULES)
            {
                [[AppDelegate sharedAppDelegate] addloadingView];
                isFirstTime=YES;
                isFirstTime=NO;
                cardDetailButtonType = CARDS_EXPENSE_RULE_BUTTON;
                [self getRequest];
            }
        }
            break;
        default:
            break;
    }
    
}


@end
