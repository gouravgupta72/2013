//
//  HelpMenuItem.h



// Class for design Help Menu Content.
#import <UIKit/UIKit.h>

@interface HelpMenuItem : UIView
{
    UIImageView *imglogo;
    UILabel *lblTitle;
    UIButton *btnSelect;
    
}
@property(nonatomic,retain) UILabel *lblTitle;
- (id)initWithHelpMenuFrame:(CGRect)frame delegate:(id)del image:(NSString *)imgName Title:(NSString *)title tag:(int)index;
@end
