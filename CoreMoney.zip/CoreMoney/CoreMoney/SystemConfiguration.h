//
//  SystemConfiguration.h
//  CoreMoney

// Hold Data For Server Request.
#import <Foundation/Foundation.h>

@interface SystemConfiguration : NSObject
{
    NSString *deCIAIPAddress,*dePPVersionComments,*deUsrActLogParam2,*deIVRSource,*deIVRIpAddress,*deIVRCallerId,*deIVRCalledId,*deIVRRequestTime,*deIVRSessionID,*deDeviceId,*deDBBServiceApiLevel,*deDBBServiceAppID,*dbbSystemExtLogin,*dbbSystemSingleSignon,*dbbServiceName, *deSetFlagValue_BankAct, *Application,*deFlagShowDetails, *deCIASTxnFilter;
}
@property(nonatomic,retain)NSString *deCIAIPAddress,*dePPVersionComments,*deUsrActLogParam2,*deIVRSource,*deIVRIpAddress,*deIVRCallerId,*deIVRCalledId,*deIVRRequestTime,*deIVRSessionID,*deDeviceId,*deDBBServiceApiLevel,*deDBBServiceAppID,*dbbSystemExtLogin,*dbbSystemSingleSignon,*dbbServiceName, *deSetFlagValue_BankAct,*Application,*deFlagShowDetails, *deCIASTxnFilter;
+(SystemConfiguration *)sharedSystemConfig;
@end
