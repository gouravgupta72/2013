//
//  AlertsDetailViewController.m
//  CoreMoney
//
// class used for alert detail view
#import "AlertsDetailViewController.h"

#import "TransferViewController.h"
#import "TransactionViewController.h"
#import "CardDataCell.h"
#import "PopUpView.h"
#import "HomeViewController.h"
#import "UserProfileViewController.h"
#import "pendingAlertViewCntroller.h"
#define ALERTSTATUSNEW @"NEW"
#define ALERTSTATUSREAD @"READ"
#define ALERTSTATUSDELETE @"DELETE"

#define READFLAG @"2"
#define DELETEFLAG @"1"

@interface AlertsDetailViewController ()
// following methods added in interface
-(void)openBack;
-(void)openSlide;
-(void) addNavigattionBar;
-(void) removeStatusView;
-(void)removeChangeStatusView;
-(int) setHeightofRow;
-(void) removePopUpview;
-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index;
-(void)changeCardStatus :(int)chagedStatus;
-(void) getResponce:(id)jsonData;
-(void)openStatusView:(int)index;

@end
NSInteger row, section;
CGFloat fImageheight;
@implementation AlertsDetailViewController
@synthesize strAccountNumber, strBussAccountID;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil alertType:(Alert_Type )alerttype array:(NSMutableArray *) array alertGroup:(int)alertcolor
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
            // Custom initialization
        alertType = alerttype;
        alertColorIdentifier=alertcolor;
        if (array!=nil)
        {
            dataArray = [[NSMutableArray alloc] initWithArray:array];
        }else
        {
            dataArray = [[NSMutableArray alloc]init];
        }
        
        [self addNavigattionBar];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
     // Do any additional setup after loading the view from its nib.
    self.backView.frame = CGRectMake(0,IS_IPAD?30:0, self.backView.frame.size.width,IS_IPAD?self.backView.frame.size.height-30:self.backView.frame.size.height);

    alertBottomViewNumber=-1;
}

-(void) viewWillAppear:(BOOL)animated
{
    [AppDelegate sharedAppDelegate].classType = ADMIN_ALERTS_PAGE ;
    [self.navigationController setNavigationBarHidden:NO];
//    NavigationBarStyle();
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_backView release];
    [_listTableView release];
    //memory release 
    [dataArray release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setBackView:nil];
    [self setListTableView:nil];
    [super viewDidUnload];
}

// method use for send to previus view
-(void)openBack
{
    if([AppDelegate sharedAppDelegate].isNotification == NO)
    {
        [self getAlertListCount];
//       [self.navigationController popViewControllerAnimated:YES]; 
    }
    else{
        [AppDelegate sharedAppDelegate].isNotification = NO;
        
        HomeViewController *homeView = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
        [self.navigationController pushViewController:homeView animated:YES];
        [homeView release];
    }
    
}
// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

// method use for create navigation bar and add title
-(void) addNavigattionBar
{
    NSString *strtitle = @"";
    switch (alertType) {
        case Card_Pending_Activation_Alert:
            strtitle =ALERT_CARD_PENDING_ACTIVATION;
            break;
        case Auto_Funding_Faild_Alert:
            strtitle =ALERT_AUTO_FUNDING_FAILD_LOW_FUNDS;
            break;
        case Low_Balance_Cards_Alert:
            strtitle =ALERT_LOW_BALANCE_CARDS;
            break;
        case Negative_Card_Balance_Alert:
            strtitle =ALERT_NEGATIVE_CARD_BALANCE;
            break;
        case Card_Transaction_Decline_Alert:
            strtitle =ALERT_CARD_TRANSACTION_DECLINE;
            break;
        case enumFraudAlert:
            strtitle = ALERT_FRAUD_ALERT;
            break;
        case Card_Spend_Rules_Changed_Alert:
            strtitle =ALERT_CARD_SPEND_RULES_CHANGED;
            break;
        case Funding_Rules_Changed_Alert:
            strtitle =ALERT_FUNDING_RULES_CHANGED;
            break;
        case New_card_issued_Alert:
            strtitle =ALERT_NEW_CARD_ISSUED_REISSUED;
            break;
        case Auto_Funding_Faild_Admin:
            strtitle =ALERT_AUTO_FUNDING_FAILED_ADMIN_LOAD_LIMIT
;
            break;
        case High_value_transaction_Alert:
            strtitle =ALERT_HIGH_VALUE_TRANSACTION;
            break;
        case Business_Policy_Changed:
            strtitle =ALERT_BUSINESS_POLICY_CHANGED;
            break;
        case Card_Profile_Updated:
            strtitle =ALERT_CARD_PROFILE_UPDATE;
            break;
         // Navigation page title for detail view of alert
        case Bulk_Card_Request:
            strtitle =ALERT_BULK_CARD_REQUEST_LOAD;
            break;
        case Low_Balance_on_Business:
            strtitle =ALERT_LOW_BALANCE_ON_BUSINESS;
            break;
        case International_Card_Transactions:
            strtitle =ALERT_INTERNATIONAL_TRANSACTIONS;
            break;
        case Card_Frequency_Alert:
            strtitle =ALERT_FREQUENCY;
            break;
        default:
            break;
    }

    addNavigationBar(strtitle, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
}

- (void)openEmpComboView
{
    [self removeComboView];
    
    popView = [[UIView alloc] initWithFrame:self.view.frame];
    popView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:popView];
    
    if (!alertSearchArray)
    {
        alertSearchArray = [[NSMutableArray alloc]init];
        [alertSearchArray addObject:MARk_ALL_READ];
        [alertSearchArray addObject:MARk_ALL_DELETE];
    }
    
    comboView = [[ComboViewController alloc] initWithFrame:CGRectMake(170,(IS_IOS7?(IS_IPAD?0:60):0), 150, 50) records:alertSearchArray callingClassType:yearList];
    
    comboView.delegate=self;
    [popView addSubview:comboView];
    [comboView release];
    
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if([comboView isDescendantOfView:popView])
    {
        [self removeComboView];
    }
}

-(void)removeComboView
{
    if ([popView isDescendantOfView:self.view])
    {
        [popView removeFromSuperview];
        popView=nil;
    }
}

-(void) selectQuetion:(id) que
{
    NSString *txt = (NSString *)que;
    
    if ([txt  isEqual: MARk_ALL_DELETE])
    {
        requestID =  Mark_ALL_Delete_Alert;
        [self makeRequestForAll:DELETEFLAG];
        
    }else if ([txt  isEqual: MARk_ALL_READ])
    {
        requestID = Mark_All_Read_Alert;
        [self makeRequestForAll:READFLAG];
        
    }
    [self removeComboView];
}

-(void)makeRequestForAll :(NSString *)flag
{
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;

    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=alertReadDeleteService;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    NSString *strTemp=@"";
    
    for (int i = 0; i<[dataArray count]; i++)
    {
        AlertDetailSearchClass *adsc = [dataArray objectAtIndex:i];
        strTemp = [strTemp stringByAppendingString:[NSString stringWithFormat:@"<List_AlertRead><AlertID>%@</AlertID></List_AlertRead>",adsc.strAlertId]];
    }
    NSString *strXMLString = [NSString stringWithFormat:@"<AlertRead_Req><FLAG>%@</FLAG><CardNo>0</CardNo><AlertType>%d</AlertType><ReadDelete_AlertSetup>%@</ReadDelete_AlertSetup></AlertRead_Req>",flag,alertType,strTemp];
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deAlertRead_ResponseMSG=%@",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,strXMLString]ServiceName:svcAlertRead];
    [DataReq release];
}

-(void)markAll
{
    [self openEmpComboView];
}

// method use for set row height
-(int) setHeightofRow{
    
    switch (alertType) {
        case Card_Pending_Activation_Alert:
            return SMALL_HEIGHT;
            break;
        case Auto_Funding_Faild_Alert:
            return LARGE_HEIGHT;
            break;
        case Low_Balance_Cards_Alert:
            return MEDIUM_HEIGHT;
            break;
        case Negative_Card_Balance_Alert:
            return SMALL_HEIGHT;
            break;
        case Card_Transaction_Decline_Alert:
            return MEDIUM_HEIGHT;
            break;
//        case Fradu_Alert_Alert:
//            return MEDIUM_HEIGHT;
            break;
        case Card_Spend_Rules_Changed_Alert:
            return MEDIUM_HEIGHT;
            break;
        case Funding_Rules_Changed_Alert:
            return MEDIUM_HEIGHT;
            break;
        case New_card_issued_Alert:
            return SMALL_HEIGHT;
            break;
        case Auto_Funding_Faild_Admin:
            return LARGE_HEIGHT;
            break;
        case High_value_transaction_Alert:
            return MEDIUM_HEIGHT;
            break;
        case Business_Policy_Changed:
            return MEDIUM_HEIGHT;
            break;
        case Card_Profile_Updated:
            return MEDIUM_HEIGHT;
            break;
       //Height  defined for all folloing enum type
        case Bulk_Card_Request:
            return SMALL_HEIGHT;
            break;
        case Low_Balance_on_Business:
            return SMALL_HEIGHT;
            break;
        case International_Card_Transactions:
            return LARGE_HEIGHT;
            break;
        case Card_Frequency_Alert:
            return MEDIUM_HEIGHT;
            break;
        default:
            return SMALL_HEIGHT;
            break;
    }
    
}

-(AlertDetailViewCell *) setcontentToBold:(AlertDetailViewCell *)cell
{
    //[UIFont fontWithName:@"Arial-BoldMT" size:20]
    CGFloat fltFontSize = cell.lblLeftFirst.font.pointSize;
    cell.lblLeftFirst.font = [UIFont fontWithName:@"Arial-BoldMT" size:fltFontSize];
    fltFontSize = cell.lblLeftSecond.font.pointSize;
    cell.lblLeftSecond.font = [UIFont fontWithName:@"Arial-BoldMT" size:fltFontSize];
    fltFontSize = cell.lblLeftThird.font.pointSize;
    cell.lblLeftThird.font = [UIFont fontWithName:@"Arial-BoldMT" size:fltFontSize];
    fltFontSize = cell.lblLeftFourth.font.pointSize;
    cell.lblLeftFourth.font = [UIFont fontWithName:@"Arial-BoldMT" size:fltFontSize];
    
    fltFontSize = cell.lblRightFirst.font.pointSize;
    cell.lblRightFirst.font = [UIFont fontWithName:@"Arial-BoldMT" size:fltFontSize];
    fltFontSize = cell.lblRightSecond.font.pointSize;
    cell.lblRightSecond.font = [UIFont fontWithName:@"Arial-BoldMT" size:fltFontSize];
    fltFontSize = cell.lblRightThird.font.pointSize;
    cell.lblRightThird.font = [UIFont fontWithName:@"Arial-BoldMT" size:fltFontSize];
    fltFontSize = cell.lblRightFourth.font.pointSize;
    cell.lblRightFourth.font = [UIFont fontWithName:@"Arial-BoldMT" size:fltFontSize];
    cell.btnRead.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ButtonActive.png"]];
    cell.btnRead.enabled = YES;
    return cell;
}


-(AlertDetailViewCell *) setcontentToNormal:(AlertDetailViewCell *)cell
{//[UIFont fontWithName:@"Arial-BoldMT" size:20]
    CGFloat fltFontSize = cell.lblLeftFirst.font.pointSize;
    cell.lblLeftFirst.font = [UIFont fontWithName:@"Arial" size:fltFontSize];
    fltFontSize = cell.lblLeftSecond.font.pointSize;
    cell.lblLeftSecond.font = [UIFont fontWithName:@"Arial" size:fltFontSize];
    fltFontSize = cell.lblLeftThird.font.pointSize;
    cell.lblLeftThird.font = [UIFont fontWithName:@"Arial" size:fltFontSize];
    fltFontSize = cell.lblLeftFourth.font.pointSize;
    cell.lblLeftFourth.font = [UIFont fontWithName:@"Arial" size:fltFontSize];
    
    fltFontSize = cell.lblRightFirst.font.pointSize;
    cell.lblRightFirst.font = [UIFont fontWithName:@"Arial" size:fltFontSize];
    fltFontSize = cell.lblRightSecond.font.pointSize;
    cell.lblRightSecond.font = [UIFont fontWithName:@"Arial" size:fltFontSize];
    fltFontSize = cell.lblRightThird.font.pointSize;
    cell.lblRightThird.font = [UIFont fontWithName:@"Arial" size:fltFontSize];
    fltFontSize = cell.lblRightFourth.font.pointSize;
    cell.lblRightFourth.font = [UIFont fontWithName:@"Arial" size:fltFontSize];
    cell.btnRead.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ButtonInActive.png"]];
    cell.btnRead.enabled = NO;
    return cell;
}

// method use for initialize the cell
-(AlertDetailViewCell *) initializeTableViewCell:(AlertDetailViewCell *)cell AlertDetailSearchObj:(AlertDetailSearchClass *) dataObj
{
    if ([dataObj.AlertStatus caseInsensitiveCompare:ALERTSTATUSNEW] == NSOrderedSame)
    {
        cell = [self setcontentToBold:cell];
    }else{
        cell = [self setcontentToNormal:cell];
    }
//    if ([dataObj.AlertStatus compare:ALERTSTATUSNEW options:NSCaseInsensitiveSearch])
//    {
//        
//    }
    switch (alertType) {
                    
        case Auto_Funding_Faild_Alert: /* Auto Funding Failed (due to low funds) */
        {
            cell.lblLeftFourth.hidden = YES;
            cell.lblLeftFirst.frame = CGRectMake(10, 0, 210, 25);
            cell.lblLeftFirst.text =  [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.BusinessName)?@"":dataObj.BusinessName)];
            
            cell.lblRightFirst.frame = CGRectMake(210, 0, 100, 25);
            cell.lblRightFirst.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.BusinessBal)?@"":[NSString stringWithFormat:@"$%@",ChangeTocurrency([dataObj.BusinessBal floatValue])])];
            
            cell.lblLeftSecond.frame = CGRectMake(10, 25, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            cell.lblRightSecond.frame = CGRectMake(120, 25, 190, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            cell.lblLeftThird.frame = CGRectMake(10, 50, 160, 25);
            cell.lblLeftThird.textColor = [UIColor grayColor];
            cell.lblLeftThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.EmployeeId)?@"":dataObj.EmployeeId)];
            
            cell.lblRightThird.frame= CGRectMake(200, 50, 110, 25);
            cell.lblRightThird.textColor = [UIColor blackColor];
            cell.lblRightThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AvailableBal)?@"":[NSString stringWithFormat:@"$%@",ChangeTocurrency([dataObj.AvailableBal floatValue]) ])];
            
            cell.lblRightFourth.frame = CGRectMake(180, 75, 130, 25);
            cell.lblRightFourth.textColor = Status_Color_Code;
            cell.lblRightFourth.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.FundingStatus)?@"":dataObj.FundingStatus)] ;
            return cell;
        }
            break;
        case Low_Balance_Cards_Alert:   /* Low Balance Cards */
        {
            cell.lblLeftFourth.hidden = YES;
            cell.lblLeftThird.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            cell.lblRightFourth.hidden = YES;
            cell.lblLeftFirst.frame = CGRectMake(10, 0, 300, 25);
            cell.lblLeftFirst.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.BusinessName)?@"":dataObj.BusinessName)];
            
            cell.lblLeftSecond.frame = CGRectMake(10, 25, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            cell.lblRightSecond.frame = CGRectMake(120, 25, 190, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            cell.lblRightThird.frame= CGRectMake(200, 50, 110, 25);
            cell.lblRightThird.textColor = [UIColor blackColor];
            cell.lblRightThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AvailableBal)?@"":[NSString stringWithFormat:@"$%@",ChangeTocurrency([dataObj.AvailableBal floatValue]) ])];
            
                        
            return cell;
        }
            break;
        case Negative_Card_Balance_Alert:
        {
            cell.lblLeftFourth.hidden = YES;
            cell.lblLeftFirst.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            
            cell.lblLeftSecond.frame = CGRectMake(10, 0, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            cell.lblRightSecond.frame = CGRectMake(120, 0, 190, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            cell.lblLeftThird.hidden = YES;
            
            cell.lblRightThird.frame= CGRectMake(200, 25, 110, 25);
            cell.lblRightThird.textColor = [UIColor blackColor];
            cell.lblRightThird.text =[NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AvailableBal)?@"":[NSString stringWithFormat:@"$%@",ChangeTocurrency([dataObj.AvailableBal floatValue]) ])];
            
            cell.lblRightFourth.hidden = YES;
            return cell;
        }
            break;
        case Card_Transaction_Decline_Alert:    /* Card Txn Decline */
        {
            cell.lblLeftFirst.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            cell.lblLeftThird.hidden = YES;

            cell.lblLeftSecond.frame = CGRectMake(10, 0, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            cell.lblRightSecond.frame = CGRectMake(120, 0, 190, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            cell.lblRightThird.frame = CGRectMake(140, 25, 170, 25);
            cell.lblRightThird.textColor = [UIColor grayColor];
            cell.lblRightThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AlertDate)?@"":[NSString stringWithFormat:@"%@",dataObj.AlertDate])];
            
            cell.lblLeftFourth.frame = CGRectMake(10, 50, 190, 50);
            cell.lblLeftFourth.font = FONT_ARIAL_13;
            cell.lblLeftFourth.numberOfLines = 2;
            cell.lblLeftFourth.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.DeclineReason)?@"":[NSString stringWithFormat:@"%@",dataObj.DeclineReason])];
            
            cell.lblRightFourth.frame = CGRectMake(190, 50, 120, 25);
            cell.lblRightFourth.textColor = [UIColor blackColor];
            cell.lblRightFourth.text =[NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.TxnRecipentAmt)?@"":ChangeTocurrency([dataObj.strTransactinAmt floatValue]))];
            return cell;
        } 
            break;
        case enumFraudAlert:                    /* Fraud Alert */
        {
            cell.lblLeftFirst.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            cell.lblRightThird.hidden = YES;
            
            cell.lblLeftSecond.frame = CGRectMake(10, 0, 300, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            cell.lblRightSecond.frame = CGRectMake(120, 25, 190, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            cell.lblLeftThird.frame = CGRectMake(10, 25, 190, 25);
            cell.lblLeftThird.textColor = [UIColor darkGrayColor];
            cell.lblLeftThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.strBusinessAcountID)?@"":dataObj.AccountNumber)];
            
            cell.lblLeftFourth.frame = CGRectMake(10, 50, 190, 25);
            cell.lblLeftFourth.font = FONT_ARIAL_16;
            cell.lblLeftFourth.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AccountNumber)?@"":dataObj.AccountNumber)];
            
            cell.lblRightFourth.frame = CGRectMake(190, 50, 110, 25);
            cell.lblRightFourth.textColor = Status_Color_Code;
            cell.lblRightFourth.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.FraudType)?@"":dataObj.FraudType)];
            return cell;
        }
            break;
        case Card_Spend_Rules_Changed_Alert:    /* Card Spend rules changed */
        {
            cell.lblLeftFourth.hidden = YES;
            cell.lblLeftThird.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            cell.lblRightFourth.hidden = YES;
            cell.lblLeftFirst.frame = CGRectMake(10, 0, 210, 25);
            cell.lblLeftFirst.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.BAdminFirstName)?@"":dataObj.BAdminFirstName),(checkISNullStrings(dataObj.BAdminLastName)?@"":dataObj.BAdminLastName)];;
            
            cell.lblLeftSecond.frame = CGRectMake(10, 25, 140, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            cell.lblRightSecond.frame = CGRectMake(140, 25, 170, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            cell.lblRightThird.frame= CGRectMake(140, 50, 170, 25);
            cell.lblRightThird.textColor = [UIColor grayColor];
            cell.lblRightThird.text =[NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.SpendRuleUpdate)?@"":[NSString stringWithFormat:@"%@",dataObj.SpendRuleUpdate])];
            return cell;
        }
            break;
        case Funding_Rules_Changed_Alert:       /* Funding Rules Changed */
        {
            cell.lblLeftFourth.hidden = YES;
            cell.lblLeftThird.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            cell.lblRightFourth.hidden = YES;
            cell.lblLeftFirst.frame = CGRectMake(10, 0, 210, 25);
            cell.lblLeftFirst.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.BAdminFirstName)?@"":dataObj.BAdminFirstName),(checkISNullStrings(dataObj.BAdminLastName)?@"":dataObj.BAdminLastName)];;
            
            cell.lblLeftSecond.frame = CGRectMake(10, 25, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            cell.lblRightSecond.frame = CGRectMake(120, 25, 190, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            cell.lblRightThird.frame= CGRectMake(140, 50, 170, 25);
            cell.lblRightThird.textColor = [UIColor grayColor];
            cell.lblRightThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AlertDate)?@"":[NSString stringWithFormat:@"%@",dataObj.AlertDate])];
            
            return cell;
        }

            break;
        case New_card_issued_Alert:             /* New Card Issued/Reissued */
        {
            
            cell.lblLeftFourth.hidden = YES;
            cell.lblLeftThird.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            
            cell.lblLeftFirst.hidden = YES;
            cell.lblRightThird.hidden = YES;
            cell.lblLeftSecond.frame = CGRectMake(10, 25, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            cell.lblRightSecond.frame = CGRectMake(120, 25, 190, 25);
            cell.lblRightSecond.text =[NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            cell.lblRightFourth.frame = CGRectMake(190, 5, 120, 25);
            cell.lblRightFourth.textColor = Status_Color_Code;
            cell.lblRightFourth.textAlignment=UITextAlignmentRight;
            cell.lblRightFourth.text =CardStatusValue([dataObj.CardStatus intValue]);
            return cell;
        }
            break;
        case Auto_Funding_Faild_Admin:  /* Auto Funding Failed (due to admin load limit) */
        {

            cell.lblLeftFirst.hidden = YES;
            cell.lblLeftThird.hidden = YES;
//            cell.lblLeftFirst.frame = CGRectMake(10, 0, 210, 25);
//            cell.lblLeftFirst.text =  [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];;
            
            cell.lblRightFirst.frame = CGRectMake(130, 0, 180, 25);
            cell.lblRightFirst.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            cell.lblLeftSecond.frame = CGRectMake(10, 0, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            cell.lblRightSecond.frame = CGRectMake(120, 25, 190, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AlertDate)?@"":dataObj.AlertDate)];

            
//            cell.lblLeftThird.frame = CGRectMake(10, 50, 160, 25);
//            cell.lblLeftThird.textColor = [UIColor grayColor];
//            cell.lblLeftThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.EmployeeId)?@"":dataObj.EmployeeId)];
            
            cell.lblRightThird.frame= CGRectMake(200, 50, 110, 25);
            cell.lblRightThird.textColor = [UIColor blackColor];
            cell.lblRightThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.TxnRecipentAmt)?@"":ChangeTocurrency([dataObj.TxnRecipentAmt floatValue]))];
            
            cell.lblRightFourth.frame = CGRectMake(180, 75, 130, 25);
            cell.lblRightFourth.textColor = Status_Color_Code;
            cell.lblRightFourth.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.UpdatedBY)?@"":dataObj.UpdatedBY)];
            
            cell.lblRightFourth.frame = CGRectMake(180, 75, 130, 25);
            cell.lblRightFourth.textColor = Status_Color_Code;
            cell.lblRightFourth.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.UpdatedTime)?@"":dataObj.UpdatedTime)];
            return cell;
        }
            
            break;
        case High_value_transaction_Alert:  /* High Value Transaction Alert */
        {
            cell.lblLeftFirst.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            cell.lblLeftThird.hidden = YES;
            
            cell.lblLeftSecond.frame = CGRectMake(10, 0, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            cell.lblRightSecond.frame = CGRectMake(130, 0, 180, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            cell.lblRightThird.frame = CGRectMake(150, 25, 160, 25);
            cell.lblRightThird.textColor = [UIColor grayColor];
            cell.lblRightThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AlertDate)?@"":[NSString stringWithFormat:@"%@",dataObj.AlertDate])];
            
            cell.lblLeftFourth.hidden = YES;
            
            cell.lblRightFourth.frame = CGRectMake(190, 50, 120, 25);
            cell.lblRightFourth.textColor = [UIColor blackColor];
            cell.lblRightFourth.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.TxnRecipentAmt)?@"":ChangeTocurrency([dataObj.strTransactinAmt floatValue]))];

            return cell;
        }
            break;
            
        case Business_Policy_Changed:
        {
            
            cell.lblLeftFourth.hidden = YES;
            cell.lblLeftThird.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            cell.lblRightFourth.hidden = YES;
            cell.lblLeftFirst.frame = CGRectMake(10, 0, 210, 25);
            cell.lblLeftFirst.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.BAdminFirstName)?@"":dataObj.BAdminFirstName),(checkISNullStrings(dataObj.BAdminLastName)?@"":dataObj.BAdminLastName)];;
            
            cell.lblLeftSecond.hidden = YES;
            
            cell.lblRightSecond.hidden = YES;
            
            cell.lblRightThird.frame = CGRectMake(140, 25, 170, 25);
            cell.lblRightThird.textColor = [UIColor grayColor];
            cell.lblRightThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AlertDate)?@"":[NSString stringWithFormat:@"%@",dataObj.AlertDate])];
            return cell;
        }
            break;
        case Card_Profile_Updated:  /* Card Profile Update */

        {
            // This Label will display the "Business Name" of First Left Label
            cell.lblLeftFirst.frame = CGRectMake(10, 0, 300, 25);
            cell.lblLeftFirst.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.BusinessName)?@"":dataObj.BusinessName)];
            
            
            // This Label will display the "First name and Second Name" of User on Second Left Label
            cell.lblLeftSecond.frame = CGRectMake(10, 25, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName), (checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            
            // This will display the "Person Name" who updated the last in Third left Label
            cell.lblLeftThird.frame = CGRectMake(10, 50, 120, 25);
            cell.lblLeftThird.text = dataObj.UpdatedBY;
            
            
            // This label will display the "4 digit Card Number" in Second Right Label
            cell.lblRightSecond.frame = CGRectMake(120, 25, 190, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            
            // This Label will display the "Time" when it was Updated
            cell.lblRightThird.frame = CGRectMake(140, 50, 170, 25);
            cell.lblRightThird.textColor = [UIColor grayColor];
            cell.lblRightThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AlertDate)?@"":[NSString stringWithFormat:@"%@",dataObj.AlertDate])];
            
            
            cell.lblLeftFourth.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            cell.lblRightFourth.hidden = YES;
            
            return cell;
        }
    
            break;
            
      //  Cell Created for Bulk Card Request/Load
        case Bulk_Card_Request:     /* Bulk Card Request/Load */
        {
            // This   First Left Label will display the value of  "Business Name" 
            cell.lblLeftFirst.frame = CGRectMake(10, 0, 210, 25);
            cell.lblLeftFirst.text =  [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.BusinessName)?@"":dataObj.BusinessName)];
            
            // This Third Left Label will display the value of "updated by"
            cell.lblLeftSecond.frame=CGRectMake(10, 23, 190, 25);
            cell.lblLeftSecond.text=[NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.UpdatedBY)?@"":dataObj.UpdatedBY)];
         
            // This Third Right  Label will display the "Time" 
            cell.lblRightSecond.frame = CGRectMake(140, 23, 170, 25);
            cell.lblRightSecond.textColor = [UIColor grayColor];
            cell.lblRightSecond.textAlignment=UITextAlignmentRight;
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AlertDate)?@"":[NSString stringWithFormat:@"%@",dataObj.AlertDate])];
            
            cell.lblRightFirst.hidden=YES;
            cell.lblLeftThird.hidden=YES;
            cell.lblRightThird.hidden=YES;
            cell.lblLeftFourth.hidden=YES;
            cell.lblRightFourth.hidden=YES;
            return cell;
        }
          
  //  Cell Created for Low Balance on Business ,  International Card Transactions,Card_Frequency_Alert
           case Low_Balance_on_Business:    /* Low Balance on Business */
        {
            // This   First Left Label will display the value of  "Business Name"
            cell.lblLeftFirst.frame = CGRectMake(10, 13, 150, 25);
            cell.lblLeftFirst.textAlignment=UITextAlignmentLeft;
            cell.lblLeftFirst.text =  [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.BusinessName)?@"":dataObj.BusinessName)];
            // This  First Right Label will display the value of  "AvailableBal"

            cell.lblRightFirst.frame=CGRectMake(140, 13, 170, 25);
            cell.lblRightFirst.textColor = [UIColor blackColor];
            cell.lblRightFirst.textAlignment=UITextAlignmentRight;
            cell.lblRightFirst.text=[NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AvailableBal)?@"":[NSString stringWithFormat:@"$%@",ChangeTocurrency([dataObj.AvailableBal floatValue]) ])];
            cell.lblLeftSecond.hidden=YES;
            cell.lblRightSecond.hidden=YES;
            cell.lblLeftThird.hidden=YES;
            cell.lblRightThird.hidden=YES;
            cell.lblLeftFourth.hidden=YES;
            cell.lblRightFourth.hidden=YES;
            return cell;
        }
            break;
        case International_Card_Transactions:       /* International Transactions */
        {
            // This   First Left Label will display the value of  "Business Name"
            cell.lblLeftFirst.frame = CGRectMake(10, 0, 300, 25);
            cell.lblLeftFirst.text =  [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.BusinessName)?@"":dataObj.BusinessName)];
            cell.lblRightFirst.hidden=YES;
            // This Second Left Label will display the value of  "First and Last Name"
            cell.lblLeftSecond.frame = CGRectMake(10, 25, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            // This Second Right Label will display the value of  "CardNumber4Digit"
            cell.lblRightSecond.frame= CGRectMake(120, 25, 190, 25);
            cell.lblRightSecond.textAlignment=UITextAlignmentRight;
            cell.lblRightSecond.text=[NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
            cell.lblRightSecond.textAlignment=UITextAlignmentRight;
            // This Third Left Label will display the value of  "UpdatedTime"
            cell.lblLeftThird.frame = CGRectMake(10, 50, 170, 25);
            cell.lblLeftThird.textColor = [UIColor grayColor];
            cell.lblLeftThird.textAlignment=UITextAlignmentLeft;
            cell.lblLeftThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.UpdatedTime)?@"":[NSString stringWithFormat:@"%@",dataObj.UpdatedTime])];
            // This Third Right Label will display the value of  "TxnRecipentAmt"
            cell.lblRightThird.frame=CGRectMake(120, 50, 190, 25);
            cell.lblRightThird.textAlignment=UITextAlignmentRight;
            cell.lblRightThird.text=[NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.TxnRecipentAmt)?@"":ChangeTocurrency([dataObj.strTransactinAmt floatValue]))];
        // This Third Right Label will display the value of  "Country" now it will change according to the response
            cell.lblLeftFourth.frame=CGRectMake(10, 75, 170, 25);
            cell.lblLeftFourth.textColor=[UIColor blackColor];
            cell.lblLeftFourth.text=[NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.strTxnCountry)?@"":[NSString stringWithFormat:@"%@",dataObj.strTxnCountry])];
            cell.lblRightFourth.hidden=YES;
                     
            return cell;
        }
            break;
      
        case Card_Frequency_Alert:      /* Frequency Alert */
        {
        // This   First Left Label will display the value of  "Business Name"
            cell.lblLeftFirst.frame = CGRectMake(10, 0, 300, 25);
            cell.lblLeftFirst.text =  [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.BusinessName)?@"":dataObj.BusinessName)];
            cell.lblLeftSecond.frame = CGRectMake(10, 25, 140, 25);
         // This Second Left Label will display the value of  "First and Last Name"
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
        // This Second Right Label will display the value of  "CardNumber4Digit"  
            cell.lblRightSecond.frame=CGRectMake(120, 25, 190, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNumber4Digit)?@"":[NSString stringWithFormat:@"xxxx xxxx xxxx %@",dataObj.CardNumber4Digit])];
        // This Third Left Label will display the string "No. of Card Transaction"  
            cell.lblLeftThird.frame=CGRectMake(10,50, 190, 25);
            cell.lblLeftThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.TxnCountNo)?@"":dataObj.TxnCountNo)];
            cell.lblLeftThird.textAlignment=UITextAlignmentLeft;
        // This Third Right Label will display the value of  "No. of Card Transaction" it will change according to response   
//            cell.lblRightThird.frame=CGRectMake(190, 50, 120, 25);
//            cell.lblRightThird.text=@"8";
//            cell.lblRightThird.textAlignment=UITextAlignmentRight;
            cell.lblRightThird.hidden = YES;
            cell.lblRightFirst.hidden=YES;
            cell.lblLeftFourth.hidden=YES;
            cell.lblRightFourth.hidden=YES;
            
            return cell;
        }
            break;
            case Card_Pending_Activation_Alert:
        {
            cell.lblLeftFourth.hidden = YES;
            cell.lblLeftThird.hidden = YES;
            cell.lblRightFirst.hidden = YES;
            cell.lblRightFourth.hidden = YES;
            cell.lblRightThird.hidden = YES;
            cell.lblLeftFirst.frame = CGRectMake(10, 0, 300, 25);
            cell.lblLeftFirst.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.BusinessName)?@"":dataObj.BusinessName)];
            
            cell.lblLeftSecond.frame = CGRectMake(10, 25, 120, 25);
            cell.lblLeftSecond.text = [NSString stringWithFormat:@"%@ %@",(checkISNullStrings(dataObj.FirstName)?@"":dataObj.FirstName),(checkISNullStrings(dataObj.Lastname)?@"":dataObj.Lastname)];
            
            cell.lblRightSecond.frame = CGRectMake(120, 25, 190, 25);
            cell.lblRightSecond.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.CardNo)?@"":ChangeCardNumber(dataObj.CardNo))];
            
//            cell.lblRightThird.frame= CGRectMake(200, 50, 110, 25);
//            cell.lblRightThird.textColor = [UIColor blackColor];
//            cell.lblRightThird.text = [NSString stringWithFormat:@"%@",(checkISNullStrings(dataObj.AvailableBal)?@"":[NSString stringWithFormat:@"$%@",ChangeTocurrency([dataObj.AvailableBal floatValue]) ])];
            
            return cell;
        }
        default:
            return cell;
            break;
    }
}
//method use for remove popup view
-(void) removePopUpview{
    
    if (statusSelectView) {
        [statusSelectView removeFromSuperview];
        [statusSelectView release];
        statusSelectView = nil;
    }
    CardDetailClass *card = [dataArray objectAtIndex:0];
    card.isActiveButtonShow=NO;
    
    self.listTableView.separatorColor=[UIColor clearColor];
    [self.listTableView reloadData];

    
}

-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index
{
    newCardStatus=index;
    showAlertWithOtherButtons(nil,languageSelectedStringForKey(@"Do you want to change the Status ?") , alert_change_card_status, self);
    
}

-(NSString *) makeXMLForReadAlert :(int)recordNumber
{
    AlertDetailSearchClass *adsc = [dataArray objectAtIndex:recordNumber];/**/
    NSString *strXMLString = [NSString stringWithFormat:@"<AlertRead_Req><FLAG>%@</FLAG><CardNo>0</CardNo><AlertType>%d</AlertType><ReadDelete_AlertSetup><List_AlertRead><AlertID>%@</AlertID></List_AlertRead></ReadDelete_AlertSetup></AlertRead_Req>",READFLAG,alertType,adsc.strAlertId];
    return strXMLString;
}

-(NSString *) makeXMLForDeleteAlert :(int)recordNumber
{
    AlertDetailSearchClass *adsc = [dataArray objectAtIndex:recordNumber];/**/
    NSString *strXMLString = [NSString stringWithFormat:@"<AlertRead_Req><FLAG>%@</FLAG><CardNo>0</CardNo><AlertType>%d</AlertType><ReadDelete_AlertSetup><List_AlertRead><AlertID>%@</AlertID></List_AlertRead></ReadDelete_AlertSetup></AlertRead_Req>",DELETEFLAG,alertType,adsc.strAlertId];
    return strXMLString;
}

#pragma mark - Request & Response method
//method use for send request
-(void)getRequest :(int)selectedRecord
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    switch (requestID)
    {
        case alert_transfer_list:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=ViewTransferDetail_Request;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deBABussinessAccAcctId=&deProductid=%@&deTCIVRNOOFTRANSACTIONS=&deTCIVRLASTTRANSACTION=&deBAOriginSource=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.BusinessName,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBAViewTransferDetail];
        }
            break;
        case alert_Bank_list:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=GetExternal_Bank_list;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deBABussinessAccAcctId=%@&deBABussinessAccountNum=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,strBussAccountID,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBAExternalBankList];
        }
            break;
        case alert_change_card_status:
        {
            [self changeCardStatus:requestID];
        }
            break;
        case alert_Frquency_Request:
        {
            int BatchSize=50;

            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            [SystemConfiguration sharedSystemConfig].dbbServiceName=TransactionHistory_Request;
            [SystemConfiguration sharedSystemConfig].deCIASTxnFilter=@"0";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deCIAClientID=%@&deCIAAccountNumber=%@&deANAProductID=%@&deCIASFromDate=&deCIASToDate=&deCIASTxnFilter=%@&deCIASTxnBatchSize=%@&deCIASTxnPageIndex=0&de_TranId_TH=&deCIASTxnHistoryType=0&deCIAMaximumTxnAmount=&deCIAminimumTxnAmount=&deCIAMerchantSearch=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,objCardDetailClass.CLIENTID,objCardDetailClass.ACCOUNTNUMBER,objCardDetailClass.PRODUCTID,[SystemConfiguration sharedSystemConfig].deCIASTxnFilter,[NSString stringWithFormat:@"%d",BatchSize],[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCHTransactionHistory];
            
        }
            break;
        case alertCardPendingActivation:
            [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=&deBsAccountNumber=%@&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=&deBusinessName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,strAccountNumber,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBACardHolderList];
            break;
        case alertCardProfileUpdate:
            [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=&deBsAccountNumber=%@&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=&deBusinessName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,strAccountNumber,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBACardHolderList];
            break;
        case alertFrequency: /* For the Frequency Alert */
            [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=&deBsAccountNumber=%@&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=&deBusinessName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,strAccountNumber,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBACardHolderList];
            break;
        case alertReadAlert:
        {
            NSString *strXMLRequest = [self makeXMLForReadAlert:selectedRecord];
            selectedAlert=selectedRecord;
            [SystemConfiguration sharedSystemConfig].dbbServiceName=alertReadDeleteService;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deAlertRead_ResponseMSG=%@",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,strXMLRequest]ServiceName:svcAlertRead];
        }
            break;
        case alertDeleteAlert:
        {
            NSString *strXMLRequest = [self makeXMLForDeleteAlert:selectedRecord];
            
            selectedAlert=selectedRecord;
            [SystemConfiguration sharedSystemConfig].dbbServiceName=alertReadDeleteService;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deAlertRead_ResponseMSG=%@",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,strXMLRequest]ServiceName:svcAlertRead];
        }
            break;
        default:
            break;
    }
    [DataReq release];
}
// method use for got responce from the server
-(void)getResponce:(id)jsonData
{
    switch (requestID)
    {
        case alert_transfer_list:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]==0)
                {
                    //                    showAlertScreen(nil, @"No record Found");
                }else
                {
                    if (![AppDelegate sharedAppDelegate].Arraytransfer) {
                        [AppDelegate sharedAppDelegate].Arraytransfer=[[NSMutableArray alloc]init];
                    }else
                    {
                        [[AppDelegate sharedAppDelegate].Arraytransfer removeAllObjects];
                    }
                    
                    [AppDelegate sharedAppDelegate].Arraytransfer=jsonData;
                    
                }
            }
            //            [AdminAccessInfo AdminAcess].viewTransferValue = 0;
            
            TransferViewController *tvc = [[TransferViewController alloc] initWithNibName:@"TransferViewController" bundle:nil];
            
            /* Assigning indicator to tell from where TransferViewController has been navigated*/
            tvc.strLastViewCtrl = @"AlertView";
            [self.navigationController pushViewController:tvc animated:YES];
            [tvc release];
            
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case alert_Bank_list:
        {
            
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]==0)
                {
                    //                    showAlertScreen(nil, @"No record Found");
                }else
                {
                    if (![AppDelegate sharedAppDelegate].ArraybankList) {
                        [AppDelegate sharedAppDelegate].ArraybankList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [[AppDelegate sharedAppDelegate].ArraybankList removeAllObjects];
                    }
                    
                    [AppDelegate sharedAppDelegate].ArraybankList=jsonData;
                    
                }
            }else
            {
                //                showAlertScreen(nil, jsonData);
            }
            
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
            requestID=transfer_list;
            
            [self getRequest :-1];
            
        }
            break;
        case alert_change_card_status:
        {
            LoginResponceDataClass *dataObj=(LoginResponceDataClass *)jsonData;
            
            if (dataObj.Error_Found)
            {
                showAlertScreen(nil, dataObj.ErrorMsg);
            }else
            {
                CardDetailClass *card = [dataArray objectAtIndex:selectedIndex];
                
                card.STATUS_CARDACCOUNT=newCardStatus;
                
                _listTableView.separatorColor=[UIColor clearColor];
                showAlertScreen(nil, dataObj.ErrorMsg);
                [dataArray replaceObjectAtIndex:selectedIndex withObject:card];
            }
            
            [self.listTableView reloadData];
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
        }
            break;
        case alert_Frquency_Request:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {

                    TransactionViewController *objTransactionViewController = [[TransactionViewController alloc] initWithNibName:@"TransactionViewController" bundle:nil trasactionData:jsonData isAlertRequest:YES objectOfCardDetailClass:objCardDetailClass navigatedFrom:@"AlertView"];
                    
                    [self.navigationController pushViewController:objTransactionViewController animated:YES];
                    [objTransactionViewController release];
                }else
                {
                    showAlertScreen(@"No Records", @"There is no record found.");
                }
                
                
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case alertCardPendingActivation:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    if (![AppDelegate sharedAppDelegate].arrCardDetailArray)
                    {
                        [AppDelegate sharedAppDelegate].arrCardDetailArray = [[NSMutableArray alloc] init];
                    }
                    else
                    {
                        [[AppDelegate sharedAppDelegate].arrCardDetailArray removeAllObjects];
                    }
//                    [AppDelegate sharedAppDelegate].arrCardDetailArray = jsonData;
                    pendingAlertViewCntroller *clvc = [[pendingAlertViewCntroller alloc] initWithNibName:@"pendingAlertViewCntroller" bundle:nil dataArray:jsonData];
                    [self.navigationController pushViewController:clvc animated:YES];
                    [clvc release];
                }else
                {
                    showAlertScreen(@"No Records", @"There is no card Available for the Account.");
                }
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case alertCardProfileUpdate:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    objCardDetailClass = (CardDetailClass *)[jsonData objectAtIndex:0];
                    if (objCardDetailClass != nil)
                    {
                        UserProfileViewController *objUserProfileViewCtrl = [[UserProfileViewController alloc] initWithNibName:@"UserProfileViewController" bundle:nil CardDetailClassObject:objCardDetailClass navigatedFrom:@"AlertView"];
                        [self.navigationController pushViewController:objUserProfileViewCtrl animated:YES];
                        
                        [objUserProfileViewCtrl release];
                        
                    }
                }else
                {
                    showAlertScreen(@"No Records", @"There is no card Available for the Account.");
                }
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case alertFrequency:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    objCardDetailClass = (CardDetailClass *)[jsonData objectAtIndex:0];
                    if (objCardDetailClass != nil)
                    {
                        requestID = alert_Frquency_Request;
                        [self getRequest:-1];
                    }
                }else
                {
                    showAlertScreen(@"No Records", @"There is no card Available for the Account.");
                }
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            
        }
            break;
        case alertReadAlert:
        {
            
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
            alertBottomViewNumber = -1;
            
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                LoginResponceDataClass *responseClass = (LoginResponceDataClass *)jsonData;
                if (responseClass.Error_Code == 1)
                {
                    AlertDetailSearchClass *adsc = [dataArray objectAtIndex:selectedAlert];
                    
                    adsc.AlertStatus= ALERTSTATUSREAD;
                    [dataArray replaceObjectAtIndex:selectedAlert withObject:adsc];
                }
                showAlertScreen(nil, responseClass.ErrorMsg);
            }
            [self.listTableView reloadData];
        }
            break;
        case alertDeleteAlert:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
            alertBottomViewNumber = -1;
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                LoginResponceDataClass *responseClass = (LoginResponceDataClass *)jsonData;
                showAlertScreen(nil, responseClass.ErrorMsg);
                if (responseClass.Error_Code == 1)
                {
                    [dataArray removeObjectAtIndex:selectedAlert];
                }
            }
            [self.listTableView reloadData];
        }
            break;
        case alertListCount:
        {
                if ([jsonData isKindOfClass:[NSArray class]])
                {
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"WineDetailsStoreLocation" object:jsonData];
                }
            [self.navigationController popViewControllerAnimated:YES];
        }
            break;
            case Mark_All_Read_Alert:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
            alertBottomViewNumber = -1;
            
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                LoginResponceDataClass *responseClass = (LoginResponceDataClass *)jsonData;
                if (responseClass.Error_Code == 1)
                {
                    for (int i=0; i<[dataArray count]; i++)
                    {
                        AlertDetailSearchClass *adsc = [dataArray objectAtIndex:i];
                        
                        adsc.AlertStatus= ALERTSTATUSREAD;
                        [dataArray replaceObjectAtIndex:i withObject:adsc];

                    }
                }
                showAlertScreen(nil, responseClass.ErrorMsg);
            }
            [self.listTableView reloadData];

        }
            break;
            case Mark_ALL_Delete_Alert:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
            alertBottomViewNumber = -1;
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                LoginResponceDataClass *responseClass = (LoginResponceDataClass *)jsonData;
                showAlertScreen(nil, responseClass.ErrorMsg);
                if (responseClass.Error_Code == 1)
                {
                    [dataArray removeAllObjects];
                }
            }
            [self.listTableView reloadData];
        }
            break;
        default:
            break;
    }
}

#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    switch (alertView.tag) {
        case alertReadAlert:
            if (buttonIndex==0)
            {
                [self callReadDeleteAlert:alertNumber];
            }else
            {
                
                alertBottomViewNumber = -1;
                [self.listTableView reloadData];
            }

            break;
        case alertDeleteAlert:
            if (buttonIndex==0)
            {
                [self callReadDeleteAlert:alertNumber];
            }else
            {
                alertBottomViewNumber = -1;
                
                [self.listTableView reloadData];
            }

            break;
        case alert_change_card_status:
        {
            if (buttonIndex==0)
            {
                [self changeCardStatus:newCardStatus];
            }else
            {
                [self removePopUpview];
            }
        }
            break;
            
        default:
            break;
    }
    
}


-(void)getAlertListCount
{
    requestID=alertListCount;
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;

    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=ALERT_COUNT_REQUEST;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPAdminPortalClientID=&deAlertUserID=%@&deAlertDirection=2&deAlertType=&deAlertDate=&deAlertActionDate=&deAlertStatus=NEW&deRFCount=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:SvcALViewAlertMsgCountAction];
     [DataReq release];
}

//method use for change status of  Card
-(void)changeCardStatus :(int)chagedStatus
{
    [self removePopUpview];
    requestID=alert_change_card_status;
    newCardStatus=chagedStatus;
    
    CardDetailClass *card = [dataArray objectAtIndex:selectedIndex];
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
        [SystemConfiguration sharedSystemConfig].dbbServiceName=CARD_ACTIVE_REQUEST;
        
        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deTCIVRPrimaryAccountNumber=%@&deTCIVRCardRegistrationFirstName=&deTCIVRCardRegistrationMiddleName=&deTCIVRCardRegistrationLastName=&deTCIVRCardRegistrationAddress1=&deTCIVRCardRegistrationAddress2=&deTCIVRCardActivationEmail1=&deTCIVRCardActivationHomePhone=&deTCIVRCardActivationWorkPhone=&deTCIVRCardActivationPostalCode=&deTCIVRCardActivationBirthDate=&deTCIVRCardActivationLangIndiactor=&deTCIVRCardActivationSocialSecurity=&deTCIVRCardActivationCardExpirDate=&deTCIVRCardActivationCurrentPin=&deTCIVRCardActivationCurrentAccess=&deTCIVRCardActivationNewPin=&deTCIVRCardActivationNewAccess=&deTCIVRCardActivationLast4DigitsSSN=&deTCIVRCardActivationCVV=&deTCIVRCardActivationBirthYear=&deTCIVRCardActivationIdentification=&deTCIVRANI=&deTCIVRDNS=&deTCIVRInputLang=&deIVRSource=%@&deIVRIpAddress=&deIVRCallerId=&deIVRCalledId=&deIVRRequestTime=&deIVRSessionID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,card.CARDNUMBER,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCardActivationActivateCard];
        
    [DataReq release];
}



// method use for create popup view for change status
-(void)openStatusView:(int)index
{
    selectedIndex=index;
    CardDetailClass *card = [dataArray objectAtIndex:selectedIndex];
    
    
        statusSelectView = [[UIView alloc] initWithFrame:self.view.frame];
        statusSelectView.backgroundColor = [UIColor clearColor];
        
        [self.view addSubview:statusSelectView];
        
        PopUpView *csv = [[PopUpView alloc] initWithPopViewFrame:CGRectMake(0, 0, 320, 480) CardData:card Delegate:self];
        
        [statusSelectView addSubview:csv];
        [csv release];
    
}
// Method to remove the status view.
-(void)removeChangeStatusView
{
    [self removeStatusView];
}
//method use for remove status view
-(void) removeStatusView{
    if (statusSelectView) {
        [statusSelectView removeFromSuperview];
        statusSelectView = nil;
    }
    CardDetailClass *card = [dataArray objectAtIndex:selectedIndex];
    card.isActiveButtonShow=NO;
    
    [self.listTableView reloadData];

}

/* Method will be fire when user tapped on Read Button in Alert */
-(void) tappedRead:(UIButton *)paramSender
{
    UIButton *tmp=(UIButton *)paramSender;
    NSLog(@"Read Button Tapped");
    requestID = alertReadAlert;
     alertNumber=tmp.tag;
    showAlertWithOtherButtons(@"", @"Do you want to mark alert as Read ?", alertReadAlert, self);
}

/* Method will be fire when user tapped on Delete Button in Alert */
-(void) tappedDelete:(UIButton *)paramSender
{
    UIButton *tmp=(UIButton *)paramSender;
    NSLog(@"Delete Button Tapped");
    requestID = alertDeleteAlert;
    alertNumber=tmp.tag;
    showAlertWithOtherButtons(@"", @"Do you want to delete alert ?", alertDeleteAlert, self);
}


-(void)callReadDeleteAlert :(int)tag
{
    [self getRequest:tag];
}

-(void) methodBtnOpenBottomView:(UIButton *)paramSender
{
    UIButton *tmp=(UIButton *)paramSender;

//    if (alertType == Card_Pending_Activation_Alert)
//    {
//        NSLog(@"button clicked");
//    }
//    else
//    {
        if (alertBottomViewNumber == tmp.tag)
        {
            alertBottomViewNumber = -1;
        }else
        {
          alertBottomViewNumber=tmp.tag;  
        }
        
        [self.listTableView reloadData];
        
//    }
    
}

#pragma mark- Table View Delegates
// Delegate method called when the row selects.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
       switch (alertType)
    {
        case Card_Pending_Activation_Alert:
        {
            /* if Alert Type is 18 is Card Pending Activation   */
            /* than we have to move to Card List page           */
            AlertDetailSearchClass *objAlertDetailSearchClass = (AlertDetailSearchClass *)[dataArray objectAtIndex:indexPath.row];
            strAccountNumber = objAlertDetailSearchClass.AccountNumber;
            requestID = alertCardPendingActivation;
            [self getRequest:-1];
        }
            break;
        case Auto_Funding_Faild_Alert:
        {
            if ([AdminAccessInfo AdminAcess].initiateTransferValue == INITIATETRANSFER)
            {            
                AlertDetailSearchClass *objAlertDetailSearchClass = (AlertDetailSearchClass *)[dataArray objectAtIndex:indexPath.row];
                strBussAccountID = objAlertDetailSearchClass.strBusinessAcountID;
                requestID = alert_Bank_list;
                [self getRequest:-1];
            }
        }
            break;
        case Low_Balance_Cards_Alert:
        {
            AlertDetailSearchClass *objAlertDetailSearchClass = (AlertDetailSearchClass *)[dataArray objectAtIndex:indexPath.row];
            strBussAccountID = objAlertDetailSearchClass.strBusinessAcountID;
            requestID = alert_Bank_list;
            [self getRequest:-1];
        }
            break;
        case Low_Balance_on_Business:
        {
            AlertDetailSearchClass *objAlertDetailSearchClass = (AlertDetailSearchClass *)[dataArray objectAtIndex:indexPath.row];
            strBussAccountID = objAlertDetailSearchClass.strBusinessAcountID;
            requestID = alert_Bank_list;
            [self getRequest:-1];
        }
            break;
        case Negative_Card_Balance_Alert:
  
            break;
        case Card_Transaction_Decline_Alert:
            break;

        case Card_Spend_Rules_Changed_Alert:
            break;
        case Funding_Rules_Changed_Alert:
            break;
        case Card_Frequency_Alert:
        {
            /*  */
            AlertDetailSearchClass *objAlertDetailSearchClass = (AlertDetailSearchClass *)[dataArray objectAtIndex:indexPath.row];
            strAccountNumber = objAlertDetailSearchClass.AccountNumber;
            requestID = alertFrequency;
            [self getRequest:-1];
        }
            break;
        case New_card_issued_Alert:
        {
            AlertDetailSearchClass *objAlertDetailSearchClass = (AlertDetailSearchClass *)[dataArray objectAtIndex:indexPath.row];
            strAccountNumber = objAlertDetailSearchClass.AccountNumber;
            requestID = alertCardProfileUpdate;
            [self getRequest:-1];
        }
            break;
        case Auto_Funding_Faild_Admin:
            break;
        case High_value_transaction_Alert:
            break;
        case Business_Policy_Changed:
            break;
        /* We have to move to Card Profile(User Profile) Page */
        case Card_Profile_Updated:
        {
            AlertDetailSearchClass *objAlertDetailSearchClass = (AlertDetailSearchClass *)[dataArray objectAtIndex:indexPath.row];
            strAccountNumber = objAlertDetailSearchClass.AccountNumber;
            requestID = alertCardProfileUpdate;
            [self getRequest:-1];
        }
            break;
        case Bulk_Card_Request:
            break;
        case International_Card_Transactions:
            break;
//        case Card_Frequency_Alert:
//            requestID = alert_Frquency_Request;
//            [self getRequest];
           break;
        default:
            break;
    }
    
}
// Delegate method to set the number of sections in table.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
// Delegate method to set the height of the cell.
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    fImageheight = [self setHeightofRow];

    if (indexPath.row == alertBottomViewNumber)
    {
        return fImageheight + 36;
    }
    else
    {
        return fImageheight;
    }    
}



// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [dataArray count];
}
// Delegate method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    /* This will only work for Card Pending Activation Alert */
//	if (alertType == Card_Pending_Activation_Alert)
//    {
//        CardDataCell *cell = (CardDataCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//        if (cell==nil) {
//            cell = [[[CardDataCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier Delegate:self imageHeight:fImageheight] autorelease];
//        }
//        CardDetailClass *cardObj;
//        //set the cell background color in alert subcategory detail view
//        if (alertColorIdentifier==RedAlert)
//        {
//            cell.imgBackGround.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"img_AlertRed_BG_Unread"]];
//        }else if (alertColorIdentifier==AmberAlert)
//        {
//            cell.imgBackGround.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"img_AlertAmber_BG_Unread"]];
//        }else if (alertColorIdentifier==GreenAlert)
//        {
//            cell.imgBackGround.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"img_AlertGreen_BG_Unread"]];//; setImage:[UIImage imageNamed:@"img_AlertGreen_BG"]];
//        }
//        
//        cardObj =(CardDetailClass *)[dataArray objectAtIndex:indexPath.row];
//        
//        cell.lblTitleName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings(cardObj.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@. ",cardObj.FIRSTNAME],checkISNullStrings(cardObj.LASTNAME)?@"":[NSString stringWithFormat:@"%@ ",cardObj.LASTNAME]];
//        
//        cell.lblCardNumber.text=[NSString stringWithFormat:@"%@",ChangeCardNumber(cardObj.CARDNUMBER)];
//        
//        cell.btnView.frame=CGRectMake(10, CGRectGetMaxY(cell.lblCardNumber.frame), 7, 13);
//        cell.btnView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"imgStatusInactive"]];
//        
//        cell.imgArrow.hidden = YES;
//        cell.lblStatus.text=CardStatusValue(cardObj.STATUS_CARDACCOUNT);
//        
//        cell.btnState.tag=indexPath.row;
//        cell.lblAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(cardObj.AVAILABLEBALANCE))];
//       
//                
//        if (cardObj.STATUS_CARDACCOUNT == ACTIVE_CARD) {
//            cell.btnState.enabled = NO;
//        }
//        
//        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
//        
//        /*
//         if index value is 114 then user can change the status else Not able to change the status and status option is dissable.
//         */
//        if ([AdminAccessInfo AdminAcess].updateCard == UPDATECARD)
//        {
//            /* If card status is Close, Stolen or Lost*/
//            if (cardObj.STATUS_CARDACCOUNT==Closed_CARD || cardObj.STATUS_CARDACCOUNT==Stolen_CARD || cardObj.STATUS_CARDACCOUNT==Lost_CARD )
//            {
//                cell.btnState.enabled=NO;
//                cell.btnView.hidden = YES;
//                cell.lblStatus.frame = CGRectMake(10, cell.lblStatus.frame.origin.y, cell.lblStatus.frame.size.width, cell.lblStatus.frame.size.height);
//            }else
//            {
//                cell.btnState.enabled=YES;
//            }
//        }
//        else
//        {
//            cell.btnState.enabled = NO;
//            cell.btnView.hidden = YES;
//            cell.lblStatus.frame = CGRectMake(10, cell.lblStatus.frame.origin.y, cell.lblStatus.frame.size.width, cell.lblStatus.frame.size.height);
//        }
////        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
//
//        return cell;
//    }
//    
//    /* For remaining of the alerts data will be shown from this */
//    else
//    {
//	
        AlertDetailViewCell *cell = (AlertDetailViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[[AlertDetailViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier imageHeight:fImageheight delegate:self] autorelease];
        }
        //set the cell background color in alert subcategory detail view
    
        
        AlertDetailSearchClass *adsc = [dataArray objectAtIndex:indexPath.row];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        if (alertColorIdentifier==RedAlert)
        {
            cell.imgBackGround.backgroundColor =([adsc.AlertStatus isEqualToString: ALERTSTATUSREAD]?[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_AlertRed_BG"]]:[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_AlertRed_BG_Unread"]]) ;
        }
        else if (alertColorIdentifier==AmberAlert)
        {
            cell.imgBackGround.backgroundColor=([adsc.AlertStatus isEqualToString: ALERTSTATUSREAD]?[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_AlertAmber_BG"]]:[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_AlertAmber_BG_Unread"]]);
        }
        else if (alertColorIdentifier==GreenAlert)
        {
            cell.imgBackGround.backgroundColor=([adsc.AlertStatus isEqualToString: ALERTSTATUSREAD]?[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_AlertGreen_BG"]]:[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_AlertGreen_BG_Unread"]]);
        }
        
        cell.btnRead.tag=indexPath.row;
        cell.btnDelete.tag=indexPath.row;
        cell.btnOpenBottomView.tag=indexPath.row;

        
        if (alertBottomViewNumber == indexPath.row)
        {
           cell.viewCellBottom.hidden = NO; 
        }else
        {
            cell.viewCellBottom.hidden = YES;
        }
        
        return [self initializeTableViewCell:cell AlertDetailSearchObj:adsc];
//    }
    
}
 @end
