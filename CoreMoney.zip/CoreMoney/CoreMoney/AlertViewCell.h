//
//  AlertViewCell.h
//  CoreMoney
// class use for create cell for alert view
#import <UIKit/UIKit.h>

@interface AlertViewCell : UITableViewCell
{
    UILabel *lblAlertName,*lblAlertCount;
    UIImageView *imgView;
}
@property (nonatomic,retain) UILabel *lblAlertName,*lblAlertCount;
@property (nonatomic,retain)UIImageView *imgView;
@end
