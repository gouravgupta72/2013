//
//  SubCategoryDataClass.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface SubCategoryDataClass : NSObject
{
    NSString *EXPCAT_VALUE;
    int EXPCAT_VALUE_ID, EXPCAT_STATUS, EXPCAT_UPD;
}
@property (nonatomic,retain)NSString *EXPCAT_VALUE;
@property  int EXPCAT_VALUE_ID, EXPCAT_STATUS, EXPCAT_UPD;
@end
