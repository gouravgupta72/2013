//
//  AdminListCell.h
//  CoreMoney
//
// class use for fill entry into admin table view cell

#import <UIKit/UIKit.h>

@interface AdminListCell : UITableViewCell
{
    UILabel *lblTitleName,*lblCardNumber,*lblStatus,*lblAmount;
    UIButton *btnState,*btnView;
    id delegate;
}
@property(nonatomic, assign)id delegate;

@property(nonatomic, retain) UILabel *lblTitleName,*lblCardNumber,*lblStatus,*lblAmount;
@property(nonatomic, retain) UIButton *btnState,*btnView;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del;
-(void)openStatusView:(int)index;
@end


