//
//  ReplaceCardData.m
//  CoreMoney


#import "ReplaceCardData.h"

@implementation ReplaceCardData
@synthesize CARDNUMBER,ResCode,ResErrorMsg,ResErrorCode;
@end
