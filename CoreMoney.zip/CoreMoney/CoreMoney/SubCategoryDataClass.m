//
//  SubCategoryDataClass.m
//  CoreMoney

#import "SubCategoryDataClass.h"

@implementation SubCategoryDataClass
@synthesize EXPCAT_VALUE,EXPCAT_VALUE_ID, EXPCAT_STATUS, EXPCAT_UPD;

-(void)dealloc
{
    self.EXPCAT_VALUE=nil;
    [super dealloc];
}
@end
