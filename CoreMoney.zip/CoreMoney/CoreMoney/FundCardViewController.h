//
//  FundCardViewController.h
//  CoreMoney
// Class used for create Fund View
#import <UIKit/UIKit.h>
#import "CardDetailClass.h"
#import "CustomScrollView.h"
#import "DataParsingClass.h"

@interface FundCardViewController : SwipeViewController<ScrollDelegate,DataParsingDelegate>
{
    CardDetailClass *cardDataObj;
    float totalBal;
    BOOL isAddViewShow;
    int Ammount;
    int request_Id;
}

@property (retain , nonatomic) CardDetailClass *cardDataObj;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil CardData:(CardDetailClass *) carddata;

@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (retain, nonatomic) IBOutlet UILabel *lblTopMsgView;
@property (retain, nonatomic) IBOutlet UIView *addFundView;
@property (retain, nonatomic) IBOutlet UIView *addBtnView;
@property (retain, nonatomic) IBOutlet UIView *removeBtnView;
@property (retain, nonatomic) IBOutlet UILabel *lblRemoveBal;
@property (retain, nonatomic) IBOutlet UILabel *lblAddBal;
@property (retain, nonatomic) IBOutlet UILabel *lblUserName;
@property (retain, nonatomic) IBOutlet UILabel *lblCardNumber;
@property (retain, nonatomic) IBOutlet UILabel *lblStatus;
@property (retain, nonatomic) IBOutlet UILabel *lblNewBalMsg;
@property (retain, nonatomic) IBOutlet UILabel *lblTotalBalatAddView;
@property (retain, nonatomic) IBOutlet UILabel *lblBalance;
@property (retain, nonatomic) IBOutlet UILabel *lblAmountMsg;
@property (retain, nonatomic) IBOutlet UITextField *txtAddBal;
@property (retain, nonatomic) IBOutlet UIButton *btnRemoveamount;
@property (retain, nonatomic) IBOutlet CustomScrollView *pageScroll;
@property (retain, nonatomic) IBOutlet UIButton *btnOutSideTouch;
@property (retain, nonatomic) IBOutlet UITextView *lblTxtAvailBal;
@property (retain, nonatomic) IBOutlet UIButton *btnAddAmt;
- (IBAction)clickedBtnOutsideTouch:(id)sender;

@end
