//
//  MemoDataClass.m
//  CoreMoney

#import "MemoDataClass.h"

@implementation MemoDataClass
@synthesize ACCOUNTNUMBER, CATEGORY_ID, CATEGORY_LABEL, CATEGORY_TYPE, COMMENT, CREATIONDATE, CREATIONTIME, Captured_By, EXPCAT_VALUE, EXPCAT_VALUE_ID, FIRSTNAME, LASTNAME, MemoReason, MemoTranID, ReasonType, RoleType, Source, UNIQUEID, UserName, View_Access;

@synthesize Delete_Access, Edit_Access;

-(void)dealloc
{
    self.ACCOUNTNUMBER=nil;
    self.CATEGORY_ID=nil;
    self.CATEGORY_LABEL=nil;
    self.CATEGORY_TYPE=nil;
    self.COMMENT=nil;
    self.CREATIONDATE=nil;
    self.CREATIONTIME=nil;
    self.Captured_By=nil;
    self.EXPCAT_VALUE=nil;
    self.EXPCAT_VALUE_ID=nil;
    self.FIRSTNAME=nil;
    self.LASTNAME=nil;
    self.MemoReason=nil;
    self.MemoTranID=nil;
    self.ReasonType=nil;
    self.RoleType=nil;
    self.Source=nil;
    self.UNIQUEID=nil;
    self.UserName=nil;
    
    [super dealloc];
}
@end
