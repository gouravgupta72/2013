//
//  secretQustionDataClass.h
//  CoreMoney

#import <Foundation/Foundation.h>

@interface secretQustionDataClass : NSObject
{
    NSString *secretQuestion,*indexNo;
}
@property(nonatomic,retain)NSString *secretQuestion, *indexNo;
@end
