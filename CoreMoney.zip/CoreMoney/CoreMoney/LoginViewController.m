 //
//  LoginViewController.m

//  class user for login view
#import "LoginViewController.h"
#import "RegistrationViewController.h"
#import "HelpMenu.h"
#import "HomeViewController.h"
#import "ForgetUserIDViewController.h"
#import "ForgotPasswordViewController.h"
#import "AlertsDetailViewController.h"
//#import "ExpenseRulesViewController.h"

@interface LoginViewController ()

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(void) changeTextIntoselectLang;
-(void) changeLaguageAtlogin;
-(void)logIn;
-(void) setOfset;
-(void)getResponce:(id)jsonData;
-(void)loginRequest;

- (BOOL)validatePasswordString:(NSString*)psswrd;
- (BOOL)validateEmailAndPassword;
-(void)createResetPassword;

- (IBAction)clickedRegisterBtn:(id)sender;
- (IBAction)clickedLoginBtn:(id)sender;
- (IBAction)cleckedForgotUserBtn:(id)sender;
-(void)RegisterNewDevice;
@end

@implementation LoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [[AdminAccessInfo AdminAcess] resetPeremission];
    [AppDelegate sharedAppDelegate].classType = LOGIN_PAGE;
    HelpMenu *obj=[[HelpMenu alloc]initWithFrame:CGRectMake(0,420, 320, 51)];
    obj.delegatelogin = self;
    [self.view addSubview:obj];
    [obj release];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void) viewWillAppear:(BOOL)animated
{
    [AppDelegate sharedAppDelegate].classType = LOGIN_PAGE;
    [self.navigationController setNavigationBarHidden:YES];
    
    self.txtPassword.text=@"";
    
    [self changeTextIntoselectLang];
    

    [self resetData];
}

-(void)resetData
{
    if ([AppDelegate sharedAppDelegate].arrBusinessData) {
        [[AppDelegate sharedAppDelegate].arrBusinessData removeAllObjects];
        [[AppDelegate sharedAppDelegate].arrBusinessData release];
        [AppDelegate sharedAppDelegate].arrBusinessData=nil;
        
    }
    if ([AppDelegate sharedAppDelegate].arrCardDetailArray) {
        [[AppDelegate sharedAppDelegate].arrCardDetailArray removeAllObjects];
        [[AppDelegate sharedAppDelegate].arrCardDetailArray release];
        [AppDelegate sharedAppDelegate].arrCardDetailArray=nil;
        
    }
    if ([AppDelegate sharedAppDelegate].ArraybankList) {
        [[AppDelegate sharedAppDelegate].ArraybankList removeAllObjects];
        [[AppDelegate sharedAppDelegate].ArraybankList release];
        [AppDelegate sharedAppDelegate].ArraybankList=nil;
        
    }
    if ([AppDelegate sharedAppDelegate].ArrayAdmin) {
        [[AppDelegate sharedAppDelegate].ArrayAdmin removeAllObjects];
        [[AppDelegate sharedAppDelegate].ArrayAdmin release];
        [AppDelegate sharedAppDelegate].ArrayAdmin=nil;
        
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_txtUserName release];
    [_txtPassword release];
    [_btnLogin release];
    [_btnRegister release];
    
    [_pageScroll release];
    [_lblForgotPwd release];
    [_lblForgotUserId release];
    [_btnForgotUserClick release];
    [_imgVLineUserId release];
    [_imgVPwdLine release];
    [_btnForgotPassword release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setTxtUserName:nil];
    [self setTxtPassword:nil];
    [self setBtnLogin:nil];
    [self setBtnRegister:nil];
    
    [self setPageScroll:nil];
    [self setLblForgotPwd:nil];
    [self setLblForgotUserId:nil];
    [self setBtnForgotUserClick:nil];
    [self setImgVLineUserId:nil];
    [self setImgVPwdLine:nil];
    [self setBtnForgotPassword:nil];
    [super viewDidUnload];
}
// Method use for initializing labels and textfield in select language
-(void) changeTextIntoselectLang
{
    self.txtUserName.placeholder = languageSelectedStringForKey(@"user_name");
  
    self.txtPassword.placeholder = languageSelectedStringForKey(@"password");
   
    [self.btnLogin setTitle:languageSelectedStringForKey(@"login") forState:UIControlStateNormal];
   
    [self.btnRegister setTitle:languageSelectedStringForKey(@"register") forState:UIControlStateNormal];

    
    
    [self.btnForgotUserClick setTitle:languageSelectedStringForKey(@"Forgot User ID") forState:UIControlStateNormal];
    
    if ([[NSUserDefaults standardUserDefaults] integerForKey:@"applicationLanguage"]==1) {
        self.imgVPwdLine.frame = CGRectMake(68,240 ,102 ,1 );
        self.imgVLineUserId.frame = CGRectMake(124+19,238 ,85 ,1 );
    }
    else{
        self.imgVPwdLine.frame = CGRectMake(0+8,238 ,108 ,1 );
        self.imgVLineUserId.frame = CGRectMake(124+12,238 ,100 ,1 );
    }
}

// delegate method of help menu
-(void) changeLaguageAtlogin{

    [self changeTextIntoselectLang];
}
// add loading view and call loginRequest method
-(void)logIn
{
    [self.txtPassword resignFirstResponder];
    [self.txtUserName resignFirstResponder];
    
    ReqID=Login_Req;
    
    if (self.txtUserName.text.length == 0)
    {
        showAlertScreen(languageSelectedStringForKey(@"User Id") , languageSelectedStringForKey(@"User Id should not be blank"));

       
    }
    else  if (self.txtPassword.text.length == 0)
    {
         showAlertScreen(languageSelectedStringForKey(@"Password") , languageSelectedStringForKey(@"Password should not be blank"));
    }else
    {
        [[AppDelegate sharedAppDelegate] addLoginLoadingView];
        [self performSelector:@selector(loginRequest) withObject:nil afterDelay:0.0f];
    }

}



// set page in previouse position
-(void) setOfset{
    [self.pageScroll setContentSize:CGSizeMake(240,267)];
    self.pageScroll.contentOffset=CGPointMake(0, 0);
    
    [self.txtUserName resignFirstResponder];
    
    [self.txtPassword resignFirstResponder];
}
#pragma mark - Response Methods

// receive data from json
-(void)getResponce:(id)jsonData
{   
   
    switch (ReqID) {
        case Login_Req:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];

        LoginResponceDataClass *loginDataobj=(LoginResponceDataClass *)jsonData;
            
            [UserDetailClass sharedUser].strUserId=self.txtUserName.text;
            [UserDetailClass sharedUser].StrPassword=self.txtPassword.text;
            
        if (loginDataobj.Error_Code==0)
        {
            [[AppDelegate sharedAppDelegate] addLoginLoadingView];
            ReqID = HOME_PAGE_Req;
            [AppDelegate sharedAppDelegate].isUserLogin = YES;
//            [[AppDelegate sharedAppDelegate] addloadingView];
            [self performSelector:@selector(loginRequest) withObject:nil afterDelay:0.0f];

        }else if(loginDataobj.Error_Code==102)
        {
            [[AppDelegate sharedAppDelegate] addLoginLoadingView];
            forgotPageType = REGISTER_DEVICE_PAGE;
            ReqID = GetSEcurity_Question;
            [self performSelector:@selector(loginRequest) withObject:nil afterDelay:0.0f];
        }else
        {
            showAlertScreen(nil, loginDataobj.ErrorMsg);
        }
        }
        break;
            
        case Forget_pwd_req:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            UserIdValidationClass *uservalidDataobj=(UserIdValidationClass *)jsonData;
            [UserDetailClass sharedUser].strUserId=self.txtUserName.text;

            if (uservalidDataobj.ERROR_FOUND)
            {
                showAlertScreen(nil, uservalidDataobj.ERRMSG);
            }else
            {
                [[AppDelegate sharedAppDelegate] addloadingView];
                forgotPageType = FORGOT_PWD_PAGE;
                ReqID = GetSEcurity_Question;
                 [self performSelector:@selector(loginRequest) withObject:nil afterDelay:0.0f];
            }
        }
        break;

        case Forget_user_ID_req:
        {
           
        }
        break;
        case HOME_PAGE_Req:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];

            
            if (jsonData == 0)
            {
                [[AppDelegate sharedAppDelegate] addLoginLoadingView];
                ReqID = HOME_PAGE_Req;
                [self performSelector:@selector(loginRequest) withObject:nil afterDelay:0.0f];
            }
            else{
                if (![AppDelegate sharedAppDelegate].arrBusinessData)
                {
                    [AppDelegate sharedAppDelegate].arrBusinessData=[[NSMutableArray alloc] init];
                }
                else
                {
                    [[AppDelegate sharedAppDelegate].arrBusinessData removeAllObjects];
                }
                
            //*** The code must be replaced by the code which fetch the data from server
            //*** and update the value according to that
                
//
//                [AdminAccessInfo AdminAcess].updateCard = 114;              //114
//                [AdminAccessInfo AdminAcess].TerminateCard = 114;           //114
//                [AdminAccessInfo AdminAcess].loadCard = 121;                //121
//                [AdminAccessInfo AdminAcess].scheduleCard = 148;            //148
//                [AdminAccessInfo AdminAcess].expenseRules = 167;            //167
//                [AdminAccessInfo AdminAcess].initiateTransferValue = 170;   //170
//                [AdminAccessInfo AdminAcess].viewTransferValue = 171;       //171
//                [AdminAccessInfo AdminAcess].adminPageAccessValue = 129;    //129
//                [AdminAccessInfo AdminAcess].mgmtPolicyAccessValue = 129;   //129
//                [AdminAccessInfo AdminAcess].reportAccessValue = 105;       //105
//                [AdminAccessInfo AdminAcess].transactionHistoryValue = 115; //115
                
                
            [AppDelegate sharedAppDelegate].arrBusinessData=jsonData;
                if([AppDelegate sharedAppDelegate].isNotification == NO){
                    [AppDelegate sharedAppDelegate].HomePageIndexNo=0;
            HomeViewController *homeView = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
            [self.navigationController pushViewController:homeView animated:YES];
            [homeView release];
                }
                else{
                    
                    ReqID = Alert_Req;
                    [[AppDelegate sharedAppDelegate] addloadingView];
                    [self loginRequest];
                }
            }
        }
            break;
            
        case GetSEcurity_Question:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];

            if ([jsonData count]>0) {
                
            ForgetUserIDViewController *fuic = [[ForgetUserIDViewController alloc] initWithNibName:@"ForgetUserIDViewController" bundle:nil ForgotPage:forgotPageType];
            fuic.ValidUserId=self.txtUserName.text;
                 fuic.SecretQuestionArr = jsonData;
            [self.navigationController pushViewController:fuic animated:YES];
               
                [fuic release];
            }
        }
            break;
            
            case Alert_Req:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];

            if ([jsonData isKindOfClass:[NSArray class]]) {
                
                if ([jsonData count]>0)
                {
                    AlertsDetailViewController *advc = [[AlertsDetailViewController alloc] initWithNibName:@"AlertsDetailViewController" bundle:nil alertType:[AppDelegate sharedAppDelegate].notificationTag array:jsonData alertGroup:getAlertColorForNotification([AppDelegate sharedAppDelegate].notificationTag)];
                    [self.navigationController pushViewController:advc animated:YES];
                    [advc release];
                    [AppDelegate sharedAppDelegate].notificationTag = 0;
                }
                
            }
            else
            {
                AlertsDetailViewController *advc = [[AlertsDetailViewController alloc] initWithNibName:@"AlertsDetailViewController" bundle:nil alertType:[AppDelegate sharedAppDelegate].notificationTag array:nil alertGroup:getAlertColorForNotification([AppDelegate sharedAppDelegate].notificationTag)];
                [self.navigationController pushViewController:advc animated:YES];
                [advc release];
                [AppDelegate sharedAppDelegate].notificationTag = 0;
                
                showAlertScreen(@"", @"No records found");
            }

        }
            break;
        default:
        break;
    }
}


// send request to server
-(void)loginRequest
{
    
    DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
    dataParsing.Datadelegate=self;
        
    switch (ReqID) {
        case Login_Req:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=Login_Request;

            [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=%@&dbbServiceName=%@&deANAuserid=%@&deANAUsrPassword=%@&deCIAIPAddress=%@&dePPVersionComments=%@&deUsrActLogParam2=%@&deIVRSource=%@&deIVRIpAddress=%@&deIVRCallerId=%@&deIVRCalledId=%@&deIVRRequestTime=%@&deIVRSessionID=%@&deDeviceId=%@&deDBBServiceApiLevel=%@&deDBBServiceAppID=%@",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin  ,[SystemConfiguration sharedSystemConfig].dbbSystemSingleSignon  , [SystemConfiguration sharedSystemConfig].dbbServiceName,self.txtUserName.text,self.txtPassword.text  , [SystemConfiguration sharedSystemConfig].deCIAIPAddress  , [SystemConfiguration sharedSystemConfig].dePPVersionComments, [SystemConfiguration sharedSystemConfig].deUsrActLogParam2, [SystemConfiguration sharedSystemConfig].deIVRSource, [SystemConfiguration sharedSystemConfig].deIVRIpAddress, [SystemConfiguration sharedSystemConfig].deIVRCallerId, [SystemConfiguration sharedSystemConfig].deIVRCalledId  ,[SystemConfiguration sharedSystemConfig].deIVRRequestTime,[SystemConfiguration sharedSystemConfig].deIVRSessionID,[SystemConfiguration sharedSystemConfig].deDeviceId,[SystemConfiguration sharedSystemConfig].deDBBServiceApiLevel  ,[SystemConfiguration sharedSystemConfig].deDBBServiceAppID] ServiceName:svcUserLogin];
        }
            break;

            case Forget_pwd_req:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=ValidateUserId_request;
            [SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct=@"1";
            [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deUserid=%@&deSetFlagValue_BankAct=%@&deDBBServiceApiLevel=%@&deDBBServiceAppID=%@",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin  ,[SystemConfiguration sharedSystemConfig].dbbSystemSingleSignon  , [SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,self.txtUserName.text,[SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct,[SystemConfiguration sharedSystemConfig].deDBBServiceApiLevel  ,[SystemConfiguration sharedSystemConfig].deDBBServiceAppID] ServiceName:svcValidateUserID];

        }
            break;
            
        case HOME_PAGE_Req:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=Business_Search_Request;
            [SystemConfiguration sharedSystemConfig].deFlagShowDetails=@"1";
            [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPProductParent=&deBusinessName=&deCIASDDANumber=&deAADAccountNumber=&dePPCardStatus=&deCIASFirstName=&deCIASLastName=&deCIAAddressLine1=&deCIAAddressLine2=&deCIASCity=&deCIASState=&deCIASCountry=&deCIASZipCode=&deBSAcctId=&deFlagShowDetails=%@&deRequestBatchSize=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].deFlagShowDetails,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBusinessAccountSearch];
        }
            break;
            
        case GetSEcurity_Question:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=CardLookUp_Request;
            
            [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=1&dbbServiceName=%@&deCIALutID=CMSecQuestion",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName] ServiceName:svcCCardLookUp];
 }
            break;

            case Alert_Req:
        {
                
//            if ([AppDelegate sharedAppDelegate].notificationTag == Card_Pending_Activation_Alert) {
//                [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
//                [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
//                
//                [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=&deBsAccountNumber=&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=%d&deBusinessName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,Pending_CARD,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBACardHolderList];
//                
//            }
//            else{
//                
                [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
                [SystemConfiguration sharedSystemConfig].dbbServiceName=ALERT_DISPLAY_REQUEST;
                
                [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deANAuserid=%@&deAlertType=%d&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[AppDelegate sharedAppDelegate].notificationTag,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcSpendCardBAAlertDisplay];
                
            }

//        }
            break;
        default:
            break;
    }
    
    [dataParsing release];
}


// check pasword length
- (BOOL)validatePasswordString:(NSString*)psswrd
{
    int len = [psswrd length];
    if (len > 4 && len < 14)
        return YES;
    else
        return NO;
}

// check validation of email and password
- (BOOL)validateEmailAndPassword
{
	BOOL emailValid = validateEmailString(self.txtUserName.text);
	
	BOOL passwordValid = [self validatePasswordString:self.txtPassword.text];
	
	if(!emailValid)
	{        
        showAlertScreen(languageSelectedStringForKey(@"INV_USERNM_LOGIN"), languageSelectedStringForKey(@"INV_USERNM_MESSAGE"));
	}
	else if (!passwordValid)
	{
        showAlertScreen(languageSelectedStringForKey(@"INV_PWD_LOGIN"), languageSelectedStringForKey(@"INV_PWD_MESSAGE"));
	}
	
	return emailValid && passwordValid;
}

// metho used for create request for resset password
-(void)createResetPassword
{
//    ReqID=1;
//    Request *req=[[Request alloc] init];
//    req.delegate=self;
//    [req request:RESET_PASSWORD Parameter:[NSString stringWithFormat:@"email=%@",self.txtUserName.text]];
//    [req release];
}

// method used for check user name and add loading view
- (IBAction)clickedClickHereBtn:(id)sender {
    
    if (self.txtUserName.text.length >0)
    {
        ReqID=Forget_pwd_req;
        [[AppDelegate sharedAppDelegate] addloadingView];
        [self performSelector:@selector(loginRequest) withObject:nil afterDelay:0.0f];
    }
    else{
        showAlertScreen(languageSelectedStringForKey(@"User Id") , languageSelectedStringForKey(@"Please enter user id"));
    }
}



- (IBAction)clickedRegisterBtn:(id)sender
{
//    [self setOfset];
//    
//    RegistrationViewController *registrationView = [[RegistrationViewController alloc] initWithNibName:@"RegistrationViewController" bundle:nil];
//    [self.navigationController pushViewController:registrationView animated:YES];
//    [registrationView release];
}
// method use for user login
- (IBAction)clickedLoginBtn:(id)sender
{
//    HomeViewController *homeView = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
//    
//    [self.navigationController pushViewController:homeView animated:YES];
//    [homeView release];
//
//    self.txtPassword.text = @"Test123!";
    [self logIn];
}

#pragma -mark UITextField Method

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.pageScroll setContentSize:CGSizeMake(240,350)];
    if ([textField isEqual:self.txtPassword] )
	{
		[self setOfset];
        //  [self logIn];
        [self.pageScroll setContentSize:CGSizeMake(240,267)];
	}
	else if ([textField isEqual:self.txtUserName])
	{
		[self.txtPassword becomeFirstResponder];
        
        
	}
    
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if ([textField isEqual:self.txtUserName]) {
        
        [self.pageScroll setContentOffset:CGPointMake(0, self.txtUserName.frame.origin.y-4) animated:YES];
    }
    if ([textField isEqual:self.txtPassword]) {
        
        [self.pageScroll setContentOffset:CGPointMake(0, self.txtPassword.frame.origin.y-4) animated:YES];
    }
    [self.pageScroll setContentSize:CGSizeMake(240,350)];
    
    return YES;
}

// method use for add forgot user id view
- (IBAction)cleckedForgotUserBtn:(id)sender
{
    //ReqID=Forget_user_ID_req;
    [[AppDelegate sharedAppDelegate] addloadingView];
    forgotPageType = FORGOT_USER_PAGE;
    ReqID = GetSEcurity_Question;
    [self performSelector:@selector(loginRequest) withObject:nil afterDelay:0.0f];
//    ForgetUserIDViewController *forgotUserid = [[ForgetUserIDViewController alloc] initWithNibName:@"ForgetUserIDViewController" bundle:nil ForgotPage:FORGOT_USER_PAGE];
//    [self.navigationController pushViewController:forgotUserid animated:YES];
}

-(void)RegisterNewDevice
{
    ForgetUserIDViewController *forgotUserid = [[ForgetUserIDViewController alloc] initWithNibName:@"ForgetUserIDViewController" bundle:nil ForgotPage:REGISTER_DEVICE_PAGE];
    [self.navigationController pushViewController:forgotUserid animated:YES];

    [forgotUserid release];
}

// method used for check user name and add loading view
- (IBAction)touchedBtnForgotPassword:(id)sender
{
    if (self.txtUserName.text.length >0)
    {
        ReqID=Forget_pwd_req;
        [[AppDelegate sharedAppDelegate] addLoginLoadingView];
        [self performSelector:@selector(loginRequest) withObject:nil afterDelay:0.0f];
    }
    else{
        showAlertScreen(languageSelectedStringForKey(@"User Id") , languageSelectedStringForKey(@"Please enter user id"));
    }
}
@end
