//
//  ExpenseCategory.h
//  CoreMoney
//


#import <Foundation/Foundation.h>

@interface ExpenseCategory : NSObject
{
    NSString * expCatDesc;
    double expense;
}
@property (nonatomic, retain) NSString * expCatDesc;
@property double expense;

@end
