//
//  ExpenseCategoryData.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface ExpenseCategoryData : NSObject
{
    NSString *CATEGORY_LABEL;
    NSMutableArray *SubCatArray;
    int CATEGORY_ID, CATEGORY_TYPE;
}
@property (nonatomic, retain)  NSString *CATEGORY_LABEL;
@property(nonatomic,assign)NSMutableArray *SubCatArray;
@property int CATEGORY_ID, CATEGORY_TYPE;
@end
