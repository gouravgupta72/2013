//
//  TransferDetailDataClass.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface TransferDetailDataClass : NSObject
{
    NSString *AddedOnDate, *BA_ACCT_ID, *BankAccountNumber, *Bank_Name, *CreditDebitIndicator, *DDHTranId ,*FundAvailableDate, *RequestId, *Source, *Status_Desc, *UserName;
    
    int Status;
    
    double TransactionAmount;
}

@property (nonatomic,retain)NSString *AddedOnDate, *BA_ACCT_ID, *BankAccountNumber, *Bank_Name, *CreditDebitIndicator, *DDHTranId ,*FundAvailableDate, *RequestId, *Source, *Status_Desc, *UserName;

@property int Status;

@property double TransactionAmount;
@end
