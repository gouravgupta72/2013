//
//  ReviewTransferView.m
//  CoreMoney
//

#import "ReviewTransferView.h"

@implementation ReviewTransferView
@synthesize bankName,lblCardNumber,indate,lblBal,lblCompdate,lblstatus,btnChangeStatus;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        UIImageView *bgImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 60)];
        bgImage.image = [UIImage imageNamed:@"img_B_Summary_gRAY_bg.png"];
        
        [self addSubview:bgImage];
        [bgImage release];
                
         bankName = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 200, 18)];
        bankName.backgroundColor = [UIColor clearColor];
        bankName.font = [UIFont fontWithName:@"arial" size:14];
        bankName.textColor = [UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:138.0/255.0 alpha:1.0f];
               //  bankName.text = reviewObj.transferBankName;
        //bankName.textColor = [UIColor grayColor];
        [self addSubview:bankName];
        //CGSize textSize = [[bankName text] sizeWithFont:[bankName font]];
        
//        CGFloat strikeWidth = textSize.width;
//        
//        if(strikeWidth >bankName.frame.size.width){
//            bankName.numberOfLines = 2;
//            bankName.frame = CGRectMake(10, 5, 200, 35);
//            strikeWidth = 200;
//        }

               
        
        lblCardNumber = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, 150, 18)];
        lblCardNumber.backgroundColor = [UIColor clearColor];
        lblCardNumber.font = [UIFont fontWithName:@"arial" size:14];
       // lblCardNumber.text = reviewObj.transferCardNo;
        lblCardNumber.textColor = [UIColor grayColor];
        [self addSubview:lblCardNumber];
        

        
        
        indate = [[UILabel alloc] initWithFrame:CGRectMake(10, 39, 70, 16)];
       // indate.text = reviewObj.transferInDate;
         indate.backgroundColor = [UIColor clearColor];
        indate.font = [UIFont fontWithName:@"arial" size:12];
        indate.textColor = [UIColor lightGrayColor];
        [self addSubview:indate];
        
        
        UIImageView *arrowimage = [[UIImageView alloc] initWithFrame:CGRectMake(90,39, 18, 13)];
        arrowimage.image = [UIImage imageNamed:@"img_enddate_transfer.png"];
        
        [self addSubview:arrowimage];
        [arrowimage release];
        
        lblBal = [[UILabel alloc] initWithFrame:CGRectMake(230, 5, 80, 20)];
       // lblBal.text =  [NSString stringWithFormat:@"$%@", ChangeTocurrency(reviewObj.tranferBalance)];
        lblBal.backgroundColor = [UIColor clearColor];
        lblBal.textAlignment = UITextAlignmentRight;
        lblBal.textColor = [UIColor blackColor];
        lblBal.font = [UIFont fontWithName:@"arial" size:14];
        [self addSubview:lblBal];
        
        
        lblCompdate= [[UILabel alloc] initWithFrame:CGRectMake(118, 39, 80, 16)];
       // lblCompdate.text =  reviewObj.transferCompDate;;
        //lblBal.textAlignment =
        lblCompdate.backgroundColor = [UIColor clearColor];
        lblCompdate.textColor = [UIColor lightGrayColor];
        lblCompdate.font = [UIFont fontWithName:@"arial" size:12];
        lblCompdate.hidden = YES;
        [self addSubview:lblCompdate];
        
        lblstatus = [[UILabel alloc] initWithFrame:CGRectMake(230, 39, 80, 16)];
       // lblstatus.text = reviewObj.transferStatus;
        lblstatus.textColor = [UIColor colorWithRed:56.0/255.0 green:142.0/255.0 blue:212.0/255.0 alpha:1.0f];
        lblstatus.font = [UIFont fontWithName:@"arial" size:12];
        lblstatus.backgroundColor = [UIColor clearColor];
        lblstatus.textAlignment = UITextAlignmentRight;
//        if ([reviewObj.transferStatus isEqualToString:@"Complete"]) {
//            [self addSubview:lblCompdate];
//            lblstatus.textColor = [UIColor grayColor];
//            
//        }
        [self addSubview:lblstatus];

        
        btnChangeStatus=[[UIButton alloc] initWithFrame:CGRectMake(230, 39, 80, 16)];
        btnChangeStatus.backgroundColor=[UIColor clearColor];
        [btnChangeStatus addTarget:del action:@selector(ChangeTransferStatus:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btnChangeStatus];
        
        [btnChangeStatus release];
        [bankName release];
        [lblCardNumber release];
        [indate release];
        [lblBal release];
        [lblCompdate release];
        [lblstatus release];
        
        
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
