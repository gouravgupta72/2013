//
//  responseParse.m
//

#import "responseParse.h"

@implementation responseParse
@synthesize delegate;
static responseParse* _sharedParseManager;
+ (responseParse*)sharedParseManager
{
	@synchronized(self) {
		
        if (_sharedParseManager == nil) {
            [[self alloc] init]; // assignment not done here
        }
    }
    return _sharedParseManager;
}
#pragma mark Singleton Methods

+ (id)allocWithZone:(NSZone *)zone

{
    @synchronized(self) {
		
        if (_sharedParseManager == nil) {
			
            _sharedParseManager = [super allocWithZone:zone];
            return _sharedParseManager;  // assignment and return on first allocation
        }
    }
	
    return nil; //on subsequent allocation attempts return nil
}


- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

- (id)retain
{
    return self;
}

- (unsigned)retainCount
{
    return UINT_MAX;  //denotes an object that cannot be released
}

//- (void)release
//{
//    //do nothing
//}
- (id)autorelease
{
    return self;
}
//Method used for parse senser settings response.
-(void)parseSetSensorResponse:(id)jsonData
{
   /* if ([jsonData isKindOfClass:[NSDictionary class]])
    {
        id response=[jsonData valueForKey:PARSE_RESPONSE];
        if ([response isKindOfClass:[NSDictionary class]]) {
            id status=[response valueForKey:PARSE_STATUS];
            if ([status isKindOfClass:[NSString class]])
            {
                if ([status isEqualToString:PARSE_SUCCESS])
                {
                    showAlertScreen(@"Settings", [response valueForKey:PARSE_MESSAGE]);
                }
                
                else
                {
                    showAlertScreen(ERROR_MSG, [response valueForKey:PARSE_MESSAGE]);
                }
            }
        }
    }*/
}
-(BOOL)parseRegistrationResponse:(id)jsonData
{
    if ([jsonData isKindOfClass:[NSDictionary class]])
    {
        id response=[jsonData valueForKey:PARSE_RESPONSE];
        if ([response isKindOfClass:[NSDictionary class]]) {
            id status=[response valueForKey:PARSE_STATUS];
            if ([status isKindOfClass:[NSString class]])
            {
                if ([status isEqualToString:PARSE_SUCCESS])
                {
                    showAlertScreen(@"Registration", @"Account created successfully.");
                    return YES;
                }
                
                else
                {
                    showAlertScreen(ERROR_MSG, [response valueForKey:PARSE_MESSAGE]);
                    return NO;
                }
            }
        }
    }
    return NO;
}
//Method used for parse login response
-(BOOL)parseLoginResponse:(id)jsonData
{
    if ([jsonData isKindOfClass:[NSDictionary class]])
    {
        id response=[jsonData valueForKey:PARSE_RESPONSE];
        if ([response isKindOfClass:[NSDictionary class]]) {
            id status=[response valueForKey:PARSE_STATUS];
            if ([status isKindOfClass:[NSString class]])
            {
                if ([status isEqualToString:PARSE_SUCCESS])
                {
                    id UserID=[response valueForKey:@"UserID"];
                    id FirstName=[response valueForKey:@"FirstName"];
                    id LastName=[response valueForKey:@"LastName"];
                    id Email=[response valueForKey:@"Email"];
                    
                    LoginResponse *lRes=[[LoginResponse alloc] init];
                    lRes.UserId=[NSString stringWithFormat:@"%@",UserID];
                    lRes.firstName=[NSString stringWithFormat:@"%@",FirstName];
                    lRes.LastName=[NSString stringWithFormat:@"%@",LastName];
                    lRes.Email=[NSString stringWithFormat:@"%@",Email];
                    
                    NSUserDefaults *userDefault= [NSUserDefaults standardUserDefaults];
                    NSData *objData = [NSKeyedArchiver archivedDataWithRootObject:lRes];
                    [userDefault setObject:objData forKey:USERID];
                    
                    [lRes release];
                    return YES;
                }
                
                else
                {
                    showAlertScreen(ERROR_MSG, [response valueForKey:PARSE_MESSAGE]);
                    return NO;
                }
            }
        }
    }
    return NO;
}
-(NSMutableArray *)parseGetStore:(id)jsonData
{
   /* if ([jsonData isKindOfClass:[NSDictionary class]]) {
        id response=[jsonData valueForKey:PARSE_RESPONSE];
        if ([response isKindOfClass:[NSDictionary class]]) {
            id status=[response valueForKey:PARSE_STATUS];
            if ([status isKindOfClass:[NSString class]]) {
                if ([status isEqualToString:PARSE_SUCCESS])
                {
                    id sensorsList=[response valueForKey:@"Stores"];
                    if ([sensorsList isKindOfClass:[NSArray class]])
                    {
                        NSMutableArray *sensorArray=[[NSMutableArray alloc] init];
                        for (int index=0; index<[sensorsList count]; index++)
                        {
                            Storedata *sObj=[[Storedata alloc] initWithString:[[sensorsList objectAtIndex:index]valueForKey:@"StoreName"] selectRow:(index==0)?YES:NO dropDownButtonType:STORENAME id:[[[sensorsList objectAtIndex:index]valueForKey:@"StoreId"] intValue]];
                            [sensorArray addObject:sObj];
                            [sObj release];
                        }
                        [AppDelegate sharedAppDelegate].isGetResponse=YES;
                        return [sensorArray autorelease];
                    }
                }
                else
                {
                    showAlertScreen(ERROR_MSG, [response valueForKey:PARSE_MESSAGE]);
                    return nil;
                }
            }
        }
    }*/
    return nil;
}
-(void)parseResetPasswordResponse:(id)jsonData
{
    if ([jsonData isKindOfClass:[NSDictionary class]])
    {
        id response=[jsonData valueForKey:PARSE_RESPONSE];
        if ([response isKindOfClass:[NSDictionary class]]) {
            id status=[response valueForKey:PARSE_STATUS];
            if ([status isKindOfClass:[NSString class]])
            {
                if ([status isEqualToString:PARSE_SUCCESS])
                {
                    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"PasswordChange"];
                    showAlertScreen(@"Reset Password", [response valueForKey:PARSE_MESSAGE]);
                }
                
                else
                {
                    showAlertScreen(ERROR_MSG, [response valueForKey:PARSE_MESSAGE]);
                }
            }
        }
    }
}

/*-(UserUploads *)parseGetUploadResponse:(id)jsonData
{
    if ([jsonData isKindOfClass:[NSDictionary class]])
    {
        id response=[jsonData valueForKey:PARSE_RESPONSE];
        if ([response isKindOfClass:[NSDictionary class]]) {
            id status=[response valueForKey:PARSE_STATUS];
            if ([status isKindOfClass:[NSString class]])
            {
                if ([status isEqualToString:PARSE_SUCCESS])
                {
                    UserUploads *uobj=[[UserUploads alloc] init];
                    uobj.uploadArray=[[NSMutableArray alloc] init];
                    
                    id  Products=[response valueForKey:@"Products"];
                    if ([Products isKindOfClass:[NSArray class]])
                    {
                        for (int i=0; i<[Products count]; i++) {
                            
                            PhotosUpload *obje = [[PhotosUpload alloc] initWithImage:[[Products objectAtIndex:i] valueForKey:@"ImageUrl"] Date:[[Products objectAtIndex:i] valueForKey:@"UploadDate"]];
                            
                            [uobj.uploadArray addObject:obje];
                        }
                        
                    }
                    uobj.UploadCount=[[response valueForKey:@"UploadCount"] intValue];
                return [uobj autorelease];
                }
                else
                {
                     showAlertScreen(ERROR_MSG, [response valueForKey:PARSE_MESSAGE]);
                }
            }
        }
    }
return nil;
}*/

-(void)dealloc
{
    self.delegate=nil;
    [super dealloc];
}
@end
