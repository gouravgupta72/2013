//
//  pendingAlertViewCntroller.h
//  CoreMoney
//
//  Created by Mac Book on 13/01/14.
//  Copyright (c) 2014 Hunka. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CardDataCell.h"
#import "DataParsingClass.h"
#import "PopUpView.h"
@interface pendingAlertViewCntroller : SwipeViewController<DataParsingDelegate>
{
    NSMutableArray *alertArray;
    int newCardStatus, selectedIndex, oldCardStatus;
    UIView *statusSelectView;
}
@property (retain, nonatomic) IBOutlet UITableView *tblCardList;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil dataArray:(NSMutableArray *)alertDataArray;
@end
