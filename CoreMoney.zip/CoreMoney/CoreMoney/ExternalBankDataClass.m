//
//  ExternalBankDataClass.m
//  CoreMoney


#import "ExternalBankDataClass.h"

@implementation ExternalBankDataClass

@synthesize  RecipientID ,BA_ACCT_ID ,RoutingNumber, BankAccountNumber, Bank_Name, AddedOnDate, Bank_Owner, Status, IsActive, Val_Tries,  MicroDepostiRev, Description, ResErrorMsg, MicroDeposit1, MicroDeposit2, ResErrorCode, ResCode;


-(void)dealloc
{
    self. RecipientID =nil;
    self.BA_ACCT_ID=nil;
    self.RoutingNumber=nil;
    self.BankAccountNumber=nil;
    self.Bank_Name=nil;
    self.AddedOnDate=nil;
    self.Bank_Owner=nil;
    self.Status=nil;
    self.IsActive=nil;
    self.Val_Tries=nil;
    self.MicroDepostiRev=nil;
    self.Description=nil;
    self.ResErrorMsg=nil;
    
    [super dealloc];
}
@end
