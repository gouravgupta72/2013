//
//  ForgotPasswordViewController.h


#import <UIKit/UIKit.h>

@interface ForgotPasswordViewController : UIViewController
@property (retain, nonatomic) IBOutlet UITextField *txtUserID;

@property (retain, nonatomic) IBOutlet UITextField *txtEmail;
@property (retain, nonatomic) IBOutlet UITextField *txtSecretAnswer;
@property (retain, nonatomic) IBOutlet UIScrollView *myScrollView;

@end
