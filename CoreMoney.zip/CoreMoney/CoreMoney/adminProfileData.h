//
//  adminProfileData.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface adminProfileData : NSObject
{
    NSString *ROWID, *IPADDRESS, *CHECKDAY, *DOB, *EMAIL_ID, *AddressLine1, *AddressLine2, *City, *State, *ZIPCODE, *Country;
    int AllowCookies, IPBYPASS_FLAG;
}

@property (nonatomic,retain)   NSString *ROWID, *IPADDRESS, *CHECKDAY, *DOB, *EMAIL_ID, *AddressLine1, *AddressLine2, *City, *State, *ZIPCODE, *Country;

@property   int AllowCookies, IPBYPASS_FLAG;
@end
