//
//  AdminListCell.m
//  CoreMoney

#import "AdminListCell.h"

@implementation AdminListCell
@synthesize lblTitleName,lblCardNumber,lblStatus,lblAmount,btnState,delegate,btnView;

// Method to design the cell for Card Data.
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        delegate=del;
        // Initialization code
        lblTitleName=createLabel(@"", CGRectMake(10, 0, 230, 35));
        lblTitleName.font = FONT_ARIAL_16;
        lblTitleName.textAlignment = UITextAlignmentLeft;
        lblTitleName.textColor =Name_color_Code;
        lblTitleName.numberOfLines = 2;
        [self addSubview:lblTitleName];
        [lblTitleName release];
        
        
        lblCardNumber=createLabel(@"", CGRectMake(10, CGRectGetMaxY(lblTitleName.frame)-5, 230, 20));
        lblCardNumber.font = FONT_ARIAL_12;
        lblCardNumber.textAlignment = UITextAlignmentLeft;
        lblCardNumber.textColor =Card_no_colore_code;
        [self addSubview:lblCardNumber];
        [lblCardNumber release];
        
        
        btnView = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetMaxX(lblTitleName.frame)+10, 17, 7, 13)];
        btnView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"imgStatusInactive"]];
        [self addSubview:btnView];
        [btnView release];
        
        btnState= createButton(CGRectMake(CGRectGetMaxX(lblTitleName.frame), 10, 145, 30), @"", @"", self, @selector(openStatus:));
        btnState.backgroundColor=[UIColor clearColor];
        [self addSubview:btnState];
        [btnState release];
        
        lblStatus=createLabel(@"", CGRectMake(CGRectGetMaxX(btnView.frame)+5, 10, 170, 30));
        lblStatus.font = FONT_ARIAL_12;
        lblStatus.textAlignment = UITextAlignmentLeft;
        lblStatus.textColor =Status_Color_Code;;
        [self addSubview:lblStatus];
        [lblStatus release];
        
        
    }
    return self;
}
// Method to handle button pressed for changing status.
-(void)openStatus:(id)sender
{
    btnView.frame=CGRectMake(CGRectGetMaxX(lblTitleName.frame)+10, 20, 11, 7);
    btnView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"imgStatusActive"]];
    
    UIButton *tmpBtn = (UIButton *)sender;
    if ([delegate respondsToSelector:@selector(openStatusView:)]) {
        [delegate openStatusView:tmpBtn.tag];
    }
}
// Method called on selecting of the cell.
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

// Method to remove compilation error.
// Method to open the status view.
-(void)openStatusView:(int)index
{
    
}

@end
