//
//  employeeExpData.m
//  CoreMoney


#import "employeeExpData.h"

@implementation employeeExpData
@synthesize EmployeeName, CardNumber ,TotalExpenses, ExpenseLimit, Diff_Limit_Expense;
@synthesize expCatOneText, expCatTwoText, expCatThreeText,expCateGory,expCatOneAmount,expCatTwoAmount,expCatThreeAmount,expCateAmount;
@synthesize arrEmployeCatDescExpense;
-(void)dealloc
{
    self.EmployeeName=nil;
    self.CardNumber=nil;
    self.expCateGory=nil;
    self.expCatOneText=nil;
    self.expCatThreeText=nil;
    self.expCatTwoText=nil;
    [super dealloc];
}
@end
