//
//  LoginResponceDataClass.h
//  CoreMoney

// Hold data of login request.
#import <Foundation/Foundation.h>

@interface LoginResponceDataClass : NSObject
{
    NSString *ErrorMsg;
    int Error_Code;
    BOOL Error_Found;
}

@property(nonatomic,retain)NSString *ErrorMsg;
@property  int Error_Code;
@property BOOL Error_Found;
@end
