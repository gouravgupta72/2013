//
//  UserProfileViewController.m



#import "UserProfileViewController.h"
#import "UpdateUserProfileViewController.h"
#define ALERTVIEW @"AlertView"

@interface UserProfileViewController ()
-(void)openBack;
-(void)openSlide;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil userProfileData:(UserProfileDataClass *)updObj;
-(void)designProfileView;
-(void)getUserData;
-(void)getResponce:(id)jsonData;

-(void)getError:(id)error;
-(void)FillData;
- (IBAction)updateUserProfile:(id)sender;
- (IBAction)terminateUserProfile:(id)sender;
-(void) disableUpdateButton: (BOOL) uflag andTerminateButton:(BOOL)tFlag;

@end

@implementation UserProfileViewController
@synthesize AcctId,CardDataObj,dataObj,strNavigatedFrom;

// Pop to previous View
-(void)openBack
{
    if ([strNavigatedFrom isEqualToString:ALERTVIEW])
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        [[AppDelegate sharedAppDelegate] addloadingView];
        [self performSelector:@selector(delyedOpen) withObject:nil afterDelay:0.5];
    }
}

-(void)delyedOpen{
    [self.navigationController popViewControllerAnimated:YES];
}
//method use for open slide menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil userProfileData:(UserProfileDataClass *)updObj
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {//initilization
        addNavigationBar([NSString stringWithFormat:@"%@ %@",languageSelectedStringForKey(@"Card"),languageSelectedStringForKey(@"Profile")], NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        dataObj = updObj;
    }
    return self;
}

/* When we are comming from AlertView Controller */
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil CardDetailClassObject:(CardDetailClass *) objCardDetailClass navigatedFrom:(NSString *)strNavFrom
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        addNavigationBar([NSString stringWithFormat:@"%@ %@",languageSelectedStringForKey(@"Card"),languageSelectedStringForKey(@"Profile")], NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        strNavigatedFrom = strNavFrom;
        objCardDetail = objCardDetailClass;
        self.CardDataObj = objCardDetailClass;
    }
    return self;
}

//method use for design profile view
-(void)designProfileView
{
    // Top View Designing.
    self.topView.layer.cornerRadius = 10;
    self.topView.layer.masksToBounds = YES;
    self.topView.layer.borderColor = Color132.CGColor;
    self.topView.layer.borderWidth = 1.5f;
    
    self.lblTopTitle.backgroundColor=[UIColor whiteColor];
    self.lblTopTitle.textColor=Color127;
    
    
    // Bottom View Designing.
    self.bottomView.layer.cornerRadius = 10;
    self.bottomView.layer.masksToBounds = YES;
    self.bottomView.layer.borderColor = Color132.CGColor;
    self.bottomView.layer.borderWidth = 1.5f;
    
    self.lblBottomTitle.backgroundColor=[UIColor whiteColor];
    self.lblBottomTitle.textColor=Color127;
}

-(void)changeLanguage
{
    self.lblTopTitle.text=languageSelectedStringForKey(@"Personal Details");
    self.lblBottomTitle.text=languageSelectedStringForKey(@"Address");
    [self.btnUpdate setTitle:languageSelectedStringForKey(@"Update") forState:UIControlStateNormal];
    [self.btnTerminate setTitle:languageSelectedStringForKey(@"Terminate") forState:UIControlStateNormal];
}

- (void)viewDidLoad
{
    
    isPopView = NO;
    [AppDelegate sharedAppDelegate].classType = CARDS_PROFILE_PAGE;
    [super viewDidLoad];
    [self designProfileView];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated
{
    self.view.backgroundColor=[UIColor whiteColor];
//    NavigationBarStyle();
    [[AppDelegate sharedAppDelegate] removeLoadingView];
   
    if ([self.strNavigatedFrom isEqualToString:ALERTVIEW])
    {
        [AppDelegate sharedAppDelegate].classType = ADMIN_ALERTS_PAGE;
    }
    else
    {
        [AppDelegate sharedAppDelegate].classType = CARDS_PROFILE_PAGE;
    }
    
    _myUserProfileView.frame=CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, [AppDelegate sharedAppDelegate].screenWidth, [AppDelegate sharedAppDelegate].screenHeight-[AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame.size.height+20);
    if ([strNavigatedFrom isEqualToString:ALERTVIEW])
    {
        self.CardDataObj = objCardDetail;
    }
    else
    {
        self.CardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
    }
    [self changeLanguage];
    if(isPopView == YES)
    {
        [self getUserData];
    }
    else
    {
        [self FillData];
    }
    isPopView = YES;
    
    BOOL hideUpdateButton = YES;
    BOOL hideTerminateButton = YES;
    
    // if index value is 114 then user can Update the profile.Else User can not Update the profile and Update button not Visible.

    if ([AdminAccessInfo AdminAcess].updateCard == UPDATECARD)
    {
        hideUpdateButton = NO;
    }
    
    // if index value is 114 then user can Terminate the profile.

    if ([AdminAccessInfo AdminAcess].TerminateCard == TERMINATECARD) {
        hideTerminateButton = NO;
    }
    
    // Calling the Method to enable or disable the Update and Terminate Button
        [self disableUpdateButton:hideUpdateButton andTerminateButton:hideTerminateButton];
    
}

#pragma mark - Request Work
-(void)getUserData
{
    [[AppDelegate sharedAppDelegate] addloadingView];

     Request_id=1;
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Card_holder_Detail_Request;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    

    
    [Datareq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deTCIVRPrimaryAccountNumber=%@&deTCIVRAccountNumber=%@&deTCIVRANI=&deTCIVRDNS=&deBSAcctid_New=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, self.CardDataObj.CARDNUMBER,self.CardDataObj.ACCOUNTNUMBER,self.CardDataObj.BSAcctID,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCardholderDetail];

    [Datareq release];
}

-(void)getStateCodeValues
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    Request_id = 3;
    
    DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
    dataParsing.Datadelegate=self;
    [[AppDelegate sharedAppDelegate] addloadingView];
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getStateCode;
    
    [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=1&dbbServiceName=%@&deCIALutID=State&deCIALutCode=US&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcState];
    [dataParsing release];
}

-(void)terminateRequest
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    Request_id=2;
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;

    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Change_Card_Status_Update;
    
    [Datareq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deTCIVRCLIENT_ID=%@&deTCIVRCLIENT_PASSWORD=&deTCIVRLOCATION_ID=&deTCIVRLOCATION_CITY=&deTCIVRLOCATION_STATE=&deTCIVRLOCATION_COUNTRY=&deTCIVREMPLOYEE_PIN=&deTCIVRPrimaryAccountNumber=%@&deTCIVRAccountNumber=%@&deTCIVRCARD_STATUS=5&deTCIVRANI=&deTCIVRDNS=&deIVRSource=%@&deIVRIpAddress=&deIVRCallerId=&deIVRCalledId=&deIVRRequestTime=&deIVRSessionID=&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,CardDataObj.CLIENTID,CardDataObj.CARDNUMBER,CardDataObj.ADMIN_NUMBER,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcUpdateCardStatus_CardAccount];
    [Datareq release];
}
#pragma mark - Response Methods
// Delegate methods of request class to get response data
-(void)getResponce:(id)jsonData
{
    if (Request_id==1)
    {
        dataObj=(UserProfileDataClass *)jsonData;
        
        if (dataObj.ERROR_FOUND)
        {
            showAlertScreen(nil, dataObj.ERRMSG);
        }else
        {
            [self FillData];
        }
        [[AppDelegate sharedAppDelegate] removeLoadingView];
    }else if (Request_id==2)
    {
        
        LoginResponceDataClass  *resp=(LoginResponceDataClass *)jsonData;
        showAlertScreen(nil, resp.ErrorMsg);
        
        if (!resp.Error_Found)
        {
            CardDataObj.STATUS_CARDACCOUNT=Closed_CARD;
            
            self.lblCardStatus.text=CardStatusValue(Closed_CARD);
            [[AppDelegate sharedAppDelegate].arrCardDetailArray replaceObjectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex withObject:CardDataObj];
            
        }
        
       [[AppDelegate sharedAppDelegate] removeLoadingView]; 
    }else if (Request_id==3)
    {
       
        UpdateUserProfileViewController *uupvc = [[UpdateUserProfileViewController alloc] init];
        uupvc.userProfileObj = dataObj;
        uupvc.CardDetailData = self.CardDataObj;
        
        if ([jsonData count]>0)
        {
            uupvc.stateArray=jsonData;
        }
        
        if ([strNavigatedFrom isEqualToString:ALERTVIEW])
        {
            uupvc.strNavigatedFrom = @"AlertView";
        }else
        {
            uupvc.strNavigatedFrom = @"profileView";
        }
        
        [self.navigationController pushViewController:uupvc animated:YES];
        [uupvc release];
        
        
        [[AppDelegate sharedAppDelegate] removeLoadingView];
    }
     
    
}
//Delegate methods of request class to get error
-(void)getError:(id)error
{
    [[AppDelegate sharedAppDelegate] removeLoadingView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)FillData
{
    //dataobj replace by cardDataObj for showing name in user profile view
    self.lblUserName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings(CardDataObj.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@ ",CardDataObj.FIRSTNAME],checkISNullStrings(CardDataObj.LASTNAME)?@"":[NSString stringWithFormat:@"%@",CardDataObj.LASTNAME]];
      
    self.lblAvailBalance.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(CardDataObj.AVAILABLEBALANCE))];
    
    self.lblCardNo.text=[NSString stringWithFormat:@"%@",ChangeCardNumber((CardDataObj.CARDNUMBER))];

    self.lblCardStatus.text=CardStatusValue(CardDataObj.STATUS_CARDACCOUNT);
    
    self.lblEmpId.text=[NSString stringWithFormat:@"%@",checkISNullStrings(CardDataObj.CustomAccountID)?@"":[NSString stringWithFormat:@"%@ ",CardDataObj.CustomAccountID]];
    
    if ([strNavigatedFrom isEqualToString:ALERTVIEW])
    {
        self.lblEmail.text=[NSString stringWithFormat:@"%@",checkISNullStrings(CardDataObj.EMAILID)?@"":[NSString stringWithFormat:@"%@ ",CardDataObj.EMAILID]];
        
        
        
        self.lblAddress.text=[NSString stringWithFormat:@"%@",checkISNullStrings(CardDataObj.ADDRESS1)?@"":[NSString stringWithFormat:@"%@ ",CardDataObj.ADDRESS1]];
        
        self.lblAddressLine2.text=checkISNullStrings(CardDataObj.ADDRESSLINE2)?@"":[NSString stringWithFormat:@"%@",CardDataObj.ADDRESSLINE2];
        
        self.lblAddressCity.text=[NSString stringWithFormat:@"%@%@%@",checkISNullStrings(CardDataObj.CITY)?@"":[NSString stringWithFormat:@"%@",CardDataObj.CITY],[NSString stringWithFormat:@"%@",checkISNullStrings(CardDataObj.STATE)?@"":[NSString stringWithFormat:@",%@",CardDataObj.STATE]],[NSString stringWithFormat:@"%@",checkISNullStrings(CardDataObj.COUNTRY)?@"":[NSString stringWithFormat:@",%@",CardDataObj.COUNTRY]]]; /* We have to add country code here */
        
        self.lblZipcode.text=checkISNullStrings(CardDataObj.POSTALCODE)?@"":[NSString stringWithFormat:@"%@",CardDataObj.POSTALCODE];
        
        self.lblPhone.text=checkISNullStrings(CardDataObj.HOMEPHONENUMBER)?@"":changePhoneNumberToUS([NSString stringWithFormat:@"%@",CardDataObj.HOMEPHONENUMBER]);
        
        self.lblWorkPhone.text=checkISNullStrings(CardDataObj.MOBILE_PHONE_NO)?@"":[NSString stringWithFormat:@"%@",CardDataObj.MOBILE_PHONE_NO];
    }
    else
    {
        self.lblEmail.text=[NSString stringWithFormat:@"%@",checkISNullStrings(dataObj.EMAIL)?@"":[NSString stringWithFormat:@"%@ ",dataObj.EMAIL]];
        
        
        
        self.lblAddress.text=[NSString stringWithFormat:@"%@",checkISNullStrings(dataObj.ADDRESS1)?@"":[NSString stringWithFormat:@"%@ ",dataObj.ADDRESS1]];
        
        self.lblAddressLine2.text=checkISNullStrings(dataObj.ADDRESS2)?@"":[NSString stringWithFormat:@"%@",dataObj.ADDRESS2];
        
        self.lblAddressCity.text=[NSString stringWithFormat:@"%@%@%@",checkISNullStrings(dataObj.CITY)?@"":[NSString stringWithFormat:@"%@",dataObj.CITY],[NSString stringWithFormat:@"%@",checkISNullStrings(self.dataObj.STATE)?@"":[NSString stringWithFormat:@",%@",dataObj.STATE]],[NSString stringWithFormat:@"%@",checkISNullStrings(self.dataObj.COUNTRY_CODE)?@"":[NSString stringWithFormat:@",%@",dataObj.COUNTRY_CODE]]];
            
        self.lblZipcode.text=checkISNullStrings(dataObj.POSTALCODE)?@"":[NSString stringWithFormat:@"%@",dataObj.POSTALCODE];

        self.lblPhone.text=checkISNullStrings(dataObj.PHONE)?@"":changePhoneNumberToUS([NSString stringWithFormat:@"%@",dataObj.PHONE]);
        
        self.lblWorkPhone.text=checkISNullStrings(dataObj.MOBILE)?@"":[NSString stringWithFormat:@"%@",dataObj.MOBILE];
    }

}

- (void)dealloc {
    [_lblUserName release];
    [_lblCardNo release];
    [_lblCardStatus release];
    [_lblAvailBalance release];
    [_lblEmpId release];
    [_lblEmail release];
    [_lblAddress release];
    [_lblPhone release];
    [_myUserProfileView release];
    [_topView release];
    [_bottomView release];
    [_lblTopTitle release];
    [_lblBottomTitle release];
    [_lblAddressLine2 release];
    [_lblAddressCity release];
    [_lblZipcode release];
    [_lblWorkPhone release];
    [_btnUpdate release];
    [_btnTerminate release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setLblUserName:nil];
    [self setLblCardNo:nil];
    [self setLblCardStatus:nil];
    [self setLblAvailBalance:nil];
    [self setLblEmpId:nil];
    [self setLblEmail:nil];
    [self setLblAddress:nil];
    [self setLblPhone:nil];
    [self setMyUserProfileView:nil];
    [self setTopView:nil];
    [self setBottomView:nil];
    [self setLblTopTitle:nil];
    [self setLblBottomTitle:nil];
    [self setLblAddressLine2:nil];
    [self setLblAddressCity:nil];
    [self setLblZipcode:nil];
    [self setLblWorkPhone:nil];
    
    self.CardDataObj=nil;
    AcctId=nil;
    dataObj=nil;
    
    [self setBtnUpdate:nil];
    [self setBtnTerminate:nil];
    [super viewDidUnload];
}

- (IBAction)updateUserProfile:(id)sender
{
    [self getStateCodeValues];
}

- (IBAction)terminateUserProfile:(id)sender {
    
    showAlertWithOtherButtons(@"", @"Do you want to tereminate?", 1,self);
    
}
#pragma mark Enable Disable Control
-(void) disableUpdateButton:(BOOL)uflag andTerminateButton:(BOOL)tFlag
{
    [self.btnTerminate setHidden:tFlag];
    [self.btnUpdate setHidden:uflag];
}

#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 1) {
        if (buttonIndex == 0)
        {
            [self terminateRequest];
        }
    }
}



@end
