//
//  UserIdValidationClass.m
//  CoreMoney

#import "UserIdValidationClass.h"

@implementation UserIdValidationClass
@synthesize ERR_NUMBER,ERRMSG,ERROR_FOUND;

-(void)dealloc
{
    self.ERRMSG=nil;
    [super dealloc];
}
@end
