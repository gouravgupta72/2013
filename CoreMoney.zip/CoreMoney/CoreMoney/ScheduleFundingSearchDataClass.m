//
//  ScheduleFundingSearchDataClass.m
//  CoreMoney
//class use for Schedule Funding Search Data
#import "ScheduleFundingSearchDataClass.h"

@implementation ScheduleFundingSearchDataClass
@synthesize  ResErrorMsg, ACCOUNT_ACCT_ID, BA_ACCT_ID, SCHEDULE_TYPE,ResErrorCode, ResCode,AMOUNT, FREQUENCY,ISACTIVE, SelectDay;

-(void)dealloc
{
    self.ResErrorMsg=nil;
    self.ACCOUNT_ACCT_ID=nil;
    self.BA_ACCT_ID=nil;
    self.SCHEDULE_TYPE=nil;
    [super dealloc];
}


@end
