//
//  DatePickerView.h


#import <UIKit/UIKit.h>
#import "CalanderView.h"

@interface DatePickerView : UIView<UITextFieldDelegate>
{
    UITextField *lblFirstDate,*lblLastDate,*txtDescription,*txtAmountmin, *txtAmountMax;
    CalanderView *calnderObj;
    UIButton *btnFirstDate,*btnLastDate;
    NSString *strFirstDate,*strLastDate;
    BOOL isFirstDate;
    UIView * bottomView;
    id delegate;
    NSString *minAmount,*maxAmount;
    NSString *strDescription;
    UIButton *btnCrossFirstDate,*btnCrossLastDate;
}
@property(nonatomic,retain) UITextField *lblFirstDate,*lblLastDate;
@property(nonatomic,retain)UIButton *btnFirstDate,*btnLastDate;
@property(nonatomic,retain)NSString *strFirstDate,*strLastDate,*minAmount,*maxAmount,*strDescription;

- (id)initWithDatePickerViewFrame:(CGRect)frame delegate:(id)del fDate:(NSString *)firstDate lDate:(NSString *)lastDate minimumAmount:(NSString *)min maximumAmount:(NSString *)max description:(NSString *)desc;
@property (nonatomic,retain)id delegate;
-(void)DateSelectorcancel;

-(void)SendDateTocaller :(NSString *)fDate toDate:(NSString *)lDate minimumAmount:(NSString *)min maximumAmount:(NSString *)max description:(NSString *)desc;
@end
