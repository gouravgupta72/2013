//
//  businessListDataClass.m
//  CoreMoney


#import "businessListDataClass.h"

@implementation businessListDataClass
@synthesize LUTCODE, LUTDESCRIPTION, PRODUCT_PARENT;

-(void)dealloc
{
    self.LUTCODE=nil;
    self.LUTDESCRIPTION=nil;
    self.PRODUCT_PARENT=nil;
    [super dealloc];
}
@end
