//
//  TransactionViewController.m
//class is used for Transaction view
#define BatchSizeValue 50

#import "TransactionViewController.h"
#import "TransactionCell.h"
#import "DatePickerView.h"
#import "PopUpView.h"
#import "TransactionDetailsViewController.h"
#define ALERTVIEW @"AlertView"


@interface TransactionViewController ()

-(void)opensearch;
-(void)openSlide;
-(void)openBack;
-(void)fillCardDetail;
-(void)OpenDateSelector;
-(void)DateSelectorcancel;
-(void)getTransactionRecord;
-(void)getResponce:(id)jsonData;
-(void)getMemoData :(int)index;
-(void)GetExpenseCategory;
//-(void)UpdateDateSelection :(NSString *)fstDate Todate:(NSString *)lstDate minimumAmount:(NSString*)min maximumAmount:(NSString *)max description:(NSString*)desc;
@end

@implementation TransactionViewController
@synthesize cardDataObj,isAlertRequest;
@synthesize fDate,lDate, strminAmount ,strMaxAmount, strDescription,strNavigatedFrom;

// Initialize view.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)bundle trasactionData:(NSMutableArray *)transctObj isAlertRequest:(BOOL)isalertreq
{
    self = [super initWithNibName:nibNameOrNil bundle:bundle];
    if (self)
    {
        addNavigationBar(CARD_TRANSACTION_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        transactionArray = transctObj;
        isViewPop = NO;
        
        isAlertRequest = isalertreq;
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil trasactionData:(NSMutableArray *)transctObj isAlertRequest:(BOOL)isalertreq objectOfCardDetailClass:(CardDetailClass *)objCardDetail navigatedFrom:(NSString *)strNavFrom
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        addNavigationBarwithStrNavFrom(CARD_TRANSACTION_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self, strNavFrom);
        self.cardDataObj = objCardDetail;
        transactionArray = transctObj;
        isViewPop = NO;
        self.strNavigatedFrom = strNavFrom;
        isAlertRequest = isalertreq;
    }
    return self;
}

-(void)opensearch
{
     [self OpenDateSelector];
}

// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

// Pop to previous View
-(void)openBack
{
    if ([self.strNavigatedFrom isEqualToString:ALERTVIEW])
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        [[AppDelegate sharedAppDelegate] addloadingView];
        [self performSelector:@selector(delyedOpen) withObject:nil afterDelay:0.5];
    }
}

//method use for update date selection
-(void)UpdateDateSelection :(NSString *)fstDate :(NSString *)lstDate :(NSString*)min :(NSString *)max :(NSString*)desc
{
    if ([DatePickerBGView isDescendantOfView:self.view])
    {
        [DatePickerBGView removeFromSuperview];
        DatePickerBGView=nil;
    }
    self.fDate=fstDate;
    self.lDate=lstDate;
    self.strminAmount=min;
    self.strMaxAmount=max;
    self.strDescription=desc;
    
    IsSearch=YES;
    PageNumber=0;
    
    if ([transactionArray count]>0) {
        [transactionArray removeAllObjects];
    }
    
    [self.tblTransaction reloadData];
    
    self.tblTransaction.frame=CGRectMake(0, self.tblTransaction.frame.origin.y, self.tblTransaction.frame.size.width, self.tblTransaction.frame.size.height);
    
    [self getTransactionRecord];
}


-(void) delyedOpen{
    [self.navigationController popViewControllerAnimated:YES];
}
// Show Detail on View
-(void)fillCardDetail
{
    
    self.lblName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings(cardDataObj.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@ ",cardDataObj.FIRSTNAME],checkISNullStrings(cardDataObj.LASTNAME)?@"":[NSString stringWithFormat:@"%@",cardDataObj.LASTNAME]];
    
    self.lblAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(cardDataObj.AVAILABLEBALANCE))];

    
    self.lblCardNumber.text=ChangeCardNumber(cardDataObj.CARDNUMBER);
    
    
    self.lblStatus.text=CardStatusValue(self.cardDataObj.STATUS_CARDACCOUNT);

}
//method use for open date picker view
-(void)OpenDateSelector
{
    if (![DatePickerBGView isDescendantOfView:self.view])
    {
        DatePickerBGView=[[UIView alloc]initWithFrame:CGRectMake(0, IS_IPAD?IS_IOS7?60:20:IS_IOS7?60:0, 320, 480)];
        DatePickerBGView.backgroundColor=[UIColor clearColor];
        [self.view addSubview:DatePickerBGView];
        [DatePickerBGView release];
        
        if (!self.fDate)
        {
            self.fDate=[[NSString alloc]init];
        }
        
        if (!self.lDate)
        {
            self.lDate=[[NSString alloc]init];
        }
        
        if (!self.strminAmount)
        {
            self.strminAmount=[[NSString alloc]init];
        }
        
        if (!self.strMaxAmount)
        {
            self.strMaxAmount=[[NSString alloc]init];
        }
        
        if (!self.strDescription)
        {
            self.strDescription=[[NSString alloc]init];
        }
        
        
        DatePickerView *obj=[[DatePickerView alloc]initWithDatePickerViewFrame:CGRectMake(55, 10, 216, 315) delegate:self fDate:self.fDate lDate:self.lDate minimumAmount:self.strminAmount maximumAmount:self.strMaxAmount description:self.strDescription];
        [DatePickerBGView addSubview:obj];
        [obj release];

    }
}
//method use for get memo data
-(void)getMemoData :(int)index
{
    
   setteldTransaction *trnOBJ=[transactionArray objectAtIndex:index];
    
    requestID=GetMemo_data;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=GetMEmoREcord;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=%@&deCIAPrimaryAccountNumber=%@&deCIACreationDateFrom=&deCIACreationDateTo=&deTCIVRNOOFTRANSACTIONS=&deMemoUserId=%@&deMemoTranID=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.CLIENTID,cardDataObj.ACCOUNTNUMBER,[UserDetailClass sharedUser].strUserId,trnOBJ.SettledTxnTranId,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCIAMemoView];
    
    [DataReq release];
}
//method to get expense category
-(void)GetExpenseCategory
{
    
    requestID=GetExpense_data;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=GetEXpenseCategory;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&desvcBusinessAccountID=%@&desvcExpenseCategoryType=%@&deSetFlagValue_BankAct=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.PRODUCTID,@"",[SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcViewExpenseCategory];
    
    [DataReq release];
}
//cancel date picker view
-(void)DateSelectorcancel
{
    if ([DatePickerBGView isDescendantOfView:self.view])
    {
        [DatePickerBGView removeFromSuperview];
        DatePickerBGView=nil;
    }
}
//method to get transaction record
-(void)getTransactionRecord
{
    
    requestID=transactionList;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=TransactionHistory_Request;
    [SystemConfiguration sharedSystemConfig].deCIASTxnFilter=@"0";
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deCIAClientID=%@&deCIAAccountNumber=%@&deANAProductID=%@&deCIASFromDate=%@&deCIASToDate=%@&deCIASTxnFilter=%@&deCIASTxnBatchSize=%@&deCIASTxnPageIndex=%d&de_TranId_TH=&deCIASTxnHistoryType=0&deCIAMaximumTxnAmount=%@&deCIAminimumTxnAmount=%@&deCIAMerchantSearch=%@",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,self.cardDataObj.CLIENTID,self.cardDataObj.ACCOUNTNUMBER,self.cardDataObj.PRODUCTID,[NSString stringWithFormat:@"%@",(checkISNullStrings(self.fDate)?@"":[self.fDate stringByReplacingOccurrencesOfString:@"-" withString:@""])],[NSString stringWithFormat:@"%@",(checkISNullStrings(self.lDate)?@"":[self.lDate stringByReplacingOccurrencesOfString:@"-" withString:@""])],[SystemConfiguration sharedSystemConfig].deCIASTxnFilter,[NSString stringWithFormat:@"%d",BatchSizeValue],PageNumber,checkISNullStrings(self.strMaxAmount)?@"":(self.strMaxAmount),  checkISNullStrings(self.strminAmount)?@"":self.strminAmount ,checkISNullStrings(self.strDescription)?@"":strDescription] ServiceName:svcCHTransactionHistory];
    
    [DataReq release];
}

#pragma mark - Response method
//method use for get response from server
-(void)getResponce:(id)jsonData
{
    switch (requestID)
    {
        case transactionList:
        {
            if(!transactionArray)
            {
                transactionArray=[[NSMutableArray alloc]init];
            }
            
            if (IsSearch)
            {
                IsSearch=NO;
                
                [transactionArray removeAllObjects];
                if ([jsonData isKindOfClass:[NSArray class]])
                {
                    if ([jsonData count]>0)
                    {
                        [transactionArray addObjectsFromArray: jsonData];
                    }else              
                    {
                        showAlertScreen(nil, @"No record found");
                    }
                }
                else
                {
                    showAlertScreen(nil, @"No record found");
                }

            }else if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    [transactionArray addObjectsFromArray: jsonData];
                }
                
                if ([transactionArray count]==0)
                {
                    showAlertScreen(nil, @"No record found");
                }
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];

            [self.tblTransaction reloadData];
            
        }
            break;
            
        case GetMemo_data:
        {
            MemoArray=[[NSMutableArray alloc]init];
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                MemoArray=jsonData;

            }
                               
                [self GetExpenseCategory];
            
        }
            break;
            
        case GetExpense_data:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                expenseCategoryArray=jsonData;
            }
            
            setteldTransaction *obj=[transactionArray objectAtIndex:selectedTrans];
            
            TransactionDetailsViewController *tdvc = [[TransactionDetailsViewController alloc] initWithNibName:@"TransactionDetailsViewController" bundle:nil trasactiondata:obj];
            
            tdvc.memoArray=MemoArray;
            tdvc.expenseCategoryArray=expenseCategoryArray;
            
            tdvc.cardStatus=cardDataObj.STATUS_CARDACCOUNT;
            
            tdvc.SelectedRecordNumber=selectedTrans;
            [self.navigationController pushViewController:tdvc animated:YES];
            [tdvc release];
            
            [[AppDelegate sharedAppDelegate]removeLoadingView];
        }
            break;

        default:
            break;
    }
   
}

-(void)viewWillAppear:(BOOL)animated
{
     PageNumber=0;
    
    if ([self.strNavigatedFrom isEqualToString:ALERTVIEW])
    {
        [AppDelegate sharedAppDelegate].classType = ADMIN_ALERTS_PAGE;
    }
    else
    {
        [AppDelegate sharedAppDelegate].classType = CARDS_TRANSACTION_PAGE;
    }
    
    
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    
    _myTransactionView.frame=CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, 320, 110);
    self.tblTransaction.frame=CGRectMake(0, CGRectGetMaxY(_myTransactionView.frame)-5
                                         , 768,IS_IPAD?IS_IOS7?335:335:IS_IPHONE_5?335:IS_IOS7?335:335);//315
    
//    NSLog(@"%f%f%f",_myTransactionView.frame.origin.y,_myTransactionView.frame.size.height,_myTransactionView.frame.size.width);
//    NSLog(@"%f%f%f",self.tblTransaction.frame.origin.y,self.tblTransaction.frame.size.height,self.tblTransaction.frame.size.width);
    if(isViewPop == YES)
    {
        if ([transactionArray count]>0) {
            [transactionArray removeAllObjects];
        }
        
        [self.tblTransaction reloadData];
        
    [self getTransactionRecord];
    }
    [self fillCardDetail];
   
}

- (void)viewDidLoad
{
    PageNumber=0;
    
    /* If it is not navigated from Alert View */
    if (![self.strNavigatedFrom isEqualToString:ALERTVIEW])
    {
        self.cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
    }
    
    
    [AppDelegate sharedAppDelegate].classType=CARDS_TRANSACTION_PAGE;
    
    [self.tblTransaction reloadData];
    [self fillCardDetail];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
       
    if (transactionArray!=nil) {
        [transactionArray removeAllObjects];
        [transactionArray release];
        transactionArray=nil;
    }
    [_imgLogo release];
    [_lblName release];
    [_lblCardNumber release];
    [_lblStatus release];
    [_lblAmount release];
    [_tblTransaction release];
    
     [_myTransactionView release];
    [super dealloc];
}

- (void)viewDidUnload
{
    [self setImgLogo:nil];
    [self setLblName:nil];
    [self setLblCardNumber:nil];
    [self setLblStatus:nil];
    [self setLblAmount:nil];
    [self setTblTransaction:nil];
    [self setMyTransactionView:nil];
    
    self.cardDataObj=nil;
    [super viewDidUnload];
}

#pragma mark- Table View Delegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 50;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [transactionArray count];
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    tableView.separatorColor = [UIColor grayColor];
    if (indexPath.row>=(PageNumber+1)*(BatchSizeValue-1))
    {
        PageNumber++;
        [[AppDelegate sharedAppDelegate] addloadingView];
        [self getTransactionRecord];
    }
    
}
// Delegate method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	static NSString *CellIdentifier = @"Cell";
	TransactionCell *cell = (TransactionCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[TransactionCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier Delegate:self]autorelease];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    cell.contentView.backgroundColor=(indexPath.row %2 == 0)? [UIColor colorWithPatternImage:[UIImage imageNamed:@"imgCellBackground"]] : [UIColor whiteColor];
    
    
    setteldTransaction *obj=[transactionArray objectAtIndex:indexPath.row];
    
     cell.lblDate.text=ConvertDateFormatemmddyyyy(obj.SettledTxnTranTime);
     cell.lblAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(obj.Transaction_Amount))];
    
     
    
    cell.lblMemo.text=checkISNullStrings(obj.COMMENT)?@"Add Memo":obj.COMMENT;
    
    
    // Checking if COREAUTH_TRANID tag value is Null or not
    if (checkISNullStrings(obj.COREAUTH_TRANID))
    {
        if (checkISNullStrings(obj.Transaction_Description))
        {
            cell.lblMerchant.hidden=NO;
            cell.lblMerchant.text = @"";
        }else
        {
            cell.lblMerchant.hidden=NO;
            cell.lblMerchant.text=obj.Transaction_Description;
        }
    }
    else
    {
        if (checkISNullStrings(obj.CardAcceptorName_Location))
        {
            cell.lblMerchant.hidden=NO;
            cell.lblMerchant.text = @"";
        }else
        {
            cell.lblMerchant.hidden=NO;
            //TODO: Merchant City
            cell.lblMerchant.text = obj.CardAcceptorName_Location;
        }
        if (!checkISNullStrings(obj.MerchantCity)) {
            cell.lblMerchant.text = [NSString stringWithFormat:@"%@ %@",cell.lblMerchant.text,obj.MerchantCity];
        }
        
    }
    
    
    

    if (obj.transactionType == Outstanding_txn)
    {
        cell.lblStatus.text=[NSString stringWithFormat:@"(Pending)"];
        cell.lblStatus.hidden=NO;
    }else
    {
        cell.lblStatus.hidden=YES;
    }
    
    if (obj.OverLimitFlag==YES)
    {
       cell.imgOverLimit.hidden=NO;
    }else
    {
        cell.imgOverLimit.hidden=YES;
    }
    
    cell.lblTxnType.text=checkISNullStrings(obj.SPEND_CATEGORY)?@"":obj.SPEND_CATEGORY;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    if(isAlertRequest)
    {
    
    }else
    {
        isViewPop=YES;
        selectedTrans=indexPath.row;
        [self getMemoData:indexPath.row];

    }
}

@end
