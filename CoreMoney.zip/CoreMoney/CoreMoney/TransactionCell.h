//
//  TransactionCell.h


#import <UIKit/UIKit.h>

@interface TransactionCell : UITableViewCell
{
    UILabel *lblDate,*lblAmount,*lblMerchant,*lblMemo,*lblStatus,*lblTxnType;
    
    UIImageView *imgOverLimit;
}
@property(nonatomic,retain)UILabel *lblDate,*lblAmount,*lblMerchant,*lblMemo,*lblStatus,*lblTxnType;
@property (nonatomic,retain) UIImageView *imgOverLimit;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del;
@end
