//
//  EmpExpDetailView.h
//  CoreMoney
// class use for create a view for top view of employee expense view

#import <UIKit/UIKit.h>

@interface EmpExpDetailView : UIView
{
    UILabel *lblBusinessName,*lblperiod,*lblPeriodValue,*lblBusExpAmt;
    
    UILabel *lblCategory, *lblCategoryAmount, *lblEmpName, *lblEmpId, *lblEmpExpense, *lblSummraizedAmount, *lblSummraizedText, *lblSummrazidBy;
}

@property (nonatomic,retain) UILabel *lblBusinessName,*lblperiod,*lblPeriodValue,*lblBusExpAmt;

@property (nonatomic, retain)  UILabel *lblCategory, *lblCategoryAmount, *lblEmpName, *lblEmpId, *lblEmpExpense, *lblSummraizedAmount, *lblSummraizedText, *lblSummrazidBy;

- (id)initWithFrame:(CGRect)frame :(int)expenseType;
@end
