//
//  LoginResponse.h
//
// class used for get response from the server

#import <Foundation/Foundation.h>

@interface LoginResponse : NSObject<NSCoding>
{
    NSString *UserId,*firstName,*LastName,*Email;
}
@property(nonatomic,retain)NSString *UserId,*firstName,*LastName,*Email;
@end
