//
//  adminProfileData.m
//  CoreMoney
//

#import "adminProfileData.h"

@implementation adminProfileData
@synthesize  ROWID, IPADDRESS, CHECKDAY, DOB, EMAIL_ID, AddressLine1, AddressLine2, City, State, ZIPCODE, Country, AllowCookies, IPBYPASS_FLAG;
@end
