//
//  ContactUSViewController.h
//  CoreMoney
// Class use for create Contact us page

#import <UIKit/UIKit.h>
#import "MessageUI/MFMailComposeViewController.h"


@interface ContactUSViewController : UIViewController<MFMailComposeViewControllerDelegate>
@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (retain, nonatomic) IBOutlet UIView *emailView;
@property (retain, nonatomic) IBOutlet UIView *callView;
@property (retain, nonatomic) IBOutlet UILabel *lblCallusMsg;
@property (retain, nonatomic) IBOutlet UIView *emailUsMsgview;
@property (retain, nonatomic) IBOutlet UIView *contactPopView;
@property (retain, nonatomic) IBOutlet UIButton *btnHideCallPopup;
- (IBAction)tapEmailBtn:(id)sender;
- (IBAction)tapContactBtn:(id)sender;
- (IBAction)hideContactPopup:(id)sender;

@end
