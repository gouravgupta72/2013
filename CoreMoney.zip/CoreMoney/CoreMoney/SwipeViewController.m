//
//  SwipeViewController.m
//  WinePoynt


#import "SwipeViewController.h"

@interface SwipeViewController ()

@end

@implementation SwipeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(IBAction)leftSwipe:(id)sender
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO) {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
}
-(IBAction)rightSwipe:(id)sender
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==YES) {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}
- (void)viewDidLoad
{
    leftSwipe  =  [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(leftSwipe:)];
    [leftSwipe setDirection:(UISwipeGestureRecognizerDirectionLeft)];
    leftSwipe.delegate  =   self;
    [self.view addGestureRecognizer:leftSwipe];
    [leftSwipe release];

    rightSwipe  =  [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(rightSwipe:)];
    [rightSwipe setDirection:(UISwipeGestureRecognizerDirectionRight)];
    rightSwipe.delegate   =   self;
    [self.view addGestureRecognizer:rightSwipe];
    [rightSwipe release];
    
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}
-(void)cancelTouchesInView:(bool)cancel
{
    leftSwipe.cancelsTouchesInView=cancel;
    rightSwipe.cancelsTouchesInView=cancel;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
