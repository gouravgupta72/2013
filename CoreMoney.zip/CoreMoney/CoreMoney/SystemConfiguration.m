//
//  SystemConfiguration.m
//  CoreMoney


// Hold Data For Server Request.
#import "SystemConfiguration.h"
#include <ifaddrs.h>
#include <arpa/inet.h>

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

@implementation SystemConfiguration
@synthesize deCIAIPAddress, dePPVersionComments, deUsrActLogParam2, deIVRSource, deIVRIpAddress, deIVRCallerId, deIVRCalledId, deIVRRequestTime, deIVRSessionID, deDeviceId, deDBBServiceApiLevel,deDBBServiceAppID, dbbSystemExtLogin, dbbSystemSingleSignon, dbbServiceName, deSetFlagValue_BankAct,Application,deFlagShowDetails , deCIASTxnFilter;

static SystemConfiguration *systemConfigObj;

// Create Singlton Object.
+(SystemConfiguration *)sharedSystemConfig
{
    if (!systemConfigObj)
    {
        systemConfigObj=[[SystemConfiguration alloc]init];
    }
    return systemConfigObj;
}

// Initialize object.
-(id)init
{
    if (!systemConfigObj)
    {
        systemConfigObj=[super init];
    }
    self.deCIAIPAddress=@"";
    self.dePPVersionComments=@"1";
    self.deUsrActLogParam2=@"";
    self.deIVRSource=APP_SOURCE;
    self.deIVRIpAddress=@"";
    self.deIVRCallerId=@"";
    self.deIVRCalledId=@"";
    self.deIVRRequestTime=@"";
    self.deIVRSessionID=@"";
    self.deDeviceId=@"";
    self.deDBBServiceApiLevel=@"";
    self.deDBBServiceAppID=@"";
    self.dbbSystemExtLogin=@"1";
    self.dbbSystemSingleSignon=@"1";
    self.dbbServiceName=@"";
    self.deSetFlagValue_BankAct=@"0";
    self.Application=APP_SCALE_ID;
    self.deFlagShowDetails=@"0";
    self.deCIASTxnFilter=@"";
//    [self getVendorIdentifier]; // method to run application on simulator
    return systemConfigObj;
}


// Generate Vendor identifier.
-(void)getVendorIdentifier
{
    self.deDeviceId = [UIDevice currentDevice].identifierForVendor.UUIDString;
    
//    NSString *udid;
//    
//    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"6.0"))
//    {
//        udid = [UIDevice currentDevice].identifierForVendor.UUIDString;
//        
//        self.deDeviceId=udid;
//    }
//    else
//    {
//        udid = [UIDevice currentDevice].uniqueIdentifier;
//        self.deDeviceId=udid;
//    }
}


// Get system Ip address≥
- (NSString *)getIPAddress
{
    
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while(temp_addr != NULL) {
            if(temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
                
            }
            
            temp_addr = temp_addr->ifa_next;
        }
    }
    // Free memory
    freeifaddrs(interfaces);
    return address;
    
}
@end
