//
//  lowBalanceSearchDataClass.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface lowBalanceSearchDataClass : NSObject
{
    NSString *ResErrorMsg, *ACCOUNT_ACCT_ID, *BA_ACCT_ID, *SCHEDULE_TYPE;
    int ResErrorCode, ResCode;
    double AMOUNT, ThresholdAmount;
    BOOL ISACTIVE;
}

@property (nonatomic,retain)NSString *ResErrorMsg, *ACCOUNT_ACCT_ID, *BA_ACCT_ID, *SCHEDULE_TYPE;
@property int ResErrorCode, ResCode;
@property double AMOUNT, ThresholdAmount;
@property BOOL ISACTIVE;
@end
