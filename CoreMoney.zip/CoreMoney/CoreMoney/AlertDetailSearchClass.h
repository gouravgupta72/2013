//
//  AlertDetailSearchClass.h
//  CoreMoney
//

#import <Foundation/Foundation.h>

@interface AlertDetailSearchClass : NSObject
{
    NSString *strBusinessName, *strBAdminName,*strBusinessBal,*strBusinessAcount,*strCardHolderName,*strCardBal,*strAcountNumber,*strDateTime,*strActivitReason,*strstatus,*strEmpId,*strTransactinAmt,*strCardNumb,*strBusinessAcountID;
    
    NSString *AlertDate,*AlertEndDate,*ActionDate,*AlertStatus,*Cardcategory,*CardSubCategory,*CardNumber4Digit,*AccountNumber,*FirstName,*Lastname,*AvailableBal,*EmployeeId,
    *BusinessName,*FundingStatus,*CardStatus,*BusinessBal,*BAdminFirstName,*BAdminLastName,*  SpendRuleUpdate,*FundingRuleUpdate,*UpdatedBY,*UpdatedTime,*TxnRecipentAmt,*CardAccountNo,
    *RoutingNo,*TxnCountNo,*DeclineReason,*FraudType;
    
    NSString *strAlertId, *strCardNo, *strNoOfTransactionPerDay, *strProductId, *UserId, *strBankName, *strBankAccountNo, *strTxnCountry, *CardNo;
}
@property (nonatomic, retain) NSString *strAlertId, *strCardNo, *strNoOfTransactionPerDay, *strProductId, *UserId, *strBankName, *strBankAccountNo, *strTxnCountry, *CardNo;
@property (nonatomic,retain) NSString *strBusinessName, *strBAdminName,*strBusinessBal,*strBusinessAcount,*strCardHolderName,*strCardBal,*strAcountNumber,*strDateTime,*strActivitReason,*strstatus,*strEmpId,*strTransactinAmt,*strCardNumb,*strBusinessAcountID;
@property (nonatomic,retain) NSString *AlertDate,*AlertEndDate,*ActionDate,*AlertStatus,*Cardcategory,*CardSubCategory,*CardNumber4Digit,*AccountNumber,*FirstName,*Lastname,*AvailableBal,*EmployeeId,
*BusinessName,*FundingStatus,*CardStatus,*BusinessBal,*BAdminFirstName,*BAdminLastName,*  SpendRuleUpdate,*FundingRuleUpdate,*UpdatedBY,*UpdatedTime,*TxnRecipentAmt,*CardAccountNo,
*RoutingNo,*TxnCountNo,*DeclineReason,*FraudType;
@end



