//
//  ExpenseCategoryData.m
//  CoreMoney


#import "ExpenseCategoryData.h"

@implementation ExpenseCategoryData
@synthesize CATEGORY_LABEL,CATEGORY_ID, CATEGORY_TYPE,SubCatArray;

-(void)dealloc
{
    self.CATEGORY_LABEL=nil;
    [super dealloc];
}

@end
