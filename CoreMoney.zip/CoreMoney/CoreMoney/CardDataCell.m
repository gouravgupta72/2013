//
//  CardDataCell.m


// Class to design Card Data Cell.

#import "CardDataCell.h"

@implementation CardDataCell
@synthesize lblTitleName,lblCardNumber,lblStatus,lblAmount,btnState,delegate,btnView,imgArrow,lblEmployeeId,imgBackGround;
@synthesize fltImageHeight;
// Method to design the cell for Card Data.

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        delegate=del;
        // Initialization code
        
        lblTitleName=createLabel(@"", CGRectMake(10, 0, 300, 25));
        lblTitleName.font = FONT_ARIAL_18;
        lblTitleName.textAlignment = UITextAlignmentLeft;
        lblTitleName.textColor =Name_color_Code;;
        [self addSubview:lblTitleName];

        [lblTitleName release];
        
        lblEmployeeId=createLabel(@"", CGRectMake(CGRectGetMaxX(lblTitleName.frame), 0, 300, 25));
        lblEmployeeId.font = FONT_ARIAL_14;
        lblEmployeeId.textAlignment = UITextAlignmentLeft;
        lblEmployeeId.textColor =Card_no_colore_code;;
        [self addSubview:lblEmployeeId];

        [lblEmployeeId release];
        
        
        lblCardNumber=createLabel(@"", CGRectMake(10, CGRectGetMaxY(lblTitleName.frame)-7, 300, 30));
        lblCardNumber.font = FONT_ARIAL_14;
        lblCardNumber.textAlignment = UITextAlignmentLeft;
        lblCardNumber.textColor =Card_no_colore_code;
        [self addSubview:lblCardNumber];

        [lblCardNumber release];
        
        
        btnView = [[UIButton alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(lblCardNumber.frame)+3, 7, 14)];
        btnView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"imgStatusInactive"]];
        [self addSubview:btnView];
        
        [btnView release];
        
        btnState= createButton(CGRectMake(0, CGRectGetMaxY(lblCardNumber.frame)-5, 145, 20), @"", @"", self, @selector(openStatus:));
        btnState.backgroundColor=[UIColor clearColor];
        [self addSubview:btnState];

        [btnState release];
        
        lblStatus=createLabel(@"", CGRectMake(CGRectGetMaxX(btnView.frame)+5, CGRectGetMaxY(lblCardNumber.frame)-8, 170, 30));
        lblStatus.font = FONT_ARIAL_14;
        lblStatus.textAlignment = UITextAlignmentLeft;
        lblStatus.textColor =Status_Color_Code;;
        [self addSubview:lblStatus];

        [lblStatus release];
        
        
        imgArrow = [[UIImageView alloc] initWithFrame:CGRectMake(300, 32, 8, 11)];
        [imgArrow setImage:[UIImage imageNamed:@"img_arrow_home"]];
        [self addSubview:imgArrow];

        [imgArrow release];
        
        
        lblAmount=createLabel(@"", CGRectMake(200, CGRectGetMaxY(imgArrow.frame), 100, 30));
        lblAmount.font = FONT_ARIAL_16;
        lblAmount.textAlignment = UITextAlignmentRight;
        lblAmount.textColor =[UIColor blackColor];
        [self addSubview:lblAmount];

        [lblAmount release];
    }
    return self;
}


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del imageHeight:(CGFloat)imageHeight
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        delegate=del;
        // Initialization code
        self.imgBackGround = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.contentView.frame.size.width, imageHeight)];
        [self addSubview:self.imgBackGround];
        [self.imgBackGround release];
        
        lblTitleName=createLabel(@"", CGRectMake(10, 0, 300, 25));
        lblTitleName.font = FONT_ARIAL_18;
        lblTitleName.textAlignment = UITextAlignmentLeft;
        lblTitleName.textColor =Name_color_Code;;
//        [self addSubview:lblTitleName];
        [self.imgBackGround addSubview:lblTitleName];
        [lblTitleName release];
        
        lblEmployeeId=createLabel(@"", CGRectMake(CGRectGetMaxX(lblTitleName.frame), 0, 300, 25));
        lblEmployeeId.font = FONT_ARIAL_14;
        lblEmployeeId.textAlignment = UITextAlignmentLeft;
        lblEmployeeId.textColor =Card_no_colore_code;;
//        [self addSubview:lblEmployeeId];
        [self.imgBackGround addSubview:lblEmployeeId];
        [lblEmployeeId release];

        
        lblCardNumber=createLabel(@"", CGRectMake(10, CGRectGetMaxY(lblTitleName.frame)-7, 300, 30));
        lblCardNumber.font = FONT_ARIAL_14;
        lblCardNumber.textAlignment = UITextAlignmentLeft;
        lblCardNumber.textColor =Card_no_colore_code;
//        [self addSubview:lblCardNumber];
        [self.imgBackGround addSubview:lblCardNumber];
        [lblCardNumber release];
        
        
        btnView = [[UIButton alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(lblCardNumber.frame)+3, 7, 14)];
        btnView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"imgStatusInactive"]];
//        [self addSubview:btnView];
        [self.imgBackGround addSubview:btnView];
        [btnView release];
        
        btnState= createButton(CGRectMake(0, CGRectGetMaxY(lblCardNumber.frame)-5, 145, 20), @"", @"", self, @selector(openStatus:));
        btnState.backgroundColor=[UIColor clearColor];
        [self addSubview:btnState];
//        [self.imgBackGround addSubview:btnState];
        [btnState release];
        
        lblStatus=createLabel(@"", CGRectMake(CGRectGetMaxX(btnView.frame)+5, CGRectGetMaxY(lblCardNumber.frame)-8, 170, 30));
        lblStatus.font = FONT_ARIAL_14;
        lblStatus.textAlignment = UITextAlignmentLeft;
        lblStatus.textColor =Status_Color_Code;;
//        [self addSubview:lblStatus];
        [self.imgBackGround addSubview:lblStatus];
        [lblStatus release];
        
        
        imgArrow = [[UIImageView alloc] initWithFrame:CGRectMake(300, 32, 8, 11)];
        [imgArrow setImage:[UIImage imageNamed:@"img_arrow_home"]];
//        [self addSubview:imgArrow];
        [self.imgBackGround addSubview:imgArrow];
        [imgArrow release];
        
        
        lblAmount=createLabel(@"", CGRectMake(200, CGRectGetMaxY(imgArrow.frame), 100, 30));
        lblAmount.font = FONT_ARIAL_16;
        lblAmount.textAlignment = UITextAlignmentRight;
        lblAmount.textColor =[UIColor blackColor];
//        [self addSubview:lblAmount];
        [self.imgBackGround addSubview:lblAmount];
        [lblAmount release];
    }
    return self;
}
// Method to handle button pressed for changing status.
-(void)openStatus:(id)sender
{
    btnView.frame=CGRectMake(10, CGRectGetMaxY(lblCardNumber.frame)+3, 11, 7);
    btnView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"imgStatusActive"]];
    
    UIButton *tmpBtn = (UIButton *)sender;
    if ([delegate respondsToSelector:@selector(openStatusView:)]) {
        [delegate openStatusView:tmpBtn.tag];
    }
}
// Method called on selecting of the cell.
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

// Method to remove compilation error.
// Method to open the status view.
-(void)openStatusView:(int)index
{
    
}

@end
