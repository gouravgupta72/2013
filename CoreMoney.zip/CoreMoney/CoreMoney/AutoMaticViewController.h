//
//  AutoMaticViewController.h
//  CoreMoney


#import <UIKit/UIKit.h>
#import "FundingButtonView.h"
#import "CardDetailClass.h"
#import "KLCalendarView.h"
#import "CalanderSingleView.h"
#import "CustomScrollView.h"
#import "BusinessPageDetail.h"
#import "DataParsingClass.h"

@interface AutoMaticViewController : SwipeViewController<KLCalendarViewDelegate,ScrollDelegate,DataParsingDelegate>
{
   // FundingButtonView *btnLowBalance,*btnScheduleFunding;
    CardDetailClass *cardDataObj;
    UIView *comboView;
    NSMutableArray *frequencyArr;
    BOOL isScheduledViewOpen,isLowBalanceViewOpen;
    loadFrequencyType frequencyType;
    int daySelectNumber;
    NSString *strFrequency;
    BusinessPageDetail *BusinessPageObject;
    
    int RequestID;
    
    BOOL IsFirstTime;
    int dateFrequency;
    
    ScheduleFundingSearchDataClass *schedulingObj;
    lowBalanceSearchDataClass * lowBalancingObj;
}
@property (nonatomic , retain)ScheduleFundingSearchDataClass *schedulingObj;
@property (nonatomic , retain)lowBalanceSearchDataClass * lowBalancingObj;
@property (retain, nonatomic) IBOutlet UILabel *lblSetFrequency;
@property (retain, nonatomic) CardDetailClass *cardDataObj;
@property (retain, nonatomic) IBOutlet UILabel *lblUserName;
@property (retain, nonatomic) IBOutlet UILabel *lblCardNumber;
@property (retain, nonatomic) IBOutlet UILabel *lblStatus;
@property (retain, nonatomic) IBOutlet UILabel *lblBalance;
@property (retain, nonatomic) IBOutlet UIView *scheduleFundBtnView;
@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (retain, nonatomic) IBOutlet UILabel *lblSchedulBtnView;
@property (retain, nonatomic) IBOutlet UIView *lowbalnceBtnView;
@property (retain, nonatomic) IBOutlet UILabel *lblLowBalnceView;
@property (retain, nonatomic) IBOutlet UIScrollView *userdetailScrollView;
@property (retain, nonatomic) IBOutlet UILabel *lblLowBalanceTitle;
@property (retain, nonatomic) IBOutlet UILabel *lblThreshholdTitle;
@property (retain, nonatomic) IBOutlet CustomScrollView *TabScroll;
@property (retain, nonatomic) IBOutlet UIView *ScheduleFundView;
@property (retain, nonatomic) IBOutlet UIView *LowBalanceFundView;
- (IBAction)btnLoadFrequency:(id)sender;
- (IBAction)clickedBtnOutSideTouch:(id)sender;
@property (retain, nonatomic) IBOutlet UITextField *txtCardBalance;
@property (retain, nonatomic) IBOutlet UILabel *lblLoadFrequency;
@property (retain, nonatomic) IBOutlet UITextField *txtLoadAmount;
@property (retain, nonatomic) IBOutlet UITextField *txtThresholdBalance;
@property (retain, nonatomic) IBOutlet UIView *thresholdview;
@property (retain, nonatomic) IBOutlet UIView *lowbalanceView;
@property (retain, nonatomic) IBOutlet UIView *viewSetFrequence;
@property (retain, nonatomic) IBOutlet UIButton *btnOutSideTouch;

- (IBAction)clickedSchedulFundView:(id)sender;
- (IBAction)clickedLowBalView:(id)sender;
- (IBAction)setLoadFrequency:(id)sender;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil CardData:(CardDetailClass *) carddata;

@property (retain, nonatomic) IBOutlet UILabel *lblLoadAmountText;
@property (retain, nonatomic) IBOutlet UILabel *lblThresholdText;

@property (retain, nonatomic) IBOutlet UILabel *lblCardBalanceText;

- (IBAction)ClickLowBalanceFunding:(id)sender;
- (IBAction)clickScheduleFunding:(id)sender;

@end
