//
//  AdminDataClass.h
//  CoreMoney

#import <Foundation/Foundation.h>

@interface AdminDataClass : NSObject
{
    NSString *UserId, *FirstName, *LastName, *ClientName, *ClientID, *UserTypeDescription, *UserStatusDescription, *LAST_ACCESSED_AT;
    
    int UserType, UserStatus, RoleType;
}
@property (nonatomic,retain)NSString *UserId, *FirstName, *LastName, *ClientName, *ClientID, *UserTypeDescription, *UserStatusDescription, *LAST_ACCESSED_AT;
@property  int UserType, UserStatus, RoleType;

@end
