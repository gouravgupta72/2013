//
//  alertGroupCount.m
//  CoreMoney

// Class used for Keeping Alert color group data
#import "alertGroupCount.h"

@implementation alertGroupCount
@synthesize alertColorName,alertTag, alertCount;
-(void)dealloc
{
    self.alertColorName=nil;
    [super dealloc];
}
@end
