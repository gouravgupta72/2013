//
//  FundingButtonView.h
//  CoreMoney


#import <UIKit/UIKit.h>

@interface FundingButtonView : UIView
{
    UILabel *lblName;
    UIImageView *img_view;
    UIImageView *img_Arrow,*Img_view_backGround;
    
}
@property (nonatomic, retain) UILabel *lblName;
@property (nonatomic,retain) UIImageView *img_view,*img_Arrow,*Img_view_backGround;

- (id)initWithFundingButtonFrame:(CGRect)frame title:(NSString *)BtnTitle delegate:(id)del icon:(NSString *)iconImage tag:(int)value;
@end
