//
//  UserProfileDataClass.h


#import <Foundation/Foundation.h>


// Class used for hold UserProfileData.

@interface UserProfileDataClass : NSObject
{
    NSString *ADDRESS1, *BUSINESSNAME, *CITY, *COUNTRY_CODE, *CardStatus, *DATEISSUED, *DOB, *ERRMSG, *FIRSTNAME, *FaxNumber, *ID_NUMBER, *LASTNAME, *MOBILE, *NAMEONCARD, *PHONE, *PHONEEXTENSION, *POSTALCODE, *STATE, *EMAIL, *ADDRESS2, *countryName, *StateCode;
    
    BOOL CARDHOLDER_IDENTIFIED, ERROR_FOUND;
    
    double CURRENTBALANCE, CURRENT_CARD_BALANCE;
    
    int CUSTOMSPENDRULES, CardNumberLast4Digit, ERR_NUMBER, ID_CODE;
}
@property (nonatomic, retain)NSString *ADDRESS1, *BUSINESSNAME, *CITY, *COUNTRY_CODE, *CardStatus, *DATEISSUED, *DOB, *ERRMSG, *FIRSTNAME, *FaxNumber, *ID_NUMBER, *LASTNAME, *MOBILE, *NAMEONCARD, *PHONE, *PHONEEXTENSION, *POSTALCODE, *STATE, *EMAIL, *ADDRESS2 , *countryName, *StateCode;

@property BOOL CARDHOLDER_IDENTIFIED, ERROR_FOUND;

@property  double CURRENTBALANCE, CURRENT_CARD_BALANCE;

@property int CUSTOMSPENDRULES, CardNumberLast4Digit, ERR_NUMBER, ID_CODE;

@end