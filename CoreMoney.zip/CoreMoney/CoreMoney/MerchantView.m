//
//  MerchantView.m
//  CoreMoney

#import "MerchantView.h"

@implementation MerchantView
@synthesize titleName,subTitleName,DailyLimit,MonthlyLimit,btnSwitch,delegate,txtDailyLimit,txtMonthlyLimit;

- (id)initWithMerchantViewFrame:(CGRect)frame MerchantObject:(MerchantCategoryClass *)merchantCategoryObj Delegate:(id)del viewTag:(int)vTag
{
    self = [super initWithFrame:frame];
    self.delegate=del;
    self.backgroundColor=[UIColor whiteColor];
    self.tag=vTag;
    if (self) {
        if (merchantCategoryObj.tagValue==HEALTHCARE_CHILDCARE_SERVICES)
        {
            self.frame=CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, self.frame.size.height+50);
        }
        
        UILabel *lblTitle = createLabel(merchantCategoryObj.strTitle, CGRectMake(20, 0, 220, 20));
        lblTitle.textColor=[UIColor blackColor];
        lblTitle.font=FONT_ARIAL_16;
        [self addSubview:lblTitle];
        [lblTitle release];
        
        UILabel *lblSubTitle = createLabel(merchantCategoryObj.strsubTitle, CGRectMake(18, CGRectGetMaxY(lblTitle.frame), 196, 60));
        lblSubTitle.numberOfLines=4;
        lblSubTitle.textColor=[UIColor lightGrayColor];
        lblSubTitle.font=FONT_ARIAL_12;
        [self addSubview:lblSubTitle];
        [lblSubTitle release];
        
        UIButton *btnShow = createButton(CGRectMake(213, 26, 77, 27), @"", @"", self, @selector(handleCategoryObject:));
        btnShow.tag=merchantCategoryObj.tagValue;
        if (merchantCategoryObj.isEnabled==YES) {
            [btnShow setBackgroundImage:[UIImage imageNamed:@"imgExpenseYes"] forState:UIControlStateNormal];
        }
        else{
            [btnShow setBackgroundImage:[UIImage imageNamed:@"imgExpenseNo"] forState:UIControlStateNormal];
        }
        [self addSubview:btnShow];
        [btnShow release];
        
        UILabel *title = createLabel(@"Daily Limit", CGRectMake(20, CGRectGetMaxY(lblSubTitle.frame), 88, 20));
        title.textColor=[UIColor lightGrayColor];
        title.font=FONT_ARIAL_14;
        [self addSubview:title];
        [title release];
        
        title = createLabel(@"Monthly Limit", CGRectMake(162, CGRectGetMaxY(lblSubTitle.frame), 103, 20));
        title.textColor=[UIColor lightGrayColor];
        title.font=FONT_ARIAL_14;
        [self addSubview:title];
        [title release];
        
        UIView *imgBack = [[UIView alloc] initWithFrame:CGRectMake(18, CGRectGetMaxY(title.frame)+10, 113, 40)];
        imgBack.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_inputbg_Expense"]];
        [self addSubview:imgBack];
        [imgBack release];
        
        self.txtDailyLimit = [[UITextField alloc] initWithFrame:CGRectMake(0,5, 97, 30)];
        self.txtDailyLimit.delegate=self;
        self.txtDailyLimit.tag=vTag;
        self.txtDailyLimit.returnKeyType=UIReturnKeyNext;
        self.txtDailyLimit.keyboardType=UIKeyboardTypeNumberPad;
        [imgBack addSubview:self.txtDailyLimit];
        [txtDailyLimit release];
        
        imgBack = [[UIView alloc] initWithFrame:CGRectMake(162, CGRectGetMaxY(title.frame)+10, 113, 40)];
        imgBack.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_inputbg_Expense"]];
        [self addSubview:imgBack];
        [imgBack release];
        
        self.txtMonthlyLimit = [[UITextField alloc] initWithFrame:CGRectMake(0,5, 97, 30)];
        self.txtMonthlyLimit.delegate=self;
        self.txtMonthlyLimit.tag=vTag;
        self.txtMonthlyLimit.returnKeyType=UIReturnKeyDone;
        self.txtMonthlyLimit.keyboardType=UIKeyboardTypeNumberPad;
        [imgBack addSubview:self.txtMonthlyLimit];
        [self.txtMonthlyLimit release];
        
        
        UIImageView *imgLineView = [[UIImageView alloc] initWithFrame:CGRectMake(9, 160, 284, 1)];
        imgLineView.image=[UIImage imageNamed:@"img_Line_FUID"];
        [self addSubview:imgLineView];
        [imgLineView release];
        
        if (merchantCategoryObj.tagValue==HEALTHCARE_CHILDCARE_SERVICES) {
            UIButton *btnSubmit = createButton(CGRectMake(20, CGRectGetMaxY(imgLineView.frame)+20, 90, 35), @"Submit", @"imgButtonPurple", self, @selector(submitCategory));
            [self addSubview:btnSubmit];
            [btnSubmit release];
        }
    }
    return self;
}
-(void)submitCategory
{
    if ([delegate conformsToProtocol:@protocol(MerchantViewdlegate) ]) {
        if ([delegate respondsToSelector:@selector(submitData)]) {
            [delegate submitData];
        }
    }
}
-(void)handleCategoryObject:(id)sender
{
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isEqual:self.txtDailyLimit])
    {
        if ([delegate conformsToProtocol:@protocol(MerchantViewdlegate) ]) {
            if ([delegate respondsToSelector:@selector(getTextValue:Tag:)]) {
                [delegate getTextValue:self.txtDailyLimit.text Tag:0];
            }
        }
    }
    else if ([textField isEqual:self.txtMonthlyLimit])
    {
        if ([delegate conformsToProtocol:@protocol(MerchantViewdlegate) ]) {
            if ([delegate respondsToSelector:@selector(getTextValue:Tag:)]) {
                [delegate getTextValue:self.txtMonthlyLimit.text Tag:1];
            }
        }
        
    }
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if ([textField isEqual:self.txtDailyLimit])
    {
        if ([delegate conformsToProtocol:@protocol(MerchantViewdlegate) ]) {
            if ([delegate respondsToSelector:@selector(settingScrollPosition:)]) {
                [delegate settingScrollPosition:textField.tag];
            }
        }
    }
    else if ([textField isEqual:self.txtMonthlyLimit])
    {
        if ([delegate conformsToProtocol:@protocol(MerchantViewdlegate) ]) {
            if ([delegate respondsToSelector:@selector(settingScrollPosition:)])
            {
                [delegate settingScrollPosition:textField.tag];
            }
        }

    }
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return YES;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
