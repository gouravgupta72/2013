//
//  HelpMenu.h

//

// Class For Design Help Menu .

#import <UIKit/UIKit.h>
#import "HelpMenuItem.h"



@interface HelpMenu : UIView
{
    HelpMenuItem *helpMenuItemObj;
    UIButton *btnSliderOpen;
    
    UIView *MenuItemView;
    UIView *firstGroupedView,*secondGroupedView;
    UIScrollView *scroll;
    NSMutableArray *DataArray;
    int page,clickCount;
    NSTimer* autoHideTimer;
    id delegatelogin;
    id delegateReg;
}

@property (nonatomic, assign) id delegatelogin;
@property (nonatomic, assign) id delegateReg;
@end
@protocol languageSelectDelegat <NSObject>

-(void) changeLaguageAtlogin;

@end
@protocol languageSelectRegisterDelegate <NSObject>

-(void) changeLaguageAtRegister;

@end