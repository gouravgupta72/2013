//
//  TransferViewController.m
//  CoreMoney
// class use for Transfer Detail


#import "TransferViewController.h"
#import "ReviewTransferView.h"
#import "ComboViewController.h"
#define ALERTVIEW @"AlertView"
@interface TransferViewController ()

-(void)openBack;
-(void)openSlide;
- (IBAction)clickedBtnInitiateTransfer:(id)sender;
- (IBAction)clickedBtnReviewTransfer:(id)sender;
- (IBAction)clickedBtnInitial:(id)sender;
-(void) selectQuetion:(id) que;
-(void) removeComboView;
-(void) setOfset;
-(void) openComboView:(transferMethodType) isBank;
- (IBAction)openBankNameCombo:(id)sender;
- (IBAction)openTransferTypeCombo:(id)sender;

@end

@implementation TransferViewController
@synthesize strLastViewCtrl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        addNavigationBar(TRANSFER_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        
        transferTypeArr =[[NSMutableArray alloc] init];
        
        [transferTypeArr addObject:@"Fund CoreMoney Account"];
        [transferTypeArr addObject:@"Withdraw CoreMoney Account"];
        // Custom initialization
    }
    return self;
}

// Pop to previous View
-(void)openBack
{
    if ([self.strLastViewCtrl isEqualToString:ALERTVIEW])
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        requestId = back_homeTransfer;
        [self requestForTransfer];
    }
}
// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

-(BOOL)checkBlankField
{
 
    if ([self.lblSelectedBankName.text isEqualToString:@""] || [self.lblSelectedBankName.text isEqualToString:@"Select Bank Name"]) {
        showAlertScreen(nil, @"Bank Name can't be blank");
        return YES;
    }else if ([self.lblSelectedBankNumber.text isEqualToString:@""] || [self.lblSelectedBankNumber.text isEqualToString:@"Select Bank Account Number"])
    {
        showAlertScreen(nil, @"Bank Number can't be blank");
        return YES;
    }else if ([self.txtInitiatAmt.text isEqualToString:@""] || [self.txtInitiatAmt.text doubleValue]<=0 )
    {
        showAlertScreen(nil, @"Initiate amount cann't be empty or Zero");
        return YES;
    }
    return NO;
}

-(void)requestForTransfer
{
    
    ExternalBankDataClass *bankList;
    
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    for (int i=0; i<[[AppDelegate sharedAppDelegate].ArraybankList count]; i++)
    {
        bankList=[[AppDelegate sharedAppDelegate].ArraybankList objectAtIndex:i];
        
        if ([bankList.Bank_Name isEqualToString:self.lblSelectedBankName.text])
        {
            break;
        }
    }
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    switch (requestId)
    {
        case ADD_TRANSFER:
        {
            
            if ([self checkBlankField])
            {
                [[AppDelegate sharedAppDelegate] removeLoadingView];
                return ;
            }   
            
            [SystemConfiguration sharedSystemConfig].dbbServiceName=Transfer_To_business_REquest;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&ExtLogin=1&deRoutingNumber_BankAct=%@&deBABussinessAccAcctId=&deBAAmountToTransferBiz=%@&deRecipientID_BankAct=%@&deProductid=%@&deExternalBankAccountNumber_API=%@&deBACreditDebitIndicator=%@&deBAExternalBankName=%@&deBAACHUserName=%@&deAccountTransferType=0&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,bankList.RoutingNumber,self.txtInitiatAmt.text,bankList.RecipientID,BusinessPageObject.BusinessName,[self.lblSelectedBankNumber.text stringByReplacingOccurrencesOfString:@" " withString:@""],(([self.lblSelectedTransfType.text isEqualToString:@"Fund CoreMoney Account"])?@"C":([self.lblSelectedTransfType.text isEqualToString:@"Withdraw CoreMoney Account"])?@"D":@""),bankList.Bank_Name,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource];
            [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcBAFundAcctOneTimeFunding];

        }
            break;
            
            case REFRESH_TRANSFER_LIST:
        {
            
            
            [SystemConfiguration sharedSystemConfig].dbbServiceName=ViewTransferDetail_Request;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [Datareq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deBABussinessAccAcctId=&deProductid=%@&deTCIVRNOOFTRANSACTIONS=&deTCIVRLASTTRANSACTION=&deBAOriginSource=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.BusinessName,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBAViewTransferDetail];

        }
            break;
         case back_homeTransfer:
        {
                       
            [SystemConfiguration sharedSystemConfig].dbbServiceName=Business_Search_Request;
            [SystemConfiguration sharedSystemConfig].deFlagShowDetails=@"1";
            [Datareq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPProductParent=&deBusinessName=&deCIASDDANumber=&deAADAccountNumber=&dePPCardStatus=&deCIASFirstName=&deCIASLastName=&deCIAAddressLine1=&deCIAAddressLine2=&deCIASCity=&deCIASState=&deCIASCountry=&deCIASZipCode=&deBSAcctId=&deFlagShowDetails=%@&deRequestBatchSize=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].deFlagShowDetails,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBusinessAccountSearch];
            
            

        }
            break;
        default:
            break;
    }
        
    [Datareq release];

}
//method use for get response from server
-(void)getResponce:(id)jsonData
{
    switch (requestId)
    {
        case ADD_TRANSFER:
        {
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                LoginResponceDataClass *obj=(LoginResponceDataClass *)jsonData;
                
                if (!obj.Error_Found)
                {
                    [self resetView];
                    
                    requestId=REFRESH_TRANSFER_LIST;
                    
                    [self requestForTransfer];
                }
                showAlertScreen(nil, obj.ErrorMsg);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case REFRESH_TRANSFER_LIST:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]==0)
                {
                    
                }else
                {
                    if (![AppDelegate sharedAppDelegate].Arraytransfer)
                    {
                        [AppDelegate sharedAppDelegate].Arraytransfer=[[NSMutableArray alloc]init];
                    }else
                    {
                        [[AppDelegate sharedAppDelegate].Arraytransfer removeAllObjects];
                    }
                    
                    [AppDelegate sharedAppDelegate].Arraytransfer=jsonData;
             
                }
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
            [self.reInitializeTableView reloadData];
        }
            break;
            
            case change_Status:
        {
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                LoginResponceDataClass *obj=(LoginResponceDataClass *)jsonData;
                
                if (!obj.Error_Found)
                {
                    TransferDetailDataClass *obj=[[AppDelegate sharedAppDelegate].Arraytransfer objectAtIndex:selectedTransfer];
                    obj.Status_Desc=@"Delete";
                    obj.Status=10;
                    [[AppDelegate sharedAppDelegate].Arraytransfer replaceObjectAtIndex:selectedTransfer withObject:obj];
                    [self.reInitializeTableView reloadData];
                }
                showAlertScreen(nil, obj.ErrorMsg);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case back_homeTransfer:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            if ([jsonData isKindOfClass:[NSArray class]]) {
                
                if (![AppDelegate sharedAppDelegate].arrBusinessData)
                {
                    [AppDelegate sharedAppDelegate].arrBusinessData=[[NSMutableArray alloc] init];
                }
                else
                {
                    [[AppDelegate sharedAppDelegate].arrBusinessData removeAllObjects];
                }
                [AppDelegate sharedAppDelegate].arrBusinessData=jsonData;
                [self.navigationController popViewControllerAnimated:YES];
            }
            else
            {
                showAlertScreen(@"", @"No records found");
            }
            

        }
            break;
        default:
            break;
    }
    
}
//method use for resetting view
-(void)resetView
{
    
    self.lblSelectedBankName.textColor=[UIColor grayColor];
    self.lblSelectedBankNumber.textColor=[UIColor grayColor];
    self.lblSelectedTransfType.textColor=[UIColor grayColor];

    self.txtInitiatAmt.text=@"";
    self.lblSelectedBankName.text=@"Select Bank Name";
    self.lblSelectedBankNumber.text=@"Select Bank Account Number";
    self.lblSelectedTransfType.text=@"Select Transfer Type";
    
}
- (void)viewDidLoad
{
    

    self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, 320, 480);
    self.reviewTransferView.frame= CGRectMake(0, 0,320,390);
    self.initialView.frame = CGRectMake(10, 14, 300, 330);
    
    self.initialView.layer.borderWidth = 1;
    self.initialView.layer.borderColor = [UIColor grayColor].CGColor;
    self.initialView.layer.cornerRadius = 8;
    
    self.lblTopMsg.center = CGPointMake(self.initialView.frame.origin.x+25+self.lblTopMsg.frame.size.width/2, self.initialView.frame.origin.y);
    
    self.img_InitialBtnView.image = [UIImage imageNamed:@"leftTabAct.png"];
    //self.img_ReviewBtnView.image = [UIImage imageNamed:@"img_btnTansferdisable.png"];
    self.pageScroll.contentSize = CGSizeMake(self.pageScroll.frame.size.width, 500);
    [self.pageScroll addSubview:self.initialView];
    [self.pageScroll addSubview:self.lblTopMsg];
    self.btnInitialSubmit.hidden = NO;
    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void) viewWillAppear:(BOOL)animated
{
    
    
    [self shortBankName];
    
    /* If this controller is navigated from AlertView Controller */
    if ([strLastViewCtrl isEqualToString:ALERTVIEW])
    {
        [self setViewUI];
        [self showInitiateTransferView];
        [AppDelegate sharedAppDelegate].classType = ADMIN_ALERTS_PAGE;
    }
    else
    {
        [AppDelegate sharedAppDelegate].classType = TRANSFER_PAGE;
        if ([AdminAccessInfo AdminAcess].initiateTransferValue == INITIATETRANSFER && [AdminAccessInfo AdminAcess].viewTransferValue != VIEWTRANSFER) {
            [self setViewUI];
            [self showInitiateTransferView];
        }
        if ([AdminAccessInfo AdminAcess].initiateTransferValue != INITIATETRANSFER && [AdminAccessInfo AdminAcess].viewTransferValue == VIEWTRANSFER) {
            [self setViewUI];
            [self showReviewTransferView];
        }
    }
}

//method use for set view
-(void) setViewUI
{
    // Hide the Buttons from the View
    self.btnInitiateTransfer.hidden = YES;
    self.btnReviewTransfer.hidden = YES;
    
    // Hide the Labels from the View
    self.lblInitiatBtnTitle.hidden = YES;
    self.lblReviewBtnTitle.hidden = YES;
    
    // Hide the Image Views from the View
    self.img_InitialBtnView.hidden = YES;
    self.img_ReviewBtnView.hidden = YES;
    
    // Hide the initial transfer label
    self.lblTopMsg.hidden = YES;
    
    // Reposition the Scroll View
    [self.pageScroll setFrame:CGRectMake(0, 10, self.pageScroll.frame.size.width, self.pageScroll.frame.size.height)];
}

// This Method will only display the Initiate Transfer View to the user
-(void) showInitiateTransferView
{
    [self.pageScroll addSubview:self.initialView];
     self.btnInitialSubmit.hidden = NO;
}

// This Method will only display the Review Transfer View to the user
-(void) showReviewTransferView
{
     [self.pageScroll addSubview:self.reviewTransferView];
     self.btnInitialSubmit.hidden = YES;
}

-(void)shortBankName
{
    if (!bankNameArr) {
        bankNameArr = [[NSMutableArray alloc]init];
    }else
    {
        [bankNameArr removeAllObjects];
    }
    
    ExternalBankDataClass *obj;
    
    for (int i = 0; i <[[AppDelegate sharedAppDelegate].ArraybankList count] ; i++)
    {
        obj=[[AppDelegate sharedAppDelegate].ArraybankList objectAtIndex:i];
        
        int j=0;
        
        for (j=0; j<[bankNameArr count]; j++)
        {
            
         ExternalBankDataClass  *obj2=[bankNameArr objectAtIndex:j];
            if ([obj.Bank_Name isEqualToString:obj2.Bank_Name])
            {
                break;
            }
        }
        if (j== [bankNameArr count])
        {
            [bankNameArr addObject:obj];
        }
    }
    
    if ([bankNameArr count]==0)
    {
        ExternalBankDataClass  *obj2=[[ExternalBankDataClass alloc]init];
        obj2.ResCode=12;
        [bankNameArr addObject:obj2];
        [obj2 release];

    }
}

-(void)shortBankNumber :(NSString *)bankName
{
    
    if (!bankNumberArr)
    {
        bankNumberArr = [[NSMutableArray alloc]init];
    }else
    {
        [bankNumberArr removeAllObjects];
    }
    
    for (int i = 0; i <[[AppDelegate sharedAppDelegate].ArraybankList count] ; i++)
    {
      ExternalBankDataClass *obj=[[AppDelegate sharedAppDelegate].ArraybankList objectAtIndex:i];
        
        if ([obj.Bank_Name isEqualToString:bankName])
        {
            [bankNumberArr addObject:obj];
        }
    }
    
    if ([bankNumberArr count]>0)
    {
            [self openComboView:BANK_NUMBER];
    }


}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    
    if (bankNumberArr !=nil) {
        [bankNumberArr removeAllObjects];
        [bankNumberArr release];
        bankNumberArr=nil;
    }
    
 
    
    if (bankNameArr !=nil) {
        [bankNameArr removeAllObjects];
        [bankNameArr release];
        bankNameArr=nil;
    }
    
    if (transferTypeArr !=nil) {
        [transferTypeArr removeAllObjects];
        [transferTypeArr release];
        transferTypeArr=nil;
    }
    
    [_btnInitiateTransfer release];
    [_btnReviewTransfer release];
    [_pageScroll release];
    [_initialView release];
    [_lblTopMsg release];
    [_btnInitialSubmit release];
    [_img_InitialBtnView release];
    [_img_ReviewBtnView release];
    [_reviewTransferView release];
    [_lblInitiatDollAmt release];
    [_lblInitiatBankName release];
    [_lblInitiateTransfType release];
    [_txtInitiatAmt release];
    [_lblSelectedBankName release];
    [_lblSelectedTransfType release];
    [_lblInitiatBtnTitle release];
    [_lblReviewBtnTitle release];
    [_lblBankNUmber release];
    [_lblSelectedBankNumber release];
    [_reInitializeTableView release];
    [_bgView release];
    [super dealloc];
}

- (void)viewDidUnload {
    [self setBtnInitiateTransfer:nil];
    [self setBtnReviewTransfer:nil];
    [self setPageScroll:nil];
    [self setInitialView:nil];
    [self setLblTopMsg:nil];
    [self setBtnInitialSubmit:nil];
    [self setImg_InitialBtnView:nil];
    [self setImg_ReviewBtnView:nil];
    [self setReviewTransferView:nil];
    [self setLblInitiatDollAmt:nil];
    [self setLblInitiatBankName:nil];
    [self setLblInitiateTransfType:nil];
    [self setTxtInitiatAmt:nil];
    [self setLblSelectedBankName:nil];
    [self setLblSelectedTransfType:nil];
    [self setLblInitiatBtnTitle:nil];
    [self setLblReviewBtnTitle:nil];
    [self setLblBankNUmber:nil];
    [self setLblSelectedBankNumber:nil];
    [self setReInitializeTableView:nil];
    [self setBgView:nil];
    [super viewDidUnload];
}

#pragma -mark UITextField Method
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
        
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return digitValidationOnNumKeyboard(textField,range,string);
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    textField.text=[NSString stringWithFormat:@"%0.2f",changeTextToAmount(textField.text)];
}

- (IBAction)clickedBtnInitiateTransfer:(id)sender {
    
    self.img_InitialBtnView.image = [UIImage imageNamed:@"leftTabAct.png"];
   // self.img_ReviewBtnView.image = [UIImage imageNamed:@"img_btnTansferdisable.png"];
    self.btnInitialSubmit.hidden = NO;
     self.pageScroll.contentSize = CGSizeMake(320, 500);
    [self.reviewTransferView removeFromSuperview];
    
    [self.pageScroll addSubview:self.initialView];
    [self.pageScroll addSubview:self.lblTopMsg];
    
}

- (IBAction)clickedBtnReviewTransfer:(id)sender {
    
    self.img_InitialBtnView.image = [UIImage imageNamed:@"rightTabAct.png"];
   // self.img_ReviewBtnView.image = [UIImage imageNamed:@"img_btnTansferEnableR.png"];
    
    [self.pageScroll addSubview:self.reviewTransferView];
    self.pageScroll.contentSize = self.reviewTransferView.frame.size;
    
    self.btnInitialSubmit.hidden = YES;
    
    [self.lblTopMsg removeFromSuperview];
    [self.initialView removeFromSuperview];

}
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)even
{
    [self removeComboView];
}

- (IBAction)clickedBtnInitial:(id)sender
{
    requestId=ADD_TRANSFER;
    if (![self checkBlankField])
    {
        [self requestForTransfer];
    }
    
}

-(void) selectQuetion:(id) que
{
    [self removeComboView];
    [self setOfset];
    switch (transferMethod) {
        case BANK_NAME:
        {
            if ([que isKindOfClass:[ExternalBankDataClass class]])
            {
                ExternalBankDataClass *obj=(ExternalBankDataClass *)que;
                self.lblSelectedBankName.textColor = [UIColor blackColor] ;
                self.lblSelectedBankName.text = obj.Bank_Name;
            }
        }
            break;
        case BANK_NUMBER:
        {
            
            if ([que isKindOfClass:[ExternalBankDataClass class]])
           {
            ExternalBankDataClass *obj=(ExternalBankDataClass *)que;
            self.lblSelectedBankNumber.textColor = [UIColor blackColor] ;
            self.lblSelectedBankNumber.text = obj.BankAccountNumber;
           }
            
        }
            break;
        case TRANSFER_TYPE:
        {
            self.lblSelectedTransfType.textColor = [UIColor blackColor] ;
            self.lblSelectedTransfType.text = que;
        }
            break;

        default:
            break;
    }
    
}


// method remove combo view
-(void) removeComboView{
    
    [self setOfset];
    if (comboView) {
        [comboView removeFromSuperview];
        [comboView release];
        comboView = nil;
    }
}

// set page in previouse position
-(void) setOfset
{
    [self.pageScroll setContentSize:CGSizeMake(CGRectGetMaxX(self.pageScroll.frame),500)];
    
    self.pageScroll.contentOffset=CGPointMake(0, 0);
    
    [self.txtInitiatAmt resignFirstResponder];
    
    
}


//method create combo view
-(void) openComboView:(transferMethodType ) isBank{
    self.pageScroll.contentSize = CGSizeMake(CGRectGetMaxX(self.pageScroll.frame), CGRectGetMaxY(self.pageScroll.frame)+30);
    comboView = [[UIView alloc] initWithFrame:self.bgView.frame];
    comboView.backgroundColor = [UIColor clearColor];
    [self.bgView addSubview:comboView];
    transferMethod = isBank;
    switch (isBank) {
        case BANK_NAME:{
//             self.pageScroll.contentOffset=CGPointMake(0, IS_IPAD?-5:12);
            ComboViewController *cmv;
            if ([self.strLastViewCtrl isEqualToString:ALERTVIEW])
            {
                cmv = [[ComboViewController alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(self.lblSelectedBankName.frame)+22, 280, 190) records:bankNameArr callingClassType:other];
            }
            else
            {
                cmv = [[ComboViewController alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(self.lblSelectedBankName.frame)+52, 280, 190) records:bankNameArr callingClassType:other];
            }
            cmv.delegate = self;
            cmv.comboType=BankName_Combo;
            [comboView addSubview:cmv];
            [cmv release];
           

        }
            break;
        case TRANSFER_TYPE:{
             
            ComboViewController *cmv;
            if ([self.strLastViewCtrl isEqualToString:ALERTVIEW])
            {
                cmv = [[ComboViewController alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(self.lblSelectedTransfType.frame)+20, 280, 140) records:transferTypeArr callingClassType:other];
            }
            else
            {
                self.pageScroll.contentOffset=CGPointMake(0, IS_IPAD?35:60);
                cmv = [[ComboViewController alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(self.lblSelectedTransfType.frame)-3, 280, 140) records:transferTypeArr callingClassType:other];
            }
            cmv.delegate = self;
            [comboView addSubview:cmv];
            [cmv release];
           

            
        }
            break;
        case BANK_NUMBER:
        {
            ComboViewController *cmv;
            if ([self.strLastViewCtrl isEqualToString:ALERTVIEW])
            {
                cmv = [[ComboViewController alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(self.lblSelectedBankNumber.frame)+20, 280, 140) records:bankNumberArr callingClassType:other];
            }
            else
            {
                self.pageScroll.contentOffset=CGPointMake(0, IS_IPAD?5:20);
                cmv = [[ComboViewController alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(self.lblSelectedBankNumber.frame)+35, 280, 140) records:bankNumberArr callingClassType:other];
            }
            cmv.delegate = self;
            cmv.comboType=BankNumber_Combo;
            [comboView addSubview:cmv];
            [cmv release];
            
            
        }
            break;
            
        default:
            break;
    }
    
}

-(void)changeTransferStatus_request :(int)tag
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    requestId=change_Status;
    
    int flag = 2;
    
    TransferDetailDataClass *transferObj=[[AppDelegate sharedAppDelegate].Arraytransfer objectAtIndex:tag];
    
    if ([transferObj.Status_Desc isEqualToString:@"Request"] || transferObj.Status==0)
    {
        DataParsingClass *Datareq=[[DataParsingClass alloc] init];
        Datareq.Datadelegate=self;
        [SystemConfiguration sharedSystemConfig].dbbServiceName=Complete_Delete_transfer_req;
        [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
        
        NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&&deBTSFlag=%d&deDDHRequestId=%@&deDirectDebitHistoryTraceNumber=&deDDHTranid=%@",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,flag,transferObj.RequestId,transferObj.DDHTranId];
        [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcBACompleteDeleteAchTxn];
        
        [Datareq release];

    }else
    {
        showAlertScreen(nil, @"Selected record Status should be Request. Please select another record");
        [[AppDelegate sharedAppDelegate] removeLoadingView];
    }
    
    
}
//method use for open a combo view for bank names
- (IBAction)openBankNameCombo:(id)sender {
    
    self.lblSelectedBankNumber.text=@"Select Bank Account Number";
    self.lblSelectedBankNumber.textColor=[UIColor grayColor];
    [self openComboView:BANK_NAME];
    
}
//method use for open a combo view for Transfer types
- (IBAction)openTransferTypeCombo:(id)sender {
    
    [self openComboView:TRANSFER_TYPE];
}
//method use for open a combo view for bank number
- (IBAction)openBankNumbCombo:(id)sender
{
    [self shortBankNumber:self.lblSelectedBankName.text];
    
}
//method use for change status of transfer
-(void)ChangeTransferStatus :(id)sender
{
    
    UIButton *tmp=(UIButton *)sender;
    
    selectedTransfer=tmp.tag;
    
    showAlertWithOtherButtons(nil, @"Do you want to cancel Transfer ?", 0, self);
    
    
    
}
#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
       [self changeTransferStatus_request:selectedTransfer];
    }
    else
    {
        [[AppDelegate sharedAppDelegate] removeLoadingView];
    }
}

#pragma mark- Table View Delegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
//delegate method use for setting height of row
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 60;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [[AppDelegate sharedAppDelegate].Arraytransfer count];
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    tableView.separatorColor = [UIColor grayColor];
    
}
// Delegate method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"Cell";
	ReviewTransferView *cell = (ReviewTransferView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[ReviewTransferView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier Delegate:self];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    TransferDetailDataClass *reviewObj = [[AppDelegate sharedAppDelegate].Arraytransfer objectAtIndex:indexPath.row];
    
    cell.bankName.text = reviewObj.Bank_Name;
    CGSize textSize = [[cell.bankName text] sizeWithFont:[cell.bankName font]];
    
    CGFloat strikeWidth = textSize.width;
    
    if(strikeWidth >cell.bankName.frame.size.width){
        cell.bankName.numberOfLines = 2;
        cell.bankName.frame = CGRectMake(10, 5, 150, 35);
        strikeWidth = 150;
    }
    cell.lblCardNumber.frame =  CGRectMake(15+strikeWidth, 5, 120, 18);
    cell.lblCardNumber.text = reviewObj.BankAccountNumber;
    cell.indate.text = reviewObj.AddedOnDate;
    cell.lblBal.text =  [NSString stringWithFormat:@"%@", displayCurrency(ChangeTocurrency(reviewObj.TransactionAmount))];
    
    
    
    if (reviewObj.FundAvailableDate != nil)
    {
                cell.lblCompdate.text =  reviewObj.FundAvailableDate;
                cell.lblCompdate.hidden = NO;
    }
    cell.lblstatus.text = reviewObj.Status_Desc;
    
    if(reviewObj.Status==10)
    {
        cell.btnChangeStatus.enabled=NO;
    }else
    {
        cell.btnChangeStatus.enabled=YES;
    }
    cell.btnChangeStatus.tag = indexPath.row;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
   
    
}


@end
