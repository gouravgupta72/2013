//
//  TransferViewController.h
//  CoreMoney
// class use for Transfer Detail

#import <UIKit/UIKit.h>
#import "TransferDetailDataClass.h"

@interface TransferViewController : SwipeViewController<UITableViewDataSource,UITableViewDelegate,DataParsingDelegate>
{
    UIView *comboView;
    BOOL isBankComboopen;
    NSMutableArray *bankNameArr,*transferTypeArr,*bankNumberArr;
    NSMutableArray *reviewDataArray;
    transferMethodType transferMethod;
    int requestId, selectedTransfer;
    NSString *strLastViewCtrl;
}
@property (nonatomic, retain) NSString *strLastViewCtrl;
@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (retain, nonatomic) IBOutlet UILabel *lblReviewBtnTitle;
@property (retain, nonatomic) IBOutlet UIImageView *img_InitialBtnView;
@property (retain, nonatomic) IBOutlet UIImageView *img_ReviewBtnView;
@property (retain, nonatomic) IBOutlet UIButton *btnInitiateTransfer;
@property (retain, nonatomic) IBOutlet UIScrollView *pageScroll;
@property (retain, nonatomic) IBOutlet UIButton *btnReviewTransfer;
@property (retain, nonatomic) IBOutlet UIView *initialView;
@property (retain, nonatomic) IBOutlet UIButton *btnInitialSubmit;
@property (retain, nonatomic) IBOutlet UIView *reviewTransferView;
@property (retain, nonatomic) IBOutlet UILabel *lblTopMsg;
@property (retain, nonatomic) IBOutlet UILabel *lblInitiatDollAmt;
@property (retain, nonatomic) IBOutlet UILabel *lblInitiatBankName;
@property (retain, nonatomic) IBOutlet UILabel *lblInitiateTransfType;
@property (retain, nonatomic) IBOutlet UITextField *txtInitiatAmt;
@property (retain, nonatomic) IBOutlet UILabel *lblSelectedBankName;
@property (retain, nonatomic) IBOutlet UILabel *lblSelectedTransfType;
@property (retain, nonatomic) IBOutlet UILabel *lblInitiatBtnTitle;
@property (retain, nonatomic) IBOutlet UILabel *lblBankNUmber;
@property (retain, nonatomic) IBOutlet UITableView *reInitializeTableView;
@property (retain, nonatomic) IBOutlet UILabel *lblSelectedBankNumber;
@end
