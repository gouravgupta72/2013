//
//  UserIdValidationClass.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface UserIdValidationClass : NSObject
{
    NSString *ERRMSG;
    BOOL ERROR_FOUND;
    int ERR_NUMBER;
}
@property(nonatomic,retain)NSString *ERRMSG;
@property BOOL ERROR_FOUND;
@property int ERR_NUMBER;
@end
