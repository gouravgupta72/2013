//
//  EmployeeExpenseViewController.m
//  CoreMoney
// Class use for create employee expense list

#import "EmployeeExpenseViewController.h"
#import "EmpExpDetailView.h"
#import "PopUpView.h"
#import "ComboViewController.h"
#import "expenseAnalyisCell.h"

//#define MYPLUGIN_ERROR_DOMAIN @"MyPluginErrorDomain"
#define TEXT_CATEGORY  @"Category"
#define TEXT_SUB  @"Sub"
#define TEXT_EMPLOYEE  @"Employee"
#define TEXT_CURRENTWEEK @"Current Week"
#define TEXT_LASTWEEK @"Last Week"
#define TEXT_CURRENTMONTH  @"Current Month"
#define TEXT_LASTMONTH  @"Last Month"
#define TEXT_LASTQUARTER  @"Last Quarter"
#define TEXT_TODAY  @"Todays"


// List For Business Employee
#define TEXT_DAY @"Day"
#define TEXT_WEEK @"Week"
#define TEXT_MONTH @"Month"
#define TEXT_QUARTER @"Quarter"
#define TEXT_SUMMARIZEDBY @"SummarizedBy"


@interface EmployeeExpenseViewController ()

-(void)openBack; // Method to go back to Previous view Controller
-(void)opensearch; // Method to Open the Search View
-(void)openSlide; // Open Slider Menu
// Setting the gray Color for Labels for Search
-(void)setFilterDefault;

// Setting the black Color for Date Labels
-(void)setFiletSelectedDate;

// method use for create top view
-(void) addTopView;

// Method to Add the Table View
-(void)addTableView;

// Method to Re Create the Top View
-(void)recreateTopView;

// Method to Set the Value to the Labels
-(void)setValues;

// This method is used to Create the Request
-(void)makeRequest;

// Set the View according to the Filter of the User
-(void)setViewAccordingFilter;

// Remove the Search Pop Up View
-(void) removePopView;

// Remove calander view
-(void) removeCalanderView;

// Set Filter For Expense Category
-(void)setExpenseCategoryFilter;

// Create a request URL and Send it to DataParsingClass
-(void)getEmployeeExpenseRequest;

// Creating for fetching Expense Category
-(void)getExpenseCategoryRequest;

// Creating Request for Fetching Employees List
-(void)getEmployeeListRequest;

// Creating Request for Fetching Expense Category
-(void)GetExpenseCategory;

// Method to make and send the query from Employee By Expense when the user click on the filter button
-(void) getEmployeByExpenseCategory;

// Method for Submitting the Date
-(BOOL)SubmitDate;

// Resetting all the Business Filter
-(void)resetBusinessFilter;



@end

#pragma mark - Variables Declaration
BOOL isRecordFound = YES;
BOOL isDateSelected = NO;


BOOL isDateChanged = NO;

@implementation EmployeeExpenseViewController

@synthesize empExpData;
@synthesize strDateTo, strDateFrom, strPeriodText;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil empDataArray:(NSMutableArray *)EmpDataArray analysisType:(int)pageType businessListArray:(NSMutableArray *)arrayBusiness categoryArray:(NSMutableArray *)catArray
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
//        NSLog(@"%d",[self.empExpData.employeeExpenseArray count]);
        AnalysisType=pageType;
        
        localPageAnalysis=AnalysisType;
        
        tableAnalysisType=AnalysisType;
        
        businessListArray=arrayBusiness;
        
        switch (AnalysisType)
        {
            case Employee_analysis:
            {
                addNavigationBar(EMP_EXPENSE_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);                
            }
                break;
            case Employee_Business_Expense:
            {
               addNavigationBar(Business_Expense_Title, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
            }
                break;
            case Employee_by_Expense_analysis:
            {
               addNavigationBar(Employee_Expense_category_Title, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
            }
                break;
            case Employee_Expense_Category:
            {
               addNavigationBar(Expense_category_Title, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
            }
                break;
                
            default:
                break;
        }
/*
 
 */
        periodType = EMP_THIS_MONTHS;
        
        empArray = EmpDataArray;
//        NSLog(@"%d", [empArray count]);
        categoryArray=catArray;
        
        periodArr = [[NSMutableArray alloc] init];
        if (AnalysisType == Employee_Business_Expense) {
           
        }
       
        [periodArr addObject:TEXT_CURRENTWEEK];
        [periodArr addObject:TEXT_LASTWEEK];
        [periodArr addObject:TEXT_CURRENTMONTH];
        [periodArr addObject:TEXT_LASTMONTH];
        [periodArr addObject:TEXT_LASTQUARTER];
        [periodArr addObject:TEXT_TODAY];        
    }
    return self;
}

// Method to go to Previous View Controller
-(void)openBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

// Method to Open the Search View
-(void)opensearch
{
    popView = [[UIView alloc] initWithFrame:self.view.frame];
//    popView.backgroundColor = [UIColor greenColor];
    
    [self.view addSubview:popView];
    
    self.filterView.frame = CGRectMake(15,IS_IPAD?IS_IOS7?-20:20:IS_IOS7?60:0, self.filterView.frame.size.width, self.filterView.frame.size.height);
//    self.filterView.backgroundColor = [UIColor redColor];
    [popView addSubview:self.filterView];
    
    
    [self checkEmpSelection];
    
    [self setFilterDefault];//:@"%@",];
    if (!self.strPeriodText) {

        self.strPeriodText = self.lblSelectPeriod.text;
    }
    else
    {
        self.strPeriodText = self.lblSelectPeriod.text;
    }
    if (!self.strDateFrom) {

        self.strDateFrom = self.lblSelectdateFrom.text;
    }
    else
    {
        self.strDateFrom = self.lblSelectdateFrom.text;
    }
    if (!self.strDateTo)
    {

        self.strDateTo = self.lblSelectDateTo.text;
    }
    else
    {
        self.strDateTo = self.lblSelectDateTo.text;
    }
    isDateChanged = isDateSelected;
    
}

// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

// Setting the gray Color for Labels for Search
-(void)setFilterDefault
{
    if (isDateSelected)
    {
        self.lblSelectdateFrom.textColor=[UIColor blackColor];
        self.lblSelectDateTo.textColor=[UIColor blackColor];
        self.lblSelectPeriod.textColor=[UIColor grayColor];
    }
    else
    {
        self.lblSelectdateFrom.textColor=[UIColor grayColor];
        self.lblSelectDateTo.textColor=[UIColor grayColor];
        self.lblSelectPeriod.textColor=[UIColor blackColor];
    }
//    self.lblSelectdateFrom.textColor=[UIColor grayColor];
//    self.lblSelectDateTo.textColor=[UIColor grayColor];
//    self.lblSelectPeriod.textColor=[UIColor blackColor];
}

// Setting the black Color for Date Labels
-(void)setFiletSelectedDate
{
    if (isDateSelected)
    {
        self.lblSelectdateFrom.textColor=[UIColor blackColor];
        self.lblSelectDateTo.textColor=[UIColor blackColor];
        self.lblSelectPeriod.textColor=[UIColor grayColor];
    }
    else
    {
        self.lblSelectdateFrom.textColor=[UIColor grayColor];
        self.lblSelectDateTo.textColor=[UIColor grayColor];
        self.lblSelectPeriod.textColor=[UIColor blackColor];
    }
//    self.lblSelectdateFrom.textColor=[UIColor blackColor];
//    self.lblSelectDateTo.textColor=[UIColor blackColor];
//    self.lblSelectPeriod.textColor=[UIColor grayColor];
}


// method use for create top view
-(void) addTopView
{
    switch (AnalysisType)
    {
        case Employee_analysis:
        {
            tableAnalysisType=Employee_analysis;
            if ([recordArray count]>0)
            {
                [recordArray removeAllObjects];
            }
            if (self.empExpData.employeeExpenseArray) {
                recordArray=self.empExpData.employeeExpenseArray;
            }
            
            self.topScrollview.frame=CGRectMake(0, 0, 320, 60);
             empExpView = [[EmpExpDetailView alloc] initWithFrame:self.topScrollview.frame:localPageAnalysis];
            [self.topScrollview addSubview:empExpView];
            [empExpView release];

        }
            break;
        case Employee_Business_Expense:
        {
            tableAnalysisType=Employee_Business_Expense;
            
            if ([recordArray count]>0)
            {
                [recordArray removeAllObjects];
            }
            if (self.empExpData.employeeExpenseArray) {
                recordArray=self.empExpData.employeeExpenseArray;
            }
            
            self.topScrollview.frame=CGRectMake(0, 0, 320, 80);
            empExpView = [[EmpExpDetailView alloc] initWithFrame:self.topScrollview.frame:localPageAnalysis];
            [self.topScrollview addSubview:empExpView];
             [empExpView release];

        }
            break;
        case Employee_by_Expense_analysis:
        {
            
            if ([recordArray count]>0)
            {
                [recordArray removeAllObjects];
            }
            if (self.empExpData.employeeExpenseArray) {
                recordArray=self.empExpData.employeeExpenseArray;
            }
            
            tableAnalysisType=Employee_Expense_Category;
            localPageAnalysis=Employee_by_Expense_analysis;
            self.topScrollview.frame=CGRectMake(0, 0, 320, 80);
            empExpView = [[EmpExpDetailView alloc] initWithFrame:(self.topScrollview.frame):localPageAnalysis];
            empExpView.lblEmpId.hidden = YES;
            empExpView.lblEmpName.hidden = YES;
            empExpView.lblEmpExpense.hidden = YES;
//            [self.topScrollview setBackgroundColor:[UIColor redColor]];
            [self.topScrollview addSubview:empExpView];
            [empExpView release];

        }
            break;
        case Employee_Expense_Category:
        {
         
            if ([recordArray count]>0)
            {
                [recordArray removeAllObjects];
            }
            if (self.empExpData) {
                recordArray=self.empExpData.employeeExpenseArray;
            }
            

            tableAnalysisType=Employee_by_Expense_analysis;
            localPageAnalysis=Employee_Expense_Category;
            
            self.topScrollview.frame=CGRectMake(0, 0, 320, 80);
            empExpView = [[EmpExpDetailView alloc] initWithFrame:self.topScrollview.frame:localPageAnalysis];
            [self.topScrollview addSubview:empExpView];
            [empExpView release];
        }
            break;
            
        default:
            break;
    }
    
    empExpView.frame=CGRectMake(0,IS_IPAD?IS_IOS7?empExpView.frame.origin.y:empExpView.frame.origin.y:IS_IOS7?empExpView.frame.origin.y-60:empExpView.frame.origin.y,  empExpView.frame.size.width,  empExpView.frame.size.height);
    
    [self setValues];
    [self addTableView];
}

// Method to Add the Table View
-(void)addTableView
{
    if ([ExpenseRecordObj isDescendantOfView:self.view])
    {
        [ExpenseRecordObj removeFromSuperview];
        ExpenseRecordObj=nil;
    }
    // Call a Table Creation class with the flag of Employee Search and Category Search
    if (searchByEmployee && !searchByCategory)
    {
        tableAnalysisType = Employee_by_Expense_analysis;
        empExpView.lblEmpExpense.hidden = NO;
        
        employeeExpData *dataObj = nil;
        // Fetch the object at specified position from record Array
        if ([recordArray count] > 0)
        {
            dataObj = [recordArray objectAtIndex:0];
        }
        
        double dblEmployeeExpenseAmount = 0;
        for (int arrCount = 0; arrCount < [dataObj.arrEmployeCatDescExpense count]; arrCount ++)
        {
            ExpenseCategory *objExpenseCat = [dataObj.arrEmployeCatDescExpense objectAtIndex:arrCount];
            dblEmployeeExpenseAmount += objExpenseCat.expense;
        }
        empExpView.lblEmpExpense.text = [NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dblEmployeeExpenseAmount))];
        ExpenseRecordObj = [[expenseRecordView alloc] initwithExpenseRecordFrame:CGRectMake(0, CGRectGetMaxY(self.topScrollview.frame), 320,480-self.topScrollview.frame.size.height-50) analysisType:tableAnalysisType dataArray:dataObj.arrEmployeCatDescExpense period:periodType searchForEmployee:YES searchForCategory:NO];
    }
    else if (!searchByEmployee && searchByCategory)
    {
        tableAnalysisType = Employee_analysis;
        ExpenseRecordObj = [[expenseRecordView alloc] initwithExpenseRecordFrame:CGRectMake(0, CGRectGetMaxY(self.topScrollview.frame), 320,480-self.topScrollview.frame.size.height-50) analysisType:tableAnalysisType dataArray:recordArray period:periodType searchForEmployee:NO searchForCategory:YES];
    }
    else if (searchByEmployee && searchByCategory)
    {
        tableAnalysisType = Employee_by_Expense_analysis;
        
        employeeExpData *dataObj = nil;
        // Fetch the object at specified position from record Array
        if ([recordArray count] > 0)
        {
            dataObj = [recordArray objectAtIndex:0];
        }
        
        ExpenseRecordObj = [[expenseRecordView alloc] initwithExpenseRecordFrame:CGRectMake(0, CGRectGetMaxY(self.topScrollview.frame), 320,480-self.topScrollview.frame.size.height-50) analysisType:tableAnalysisType dataArray:dataObj.arrEmployeCatDescExpense period:periodType searchForEmployee:YES searchForCategory:NO];
    }
    else  // Call with the default option
    {
        ExpenseRecordObj = [[expenseRecordView alloc] initwithExpenseRecordFrame:CGRectMake(0, CGRectGetMaxY(self.topScrollview.frame)+5, 320,480-self.topScrollview.frame.size.height-50) analysisType:tableAnalysisType dataArray:recordArray period:periodType searchForEmployee:searchByEmployee searchForCategory:searchByCategory];
    }

    [self.bgView addSubview:ExpenseRecordObj];
    [ExpenseRecordObj release];
    
    searchByEmployee = NO;
    searchByEmployee = NO;
}

// Method to Re Create the Top View
-(void)recreateTopView
{
    if ([empExpView isDescendantOfView:self.view])
    {
        [empExpView removeFromSuperview];
        empExpView=nil;
    }
    
    switch (localPageAnalysis)
    {
        case Employee_analysis:
        {
            self.topScrollview.frame=CGRectMake(0, 0, 320, 60);
            
            if (![self.lblSelectEmployee.text isEqualToString:@"Employee"])
            {
                self.topScrollview.frame=CGRectMake(0, 0, 320, 80);
                empExpView = [[EmpExpDetailView alloc] initWithFrame:(self.topScrollview.frame):localPageAnalysis];
                
                
                empExpView.lblEmpName.hidden = NO;
                empExpView.lblEmpExpense.hidden = NO;
            }
            else
            {
                empExpView = [[EmpExpDetailView alloc] initWithFrame:(self.topScrollview.frame):localPageAnalysis];
            }
            [self.topScrollview addSubview:empExpView];
            [empExpView release];
            
        }
            break;
        case Employee_Business_Expense:
        {
            self.topScrollview.frame=CGRectMake(0, 0, 320, 80);
            empExpView = [[EmpExpDetailView alloc] initWithFrame:self.topScrollview.frame:localPageAnalysis];
            [self.topScrollview addSubview:empExpView];
            [empExpView release];
            
        }
            break;
        case Employee_by_Expense_analysis:
        {
            self.topScrollview.frame=CGRectMake(0, 0, 320, 80);
            
            if ([self.lblSelectEmployee.text isEqualToString:@"Employee"] && ![self.lblSubCategory.text isEqualToString:@"Sub"])
            {
                empExpView = [[EmpExpDetailView alloc] initWithFrame:(self.topScrollview.frame):localPageAnalysis];
                empExpView.lblEmpName.hidden = YES;
                empExpView.lblEmpExpense.hidden = YES;
                empExpView.lblEmpId.hidden = YES;
            }
            else if (![self.lblSelectEmployee.text isEqualToString:@"Employee"] && [self.lblSubCategory.text isEqualToString:@"Sub"])
            {
                self.topScrollview.frame=CGRectMake(0, 0, 320, 100);
                empExpView = [[EmpExpDetailView alloc] initWithFrame:(self.topScrollview.frame):localPageAnalysis];
            }
            else if ([self.lblSelectEmployee.text isEqualToString:@"Employee"] && [self.lblSubCategory.text isEqualToString:@"Sub"])
            {
                empExpView = [[EmpExpDetailView alloc] initWithFrame:(self.topScrollview.frame):localPageAnalysis];
                empExpView.lblEmpName.hidden = YES;
                empExpView.lblEmpExpense.hidden = YES;
                empExpView.lblEmpId.hidden = YES;                
            }
            else if(![self.lblSelectEmployee.text isEqualToString:@"Employee"] && ![self.lblSubCategory.text isEqualToString:@"Sub"])
            {
                self.topScrollview.frame=CGRectMake(0, 0, 320, 100);
                empExpView = [[EmpExpDetailView alloc] initWithFrame:(self.topScrollview.frame):localPageAnalysis];
            }
            
            [self.topScrollview addSubview:empExpView];
            [empExpView release];
        }
            break;
        case Employee_Expense_Category:
        {
            self.topScrollview.frame=CGRectMake(0, 0, 320, 80);
            empExpView = [[EmpExpDetailView alloc] initWithFrame:self.topScrollview.frame:localPageAnalysis];
            [self.topScrollview addSubview:empExpView];
            [empExpView release];
        }
            break;
            
        default:
            break;
    }
    
    self.topScrollview.contentSize=CGSizeMake(self.topScrollview.frame.size.width, self.topScrollview.frame.size.height);
    
    
    empExpView.frame=CGRectMake(0,IS_IPAD?IS_IOS7?empExpView.frame.origin.y:empExpView.frame.origin.y:IS_IOS7?empExpView.frame.origin.y-60:empExpView.frame.origin.y,  empExpView.frame.size.width,  empExpView.frame.size.height);

    [self setValues];
    [self addTableView];
    
    // If any record is Available than employee amount and summarized amount label will be shown else they will be hidden
    if (!isRecordFound)
    {
        empExpView.lblEmpExpense.hidden = YES;
        empExpView.lblSummraizedAmount.hidden = YES;
        isRecordFound = YES;
    }
}


// Method to Set the Value to the Labels
-(void)setValues
{
    empExpView.lblBusinessName.text=SelectedBusinessName;
    
    // if From Date and To Date is selected than lblPeriodValue will display that dates
    // else it will going to display Perios value from combo box from pop up View
    if (isDateSelected)
    {
        empExpView.lblPeriodValue.text = [NSString stringWithFormat:@"%@ %@",self.lblSelectdateFrom.text,self.lblSelectDateTo.text];
    }
    else
    {
        empExpView.lblPeriodValue.text=strPeriod;
    }
    empExpView.lblBusExpAmt.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(self.empExpData.CardSpendTotal))];
    if (localPageAnalysis == Employee_by_Expense_analysis)
    {
        ExpenseCategoryData *obj = nil;
        if ([categoryArray count] > 0) {
           obj = [categoryArray objectAtIndex:0];
        }
        

        empExpView.lblCategory.text =  [NSString stringWithFormat:@"%@%@",checkISNullStrings(strCategory)?(checkISNullStrings(obj.CATEGORY_LABEL)?@"":obj.CATEGORY_LABEL):([strCategory isEqualToString:@"Category"]?(checkISNullStrings(obj.CATEGORY_LABEL)?@"":obj.CATEGORY_LABEL):strCategory),([self.lblSubCategory.text isEqualToString:@"Sub"]?@"":[NSString stringWithFormat:@", %@",self.lblSubCategory.text])];
        
        empExpView.lblEmpName.text = [NSString stringWithFormat:@"%@%@",strEmpName,checkISNullStrings(selectedEmpId)?@"":@","];
        empExpView.lblEmpId.text = checkISNullStrings(selectedEmpId)?@"":[NSString stringWithFormat:@" %@",selectedEmpId];
        double dblTextWidth = getTextWidth(empExpView.lblEmpName.text, empExpView.lblEmpName.font);
        [empExpView.lblEmpName setFrame:(dblTextWidth < 170?CGRectMake(10, empExpView.lblEmpName.frame.origin.y, dblTextWidth, 20):CGRectMake(10, empExpView.lblEmpName.frame.origin.y, 170, 20))];
        [empExpView.lblEmpId setFrame:CGRectMake(CGRectGetMaxX(empExpView.lblEmpName.frame), empExpView.lblEmpId.frame.origin.y, CGRectGetMinX(empExpView.lblEmpExpense.frame)-CGRectGetMaxX(empExpView.lblEmpName.frame), 20)];
        
    }
    else if(localPageAnalysis == Employee_Expense_Category)
    {
        ExpenseCategoryData *obj = nil;
        if ([categoryArray count] > 0) {
            obj = [categoryArray objectAtIndex:0];
        }
        empExpView.lblCategory.text =  [NSString stringWithFormat:@"%@%@",checkISNullStrings(strCategory)?(checkISNullStrings(obj.CATEGORY_LABEL)?@"":obj.CATEGORY_LABEL):([strCategory isEqualToString:@"Category"]?(checkISNullStrings(obj.CATEGORY_LABEL)?@"":obj.CATEGORY_LABEL):strCategory),([self.lblSubCategory.text isEqualToString:@"Sub"]?@"":[NSString stringWithFormat:@", %@",self.lblSubCategory.text])];
    }
    else if(localPageAnalysis == Employee_analysis)
    {

        empExpView.lblEmpId.hidden = NO;
       
        empExpView.lblEmpName.text = [NSString stringWithFormat:@"%@%@",strEmpName,checkISNullStrings(selectedEmpId)?@"":@","];
        empExpView.lblEmpId.text = checkISNullStrings(selectedEmpId)?@"":[NSString stringWithFormat:@" %@",selectedEmpId];
        
        double dblTextWidth = getTextWidth(empExpView.lblEmpName.text, empExpView.lblEmpName.font);
        [empExpView.lblEmpName setFrame:(dblTextWidth < 170?CGRectMake(10,CGRectGetMaxY( empExpView.lblperiod.frame), dblTextWidth, 20):CGRectMake(10, empExpView.lblEmpName.frame.origin.y, 170, 20))];
        [empExpView.lblEmpId setFrame:CGRectMake(CGRectGetMaxX(empExpView.lblEmpName.frame),CGRectGetMaxY( empExpView.lblperiod.frame), CGRectGetMaxX(empExpView.lblEmpExpense.frame)-CGRectGetMaxX(empExpView.lblEmpName.frame), 20)];

    }
    else
    {
        empExpView.lblSummraizedAmount.text = [NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(self.empExpData.CardSpendTotal))];
        empExpView.lblSummrazidBy.text = strSelectedSummarizedBy.length > 0?strSelectedSummarizedBy:@"Day";
    }
    
}
-(void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    switch (AnalysisType)
    {
        case Employee_analysis:
        {
            [AppDelegate sharedAppDelegate].classType = EXP_EMPLOYEE_PAGE;
        }
            break;
        case Employee_Business_Expense:
        {
            if ([empArray count] > 0) {
                [empArray removeAllObjects];
            }
            [empArray addObject:TEXT_DAY];
            [empArray addObject:TEXT_WEEK];
            [empArray addObject:TEXT_MONTH];
            [empArray addObject:TEXT_QUARTER];
            self.lblSelectEmployee.text = TEXT_SUMMARIZEDBY;
            [AppDelegate sharedAppDelegate].classType = EXP_BUSINESS_EXP_PAGE;
        }
            break;
        case Employee_by_Expense_analysis:
        {
            [AppDelegate sharedAppDelegate].classType = EXP_EMP_BY_EXPENSE_PAGE;
        }
            break;
        case Employee_Expense_Category:
        {
           [AppDelegate sharedAppDelegate].classType = EXP_EXPENSE_CAT_PAGE;
        }
            break;
            
        default:
            break;
    }

}

- (void)viewDidLoad
{
    self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0 , self.bgView.frame.size.width, self.bgView.frame.size.height);
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    empExpView.lblBusinessName.text=BusinessPageObject.Business_ID_Desc;
    
    selectedBusinessId=BusinessPageObject.BusinessName;
    SelectedBusinessName=BusinessPageObject.Business_ID_Desc;
    OwningPartnerTag=BusinessPageObject.OwningPartner;

    
    strPeriod = TEXT_CURRENTMONTH;
    strEmpName = TEXT_EMPLOYEE;

    
    self.lblSelectdateFrom.text=getStringFromDate(returnDate([NSDate date],CurrentMonth_First));
    self.lblSelectDateTo.text=getStringFromDate([NSDate date]);
    self.lblSelectPeriod.text=TEXT_CURRENTMONTH;
    self.lblBusinessNameFilter.text=SelectedBusinessName;
    periodType=EMP_THIS_MONTHS;

    [self addTopView ];
    
    if (AnalysisType== Employee_Expense_Category)
    {
        [self setExpenseCategoryFilter];
    }else if (AnalysisType!=Employee_by_Expense_analysis)
    {
        [self collapseFilter];
    }
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)dealloc
{
    empExpView = nil;
    strFromDate = nil;
    strToDate = nil;
    strEmpName = nil;
    strCategory = nil;
    strSubCategory = nil;
    strPeriod = nil;
    empExpData = nil;
    empObj = nil;
    selectedEmpId = nil;
    SelectedBusinessName = nil;
    selectedBusinessId = nil;
    OwningPartnerTag = nil;
    

    [_bgView release];
    [_topScrollview release];
    [_lblfilterTitle release];
    [_lblPeriod release];
    [_lblSelectPeriod release];
    [_lblSelectdateFrom release];
    [_lblSelectDateTo release];
    [_lblSelectEmployee release];
    [_filterView release];
    [_secondComboView release];
    [_imgFilterBackground release];
    [_btnCancle release];
    [_btnSubmit release];
    [_lblSelectedCategory release];
    [_lblSubCategory release];
    [_btnEmpClear release];
    [_btnCategoryClear release];
    [_lblBusinessNameFilter release];
    [_businessFilterView release];

    [_employeeView release];
    [super dealloc];
}

- (void)viewDidUnload {
    [self setBgView:nil];
    [self setTopScrollview:nil];
    [self setLblfilterTitle:nil];
    [self setLblPeriod:nil];
    [self setLblSelectPeriod:nil];
    [self setLblSelectdateFrom:nil];
    [self setLblSelectDateTo:nil];
    [self setLblSelectEmployee:nil];
    [self setFilterView:nil];
    [self setSecondComboView:nil];
    [self setImgFilterBackground:nil];
    [self setBtnCancle:nil];
    [self setBtnSubmit:nil];
    [self setLblSelectedCategory:nil];
    [self setLblSubCategory:nil];
    [self setBtnEmpClear:nil];
    [self setBtnCategoryClear:nil];
    [self setLblBusinessNameFilter:nil];
    [self setBusinessFilterView:nil];

    [self setEmployeeView:nil];
    [super viewDidUnload];
}

// Method Calls when user click on Cancel button of the Search View
- (IBAction)canclePopView:(id)sender
{
    self.lblSelectPeriod.text = self.strPeriodText ;
    self.lblSelectdateFrom.text = self.strDateFrom;
    self.lblSelectDateTo.text = self.strDateTo;
    isDateSelected = isDateChanged;
    
  [self removePopView];
}
#pragma mark - Response Methods
//Delegate methods of request class to get error

// Delegate Method of Data Parsing which get Call when any response is receives
// Delegate methods of request class to get response data
-(void)getResponce:(id)jsonData
{
    switch (requestId) {
        case report_list:
        {
            if ([jsonData isKindOfClass:[employeeExpenseDataClass class]])
            {
                employeeExpenseDataClass *expObj=(employeeExpenseDataClass *)jsonData;
                if ([expObj.employeeExpenseArray count]==0)
                {
                    showAlertScreen(nil, @"No record Found..");
                    isRecordFound = NO;
                }else
                {
                    self.empExpData=expObj;
                }
                
                if ([recordArray count]>0)
                {
                    [recordArray removeAllObjects];
                }
                if ([expObj.employeeExpenseArray count] > 0) {
                    recordArray=expObj.employeeExpenseArray;
                }
            
                
            }else
            {
                if ([recordArray count]>0)
                {
                    [recordArray removeAllObjects];
                }
//                recordArray=expObj.employeeExpenseArray;
                showAlertScreen(nil, jsonData);
            }
            
            [self setViewAccordingFilter];
            [self removePopView];
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
            case emp_List_Req:
        {
            if ([empArray count]>0)
            {
                [empArray removeAllObjects];
            }
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                empArray=jsonData;
            }
            [self GetExpenseCategory];
        }
            break;
            case category_list_req:
        {
            if ([categoryArray count]>0) {
                [categoryArray removeAllObjects];
            }
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                categoryArray=jsonData;
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case Employee_Business_Expense:
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            break;
        default:
            break;
    }
    

}

// This method is used to Create the Request
-(void)makeRequest
{
    switch (AnalysisType)
    {
        case Employee_analysis:  // For the case of Employee
        {
            
            [[AppDelegate sharedAppDelegate] addloadingView];
            [self getEmployeeExpenseRequest];
        }
            break;
        case Employee_Business_Expense:
        {
            [self getBusinessExpense];
        }
            break;
        case Employee_by_Expense_analysis:
        {
            // In case of Employee By Expense
            // When we click on search button (from top navigation bar)
            [self getEmployeByExpenseCategory];
        }
            break;
        case Employee_Expense_Category:
        {
            [[AppDelegate sharedAppDelegate] addloadingView];
            [self getExpenseCategoryRequest];
        }
            break;
            
        default:
            break;
    }
}

// Set the View according to the Filter of the User
-(void)setViewAccordingFilter
{
    switch (AnalysisType)
    {
        case Employee_analysis:
            {
                empExpView.lblPeriodValue.text=strPeriod;
                [self recreateTopView];
            }
            break;
        case Employee_Business_Expense:
            {
                empExpView.lblPeriodValue.text=strPeriod;
                tableAnalysisType=Employee_Business_Expense;
                [self recreateTopView];
            }
            break;
        case Employee_by_Expense_analysis:
            {
                empExpView.lblPeriodValue.text=strPeriod;
                
                if (![strEmpName isEqualToString:TEXT_EMPLOYEE])
                {
                    tableAnalysisType=Employee_by_Expense_analysis;
                    localPageAnalysis=Employee_by_Expense_analysis;
                    [self recreateTopView];
                }else if (![strCategory isEqualToString:TEXT_CATEGORY])
                {
                    localPageAnalysis=Employee_by_Expense_analysis;
                    if ([strSubCategory isEqualToString:TEXT_SUB]) {
                        tableAnalysisType = Employee_Expense_Category;
                    }
                    else
                    {
                        tableAnalysisType = Employee_analysis;
                    }
                    [self recreateTopView];
                }else
                {
                    tableAnalysisType=Employee_Expense_Category;
                    localPageAnalysis=Employee_by_Expense_analysis;
                    [self recreateTopView];
                }
            }
            break;
            case Employee_Expense_Category:
            {
                empExpView.lblPeriodValue.text=strPeriod;
                     localPageAnalysis=Employee_Expense_Category;
                     tableAnalysisType=Employee_by_Expense_analysis;
                [self recreateTopView];
            }
            break;
            
        default:
            break;
    }
}

// Remove the Search Pop Up View
-(void) removePopView
{
    if (popView)
    {
        [popView removeFromSuperview];
        popView = nil;
    }
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if([comboView isDescendantOfView:popView])
    {
        [self removeComboView];
    }
}

- (IBAction)tapCalanderFrom:(id)sender
{
    if (!calendrObj)
    {
//         [self setFiletSelectedDate];
        isFirstDate=YES;
        calendrObj=[[CalanderView alloc]initWithCalanderFrame:CGRectMake(54, 62, 216, 315) Delegate:self backGroundColor:[UIColor whiteColor] date:self.lblSelectdateFrom.text];
        [popView addSubview:calendrObj];
        [calendrObj release];
    }
}

- (IBAction)tapCalanderTo:(id)sender
{
    if (!calendrObj)
    {
//         [self setFiletSelectedDate];
        isFirstDate=NO;
        calendrObj=[[CalanderView alloc]initWithCalanderFrame:CGRectMake(54, 62, 216, 315) Delegate:self backGroundColor:[UIColor whiteColor] date:self.lblSelectDateTo.text];
        [popView addSubview:calendrObj];
        [calendrObj release];
    }

}

-(void) calanderCancelDelegate
{
    [self removeCalanderView];
    
}

// Remove calander view
-(void) removeCalanderView
{
    if (calendrObj)
    {
        [calendrObj removeFromSuperview];
        calendrObj = nil;
    }
}


    // Date Changed Method
-(void)PickDate:(id)sender
{
    if ([calendrObj isDescendantOfView:popView])
    {
        [calendrObj removeFromSuperview];
        calendrObj=nil;
    }
    if (isFirstDate)
    {
        self.lblSelectdateFrom.text=sender;
    }else
    {
        self.lblSelectDateTo.text=sender;
    }
    isDateSelected = YES;
    [self setFilterDefault];
    
}

-(void)collapseFilter
{
    self.secondComboView.hidden=YES;
    
    self.filterView.frame=CGRectMake(self.filterView.frame.origin.x,IS_IOS7?self.filterView.frame.origin.y+60:self.filterView.frame.origin.y , self.filterView.frame.size.width, self.filterView.frame.size.height-65);

    self.businessFilterView.frame=CGRectMake(self.businessFilterView.frame.origin.x, self.businessFilterView.frame.origin.y-5, self.businessFilterView.frame.size.width, self.businessFilterView.frame.size.height);
    
    self.employeeView.frame=CGRectMake(self.employeeView.frame.origin.x, self.employeeView.frame.origin.y+5, self.employeeView.frame.size.width, self.employeeView.frame.size.height);
    
    self.lblfilterTitle.frame=CGRectMake(self.lblfilterTitle.frame.origin.x, self.lblfilterTitle.frame.origin.y-5, self.lblfilterTitle.frame.size.width, self.lblfilterTitle.frame.size.height);
    
    self.btnSubmit.frame=CGRectMake(self.btnSubmit.frame.origin.x, self.btnSubmit.frame.origin.y-60, self.btnSubmit.frame.size.width, self.btnSubmit.frame.size.height);
    
    self.btnCancle.frame=CGRectMake(self.btnCancle.frame.origin.x, self.btnCancle.frame.origin.y-60, self.btnCancle.frame.size.width, self.btnCancle.frame.size.height);
}


// Set Filter For Expense Category
-(void)setExpenseCategoryFilter
{
    self.secondComboView.hidden=NO;
    
    self.secondComboView.frame=CGRectMake(self.secondComboView.frame.origin.x, self.secondComboView.frame.origin.y-55, self.secondComboView.frame.size.width, self.secondComboView.frame.size.height);
    
    self.businessFilterView.frame=CGRectMake(self.businessFilterView.frame.origin.x, self.businessFilterView.frame.origin.y-5, self.businessFilterView.frame.size.width, self.businessFilterView.frame.size.height);

    self.lblfilterTitle.frame=CGRectMake(self.lblfilterTitle.frame.origin.x, self.lblfilterTitle.frame.origin.y-5, self.lblfilterTitle.frame.size.width, self.lblfilterTitle.frame.size.height);

    
    self.employeeView.hidden=YES;
    
    self.filterView.frame=CGRectMake(self.filterView.frame.origin.x,IS_IOS7? self.filterView.frame.origin.y+60: self.filterView.frame.origin.y, self.filterView.frame.size.width, self.filterView.frame.size.height-70);
    
    self.btnSubmit.frame=CGRectMake(self.btnSubmit.frame.origin.x, self.btnSubmit.frame.origin.y-65, self.btnSubmit.frame.size.width, self.btnSubmit.frame.size.height);
    
    self.btnCancle.frame=CGRectMake(self.btnCancle.frame.origin.x, self.btnCancle.frame.origin.y-65, self.btnCancle.frame.size.width, self.btnCancle.frame.size.height);
}


-(void)checkEmpSelection
{
    switch (AnalysisType)
    {
        case Employee_Business_Expense:
        {
            if (![self.lblSelectEmployee.text isEqualToString:TEXT_SUMMARIZEDBY])
            {
                self.btnEmpClear.hidden=NO;
            }else
            {
                self.btnEmpClear.hidden=YES;
            }
        }
            break;
        case Employee_analysis:
        {
            if (![self.lblSelectEmployee.text isEqualToString:TEXT_EMPLOYEE])
            {
                self.btnEmpClear.hidden=NO;
            }else
            {
                self.btnEmpClear.hidden=YES;
            }
        }
            break;
            
        default:
        {
            if (![self.lblSelectEmployee.text isEqualToString:TEXT_EMPLOYEE])
            {
                self.btnEmpClear.hidden=NO;
            }else
            {
                self.btnEmpClear.hidden=YES;
            }
        }
            break;
    }
    
    if (![self.lblSelectedCategory.text isEqualToString:TEXT_CATEGORY])
    {
        self.btnCategoryClear.hidden=NO;
    }else{
        self.btnCategoryClear.hidden=YES;
        
    }

   
}



- (IBAction)cancleEmpSelection:(id)sender
{
    [self removeComboView];
    switch (AnalysisType)
    {        
        case Employee_Business_Expense:
        {
            self.lblSelectEmployee.text=TEXT_SUMMARIZEDBY;
        }
        break;
        default:
        {
            self.lblSelectEmployee.text=TEXT_EMPLOYEE;
        }
        break;
    }
    
    self.btnEmpClear.hidden=YES;
}

- (IBAction)openCategoryCombo:(id)sender
{
    
    subCategoryId=0;
    CategoryId=0;
    
    ComboType=Category_List_combo;
    
    [self removeComboView];
    
    if ([categoryArray count]==0)
    {
        showAlertScreen(nil, @"There is no Category associated with this Business..");
    }
    
    float distX = CGRectGetMinX(self.filterView.frame) + CGRectGetMinX(self.secondComboView.frame) + 8;
    float distY = CGRectGetMinY(self.filterView.frame) + CGRectGetMinY(self.secondComboView.frame) + 13;
    
    
    comboView = [[ComboViewController alloc] initWithFrame:CGRectMake(distX, distY, 100, 120) records:categoryArray callingClassType:Category_List];
    
    comboView.delegate=self;
    [popView addSubview:comboView];
     [comboView release];
    
    self.lblSubCategory.text=TEXT_SUB;
   
}

- (IBAction)openSubCategory:(id)sender
{
    subCategoryId=0;
    
    if ([self.lblSelectedCategory.text isEqualToString:TEXT_CATEGORY])
    {
        showAlertScreen(nil, @"Please select Category First");
        return;
    }
    ComboType=Category_Sub_List;
    
    [self removeComboView];
    
    for (int i=0; i<[categoryArray count]; i++)
    {
        ExpenseCategoryData *expObj=[categoryArray objectAtIndex:i];
        if (expObj.CATEGORY_TYPE==CategoryId)
        {
            float distX = CGRectGetMinX(self.filterView.frame) + CGRectGetMinX(self.secondComboView.frame) + CGRectGetMinX(self.lblSubCategory.frame) - 5;
            float distY = CGRectGetMinY(self.filterView.frame) + CGRectGetMinY(self.secondComboView.frame) + 13;
                        comboView = [[ComboViewController alloc] initWithFrame:CGRectMake(distX, distY, 110, 120) records:expObj.SubCatArray callingClassType:subCategory_List];

            comboView.delegate=self;
            [popView addSubview:comboView];
            [comboView release];
            break;
        }
    }
}

- (IBAction)cancleCategorySelection:(id)sender
{
    [self removeComboView];
    CategoryId=0;
    subCategoryId=0;
    
    self.lblSelectedCategory.text=TEXT_CATEGORY;
    self.lblSubCategory.text=TEXT_SUB;
    self.btnCategoryClear.hidden=YES;
}


- (IBAction)openEmpComboView:(id)sender
{
    
    [self removeComboView];
    
    if ([empArray count]==0)
    {
        showAlertScreen(nil, @"There is no Employee associated with this Business..");
    }
    
    float distX = CGRectGetMinX(self.filterView.frame) + CGRectGetMinX(self.employeeView.frame) + 10;
    float distY = CGRectGetMinY(self.filterView.frame) + CGRectGetMinY(self.employeeView.frame) + 10;

    
    selectedEmpId=@"";
    ComboType = AnalysisType == Employee_Business_Expense?summarized_List_combo:Employee_list_combo;
    comboView = [[ComboViewController alloc] initWithFrame:CGRectMake(distX, distY, 200, 150) records:empArray callingClassType:AnalysisType == Employee_Business_Expense?summarizedBy:emp_List];

    comboView.delegate=self;
    [popView addSubview:comboView];
    [comboView release];

}

-(void)removeComboView
{
    if ([comboView isDescendantOfView:popView])
    {
        [comboView removeFromSuperview];
        comboView=nil;
    }
}

-(void) selectQuetion:(id) que
{
    switch (ComboType)
    {
        case Employee_list_combo:
        {
            empObj=(employeeDataClass *)que;
            self.lblSelectEmployee.text=empObj.Name;
            
            selectedEmpId=empObj.EmployeeId;
        }
            break;
            
        case Period_list_combo:
        {
            self.lblSelectPeriod.text=que;
            [self checkPeriod];
        }
            break;

        case Category_List_combo:
        {
            ExpenseCategoryData *expCatObj=(ExpenseCategoryData *)que;
            self.lblSelectedCategory.text=expCatObj.CATEGORY_LABEL;
            CategoryId=expCatObj.CATEGORY_TYPE;
        }
            break;
            
        case Category_Sub_List:
        {
            SubCategoryDataClass *subDataObj=(SubCategoryDataClass *)que;
            self.lblSubCategory.text=subDataObj.EXPCAT_VALUE;
            subCategoryId=subDataObj.EXPCAT_VALUE_ID;
        }
            break;
        case business_List:
        {
            businessListDataClass *subDataObj=(businessListDataClass *)que;
            self.lblBusinessNameFilter.text=subDataObj.LUTDESCRIPTION;
            SelectedBusinessName=subDataObj.LUTDESCRIPTION;
            selectedBusinessId=subDataObj.LUTCODE;
            OwningPartnerTag=subDataObj.PRODUCT_PARENT;
            
            switch (AnalysisType)
            {
                case EMPLOYEE_PAGE:
                {
                    [self getEmployeeListRequest];
                }
                    break;
                case EMP_BY_EXP_PAGE:
                {
                    [self getEmployeeListRequest];
                }
                    
                    break;
                case EMP_EXP_CAT_PAGE:
                {
                    [self GetExpenseCategory];
                    
                }
                    break;
                case EMP_BUSSINESS_EXP_PAGE:
                {
                    
                    
                }
                    break;
                default:
                    break;
            }
        }
            break;
        case summarized_List_combo:
        {
            self.lblSelectEmployee.text = que;
            strSelectedSummarizedBy = que;
        }
            break;
        default:
            break;
    }
    
    [self checkEmpSelection];
    
    [self removeComboView];
}



// Period method
-(void)checkPeriod
{

    if ([self.lblSelectPeriod.text isEqualToString:TEXT_TODAY])
    {
        self.lblSelectdateFrom.text=getCurrentDate();
        self.lblSelectDateTo.text=getCurrentDate();
        periodType=EMP_TODAYS;
        
    }else  if ([self.lblSelectPeriod.text isEqualToString:TEXT_CURRENTMONTH])
    {
        self.lblSelectdateFrom.text=getStringFromDate(returnDate([NSDate date],CurrentMonth_First));
        self.lblSelectDateTo.text=getStringFromDate([NSDate date]);
        
        periodType=EMP_THIS_MONTHS;

    }else  if ([self.lblSelectPeriod.text isEqualToString:TEXT_LASTMONTH])
    {
        self.lblSelectdateFrom.text=getStringFromDate(returnDate([NSDate date],LastMonth_First));
        self.lblSelectDateTo.text=getStringFromDate(returnDate([NSDate date],LastMonth_last));
        periodType=EMP_LAST_MONTH;

    }else if ([self.lblSelectPeriod.text isEqualToString:TEXT_LASTQUARTER])
    {
        
        self.lblSelectdateFrom.text=getQuarterDate(YES);
        self.lblSelectDateTo.text=getQuarterDate(NO);

        periodType=EMP_LAST_QUARTER;
    }
    else if ([self.lblSelectPeriod.text isEqualToString:TEXT_CURRENTWEEK])
    {
        self.lblSelectdateFrom.text=getWeekFirstLastDate(@"BeginningOfCurrentWeek");
        self.lblSelectDateTo.text=getWeekFirstLastDate(@"EndOfCurrentWeek");
    }
    else if ([self.lblSelectPeriod.text isEqualToString:TEXT_LASTWEEK])
    {
        self.lblSelectdateFrom.text=getWeekFirstLastDate(@"BeginningOfLastWeek");
        self.lblSelectDateTo.text=getWeekFirstLastDate(@"EndOfLastWeek");
    }
    isDateSelected = NO;
    [self setFilterDefault];
}


- (IBAction)openPeriodComboView:(id)sender
{
//     [self setFilterDefault];
    
    [self removeComboView];
    ComboType=Period_list_combo;
    
    float distX = CGRectGetMinX(self.filterView.frame) + CGRectGetMinX(self.lblSelectPeriod.frame) - 5;
    float distY = CGRectGetMinY(self.filterView.frame) + CGRectGetMinY(self.lblSelectPeriod.frame);
    
        comboView= [[ComboViewController alloc] initWithFrame:CGRectMake(distX, distY, 150, 180) records:periodArr callingClassType:other];
    comboView.delegate=self;
    [popView addSubview:comboView];
     [comboView release];
}


#pragma Response/Requests

// Create a request URL and Send it to DataParsingClass
-(void)getEmployeeExpenseRequest
{
    requestId=report_list;
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getEmployee_Expense;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deFromDate_EC=%@&deToDate_EC=%@&deBSProductId_EC=%@&deFlag_EC=SC&deChannelID_EC=&DE_EmployeeID_MS=%@&deMerchantCategory_EC=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,dateForAnalysis(strFromDate),dateForAnalysis(strToDate),selectedBusinessId,([strEmpName isEqualToString:TEXT_EMPLOYEE])?@"":selectedEmpId,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcCardSpendReportAPI];
    [Datareq release];
}


// Creating for fetching Expense Category
-(void)getExpenseCategoryRequest
{
    requestId=report_list;
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getExpenseCategory_Expense;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";

    ExpenseCategoryData *objExpenseCategoryData = nil;
    if ([categoryArray count] > 0) {
        objExpenseCategoryData = [categoryArray objectAtIndex:0];
    }

     NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deFromDate_EC=%@&deToDate_EC=%@&deBSProductId_EC=%@&deChannelID_EC=&deExpCatID1_EC=%d&deExpSubCatID1_EC=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,dateForAnalysis(strFromDate),dateForAnalysis(strToDate),selectedBusinessId,([self.lblSelectedCategory.text isEqualToString:@"Category"]?objExpenseCategoryData.CATEGORY_TYPE:CategoryId),[self.lblSubCategory.text isEqualToString:@"Sub"]?@"":[NSString stringWithFormat:@"%d",subCategoryId],[SystemConfiguration sharedSystemConfig].deIVRSource];
    

    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcGenerateReport_ExpenseCategoryAPI];
    [Datareq release];
}


// Creating Request for Fetching Employees List
-(void)getEmployeeListRequest
{
    requestId=emp_List_Req;
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getEmployeeList;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deUserid=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=&deProductID=%@&deClientid=%@",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource,selectedBusinessId,OwningPartnerTag];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcGetEmployees];
    [Datareq release];
    
}


// Creating Request for Fetching Expense Category
-(void)GetExpenseCategory
{
    requestId=category_list_req;
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=GetEXpenseCategory;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&desvcBusinessAccountID=%@&desvcExpenseCategoryType=%@&deSetFlagValue_BankAct=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,selectedBusinessId,@"",[SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcViewExpenseCategory];
    
    [DataReq release];
}


// Method to make and send the query from Employee By Expense when the user click on the filter button
-(void) getEmployeByExpenseCategory
{
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    requestId = report_list;
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getEmployeeByExpenceAnalysisReport;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deEmpByExpense_FromDate=%@&deEmpByExpense_ToDate=%@&deEmpByExpense_ProductID=%@&deEmpByExpense_ChannelID=&deEmpByExpense_ExpenseCategory=%@&deEmpByExpense_ExpenseType=%@&deEmpByExpense_EmployeeId=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,dateForAnalysis(strFromDate),dateForAnalysis(strToDate),selectedBusinessId,([self.lblSelectedCategory.text isEqualToString:TEXT_CATEGORY]?@"":[NSString stringWithFormat:@"%d",CategoryId]),([self.lblSubCategory.text isEqualToString:TEXT_SUB]?@"":[NSString stringWithFormat:@"%d",subCategoryId]),([strEmpName isEqualToString:TEXT_EMPLOYEE])?@"":selectedEmpId,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcEmployeeByExpenseCategoryAPI];
    [Datareq release];
}

// Create a query For Business Expense
-(void)getBusinessExpense
{
//    char initialCharacter = strSelectedSummarizedBy
    NSString *initialCharacter;
    if (strSelectedSummarizedBy.length > 0)
    {
        initialCharacter = [strSelectedSummarizedBy substringToIndex:1];
    }
    else
    {
        initialCharacter = @"D";
    }
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    requestId = report_list;
    
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    // in Place of deBusinessExpBusinessId = 1867
    // We have placed selectedBussinessId
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName = getBusiness_Expense;
    
    NSString *url = [NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deBusinessExpBusinessId=%@&deBusinessExpBusinessName=&deBusinessExpReportFrom=%@&deBusinessExpReportUpto=%@&deBusinessExpSummarizedByPeriod=%@&deBusinessExpCustomDuration=&deBusinessExpCustomPeriod=&deBusinessExpOrderBy=&deBusinessExpGroupBy=&deIVRSource=MobileCoreMoney&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,selectedBusinessId,dateForAnalysis(strFromDate),dateForAnalysis(strToDate),initialCharacter];
    
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcBusinessExpense];
    [Datareq release];
}

-(BOOL) isFutureDate:(NSString *)strDate dateFormatIs:(NSString *)dateFormat
{
    BOOL isDateIsFutureDate;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:dateFormat];
    NSTimeInterval secondsBetween;
    NSDate *today = [NSDate date];
    NSDate *date = [dateFormatter dateFromString:strDate];
    secondsBetween = [today timeIntervalSinceDate:date];
    isDateIsFutureDate = secondsBetween < 0 ?NO:YES;
    return isDateIsFutureDate;
}

- (IBAction)submitFilterRequest:(id)sender
{
    if (AnalysisType == Employee_by_Expense_analysis)
    {
        searchByCategory = [self.lblSubCategory.text isEqualToString:@"Sub"]?NO:YES;
        searchByEmployee = [self.lblSelectEmployee.text isEqualToString:@"Employee"]?NO:YES;
    }
    
    // Assigning values for Setting back to Default Values if Cancel button is clicked
    self.strPeriodText = self.lblSelectPeriod.text;
    self.strDateFrom = self.lblSelectdateFrom.text;
    self.strDateTo = self.lblSelectDateTo.text;
    isDateChanged = isDateSelected;
    
    BOOL boolTimePeriodFlag = YES;

    strFromDate=self.lblSelectdateFrom.text;
    strToDate=self.lblSelectDateTo.text;

    boolTimePeriodFlag = isFutureDateWithFormat(strFromDate, @"MM-dd-yyyy")?YES:isFutureDateWithFormat(strToDate, @"MM-dd-yyyy")?YES:NO;
    if (!boolTimePeriodFlag)
    {
        int numberOfDays = daysDifferenceBetweenDates(strToDate, strFromDate, @"MM-dd-yyyy");

        if (AnalysisType == Employee_Business_Expense)
        {
            if (numberOfDays > 31 && numberOfDays <= 210)
            {
                if ([self.lblSelectEmployee.text isEqualToString:TEXT_DAY])
                {
                    showAlertScreen(@"", @"Day can't be selected for period more than 31 Days");
                }
                else
                {
                    strSelectedSummarizedBy = [self.lblSelectEmployee.text isEqualToString:TEXT_SUMMARIZEDBY]?TEXT_WEEK:self.lblSelectEmployee.text;
                    strPeriod=self.lblSelectPeriod.text;
                    if ([self SubmitDate])
                    {
                        [self makeRequest];
                    }
                }
            }
            else if (numberOfDays > 210 && numberOfDays <= 912)
            {
                if([self.lblSelectEmployee.text isEqualToString:TEXT_WEEK] || [self.lblSelectEmployee.text isEqualToString:TEXT_DAY])
                {
                    showAlertScreen(@"", @"Week or Day can't be selected for period more than 30 week");
                }
                else
                {
                    strSelectedSummarizedBy = [self.lblSelectEmployee.text isEqualToString:TEXT_SUMMARIZEDBY]?TEXT_MONTH:self.lblSelectEmployee.text;
                    strPeriod=self.lblSelectPeriod.text;
                    if ([self SubmitDate])
                    {
                        [self makeRequest];
                    }
                }
            }
            else if (numberOfDays > 912)
            {
                if ([self.lblSelectEmployee.text isEqualToString:TEXT_MONTH] || [self.lblSelectEmployee.text isEqualToString:TEXT_WEEK] || [self.lblSelectEmployee.text isEqualToString:TEXT_DAY])
                {
                    strSelectedSummarizedBy = [self.lblSelectEmployee.text isEqualToString:TEXT_SUMMARIZEDBY]?TEXT_QUARTER:self.lblSelectEmployee.text;
                    showAlertScreen(@"", @"Week, Day and Month can't be selected for period more than 2.5 years");
                }
                else
                {
                    strPeriod=self.lblSelectPeriod.text;
                    if ([self SubmitDate])
                    {
                        [self makeRequest];
                    }
                }
            }
            else
            {
                strSelectedSummarizedBy = [self.lblSelectEmployee.text isEqualToString:TEXT_SUMMARIZEDBY]?TEXT_DAY:self.lblSelectEmployee.text;
                strPeriod=self.lblSelectPeriod.text;
                if ([self SubmitDate])
                {
                    [self makeRequest];
                }
            }
            
            
        }
        else
        {
            strEmpName=self.lblSelectEmployee.text;
            strCategory=self.lblSelectedCategory.text;
            strSubCategory=self.lblSubCategory.text;
            strPeriod=self.lblSelectPeriod.text;
            if ([self SubmitDate])
            {
                [self makeRequest];
            }
        }
    }
    else
    {
        showAlertScreen(nil, @"You cannot choose Future Date");
    }
}

// Method for Submitting the Date
-(BOOL)SubmitDate
{
    NSComparisonResult result = [GetDateFromSTring(strFromDate) compare:GetDateFromSTring(strToDate)];
    if (result == NSOrderedAscending)
    {
        return YES;
        
    } else if (result == NSOrderedDescending)
    {
        //  Last date < First Date
        showAlertScreen(nil,languageSelectedStringForKey(DATE_ALERT));
        return NO;
    }  else
    {
        // Last date == First Date
        return YES;
    }
    
}


// Resetting all the Business Filter
-(void)resetBusinessFilter
{
    [self setFilterDefault];
    
    strPeriod=TEXT_CURRENTMONTH;

    
    strEmpName = AnalysisType == Employee_Business_Expense?TEXT_SUMMARIZEDBY:TEXT_EMPLOYEE;
    
    self.lblSelectdateFrom.text=getStringFromDate(returnDate([NSDate date],CurrentMonth_First));
    self.lblSelectDateTo.text=getStringFromDate([NSDate date]);
    self.lblSelectPeriod.text=TEXT_CURRENTMONTH;
    self.lblBusinessNameFilter.text=SelectedBusinessName;
    self.lblSelectedCategory.text=TEXT_CATEGORY;
    self.lblSubCategory.text=TEXT_SUB;
    self.lblSelectEmployee.text=strEmpName;

    CategoryId=0;
    subCategoryId=0;
    periodType=EMP_THIS_MONTHS;
}


- (IBAction)openBusinessList:(id)sender
{
    [self resetBusinessFilter];
    [self removeComboView];
    
    float distX = CGRectGetMinX(self.filterView.frame) + CGRectGetMinX(self.businessFilterView.frame);
    float distY = CGRectGetMinY(self.filterView.frame) + CGRectGetMinY(self.businessFilterView.frame) + 5;
    NSLog(@"x = %f Y = %f",distX,distY);
    NSLog(@"%f",CGRectGetMinX(self.filterView.frame));
    NSLog(@"%f",CGRectGetMinY(self.filterView.frame));
    NSLog(@"%f",CGRectGetMinX(self.businessFilterView.frame));
    NSLog(@"%f",CGRectGetMinY(self.businessFilterView.frame));
    ComboType=business_List;
    comboView= [[ComboViewController alloc] initWithFrame:CGRectMake(distX + 10, distY, 240, 180) records:businessListArray callingClassType:business_List];
    comboView.delegate=self;
    [popView addSubview:comboView];
    [comboView release];
}


@end
