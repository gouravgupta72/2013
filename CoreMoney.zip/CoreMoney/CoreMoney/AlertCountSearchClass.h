//
//  AlertCountSearchClass.h
//  CoreMoney
//

#import <Foundation/Foundation.h>

@interface AlertCountSearchClass : NSObject
{
    NSString *strCount;
    BOOL isDataNull;
    int alertTypeNo;
    NSString *strAlertName;
    int colorNo;

}
@property int colorNo;
@property int alertTypeNo;
@property (nonatomic, retain) NSString *strCount;
@property (nonatomic, retain) NSString *strAlertName;
@property (nonatomic) BOOL isDataNull;
@end
