//
//  ExpenseAnalysisViewController.m
//  CoreMoney
// class create for expense analysis menu view

#import "ExpenseAnalysisViewController.h"
#import "HomeCell.h"
#import "EmployeeExpenseViewController.h"
#define TEXT_DAY @"Day"
#define TEXT_WEEK @"Week"
#define TEXT_MONTH @"Month"
#define TEXT_QUARTER @"Quarter"
@interface ExpenseAnalysisViewController ()

@end

@implementation ExpenseAnalysisViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        addNavigationBar(EXPENSE_ANALYSIS_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        cellArray = [[NSMutableArray alloc] init];
        
        [self addObjectToArray:@"Employee-icon" Label:@"Employee"];
        [self addObjectToArray:@"Employee-by-Expense-Categories-icon" Label:@"Employee By Expense"];
        [self addObjectToArray:@"Expense-categories-icon" Label:@"Expense Category"];
        [self addObjectToArray:@"Business-Expense-icon" Label:@"Business Expense"];
        
    }
    return self;
}
// method use for send to previus view
-(void)openBack
{
    [self getBussinessRequest ];
}
// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

-(void) viewWillAppear:(BOOL)animated
{
    [AppDelegate sharedAppDelegate].classType=EXPENCE_ANALYSIS_PAGE;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [AppDelegate sharedAppDelegate].classType=EXPENCE_ANALYSIS_PAGE;
    [super viewWillDisappear:animated];
}
// Method to initialise the cell array.
-(void) addObjectToArray:(NSString *) imgName Label:(NSString *)lblString
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:imgName forKey:@"imgName"];
    [dict setObject:languageSelectedStringForKey(lblString) forKey:@"lblString"];
    
    [cellArray addObject:dict];
    [dict release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)getBussinessRequest
{
    RequestId = BAckToHome;
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Business_Search_Request;
    [SystemConfiguration sharedSystemConfig].deFlagShowDetails=@"1";
    [Datareq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPProductParent=&deBusinessName=&deCIASDDANumber=&deAADAccountNumber=&dePPCardStatus=&deCIASFirstName=&deCIASLastName=&deCIAAddressLine1=&deCIAAddressLine2=&deCIASCity=&deCIASState=&deCIASCountry=&deCIASZipCode=&deBSAcctId=&deFlagShowDetails=%@&deRequestBatchSize=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].deFlagShowDetails,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBusinessAccountSearch];
    
    [Datareq release];
}


-(void)getEmployeeExpenseRequest
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    RequestId=Employee;
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getEmployee_Expense;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deFromDate_EC=%@&deToDate_EC=%@&deBSProductId_EC=%@&deFlag_EC=SC&deChannelID_EC=&DE_EmployeeID_MS=&deMerchantCategory_EC=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_First))),dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_Lats))),BusinessPageObject.BusinessName,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcCardSpendReportAPI];
    [Datareq release];
}


-(void)getExpenseCategoryRequest
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    RequestId=EmployeeExpenseCategor;
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getExpenseCategory_Expense;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    ExpenseCategoryData *objExpenseCategoryData = nil;
    if ([categoryArray count] > 0) {
        objExpenseCategoryData = [categoryArray objectAtIndex:0];
        
    }
//    ExpenseCategoryData *objExpenseCategoryData = [categoryArray objectAtIndex:0];
    //01/01/2013
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deFromDate_EC=%@&deToDate_EC=%@&deBSProductId_EC=%@&deChannelID_EC=&deExpCatID1_EC=%d&deExpSubCatID1_EC=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_First))),dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_Lats))),BusinessPageObject.BusinessName,objExpenseCategoryData.CATEGORY_TYPE,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcGenerateReport_ExpenseCategoryAPI];
    [Datareq release];
}

-(void)getEmployeeByExpenseAnalysisRequest
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    RequestId=EmployeeByExpense;
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    ExpenseCategoryData *objExpenseCategoryData = nil;
    if ([categoryArray count] > 0) {
        objExpenseCategoryData = [categoryArray objectAtIndex:0];

    }
    //    NSLog(@"%d",objExpenseCategoryData.CATEGORY_TYPE);
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getEmployeeByExpenceAnalysisReport;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deEmpByExpense_FromDate=%@&deEmpByExpense_ToDate=%@&deEmpByExpense_ProductID=%@&deEmpByExpense_ChannelID=&deEmpByExpense_ExpenseCategory=%d&deEmpByExpense_ExpenseType=&deEmpByExpense_EmployeeId=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_First))),dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_Lats))),BusinessPageObject.BusinessName,objExpenseCategoryData.CATEGORY_TYPE,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcEmployeeByExpenseCategoryAPI];
    [Datareq release];
}


-(void)getEmployeeListRequest
{
    RequestId=EmployeeList_Request;
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];

    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getEmployeeList;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deUserid=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=&deProductID=%@&deClientid=%@",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource,BusinessPageObject.BusinessName,BusinessPageObject.OwningPartner];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcGetEmployees];
    [Datareq release];
    
}


-(void)GetExpenseCategory
{
    RequestId=Exp_Cate_List;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=GetEXpenseCategory;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&desvcBusinessAccountID=%@&desvcExpenseCategoryType=%@&deSetFlagValue_BankAct=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.BusinessName,@"",[SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcViewExpenseCategory];
    
    [DataReq release];
}

-(void)getBusinessList
{
    RequestId=exp_Business_List;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getBusiness_List;
    
    // We have to change this value deSpendProductFlag=5
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deSpendProductFlag=5&dePPProductParent=%@&dePPClientList=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcGetSpendProducts];
    
    [DataReq release];
}

// Create a query For Business Expense
-(void)getBusinessExpense
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    RequestId = EmployeeBusinessExpense;
    
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName = getBusiness_Expense;

    NSString *url = [NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deBusinessExpBusinessId=%@&deBusinessExpBusinessName=&deBusinessExpReportFrom=%@d&deBusinessExpReportUpto=%@&deBusinessExpSummarizedByPeriod=D&deBusinessExpCustomDuration=&deBusinessExpCustomPeriod=&deBusinessExpOrderBy=&deBusinessExpGroupBy=&deIVRSource=MobileCoreMoney&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.BusinessName,dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_First))),dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_Lats)))];
 
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcBusinessExpense];
    [Datareq release];
}

-(void)getResponce:(id)jsonData
{
    switch (RequestId)
    {
        case BAckToHome:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            if ([jsonData isKindOfClass:[NSArray class]]) {
                
                if (![AppDelegate sharedAppDelegate].arrBusinessData)
                {
                    [AppDelegate sharedAppDelegate].arrBusinessData=[[NSMutableArray alloc] init];
                }
                else
                {
                    [[AppDelegate sharedAppDelegate].arrBusinessData removeAllObjects];
                }
                [AppDelegate sharedAppDelegate].arrBusinessData=jsonData;
                [self.navigationController popViewControllerAnimated:YES];
            }
            else
            {
                showAlertScreen(@"", @"No records found");
            }
        }
            break;
            case EmployeeList_Request: // Fetching the Employee List
        {
            if (!empArray)
            {
                empArray=[[NSMutableArray alloc]init];
            }else
            {
                [empArray removeAllObjects];
            }
            
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                empArray=jsonData;
            }
            switch (selectedExpense)
            {
                case EMPLOYEE_PAGE:
                {
                    [[AppDelegate sharedAppDelegate] addloadingView];
                    [self getEmployeeExpenseRequest];
                }
                    break;
                case EMP_BY_EXP_PAGE:
                {
                    [self GetExpenseCategory];
                   
                }
                    
                    break;
                case EMP_EXP_CAT_PAGE:
                {
                    [[AppDelegate sharedAppDelegate] addloadingView];
                    [self getExpenseCategoryRequest];
                }
                    
                    break;
                case EMP_BUSSINESS_EXP_PAGE:
                {
                    [[AppDelegate sharedAppDelegate] removeLoadingView];
                    
                    EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:empArray analysisType:Employee_Business_Expense businessListArray:businessListArray categoryArray:categoryArray];
                    [self.navigationController pushViewController:adPVC animated:YES];
                    [adPVC release];
                }
                    
                    break;
                default:
                    break;
            }
        }
            break;
            case Employee:
        {
            employeeExpenseDataClass *expObj;
            if (![jsonData isKindOfClass:[employeeExpenseDataClass class]])
            {
                expObj = [[employeeExpenseDataClass alloc] init];
                showAlertScreen(nil, jsonData);
            }
            else
            {
                expObj=(employeeExpenseDataClass *)jsonData;
                if ([expObj.employeeExpenseArray count]==0)
                {
                    showAlertScreen(nil, @"No record Found..");
                }
            }
                
              
                    EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:empArray analysisType:Employee_analysis businessListArray:businessListArray categoryArray:categoryArray];
                    
                    adPVC.empExpData=expObj;
                    
                    [self.navigationController pushViewController:adPVC animated:YES];
                    [adPVC release];
            
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
            case EmployeeExpenseCategor:
        {
            employeeExpenseDataClass *expObj;
            if (![jsonData isKindOfClass:[employeeExpenseDataClass class]])
            {
                expObj = [[employeeExpenseDataClass alloc] init];
                showAlertScreen(nil, jsonData);
            }
            else
            {
                expObj=(employeeExpenseDataClass *)jsonData;
                if ([expObj.employeeExpenseArray count]==0)
                {
                    showAlertScreen(nil, @"No record Found..");
                }
            }
            
                    EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:empArray analysisType:Employee_Expense_Category businessListArray:businessListArray categoryArray:categoryArray];

                    adPVC.empExpData=expObj;
                    [self.navigationController pushViewController:adPVC animated:YES];
                    [adPVC release];
            
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case Exp_Cate_List:
        {
            if (!categoryArray)
            {
                categoryArray=[[NSMutableArray alloc]init];
            }else
            {
                [categoryArray removeAllObjects];
            }
            
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                categoryArray=jsonData;
            }
            switch (selectedExpense) {
                case EMP_BY_EXP_PAGE:  // For Employee By Expense (Making Request)
                {
                    
                    [self getEmployeeByExpenseAnalysisRequest];

                }
                    break;
                case EMP_EXP_CAT_PAGE: // For Expense Category (Making Request)
                    [self getExpenseCategoryRequest];
                    break;
                    
                default:
                    break;
            }
                    }
            break;
            
            case exp_Business_List:   // Fetching the Business List
        {
            
            if (!businessListArray)
            {
                businessListArray=[[NSMutableArray alloc]init];
            }else
            {
                [businessListArray removeAllObjects];
            }
            
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                businessListArray=jsonData;
            }

            switch (selectedExpense)
            {
                case EMPLOYEE_PAGE:
                {
                    [self getEmployeeListRequest];
                }
                    break;
                case EMP_BY_EXP_PAGE:
                {
                    [self getEmployeeListRequest];
                }
                    
                    break;
                case EMP_EXP_CAT_PAGE:
                {
                    [self GetExpenseCategory];
                    
                }
                    break;
                case EMP_BUSSINESS_EXP_PAGE:
                {
                    [self getBusinessExpense];
//                    [[AppDelegate sharedAppDelegate] removeLoadingView];
                }
                    break;
                default:
                    break;
            }
        }
            break;
            case EmployeeByExpense:
        {
            employeeExpenseDataClass *expObj;
            if (![jsonData isKindOfClass:[employeeExpenseDataClass class]])
            {
                expObj = [[employeeExpenseDataClass alloc] init];
                showAlertScreen(nil, jsonData);
            }
            else
            {
                expObj=(employeeExpenseDataClass *)jsonData;
                if ([expObj.employeeExpenseArray count]==0)
                {
                    showAlertScreen(nil, @"No record Found..");
                }
            }

            
            EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:empArray analysisType:Employee_by_Expense_analysis businessListArray:businessListArray categoryArray:categoryArray];
            adPVC.empExpData=expObj;
            [self.navigationController pushViewController:adPVC animated:YES];
            [adPVC release];
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case EmployeeBusinessExpense:
            // Calling EmployeeExpens
        {
            employeeExpenseDataClass *expObj;
            if (![jsonData isKindOfClass:[employeeExpenseDataClass class]])
            {
                expObj = [[employeeExpenseDataClass alloc] init];
                showAlertScreen(nil, jsonData);
            }
            else
            {
                expObj=(employeeExpenseDataClass *)jsonData;
                if ([expObj.employeeExpenseArray count]==0)
                {
                    showAlertScreen(nil, @"No record Found..");
                }
            }
                NSMutableArray *arrSummarizedPeriod = [[NSMutableArray alloc] init];
                [arrSummarizedPeriod addObject:TEXT_DAY];
                [arrSummarizedPeriod addObject:TEXT_WEEK];
                [arrSummarizedPeriod addObject:TEXT_MONTH];
                [arrSummarizedPeriod addObject:TEXT_QUARTER];
                EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:arrSummarizedPeriod analysisType:Employee_Business_Expense businessListArray:businessListArray categoryArray:nil];
                adPVC.empExpData=expObj;
                
                [self.navigationController pushViewController:adPVC animated:YES];

                [adPVC release];
            

        
        [[AppDelegate sharedAppDelegate] removeLoadingView];
//        NSLog(@"EmployeeBusinessExpense");
        }
        break;
        default:
            break;
    }
}


-(void)openExpensePage
{
    switch (selectedExpense)
    {
        case EMPLOYEE_PAGE:
        {
            
        }
            break;
        case EMP_BY_EXP_PAGE:
        {
            
            EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:empArray analysisType:Employee_by_Expense_analysis businessListArray:businessListArray categoryArray:categoryArray];
            [self.navigationController pushViewController:adPVC animated:YES];
            [adPVC release];
        }
            
            break;
        case EMP_EXP_CAT_PAGE:
        {
            
            EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:empArray analysisType:Employee_Expense_Category businessListArray:businessListArray categoryArray:categoryArray];
            [self.navigationController pushViewController:adPVC animated:YES];
            [adPVC release];
        }
            
            break;
        case EMP_BUSSINESS_EXP_PAGE:
        {
            
            EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:empArray analysisType:Employee_Business_Expense businessListArray:businessListArray categoryArray:categoryArray];
            [self.navigationController pushViewController:adPVC animated:YES];
            [adPVC release];
        }
            
            break;
        default:
            break;
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_bgView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setBgView:nil];
    [super viewDidUnload];
}

#pragma mark- Table View Delegates
// Delegate method to set the number of sections in table.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
// Delegate method to set the height of the cell.
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 58;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [cellArray count];
}
// Delegate method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"Cell";
	HomeCell *cell = (HomeCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[HomeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    NSMutableDictionary *dict = [cellArray objectAtIndex:indexPath.row];
    
    
    cell.lblName.text=[dict objectForKey:@"lblString"];
    cell.cellImage.image=[UIImage imageNamed:[dict objectForKey:@"imgName"]];
    cell.lblName.textColor=[UIColor blackColor];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}

// Delegate method called when the row selects.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    selectedExpense=indexPath.row;
    [self getBusinessList];
}

@end
