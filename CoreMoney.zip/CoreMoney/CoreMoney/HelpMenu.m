//
//  HelpMenu.m



// Class For Design Help Menu .

#import "HelpMenu.h"
#import "HelpMenuDataClass.h"
#import "PopUpView.h"
#import "TermAndConditionViewController.h"
#import "ContactUSViewController.h"
#import "RecommendViewController.h"
#include <CoreGraphics/CGBase.h>
#include <CoreGraphics/CGGeometry.h>
@implementation HelpMenu

@synthesize delegatelogin,delegateReg;
// Fill data for create View.
-(void)Filldata
{
    if (!DataArray) {
        DataArray=[[NSMutableArray alloc]init];
    }else
    {
        [DataArray removeAllObjects];
    }
    
    HelpMenuDataClass *dataObj=[[HelpMenuDataClass alloc]initwithHelpData:imgHelp_About :languageSelectedStringForKey(txtHelp_About) :ABOUT ];
    [DataArray addObject:dataObj];
    [dataObj release];
    
    dataObj=[[HelpMenuDataClass alloc]initwithHelpData:imgHelp_Recommend :languageSelectedStringForKey(txtHelp_Recommend) :RECOMMEND ];
    [DataArray addObject:dataObj];
    [dataObj release];
    
    dataObj=[[HelpMenuDataClass alloc]initwithHelpData:imgHelp_Contact :languageSelectedStringForKey(txtHelp_Contact) :CONTACT ];
    [DataArray addObject:dataObj];
    [dataObj release];
    
    dataObj=[[HelpMenuDataClass alloc]initwithHelpData:imgHelp_FAQ :languageSelectedStringForKey(txtHelp_Faq) :FAQ ];
    [DataArray addObject:dataObj];
    [dataObj release];
    
    dataObj=[[HelpMenuDataClass alloc]initwithHelpData:imgHelp_TERMCondition :(txtHelp_Term_Condition ) :TERM_CONDITION ];
    [DataArray addObject:dataObj];
    [dataObj release];
  
//    dataObj=[[HelpMenuDataClass alloc]initwithHelpData: imgHelp_SelectLang :languageSelectedStringForKey(txtHelp_Select_language) :SELECT_LANG ];
//    [DataArray addObject:dataObj];
//    [dataObj release];
    
}

// initialize and return Help Menu View.
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        
        clickCount=0;
        [self Filldata];
        MenuItemView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 322, frame.size.height)];
        MenuItemView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgHelp_Footer_BG]];
        MenuItemView.clipsToBounds = YES;
        [self addSubview:MenuItemView];
        [MenuItemView release];
        
        btnSliderOpen=[[UIButton alloc]initWithFrame:CGRectMake(-3, 0, 40, 51)];
        btnSliderOpen.backgroundColor=[UIColor clearColor];
        [btnSliderOpen setImage:[UIImage imageNamed:imgHelp_Help] forState:UIControlStateNormal];
        [btnSliderOpen addTarget:self action:@selector(OpenSlider:) forControlEvents:UIControlEventTouchUpInside];
        btnSliderOpen.selected=NO;
        [self addSubview:btnSliderOpen];
        [btnSliderOpen release];
        
        
        [self designHelpMenu:frame];
    }
    return self;
}


-(void)changeLanguage
{
    for (UIView *subview in MenuItemView.subviews)
    {
        if ([subview isKindOfClass:[HelpMenuItem class]])
        {
            HelpMenuItem *obj=(HelpMenuItem *)subview;
            obj.lblTitle.text=languageSelectedStringForKey(txtHelp_More);
        }
    }
    
    // if ([subview isKindOfClass:[UIScrollView class]])
    //{
    //    UIScrollView *obj=(UIScrollView *)subview;
    //            for (UIView *subviews in subview)
    //            {
    
    for(UIView *subview in firstGroupedView.subviews){
        
        HelpMenuItem *obj=(HelpMenuItem *)subview;
        
        
        switch (obj.tag) {
            case ABOUT:
            {
                obj.lblTitle.text=languageSelectedStringForKey(txtHelp_About);
            }
                break;
            case CONTACT:
            {
                obj.lblTitle.text=languageSelectedStringForKey(txtHelp_Contact);
            }
                break;
            case FAQ:
            {
                obj.lblTitle.text=languageSelectedStringForKey(txtHelp_Faq);
            }
                break;
            default:
                break;
                
        }
    }
    
    for(UIView *subview in secondGroupedView.subviews){
        
        HelpMenuItem *obj =  (HelpMenuItem *) subview;
        
        switch (obj.tag) {
            case TERM_CONDITION:
            {
                obj.lblTitle.text=languageSelectedStringForKey(txtHelp_Term_Condition);
            }
                break;
            case RECOMMEND:
            {
                obj.lblTitle.text=languageSelectedStringForKey(txtHelp_Recommend);
            }
                break;
            case SELECT_LANG:
            {
                obj.lblTitle.text=languageSelectedStringForKey(txtHelp_Select_language);
            }
                break;
            default:
                break;
        }
        
    }
    
    
}

// method use for create animation
-(void) createMovingAnimation:(UIView *)view OriginX:(float)oX OriginY:(float)oY{
    
}

// Event Handler for Help Icon Click.
-(void)OpenSlider :(id)sender
{
    UIButton *tmp=(UIButton *)sender;
    tmp.selected=!tmp.selected;
    if (tmp.selected)
    {
        [UIView animateWithDuration:0.5f
                              delay:0.0f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             MenuItemView.frame = CGRectMake(0, 0, 320,MenuItemView.frame.size.height);
                         }
                         completion:nil];
        //        [self startTimer];
    }else
    {
        [UIView animateWithDuration:0.5f
                              delay:0.0f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             MenuItemView.frame = CGRectMake(-275, 0, 320,MenuItemView.frame.size.height);
                             
                         }
                         completion:nil];
        //        [self stopAutoHideTimer];
        ///[scroll setContentOffset:CGPointMake(0,0) animated:NO];
        firstGroupedView.frame = CGRectMake(0, 0, firstGroupedView.frame.size.width, firstGroupedView.frame.size.height);
        secondGroupedView.frame = CGRectMake(CGRectGetMaxX(firstGroupedView.frame), 0, secondGroupedView.frame.size.width, secondGroupedView.frame.size.height);
        clickCount=0;
    }
}

// Design Help menu Content.
-(void)designHelpMenu :(CGRect)frame
{
    
    
    UIView *suportView = [[UIView alloc] initWithFrame:CGRectMake(27, 0, 200, frame.size.height)];
    suportView.clipsToBounds = YES;
    [MenuItemView addSubview:suportView];
    
    helpMenuItemObj=[[HelpMenuItem alloc]initWithHelpMenuFrame:CGRectMake(CGRectGetMaxX(MenuItemView.frame)-97, 0, 82, frame.size.height) delegate:self image:imgHelp_More Title:languageSelectedStringForKey(txtHelp_More) tag:MORE_OPTION];
    [MenuItemView addSubview:helpMenuItemObj];
    
    UIImageView *imgLine=[[UIImageView alloc]initWithFrame:CGRectMake(0, 1, 2, 46)];
    imgLine.image=[UIImage imageNamed:imgHelp_Tab_footer];
    [helpMenuItemObj addSubview:imgLine];
    [imgLine release];
    
    [helpMenuItemObj release];
    
    firstGroupedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, frame.size.height)];
    
    firstGroupedView.backgroundColor = [UIColor clearColor];
    [suportView addSubview:firstGroupedView];
    
    secondGroupedView = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(firstGroupedView.frame), 0, 300, frame.size.height)];
    secondGroupedView.backgroundColor = [UIColor clearColor];
    [suportView addSubview:secondGroupedView];
    [suportView release];
    //    scroll=[[UIScrollView alloc]initWithFrame:CGRectMake(20, 0,MenuItemView.frame.size.width-helpMenuItemObj.frame.size.width-35,frame.size.height)];
    //    scroll.backgroundColor=[UIColor clearColor];
    scroll.showsHorizontalScrollIndicator=NO;
    //    scroll.pagingEnabled=YES;
    //    scroll.showsVerticalScrollIndicator=NO;
    //    scroll.scrollEnabled=NO;
    //    [MenuItemView addSubview:scroll];
    //    [scroll release];
    [self addscrollViewContent:frame];
}

// Add content on Help Menu Scroll.
-(void)addscrollViewContent :(CGRect)frame
{
    HelpMenuDataClass *dataObj;
    
    int xpos=0;
    for (int i=0; i<[DataArray count]; i++)
    {
        dataObj=(HelpMenuDataClass *)[DataArray objectAtIndex:i];
        if (i%3==0) {
            xpos = 0;
        }
        
        helpMenuItemObj=[[HelpMenuItem alloc]initWithHelpMenuFrame:CGRectMake(xpos, 0, 100, frame.size.height) delegate:self image:dataObj.strimgName Title:dataObj.strTitle tag:dataObj.tag];
        // [scroll addSubview:helpMenuItemObj];
        
        if (i<3) {
            [firstGroupedView addSubview:helpMenuItemObj];
        }
        else {
            [secondGroupedView addSubview:helpMenuItemObj];
        }
        
        UIImageView *imgLine=[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(helpMenuItemObj.frame)-2, 1, 2, 46)];
        imgLine.image=[UIImage imageNamed:imgHelp_Tab_footer];
        [helpMenuItemObj addSubview:imgLine];
        [imgLine release];
        
        
        xpos=CGRectGetMaxX(helpMenuItemObj.frame);
        
        [helpMenuItemObj release];
    }
    
    //[scroll setContentSize:CGSizeMake(xpos, 0)];
    
    MenuItemView.frame=CGRectMake(-275, 0, 320, frame.size.height);
    
    
    if (DataArray!=nil)
    {
        [DataArray release];
        DataArray=nil;
    }
}

// Click Event Handler of click menu iitem click.
-(void)HelpItemClick :(id)sender
{
    UIButton *tmp=(UIButton *)sender;
    
    //    [self startTimer];
    switch (tmp.tag) {
        case ABOUT:
        {
            [self openAbout];
        }
            break;
        case CONTACT:
        {
            [self OpenContact];
        }
            break;
        case FAQ:
        {
            [self openFaq];
        }
            break;
        case TERM_CONDITION:
        {
            [self TermconditionOpen];
        }
            break;
        case RECOMMEND:
        {
            [self RecommendOpen];
        }
            break;
        case SELECT_LANG:
        {
            [self SelectLanguageOpen];
        }
            break;
        case MORE_OPTION:
        {
            clickCount++;
            [self itemChange];
        }
            break;
        default:
            break;
    }
}

// About click handler.
-(void)openAbout
{
    TermAndConditionViewController *tcvc = [[TermAndConditionViewController alloc] initWithNibName:@"TermAndConditionViewController" bundle:nil pageType:about_Page];
    [[AppDelegate sharedAppDelegate].naviGationController pushViewController:tcvc animated:YES];
    
    [tcvc release];
}

// Contact click handler.
-(void)OpenContact
{
    ContactUSViewController *cuvc = [[ContactUSViewController alloc] initWithNibName:@"ContactUSViewController" bundle:nil];
    [[AppDelegate sharedAppDelegate].naviGationController pushViewController:cuvc animated:YES];
    [cuvc release];

}

// Faq click handler.
-(void)openFaq
{
    TermAndConditionViewController *tcvc = [[TermAndConditionViewController alloc] initWithNibName:@"TermAndConditionViewController" bundle:nil pageType:FAQs_Page];
    [[AppDelegate sharedAppDelegate].naviGationController pushViewController:tcvc animated:YES];
    
    [tcvc release];
}

// T&C click handler.
-(void)TermconditionOpen
{
    TermAndConditionViewController *tcvc = [[TermAndConditionViewController alloc] initWithNibName:@"TermAndConditionViewController" bundle:nil pageType:term_and_Condition_Page];
    [[AppDelegate sharedAppDelegate].naviGationController pushViewController:tcvc animated:YES];
    
    [tcvc release];
}

// Recommend click handler.
-(void)RecommendOpen
{
    RecommendViewController *tcvc = [[RecommendViewController alloc] initWithNibName:@"RecommendViewController" bundle:nil];
    [[AppDelegate sharedAppDelegate].naviGationController pushViewController:tcvc animated:YES];
    
    [tcvc release];
}
-(void)removeChangeStatusView
{
    for (UIView *view in [[AppDelegate sharedAppDelegate].window subviews]) {
        if ([view isKindOfClass:[PopUpView class]]) {
            [view removeFromSuperview];
            if ([AppDelegate sharedAppDelegate].classType == LOGIN_PAGE) {
                if ([self.delegatelogin respondsToSelector:@selector(changeLaguageAtlogin)]) {
                    
                    [self.delegatelogin changeLaguageAtlogin];
                }
                
            }
            else if ([AppDelegate sharedAppDelegate].classType == REGISTRATION_PAGE) {
                if ([self.delegateReg respondsToSelector:@selector(changeLaguageAtRegister)]) {
                    [self.delegateReg changeLaguageAtRegister];
                }
            }
            break;
        }
    }
//    [self changeLanguage];
    
}
// SelectLanguage click handler.
-(void)SelectLanguageOpen
{
    PopUpView *csv = [[PopUpView alloc] initWithLanguageViewFrame:CGRectMake(0, 0, [AppDelegate sharedAppDelegate].screenWidth, [AppDelegate sharedAppDelegate].screenHeight) Delegate:self];
    [[AppDelegate sharedAppDelegate].window addSubview:csv];
}


// Change images on scroll view
-(void)itemChange
{
    if (clickCount==1)
    {
        //[scroll setContentOffset:CGPointMake(100*(2),0) animated:YES];
        if (secondGroupedView.frame.origin.x<0) {
            secondGroupedView.frame = CGRectMake(300, 0, secondGroupedView.frame.size.width,secondGroupedView.frame.size.height);
        }
        
        
        [UIView animateWithDuration:0.4f
                              delay:0.0f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             firstGroupedView.frame = CGRectMake(-200, 0, firstGroupedView.frame.size.width,firstGroupedView.frame.size.height);
                         }
                         completion:nil];
        [UIView animateWithDuration:0.4f
                              delay:0.0f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             secondGroupedView.frame = CGRectMake(100, 0, secondGroupedView.frame.size.width,secondGroupedView.frame.size.height);
                         }
                         completion:nil];
        
        
        
        
        
    }else if(clickCount==2)
    {
        // [scroll setContentOffset:CGPointMake(100*(4),0) animated:YES];
        [UIView animateWithDuration:0.2f
                              delay:0.0f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             firstGroupedView.frame = CGRectMake(-300, 0, firstGroupedView.frame.size.width,firstGroupedView.frame.size.height);
                         }
                         completion:nil];
        [UIView animateWithDuration:0.2f
                              delay:0.0f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             secondGroupedView.frame = CGRectMake(-0, 0, secondGroupedView.frame.size.width,secondGroupedView.frame.size.height);
                         }
                         completion:nil];
    }else
    {
        //        [scroll setContentOffset:CGPointMake(-100*(2),0) animated:NO];
        //  [scroll setContentOffset:CGPointMake(0,0) animated:NO];
        if (firstGroupedView.frame.origin.x<0) {
            firstGroupedView.frame = CGRectMake(200, 0, firstGroupedView.frame.size.width,firstGroupedView.frame.size.height);
        }
        
        [UIView animateWithDuration:0.4f
                              delay:0.0f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             firstGroupedView.frame = CGRectMake(0, 0, firstGroupedView.frame.size.width,firstGroupedView.frame.size.height);
                         }
                         completion:nil];
        [UIView animateWithDuration:0.4f
                              delay:0.0f
                            options: UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             secondGroupedView.frame = CGRectMake(-300, 0, secondGroupedView.frame.size.width,secondGroupedView.frame.size.height);
                         }
                         completion:nil];
        clickCount=0;
    }
}



#pragma mark - Timer
// Start Timer for auto hide.
-(void)startTimer
{
    //    [self stopAutoHideTimer];
    
    autoHideTimer = [NSTimer scheduledTimerWithTimeInterval:7.f
                                                     target:self
                                                   selector:@selector(HideAfterTimerComplete) userInfo:nil repeats:NO];
    
}

// Stop Timer for auto hide.
-(void)stopAutoHideTimer
{
    if ([autoHideTimer isValid])
    {
        [autoHideTimer invalidate];
    }
    autoHideTimer = nil;
}


// Hide Menu View Automatic.
-(void)HideAfterTimerComplete
{
    [UIView animateWithDuration:0.5f
                          delay:0.0f
                        options: UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         MenuItemView.frame = CGRectMake(-275, 0, 320,MenuItemView.frame.size.height);
                         
                     }
                     completion:nil];
    
    //[scroll setContentOffset:CGPointMake(0,0) animated:NO];
    clickCount=0;
    
    btnSliderOpen.selected=NO;
    //    [self stopAutoHideTimer];
}


-(void)dealloc
{
    
    if (DataArray!=nil)
    {
        [DataArray release];
        DataArray=nil;
    }
    
    [super dealloc];
}

@end
