//
//  ExpenseRulesViewController.m
//  CoreMoney

// Class is used for displaying the expense rules.

#import "ExpenseRulesViewController.h"
#import "MerchantCategoryCell.h"
#import "PopUpClass.h"



@interface ExpenseRulesViewController ()
-(void)settingScrollPosition :(int)tag;
-(void)getTextValue:(NSString *)value Tag:(int)tagValue;
-(void)removeChangeStatusView;
-(void)openBypassFlagPopup;
-(void) removecomboView;
-(void) selectQuetionview:(NSString *)dayName  SelectedIndex:(int)index;
-(void)getResponce:(id)jsonData;
-(void)getlimitParameter;
-(void)requestSaveSpendParameter :(int)type;
-(NSString *)interNationalUseRequest;
-(NSString *)dailyMonthlySpendLimitRequest;
-(NSString *)singleTxnLimitRequest;
-(NSString *)merchantCatRequest;
-(void) setAllViewinInitialPos;
-(NSString *)bypassCardMoneyRequest;
-(NSString *)bypassBusinessBudgetRequest;
-(void) delyedOpen;
-(void)openBack;
-(void)openSlide;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(void)setCardDetails;
-(void) setOfSet;
-(void)designExpenseView;
-(void)addMerchantCategoryonScrollView;
- (IBAction)cleckedOutsideBtn:(id)sender;
- (IBAction)btnInternationalUse:(id)sender;
- (IBAction)btnAllowance:(id)sender;
- (IBAction)btnSingleTansaction:(id)sender;
- (IBAction)btnMerchantCategory:(id)sender;
-(void) switchDelegateMethod:(id) sender;
- (IBAction)changeValueofslider:(id)sender;
@end

@implementation ExpenseRulesViewController
@synthesize cardDataObj,doneButton,expenseRulesData,strDayName;


typedef enum
{
    int_Switch=35,
    by_Pass_Budget,
    by_pass_Card,
}switchTag;

#pragma mark - Merchant View Delegate Method
//method use for set position of scroll view
-(void)settingScrollPosition :(int)tag
{
    
    switch (tag) {
        case 0:
             [merchantListScrollView setContentOffset:CGPointMake(0, 80) animated:YES];
            break;
        case 1:
             [merchantListScrollView setContentOffset:CGPointMake(0, 280) animated:YES];
            break;
        case 2:
             [merchantListScrollView setContentOffset:CGPointMake(0, 480) animated:YES];
            break;
        case 3:
             [merchantListScrollView setContentOffset:CGPointMake(0, 680) animated:YES];
            break;
        case 4:
             [merchantListScrollView setContentOffset:CGPointMake(0, 880) animated:YES];
            break;
        case 5:
             [merchantListScrollView setContentOffset:CGPointMake(0, 1080) animated:YES];
            break;
        case 6:
             [merchantListScrollView setContentOffset:CGPointMake(0, 1280) animated:YES];
            break;
        case 7:
             [merchantListScrollView setContentOffset:CGPointMake(0, 1480) animated:YES];
            break;
            
        default:
            break;
    }
    [self.expenseScrollView setContentOffset:CGPointMake(0, 180) animated:YES];
}
-(void)getTextValue:(NSString *)value Tag:(int)tagValue
{
//    NSLog(@"value=%@",value);
    
}
//called when touch starts
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self setOfSet];
}
//remove status view
-(void)removeChangeStatusView
{
    [self removecomboView];
    //at popup cancel switch doesnot change 
    if(checkByPassMonetaryAndBudget)
    {
    self.switch_BypMonetoryLimit.on=!self.switch_BypMonetoryLimit.on;
    }else
    {
     self.switch_BypBussBudgLmt.on=!self.switch_BypBussBudgLmt.on;
    }

}
// Pop to previous View
-(void)openBack
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    [self performSelector:@selector(delyedOpen) withObject:nil afterDelay:0.5];
}

-(void) delyedOpen{
    [self.navigationController popViewControllerAnimated:YES];
}

// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}
//method use for adding navigation bar to Expense Rules page
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        addNavigationBar(EXPENSE_RULES, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
    }
    return self;
}
//method use for storing data to  Expense Rules data class object
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil CardData:(ExpenseRulesdata *) carddata
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        addNavigationBar(EXPENSE_RULES, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        self.expenseRulesData = carddata;
//        NSLog(@"%d",[expenseRulesData.murchantCatData count]);
        if (arrMerchantCategoryData==nil)
        {
            arrMerchantCategoryData = [[NSMutableArray alloc] initWithArray:self.expenseRulesData.murchantCatData];
        }
        
    }
    return self;
}
//method use for set detail of card
-(void)setCardDetails
{
    self.lblName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings(cardDataObj.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@ ",cardDataObj.FIRSTNAME],checkISNullStrings(cardDataObj.LASTNAME)?@"":[NSString stringWithFormat:@"%@",cardDataObj.LASTNAME]];

    
    self.lblCardNumber.text =ChangeCardNumber(cardDataObj.CARDNUMBER) ;
    self.lblAmount.text = [NSString stringWithFormat:@"%@",displayCurrency( ChangeTocurrency(cardDataObj.AVAILABLEBALANCE))] ;
    
    self.lblCardStatus.text=CardStatusValue(cardDataObj.STATUS_CARDACCOUNT);
    
    self.switch_IntUse.on = self.expenseRulesData.International_Use_Allowed;
    
    self.txtDailyAllowanceLimit.text =checkISNullStrings(self.expenseRulesData.Daily_Spend_Limit)?@"":displayCurrency(ChangeTocurrency((([self.expenseRulesData.Daily_Spend_Limit doubleValue]))));
    
    self.txtMonthlyAllowanceLimit.text =checkISNullStrings(self.expenseRulesData.Monthly_Spend_Limit)?@"":displayCurrency(ChangeTocurrency((([self.expenseRulesData.Monthly_Spend_Limit doubleValue]))));
    
    self.txtSingleTransactionAmount.text =checkISNullStrings(self.expenseRulesData.SingleTransaction_Spend_Limit)?@"":displayCurrency(ChangeTocurrency((([self.expenseRulesData.SingleTransaction_Spend_Limit doubleValue]))));
    
    
    for (UISwitch *swch in self.byPassView.subviews)
    {
        if (swch.tag==by_pass_Card)
        {
            swch.on=self.expenseRulesData.ByPass_Card_Monetary_Limit;
        }
        if (swch.tag==by_Pass_Budget)
        {
            swch.on = self.expenseRulesData.ByPassBusiness_BudgetLimit ;
        }
        
    }

    
}

// methods use for setting view border  
-(void) createBorderofView:(UIView *) view
{
    view.layer.borderWidth = 1;
    view.layer.cornerRadius = 8;
    view.layer.borderColor = [UIColor grayColor].CGColor;
}

// method use for design of expense view
-(void)designExpenseView
{

    [self createBorderofView:self.internationalView];
    [self createBorderofView:self.allowanceView];
        [self createBorderofView:self.transactionView];
    [self createBorderofView:self.merchantView];
    
     [self createBorderofView:self.internationUseView];
   [self createBorderofView:self.dailyMonthlyView];
    [self createBorderofView:self.singleTransactionLimitView];
    [self createBorderofView:self.MerchantCategoryView];
    
}
//method use for adding Merchant category on scroll view
-(void)addMerchantCategoryonScrollView
{
    
    
    float posY = 175*[arrMerchantCategoryData count];
    
    self.MerchantCategoryView.frame = CGRectMake(self.MerchantCategoryView.frame.origin.x, self.MerchantCategoryView.frame.origin.y, self.MerchantCategoryView.frame.size.width, posY+80);
    
    merchantTableView = createTableView(CGRectMake(0, 8, 300, posY), self);
    
    merchantTableView.scrollEnabled = NO;
    [self.MerchantCategoryView addSubview:merchantTableView];
    
}
//method called when we click outside of button
- (IBAction)cleckedOutsideBtn:(id)sender {
    
    [self setAllViewinInitialPos];
}

-(void)viewWillAppear:(BOOL)animated
{
    [AppDelegate sharedAppDelegate].classType = CARDS_EXPENSE_RULE_PAGE;
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    [super viewWillAppear:animated];
    
}
- (void)viewDidLoad
{
   

    self.switch_IntUse.tag = int_Switch;
    self.switch_BypMonetoryLimit.tag = by_pass_Card;
    self.switch_BypBussBudgLmt.tag = by_Pass_Budget;
    self.expenseScrollView.maindelegate = self;
    cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
    self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, 320, 480);
    [super viewDidLoad];
    [self designExpenseView];
    [self setCardDetails];
    self.btnOutSideTouchBtn.enabled = NO;

    [self addMerchantCategoryonScrollView];
    
    
    // Do any additional setup after loading the view from its nib.
    self.expenseScrollView.frame=CGRectMake(0, 0, 320, 328);
    [self.bottomView addSubview:self.expenseScrollView];
    [self.expenseScrollView setContentSize:CGSizeMake(320,450)];
    if ([limitArray count]==0)
    {
        [self getlimitParameter];
    }
        
}
/*
 arrStatusData = [[NSMutableArray alloc]init];
 
 for (int i=0; i<[dataArray count]; i++)
 {
 secretQustionDataClass *expData=[dataArray objectAtIndex:i];
 
 PopUpClass *statusObj = [[PopUpClass alloc] init];
 statusObj.strTitle=expData.secretQuestion;
 statusObj.StatusNo=[expData.indexNo intValue];
 [arrStatusData addObject:statusObj];
 [statusObj release];
 }
 */
-(void) fetchLimitListFillLimitArray
{
//    arrSecretQuestion = [[NSMutableArray alloc] init];
    BOOL boolByPassCard = NO;
    BOOL boolByPassBuss = NO;
    
    
    for (int arrCounter = 0; arrCounter < [limitArray count]; arrCounter++)
    {
        secretQustionDataClass *expData=[limitArray objectAtIndex:arrCounter];
        if (!boolByPassCard)
        {
            if ([self.expenseRulesData.Period isEqualToString:expData.indexNo])
            {
             //- (NSRange)rangeOfString:(NSString *)aString;
                if([expData.secretQuestion rangeOfString:@"For "].location != NSNotFound)// expData.secretQuestion;
                {
                    self.lblByPassCardMonetaryLimitItem.text = [expData.secretQuestion substringFromIndex:3];
                }
                else
                {
                    self.lblByPassCardMonetaryLimitItem.text = expData.secretQuestion;
                }
                
                [self.switch_BypMonetoryLimit setOn:YES];
                boolByPassCard = YES;
            }
            else
            {
                self.lblByPassCardMonetaryLimitItem.text = @"";
                [self.switch_BypMonetoryLimit setOn:NO];
            }
        }
        if (!boolByPassBuss)
        {
            if ([self.expenseRulesData.BypassBusinessBugdetLimitPeriod isEqualToString:expData.indexNo])
            {
                if([expData.secretQuestion rangeOfString:@"For "].location != NSNotFound)// expData.secretQuestion;
                {
                    self.lblByPassBussBudgetLimitItem.text = [expData.secretQuestion substringFromIndex:3];
                }
                else
                {
                    self.lblByPassBussBudgetLimitItem.text = expData.secretQuestion;
                }                
                [self.switch_BypBussBudgLmt setOn:YES];
                boolByPassBuss = YES;
            }
            else
            {
                self.lblByPassBussBudgetLimitItem.text = @"";
                [self.switch_BypBussBudgLmt setOn:NO];
            }
        }
    }
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_lblName release];
    [_lblCardNumber release];
    [_lblCardStatus release];
    [_lblAmount release];
    [_internationUseView release];
    [_dailyMonthlyView release];
    [_singleTransactionLimitView release];
    [_MerchantCategoryView release];
    [_expenseScrollView release];
    [_lblExpenseTitle release];
    [_internationalView release];
    [_allowanceView release];
    [_transactionView release];
    [_merchantView release];
    [_bottomView release];
    [_byPassView release];
    [_txtDailyAllowanceLimit release];
    [_txtMonthlyAllowanceLimit release];
    [_txtSingleTransactionAmount release];
 
    [_btnOutSideTouchBtn release];
    [merchantTableView release];
    [_switch_IntUse release];
    [_bgView release];
    [_switch_BypMonetoryLimit release];
    [_switch_BypBussBudgLmt release];
    
    if ([arrMerchantCategoryData count]>0)
    {
        [arrMerchantCategoryData removeAllObjects];
    }
    //realese memory for arrMerchantCategoryData ,limitArray
    [arrMerchantCategoryData release];
    [limitArray release];
    cardDataObj=nil;
    objMerchantCategory=nil;
    self.expenseRulesData=nil;
    [super dealloc];
}
- (void)viewDidUnload {
    
    [self setExpenseRulesData:nil];
    [self setLblName:nil];
    [self setLblCardNumber:nil];
    [self setLblCardStatus:nil];
    [self setLblAmount:nil];
    [self setInternationUseView:nil];
    [self setDailyMonthlyView:nil];
    [self setSingleTransactionLimitView:nil];
    [self setMerchantCategoryView:nil];
    [self setExpenseScrollView:nil];
    [self setLblExpenseTitle:nil];
    [self setInternationalView:nil];
    [self setAllowanceView:nil];
    [self setTransactionView:nil];
    [self setMerchantView:nil];
    [self setBottomView:nil];
    [self setByPassView:nil];
    [self setTxtDailyAllowanceLimit:nil];
    [self setTxtMonthlyAllowanceLimit:nil];
    [self setTxtSingleTransactionAmount:nil];
    [self setBtnOutSideTouchBtn:nil];
    [self setSwitch_IntUse:nil];
    [self setBgView:nil];
    [self setSwitch_BypMonetoryLimit:nil];
    [self setSwitch_BypBussBudgLmt:nil];
    [super viewDidUnload];
}

#pragma mark - View Frame Settings
//method use for set all the intital parameters for view
-(void) setAllViewinInitialPos{
    
    [self.expenseScrollView setContentSize:CGSizeMake(320,450)];
    [self setOfSet];
    self.dailyMonthlyView.hidden=YES;
    self.btnOutSideTouchBtn.enabled = YES;
    
    self.internationalView.hidden=NO;
    self.singleTransactionLimitView.hidden=YES;
    self.transactionView.hidden=NO;
    
    self.lblExpenseTitle.text=@"International Use";
    self.lblExpenseTitle.hidden=YES;
    
    self.allowanceView.hidden = NO;
    self.internationUseView.hidden=YES;
    
    self.MerchantCategoryView.hidden=YES;
    self.merchantView.hidden=NO;
    
    self.byPassView.frame = CGRectMake(9, 275, 302, 145);
    self.internationalView.frame = CGRectMake(10, 20, 300, 45);
    
    self.allowanceView.frame = CGRectMake(10, 80, 300, 45);
    self.transactionView.frame = CGRectMake(10, 137, 300, 45);
    self.merchantView.frame = CGRectMake(10, 199, 300, 45);
    
    
}
// Method called on button pressed for Internation Use.
- (IBAction)btnInternationalUse:(id)sender {
    [self setAllViewinInitialPos];
    self.dailyMonthlyView.hidden=YES;
    
    self.internationalView.hidden=YES;
    self.singleTransactionLimitView.hidden=YES;
    self.transactionView.hidden=NO;
    self.btnOutSideTouchBtn.enabled = YES;
    self.lblExpenseTitle.text=@"International Use";
    self.lblExpenseTitle.hidden=NO;
    self.btnOutSideTouchBtn.frame = self.lblExpenseTitle.frame;
    self.internationUseView.center = CGPointMake(160, 80);
    self.internationUseView.hidden=NO;
    
    self.MerchantCategoryView.hidden=YES;
    self.merchantView.hidden=NO;
    
    self.lblExpenseTitle.center = CGPointMake(self.internationUseView.frame.origin.x+self.lblExpenseTitle.frame.size.width/2+25, self.internationUseView.frame.origin.y);
    self.lblExpenseTitle.frame=CGRectMake(self.lblExpenseTitle.frame.origin.x, self.lblExpenseTitle.frame.origin.y, 140, self.lblExpenseTitle.frame.size.height);
    self.btnOutSideTouchBtn.center = self.lblExpenseTitle.center;
    [self.expenseScrollView addSubview:self.internationUseView];
    [self.expenseScrollView addSubview:self.lblExpenseTitle];
    [self.expenseScrollView bringSubviewToFront:self.btnOutSideTouchBtn];
    self.allowanceView.center = CGPointMake(self.allowanceView.center.x, 170);
    self.allowanceView.hidden=NO;
    self.transactionView.center = CGPointMake(self.transactionView.center.x, 230);
    self.merchantView.center = CGPointMake(self.merchantView.center.x, 290);
    self.byPassView.frame = CGRectMake(10, CGRectGetMaxY(self.merchantView.frame)+10, 301, 145);
    [self.expenseScrollView setContentSize:CGSizeMake(320,500)];
    [self.expenseScrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    
}
// Method called on button pressed for Daily/Monthly Allowance.
- (IBAction)btnAllowance:(id)sender {
     [self setAllViewinInitialPos];
    self.lblExpenseTitle.text=@"Daily, Monthly Spend Limits";
    
    self.internationUseView.hidden=YES;
    self.internationalView.hidden=NO;
    
    self.dailyMonthlyView.hidden=NO;
    self.allowanceView.hidden=YES;
    self.lblExpenseTitle.hidden=NO;
    self.transactionView.hidden=NO;
    self.MerchantCategoryView.hidden=YES;
    self.merchantView.hidden=NO;
    [self.expenseScrollView addSubview:self.internationalView];
     self.btnOutSideTouchBtn.enabled = YES;
    self.lblExpenseTitle.frame=CGRectMake(self.lblExpenseTitle.frame.origin.x, self.lblExpenseTitle.frame.origin.y, 220, self.lblExpenseTitle.frame.size.height);
    self.lblExpenseTitle.center = CGPointMake(self.dailyMonthlyView.frame.origin.x+self.lblExpenseTitle.frame.size.width/2+25, 80);
    self.btnOutSideTouchBtn.frame = self.lblExpenseTitle.frame;
   
    self.btnOutSideTouchBtn.center = self.lblExpenseTitle.center;
    self.dailyMonthlyView.center=CGPointMake(160, 210);
    [self.expenseScrollView addSubview:self.dailyMonthlyView];
    [self.expenseScrollView addSubview:self.lblExpenseTitle];
    [self.expenseScrollView setContentSize:CGSizeMake(320,600)];
    [self.expenseScrollView setContentOffset:CGPointMake(0, 60) animated:YES];
    
    self.singleTransactionLimitView.hidden=YES;
    [self.expenseScrollView bringSubviewToFront:self.btnOutSideTouchBtn];
    self.transactionView.center = CGPointMake(self.transactionView.center.x, 370);
    self.merchantView.center = CGPointMake(self.merchantView.center.x, 430);
    self.byPassView.frame = CGRectMake(10, CGRectGetMaxY(self.merchantView.frame)+10, 301, 145);
    
}
// Method called on button pressed for Single Transaction Limit.
- (IBAction)btnSingleTansaction:(id)sender {
     [self setAllViewinInitialPos];
    self.lblExpenseTitle.text=@"Single Transaction Limit";
    
    self.internationUseView.hidden=YES;
    self.internationalView.hidden=NO;
    self.internationalView.frame=CGRectMake(10, 20, 300, 45);
    self.dailyMonthlyView.hidden=YES;
    self.transactionView.hidden=YES;
    self.allowanceView.hidden=NO;
    self.lblExpenseTitle.hidden=NO;
    self.singleTransactionLimitView.hidden=NO;
    self.MerchantCategoryView.hidden=YES;
    self.merchantView.hidden=NO;
    
    self.btnOutSideTouchBtn.enabled = YES;
    self.lblExpenseTitle.frame=CGRectMake(self.lblExpenseTitle.frame.origin.x, self.lblExpenseTitle.frame.origin.y, 200, self.lblExpenseTitle.frame.size.height);
    self.lblExpenseTitle.center = CGPointMake(self.singleTransactionLimitView.frame.origin.x+self.lblExpenseTitle.frame.size.width/2+25, 150);
    self.singleTransactionLimitView.center=CGPointMake(160, 230);
    self.btnOutSideTouchBtn.frame = self.lblExpenseTitle.frame;
    
    self.btnOutSideTouchBtn.center = self.lblExpenseTitle.center;
    [self.expenseScrollView addSubview:self.internationalView];
    [self.expenseScrollView addSubview:self.singleTransactionLimitView];
    [self.expenseScrollView addSubview:self.lblExpenseTitle];
    [self.expenseScrollView setContentSize:CGSizeMake(320,530)];
    [self.expenseScrollView setContentOffset:CGPointMake(0, 120) animated:YES];
    self.allowanceView.center = CGPointMake(self.allowanceView.center.x, 100);
    [self.expenseScrollView bringSubviewToFront:self.btnOutSideTouchBtn];
     self.merchantView.center = CGPointMake(self.merchantView.center.x, 350);
    self.byPassView.frame = CGRectMake(10, CGRectGetMaxY(self.merchantView.frame)+10, 301, 145);
}
// Method called on button pressed for Merchant Category Restriction.
- (IBAction)btnMerchantCategory:(id)sender {
     [self setAllViewinInitialPos];
    self.merchantView.hidden=YES;
    self.internationUseView.hidden=YES;
    self.dailyMonthlyView.hidden=YES;
    self.singleTransactionLimitView.hidden=YES;
    self.internationalView.hidden=NO;
    self.allowanceView.hidden=NO;
    self.btnOutSideTouchBtn.enabled = YES;
    self.lblExpenseTitle.text=@"Merchant Category Restriction";
    self.MerchantCategoryView.hidden=NO;
    self.lblExpenseTitle.hidden=NO;
    self.transactionView.hidden=NO;
    self.MerchantCategoryView.center=CGPointMake(160, 199+self.MerchantCategoryView.frame.size.height/2);
    self.lblExpenseTitle.frame=CGRectMake(self.MerchantCategoryView.frame.origin.x+25, self.MerchantCategoryView.frame.origin.y-self.lblExpenseTitle.frame.size.height/2, 250, self.lblExpenseTitle.frame.size.height);
    
    self.btnOutSideTouchBtn.frame = self.lblExpenseTitle.frame;
    
    self.btnOutSideTouchBtn.center = self.lblExpenseTitle.center;
    
    self.transactionView.center = CGPointMake(self.transactionView.center.x, 160);
    [self.expenseScrollView addSubview:self.MerchantCategoryView];
    [self.expenseScrollView addSubview:self.lblExpenseTitle];

    [self.expenseScrollView setContentSize:CGSizeMake(320,self.expenseScrollView.frame.size.height+self.MerchantCategoryView.frame.size.height+80)];
    [self.expenseScrollView setContentOffset:CGPointMake(0, 185) animated:YES];
    self.allowanceView.center = CGPointMake(self.allowanceView.center.x, 100);
    [self.expenseScrollView bringSubviewToFront:self.btnOutSideTouchBtn];
    self.byPassView.frame = CGRectMake(10, CGRectGetMaxY(self.MerchantCategoryView.frame)+10, 301, 145);
    
}
-(void) setOfSet{

    [self.txtMonthlyAllowanceLimit resignFirstResponder];
    [self.txtDailyAllowanceLimit resignFirstResponder];
        [self.txtSingleTransactionAmount resignFirstResponder];

    
    for (int i=0; i< [arrMerchantCategoryData count] ; i++) {
        
            NSIndexPath *indexPath=[NSIndexPath indexPathForRow:i inSection:0];
            
            for (UITextField *txtf in [merchantTableView cellForRowAtIndexPath:indexPath].subviews){
                [txtf resignFirstResponder];
            }
        }
}
#pragma mark - UITextFieldDelegate Methods
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    if ([textField isEqual:self.txtDailyAllowanceLimit]) {
        [self.txtMonthlyAllowanceLimit becomeFirstResponder];
    }
    else if ([textField isEqual:self.txtMonthlyAllowanceLimit]) {
        [self.txtMonthlyAllowanceLimit resignFirstResponder];
        self.expenseScrollView.contentOffset=CGPointMake(0, 0);
    }
    else if ([textField isEqual:self.txtSingleTransactionAmount]) {
        [self.txtSingleTransactionAmount resignFirstResponder];
        self.expenseScrollView.contentOffset=CGPointMake(0, 0);
    }

    for (int i=0; i< [arrMerchantCategoryData count] ; i++) {
        if (textField.tag == [[NSString stringWithFormat:@"%d1",i] intValue]) {
            NSIndexPath *indexPath=[NSIndexPath indexPathForRow:i inSection:0];

            for (UITextField *txtf in [merchantTableView cellForRowAtIndexPath:indexPath].subviews){
                if (txtf.tag == [[NSString stringWithFormat:@"%d2",i] intValue]) {
                    [txtf becomeFirstResponder];
                    break;
                }
            }
        }else if (textField.tag == [[NSString stringWithFormat:@"%d2",i] intValue]) {
            [textField resignFirstResponder];
        }
    }
    return YES;
    
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([textField isEqual:self.txtDailyAllowanceLimit]) {
        [self.expenseScrollView setContentOffset:CGPointMake(0, self.txtDailyAllowanceLimit.frame.origin.y+3) animated:YES];
//        self.txtDailyAllowanceLimit.text = @"";
    }
    else if ([textField isEqual:self.txtMonthlyAllowanceLimit]) {
        [self.expenseScrollView setContentOffset:CGPointMake(0, self.txtMonthlyAllowanceLimit.frame.origin.y+5) animated:YES];
//        self.txtMonthlyAllowanceLimit.text =@"";
    }
    else if ([textField isEqual:self.txtSingleTransactionAmount])
    {
        [self.expenseScrollView setContentOffset:CGPointMake(0, self.txtSingleTransactionAmount.frame.origin.y+80) animated:YES];
//        self.txtSingleTransactionAmount.text = @"";
    }
    for (int i=0; i< [arrMerchantCategoryData count] ; i++)
    {
        if (textField.tag == [[NSString stringWithFormat:@"%d1",i] intValue]) {
            [self.expenseScrollView setContentOffset:CGPointMake( 0, textField.frame.origin.y + 150 +175*i ) animated:YES];
//            textField.text = @"";
        }
        if (textField.tag == [[NSString stringWithFormat:@"%d2",i] intValue]) {
            [self.expenseScrollView setContentOffset:CGPointMake( 0, textField.frame.origin.y + 150 +175*i) animated:YES];
//            textField.text = @"";
        }

    }
    
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return digitValidationOnNumKeyboard(textField,range,string);
}

-(double) changAmountToDoubleWithDollar:(NSString *)strAmount
{
    double dblAmount = 0.0f;
    if ([strAmount rangeOfString:@"$"].length > 0)//([str rangeOfString:@"target"].length > 0)
    {
        NSString *strAmountWithoutDollar = [strAmount substringFromIndex:1];
        dblAmount = [strAmountWithoutDollar doubleValue];
    }
    else
    {
        dblAmount = [strAmount doubleValue];
    }
    return dblAmount;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    //double amount = [self changAmountToDoubleWithDollar:textField.text];
    textField.text=[NSString stringWithFormat:@"%0.2f",changeTextToAmount(textField.text)];
    
    for (int i=0; i< [arrMerchantCategoryData count] ; i++)
    {
        
        MerchantCategoryClass *cardObj;
        
        cardObj =(MerchantCategoryClass *)[arrMerchantCategoryData objectAtIndex:i];
        

        if (textField.tag == [[NSString stringWithFormat:@"%d1",i] intValue])
        {
            cardObj.SpendLimit_Auto=[NSString stringWithFormat:@"%@",checkISNullStrings(textField.text)?@"":textField.text];
            
             [arrMerchantCategoryData replaceObjectAtIndex:i withObject:cardObj];
        }
        if (textField.tag == [[NSString stringWithFormat:@"%d2",i] intValue])
        {
            cardObj.SpendLimit_Auto_Month=[NSString stringWithFormat:@"%@",checkISNullStrings(textField.text)?@"":textField.text];
            
             [arrMerchantCategoryData replaceObjectAtIndex:i withObject:cardObj];
        }
    }

}
//method use for showing alert when swich value changed
-(void) switchDelegateMethod:(id) sender
{
    UISwitch *sld = (UISwitch *)sender;
    switchOnOffValues = sld.on;
    selectedSwitchNo=sld.tag;
    showAlertWithOtherButtons(@"", @"Do you want to change the value?", sld.tag, self);
}

//method use for changing value of slider
- (IBAction)changeValueofslider:(id)sender {
    
    UISwitch *sld = (UISwitch *)sender;
    
     switchOnOffValues = sld.on;
    
    selectedSwitchNo=sld.tag;
    showAlertWithOtherButtons(@"", @"Do you want to change the value?", sld.tag, self);
}

#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == selectedSwitchNo) {
        
        if (buttonIndex == 1) {
            
            for (UISwitch *swch in self.byPassView.subviews)
            {
                if([swch isKindOfClass:[UISwitch class]])
                if (swch.tag==selectedSwitchNo) {
                    [swch setOn:!switchOnOffValues animated:YES];
                    break;
                }
                
            }
            for (UISwitch *swch in self.internationUseView.subviews)
            {
                if([swch isKindOfClass:[UISwitch class]])
                if (swch.tag==selectedSwitchNo)
                {
                    [swch setOn:!switchOnOffValues animated:YES];
                   
                    break;
                }
                
            }
            for (UIView *view in merchantTableView.subviews)
            {
                for(UISwitch *swch in view.subviews){
                    if([swch isKindOfClass:[UISwitch class]])
                if (swch.tag==selectedSwitchNo) {
                    [swch setOn:!switchOnOffValues animated:YES];
                    break;
                }
                }
            }
        }else
        {
            selectedSwitchNo = -1;
            switch (alertView.tag) {
                case by_pass_Card:
                    if (self.switch_BypMonetoryLimit.on==YES)
                    {
                        checkByPassMonetaryAndBudget=YES;
                        if ([limitArray count]==0)
                        {
                            [self getlimitParameter];
                        }else
                        {
                            [self openBypassFlagPopup];
                        }
                        
                    } else
                    {
                        [self requestSaveSpendParameter:Bypass_Card_money];
                    }
                    break;
          // case added for by pass business budget limit
                case by_Pass_Budget:
                    if(self.switch_BypBussBudgLmt.on==YES)
                    {
                        checkByPassMonetaryAndBudget=NO;
                        if([limitArray count]==0){
                            [self getlimitParameter];
                        }else
                        {
                            [self openBypassFlagPopup];
                        }
                    
                    }else{
                        [self requestSaveSpendParameter:bypass_Business_Budget];
                    }
                    break;
                case int_Switch:
                {
                    [self requestSaveSpendParameter:international_Use];
                }
                     
                    break;
                    
                default:
                {
                        for (UIView *view in merchantTableView.subviews)
                        {
                            for(UISwitch *swch in view.subviews){
                                if([swch isKindOfClass:[UISwitch class]])
                                    if (swch.tag==alertView.tag)
                                    {
                                            MerchantCategoryClass *cardObj;
                                            
                                            cardObj =(MerchantCategoryClass *)[arrMerchantCategoryData objectAtIndex:alertView.tag];
                                            
                                                cardObj.Default_Selection=[NSString stringWithFormat:@"%d",swch.on];
                                        [arrMerchantCategoryData replaceObjectAtIndex:alertView.tag withObject:cardObj];
                                        break;
                                    }
                            }
                        }
                }
                break;
            }
        }
    }
}

-(void)openBypassFlagPopup
{
    comboView = [[UIView alloc] initWithFrame:(CGRectMake(0, 0, self.bgView.frame.size.width, self.bgView.frame.size.height))];
    
    
    comboView.backgroundColor = [UIColor clearColor];
    [self.bgView addSubview:comboView];
    
    PopUpView *csv = [[PopUpView alloc] initWithBypassLoad:CGRectMake(0, 0, self.bgView.frame.size.width, self.bgView.frame.size.height) Delegate:self limitArray:limitArray];
    [comboView addSubview:csv];
    [csv release];
}

-(void) removecomboView
{
    if (comboView)
    {
        [comboView removeFromSuperview];
        comboView = nil;
    }
}
-(void) selectQuetionview:(NSString *)dayName SelectedIndex:(int)index SelectedItem:(NSString *)itemName
{
    NSLog(@"khan");
}

-(void) selectQuetionview:(NSString *)dayName  SelectedIndex:(int)index
{
    self.strDayName = dayName;
    selectedIndex = index;
    
    if(checkByPassMonetaryAndBudget)
    {
        [self requestSaveSpendParameter:Bypass_Card_money];
//        self.switch_BypMonetoryLimit.on=!self.switch_BypMonetoryLimit.on; 
    }else
    {
        [self requestSaveSpendParameter:bypass_Business_Budget];

//        self.switch_BypBussBudgLmt.on=!self.switch_BypBussBudgLmt.on;
    }
    
  
    
  [self removecomboView];
}

#pragma mark - UITableView Delegate Methods

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self setOfSet];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 175;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrMerchantCategoryData count];
}
// Delegate method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"Cell";
	
    MerchantCategoryCell *cell;
    
    cell = [[[MerchantCategoryCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier:CellIdentifier Delegate:self] autorelease];
    
    MerchantCategoryClass *cardObj;
    cardObj =(MerchantCategoryClass *)[arrMerchantCategoryData objectAtIndex:indexPath.row];
    
    cell.lblTitle.text = cardObj.MCCDescription;
    cell.txtDailyLimit.delegate = self;
    cell.txtDailyLimit.tag = [[NSString stringWithFormat:@"%d1",indexPath.row] intValue];
    cell.txtMonthlyLimit.tag = [[NSString stringWithFormat:@"%d2",indexPath.row] intValue];
    
    cell.txtMonthlyLimit.delegate = self;
    
    cell.txtDailyLimit.text =checkISNullStrings(cardObj.SpendLimit_Auto)?@"":displayCurrency(ChangeTocurrency((([cardObj.SpendLimit_Auto doubleValue]))));
    
    cell.txtMonthlyLimit.text = checkISNullStrings(cardObj.SpendLimit_Auto_Month)?@"":displayCurrency(ChangeTocurrency((([cardObj.SpendLimit_Auto_Month doubleValue]))));
    
    cell.lblSubTitle.text = cardObj.MCCPlanDescription;
    
    cell.slider.on = [cardObj.Default_Selection boolValue];
    cell.slider.tag = indexPath.row;
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}
//delegate method called when row selects
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
     [self setOfSet];
}


//method use for get responce from server
-(void)getResponce:(id)jsonData
{
    BOOL flag = NO;
    if (request_Id==1)
    {
        LoginResponceDataClass *responeObj=(LoginResponceDataClass *)jsonData;
        
        if (responeObj.Error_Code == 0)
        {
            switch (requestType)
            {
                case Daily_Monthly_Limit:
                {
                   self.expenseRulesData.Daily_Spend_Limit = checkISNullStrings(self.txtDailyAllowanceLimit.text)?@"":self.txtDailyAllowanceLimit.text;
                    
                   self.expenseRulesData.Monthly_Spend_Limit =checkISNullStrings(self.txtMonthlyAllowanceLimit.text)?@"":self.txtMonthlyAllowanceLimit.text;;

                }
                    break;
                case Single_Transaction_Limit:
                {
                    self.expenseRulesData.SingleTransaction_Spend_Limit = checkISNullStrings(self.txtSingleTransactionAmount.text)?@"":self.txtSingleTransactionAmount.text;
                }
                    break;
                case international_Use:
                {
                    self.expenseRulesData.International_Use_Allowed = self.switch_IntUse.on;
                }
                    break;
                case bypass_Business_Budget:
                {
                    self.expenseRulesData.International_Use_Allowed = self.switch_IntUse.on;
                }
                    break;
                case Bypass_Card_money:
                {
                    self.expenseRulesData.International_Use_Allowed = self.switch_IntUse.on;
                }
                    break;
                default:
                    break;
            }
        }
      
        showAlertScreen(nil, responeObj.ErrorMsg);
        [[AppDelegate sharedAppDelegate]removeLoadingView];

    }else if (request_Id==0)
    {
        [[AppDelegate sharedAppDelegate] removeLoadingView];
        flag = [limitArray count] > 0 ? NO:YES;
        if ([jsonData count]>0)
        {
            limitArray=jsonData;
        }
        if (flag)
        {
            [self fetchLimitListFillLimitArray];
        }
        else
        {
            [self openBypassFlagPopup];
        }
    }
}
//method to get limit parameter
-(void)getlimitParameter
{
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    request_Id=0;
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=CardLookUp_Request;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemSingleSignon=1&dbbServiceName=%@&dbbSystemExtLogin=1&deCIALutID=limitPeriod",[SystemConfiguration sharedSystemConfig].dbbServiceName]ServiceName:svcCCardLookUp];
    
    [DataReq release];
}

//method to send request for saving spend parameter
-(void)requestSaveSpendParameter :(int)type
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    request_Id=1;
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    requestType = type;
    
    NSString *parameterString = nil;
    switch (type)
    {
        case international_Use:
            parameterString=[self interNationalUseRequest];
            break;
        case Daily_Monthly_Limit:
             parameterString=[self dailyMonthlySpendLimitRequest];
            break;
        case Single_Transaction_Limit:
             parameterString=[self singleTxnLimitRequest];
            break;
        case Merchant_Category:
             parameterString=[self merchantCatRequest];
            break;
        case bypass_Business_Budget:
             parameterString=[self bypassBusinessBudgetRequest];
            break;
        case Bypass_Card_money:
             parameterString=[self bypassCardMoneyRequest]; // Making XML Request for Bypass Card Monetary Limits
            break;
        default:
            break;
    }
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=saveSpendParameter;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deSpendParameterResponse=%@",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, [SystemConfiguration sharedSystemConfig].dbbServiceName,parameterString] ServiceName:svcSaveAccountSpendParameter];
    
    [DataReq release];
}
//return Request string corresponding  internattional use 
-(NSString *)interNationalUseRequest
{
    NSString *strParameter;
    
     strParameter=[NSString stringWithFormat:@"<AccountLevelSpendSetUp><ACCOUNT_ID>%@</ACCOUNT_ID><Daily_Spend_Limit>%@</Daily_Spend_Limit><Monthly_Spend_Limit>%@</Monthly_Spend_Limit><SingleTransaction_Spend_Limit>%@</SingleTransaction_Spend_Limit><ByPass_Card_Monetary_Limit></ByPass_Card_Monetary_Limit><Period></Period><ByPassBusiness_BudgetLimit></ByPassBusiness_BudgetLimit><International_Use_Allowed>%d</International_Use_Allowed><UseMerchantCategory></UseMerchantCategory><SpendCardParametersToBeSet>0</SpendCardParametersToBeSet><AccountSpendCardSetup_CM></AccountSpendCardSetup_CM></AccountLevelSpendSetUp>",cardDataObj.ADMIN_NUMBER,checkISNullStrings(self.expenseRulesData.Daily_Spend_Limit)?@"":self.expenseRulesData.Daily_Spend_Limit,checkISNullStrings(self.expenseRulesData.Monthly_Spend_Limit)?@"":self.expenseRulesData.Monthly_Spend_Limit,checkISNullStrings(self.expenseRulesData.SingleTransaction_Spend_Limit)?@"":self.expenseRulesData.SingleTransaction_Spend_Limit,self.switch_IntUse.on];
    
    return strParameter;

}
//return Request string corresponding  daily, monthly spend limit  

-(NSString *)dailyMonthlySpendLimitRequest
{
    NSString *strParameter;
    
    strParameter=[NSString stringWithFormat:@"<AccountLevelSpendSetUp><ACCOUNT_ID>%@</ACCOUNT_ID><Daily_Spend_Limit>%@</Daily_Spend_Limit><Monthly_Spend_Limit>%@</Monthly_Spend_Limit><SingleTransaction_Spend_Limit>%@</SingleTransaction_Spend_Limit><ByPass_Card_Monetary_Limit></ByPass_Card_Monetary_Limit><Period></Period><ByPassBusiness_BudgetLimit></ByPassBusiness_BudgetLimit><International_Use_Allowed>%d</International_Use_Allowed><UseMerchantCategory></UseMerchantCategory><SpendCardParametersToBeSet>0</SpendCardParametersToBeSet><AccountSpendCardSetup_CM></AccountSpendCardSetup_CM></AccountLevelSpendSetUp>",cardDataObj.ADMIN_NUMBER,checkISNullStrings(self.txtDailyAllowanceLimit.text)?@"":self.txtDailyAllowanceLimit.text,checkISNullStrings(self.txtMonthlyAllowanceLimit.text)?@"":self.txtMonthlyAllowanceLimit.text,checkISNullStrings(self.expenseRulesData.SingleTransaction_Spend_Limit)?@"":self.expenseRulesData.SingleTransaction_Spend_Limit, self.expenseRulesData.International_Use_Allowed];
    return strParameter;
}
//return Request string corresponding  single Transaction Limit 

-(NSString *)singleTxnLimitRequest
{
    NSString *strParameter;
    
    strParameter=[NSString stringWithFormat:@"<AccountLevelSpendSetUp><ACCOUNT_ID>%@</ACCOUNT_ID><Daily_Spend_Limit>%@</Daily_Spend_Limit><Monthly_Spend_Limit>%@</Monthly_Spend_Limit><SingleTransaction_Spend_Limit>%@</SingleTransaction_Spend_Limit><ByPass_Card_Monetary_Limit></ByPass_Card_Monetary_Limit><Period></Period><ByPassBusiness_BudgetLimit></ByPassBusiness_BudgetLimit><International_Use_Allowed>%d</International_Use_Allowed><UseMerchantCategory></UseMerchantCategory><SpendCardParametersToBeSet>0</SpendCardParametersToBeSet><AccountSpendCardSetup_CM></AccountSpendCardSetup_CM></AccountLevelSpendSetUp>",cardDataObj.ADMIN_NUMBER,checkISNullStrings(self.expenseRulesData.Daily_Spend_Limit)?@"":self.expenseRulesData.Daily_Spend_Limit,checkISNullStrings(self.expenseRulesData.Monthly_Spend_Limit)?@"":self.expenseRulesData.Monthly_Spend_Limit,checkISNullStrings(self.txtSingleTransactionAmount.text)?@"":self.txtSingleTransactionAmount.text,self.expenseRulesData.International_Use_Allowed];
    
    
    return strParameter;
}
//return Request string corresponding  Merchant Category 

-(NSString *)merchantCatRequest
{
    NSString *strParameter;
    
       
    NSString *strMerchantCat=[[NSString alloc]init];
    
       
    for (int i=0; i< [arrMerchantCategoryData count]; i++)
    {
        MerchantCategoryClass *cardObj;
        
        cardObj =(MerchantCategoryClass *)[arrMerchantCategoryData objectAtIndex:i];
        
        strMerchantCat=[strMerchantCat stringByAppendingString:[NSString stringWithFormat:@"<MerchantCategory><MerchantCategoryCodePlan>%@</MerchantCategoryCodePlan><MCCPlanName_LutCode></MCCPlanName_LutCode><Default_Selection>%@</Default_Selection><SpendLimit_Auto>%@</SpendLimit_Auto><SpendLimit_Auto_Month>%@</SpendLimit_Auto_Month></MerchantCategory>",cardObj.MerchantCategoryCodePlan,cardObj.Default_Selection,checkISNullStrings(cardObj.SpendLimit_Auto)?@"":cardObj.SpendLimit_Auto , checkISNullStrings(cardObj.SpendLimit_Auto_Month)?@"":cardObj.SpendLimit_Auto_Month]];
    }
    
    
    strParameter=[NSString stringWithFormat:@"<AccountLevelSpendSetUp><ACCOUNT_ID>%@</ACCOUNT_ID><Daily_Spend_Limit></Daily_Spend_Limit><Monthly_Spend_Limit></Monthly_Spend_Limit><SingleTransaction_Spend_Limit></SingleTransaction_Spend_Limit><ByPass_Card_Monetary_Limit></ByPass_Card_Monetary_Limit><Period></Period><ByPassBusiness_BudgetLimit></ByPassBusiness_BudgetLimit><International_Use_Allowed></International_Use_Allowed><UseMerchantCategory>0</UseMerchantCategory><SpendCardParametersToBeSet>%d</SpendCardParametersToBeSet><AccountSpendCardSetup_CM>%@</AccountSpendCardSetup_CM></AccountLevelSpendSetUp>",cardDataObj.ADMIN_NUMBER,[arrMerchantCategoryData count],strMerchantCat];
    return strParameter;
}
//return request string corresponding  by pass Card Monetary 
-(NSString *)bypassCardMoneyRequest
{
    NSString *strParameter;
    NSString *strByPassCardMonetaryLimit = (self.switch_BypMonetoryLimit.on?@"0":@"1");
    NSString *strPeriod = [strByPassCardMonetaryLimit isEqualToString:@"0"]?[NSString stringWithFormat:@"%d",selectedIndex]:@"";
    
    if([self.strDayName rangeOfString:@"For "].location != NSNotFound)// expData.secretQuestion;
    {
        self.lblByPassCardMonetaryLimitItem.text = [self.strDayName substringFromIndex:3];
    }
    else
    {
        self.lblByPassCardMonetaryLimitItem.text = self.strDayName;
    }
    //self.lblByPassCardMonetaryLimitItem.text = self.strDayName;
    self.strDayName = @"";
    
    
    
    strParameter=[NSString stringWithFormat:@"<AccountLevelSpendSetUp><ACCOUNT_ID>%@</ACCOUNT_ID><Daily_Spend_Limit>%@</Daily_Spend_Limit><Monthly_Spend_Limit>%@</Monthly_Spend_Limit><SingleTransaction_Spend_Limit>%@</SingleTransaction_Spend_Limit><ByPass_Card_Monetary_Limit>%@</ByPass_Card_Monetary_Limit><Period>%@</Period><ByPassBusiness_BudgetLimit></ByPassBusiness_BudgetLimit><BypassBusinessBugdetLimitPeriod></BypassBusinessBugdetLimitPeriod><International_Use_Allowed>%d</International_Use_Allowed><UseMerchantCategory></UseMerchantCategory><SpendCardParametersToBeSet>0</SpendCardParametersToBeSet><AccountSpendCardSetup_CM></AccountSpendCardSetup_CM></AccountLevelSpendSetUp>",cardDataObj.ADMIN_NUMBER,checkISNullStrings(self.expenseRulesData.Daily_Spend_Limit)?@"":self.expenseRulesData.Daily_Spend_Limit,checkISNullStrings(self.expenseRulesData.Monthly_Spend_Limit)?@"":self.expenseRulesData.Monthly_Spend_Limit,checkISNullStrings(self.expenseRulesData.SingleTransaction_Spend_Limit)?@"":self.expenseRulesData.SingleTransaction_Spend_Limit,strByPassCardMonetaryLimit,strPeriod,self.expenseRulesData.International_Use_Allowed];
    
    
    
    return strParameter;
}

//return Request string corresponding  by pass Business Budget
-(NSString *)bypassBusinessBudgetRequest
{
    
    NSString *strParameter;
    
    NSString *strByPassBusinessBudgetLimit = (self.switch_BypBussBudgLmt.on?@"0":@"1");
    NSString *strBypassBusinessBugdetLimitPeriod = [strByPassBusinessBudgetLimit isEqualToString:@"0"]?[NSString stringWithFormat:@"%d",selectedIndex]:@"";
    
    if([self.strDayName rangeOfString:@"For "].location != NSNotFound)// expData.secretQuestion;
    {
        self.lblByPassBussBudgetLimitItem.text = [self.strDayName substringFromIndex:3];
    }
    else
    {
        self.lblByPassBussBudgetLimitItem.text = self.strDayName;
    }
//    self.lblByPassBussBudgetLimitItem.text = self.strDayName;
    self.strDayName = @"";
    
    strParameter=[NSString stringWithFormat:@"<AccountLevelSpendSetUp><ACCOUNT_ID>%@</ACCOUNT_ID><Daily_Spend_Limit>%@</Daily_Spend_Limit><Monthly_Spend_Limit>%@</Monthly_Spend_Limit><SingleTransaction_Spend_Limit>%@</SingleTransaction_Spend_Limit><ByPass_Card_Monetary_Limit></ByPass_Card_Monetary_Limit><Period></Period><ByPassBusiness_BudgetLimit>%@</ByPassBusiness_BudgetLimit><BypassBusinessBugdetLimitPeriod>%@</BypassBusinessBugdetLimitPeriod><International_Use_Allowed>%d</International_Use_Allowed><UseMerchantCategory></UseMerchantCategory><SpendCardParametersToBeSet>0</SpendCardParametersToBeSet><AccountSpendCardSetup_CM></AccountSpendCardSetup_CM></AccountLevelSpendSetUp>",cardDataObj.ADMIN_NUMBER,checkISNullStrings(self.expenseRulesData.Daily_Spend_Limit)?@"":self.expenseRulesData.Daily_Spend_Limit,checkISNullStrings(self.expenseRulesData.Monthly_Spend_Limit)?@"":self.expenseRulesData.Monthly_Spend_Limit,checkISNullStrings(self.expenseRulesData.SingleTransaction_Spend_Limit)?@"":self.expenseRulesData.SingleTransaction_Spend_Limit,strByPassBusinessBudgetLimit,strBypassBusinessBugdetLimitPeriod,self.expenseRulesData.International_Use_Allowed];
    
    return strParameter;
}

//method called when single Load Limit button pressed
- (IBAction)singleLoadLimitAction:(id)sender
{
    
    [self requestSaveSpendParameter:Single_Transaction_Limit];
}
//method called when daily monthly spend limit button pressed

- (IBAction)dailyMonthlySpendLimitAction:(id)sender
{
    
    [self requestSaveSpendParameter:Daily_Monthly_Limit];
}
//method called when merchant category button pressed

- (IBAction)merchantCategoryAction:(id)sender
{
    [self requestSaveSpendParameter:Merchant_Category];

}
@end
