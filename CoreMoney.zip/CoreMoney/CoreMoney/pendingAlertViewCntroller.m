//
//  pendingAlertViewCntroller.m
//  CoreMoney
//
//  Created by Mac Book on 13/01/14.
//  Copyright (c) 2014 Hunka. All rights reserved.
//

#import "pendingAlertViewCntroller.h"

@interface pendingAlertViewCntroller ()

@end

static int cardCellHeight = 70;

@implementation pendingAlertViewCntroller


// Method to open the slide menu on button click.
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

// Method called on back button pressed.
-(void)openBack
{
    [self.navigationController popViewControllerAnimated:YES];
//    [self requestBusinessData];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil dataArray:(NSMutableArray *)alertDataArray
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self)
    {
        alertArray = alertDataArray;
        self.title=[NSString stringWithFormat:@"%@",languageSelectedStringForKey(@"Card Pending Activation")];
        addNavigationBar(self.title, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);

        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_tblCardList release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setTblCardList:nil];
    [super viewDidUnload];
}


-(void)removeChangeStatusView
{
    
    [self removePopUpview];
    
}

// method use for remove popup view
-(void) removePopUpview{
    
    if (statusSelectView) {
        [statusSelectView removeFromSuperview];
        [statusSelectView release];
        statusSelectView = nil;
    }
    CardDetailClass *card = [alertArray objectAtIndex:selectedIndex];
    card.isActiveButtonShow=NO;
    _tblCardList.separatorColor=[UIColor clearColor];
    [_tblCardList reloadData];
    
}

-(void)changeCardStatus :(int)chagedStatus
{
    [self removePopUpview];
    
    newCardStatus=chagedStatus;
    
    CardDetailClass *card = [alertArray objectAtIndex:selectedIndex];
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    if (newCardStatus==ACTIVE_CARD && oldCardStatus== Pending_CARD )
    {
        [SystemConfiguration sharedSystemConfig].dbbServiceName=CARD_ACTIVE_REQUEST;
        
        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deTCIVRPrimaryAccountNumber=%@&deTCIVRCardRegistrationFirstName=&deTCIVRCardRegistrationMiddleName=&deTCIVRCardRegistrationLastName=&deTCIVRCardRegistrationAddress1=&deTCIVRCardRegistrationAddress2=&deTCIVRCardActivationEmail1=&deTCIVRCardActivationHomePhone=&deTCIVRCardActivationWorkPhone=&deTCIVRCardActivationPostalCode=&deTCIVRCardActivationBirthDate=&deTCIVRCardActivationLangIndiactor=&deTCIVRCardActivationSocialSecurity=&deTCIVRCardActivationCardExpirDate=&deTCIVRCardActivationCurrentPin=&deTCIVRCardActivationCurrentAccess=&deTCIVRCardActivationNewPin=&deTCIVRCardActivationNewAccess=&deTCIVRCardActivationLast4DigitsSSN=&deTCIVRCardActivationCVV=&deTCIVRCardActivationBirthYear=&deTCIVRCardActivationIdentification=&deTCIVRANI=&deTCIVRDNS=&deTCIVRInputLang=&deIVRSource=%@&deIVRIpAddress=&deIVRCallerId=&deIVRCalledId=&deIVRRequestTime=&deIVRSessionID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[NSString stringWithFormat:@"%@",checkISNullStrings(card.CARDNUMBER)?@"":card.CARDNUMBER],[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCardActivationActivateCard];
        
    }
    [DataReq release];
}


-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index
{
    newCardStatus=index;
    showAlertWithOtherButtons(nil,languageSelectedStringForKey(@"Do you want to change the Status ?") , 1, self);
    
}
#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0)
    {
        [self changeCardStatus:newCardStatus];
    }else
    {
        [self removePopUpview];
    }
    
}

// method use for create popup view for change status
-(void)openStatusView:(int)index
{
    selectedIndex=index;
    CardDetailClass *card = [alertArray objectAtIndex:selectedIndex];
    oldCardStatus=card.STATUS_CARDACCOUNT;
    if (card.STATUS_CARDACCOUNT==Pending_CARD)
    {
        statusSelectView = [[UIView alloc] initWithFrame:self.view.frame];
        statusSelectView.backgroundColor = [UIColor clearColor];
        statusSelectView.center = self.view.center;
        [self.view addSubview:statusSelectView];
        
        PopUpView *csv = [[PopUpView alloc] initWithPopViewFrame:CGRectMake(0, 0, 320, 480) CardData:card Delegate:self];
        
        [statusSelectView addSubview:csv];
        [csv release];

    }
}

#pragma mark - Touch Methods

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self removePopUpview];
}


-(void)getRequest
{
    
}

-(void)getResponce:(id)jsonData
{
        LoginResponceDataClass *dataObj=(LoginResponceDataClass *)jsonData;
        
        if (dataObj.Error_Found)
        {
            showAlertScreen(nil, dataObj.ErrorMsg);
        }else
        {
            CardDetailClass *card = [alertArray objectAtIndex:selectedIndex];
            
            card.STATUS_CARDACCOUNT=newCardStatus;
            
            _tblCardList.separatorColor=[UIColor clearColor];
            showAlertScreen(nil, dataObj.ErrorMsg);
        }
    
        [_tblCardList reloadData];
        [[AppDelegate sharedAppDelegate] removeLoadingView];
}

#pragma mark - UITableView Delegate Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return cardCellHeight;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [alertArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"Cell";
	
    CardDataCell *cell = (CardDataCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        cell = [[[CardDataCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier Delegate:self] autorelease];
    }
    cell.contentView.backgroundColor=(indexPath.row %2 == 0)? [UIColor colorWithPatternImage:[UIImage imageNamed:@"imgCellBackground"]] : [UIColor whiteColor];
    
    CardDetailClass *cardObj;
    cardObj =(CardDetailClass *)[alertArray objectAtIndex:indexPath.row];
    
    cell.lblTitleName.text=[NSString stringWithFormat:@"%@%@%@",checkISNullStrings(cardObj.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@ ",cardObj.FIRSTNAME],checkISNullStrings(cardObj.LASTNAME)?@"":[NSString stringWithFormat:@"%@ ",cardObj.LASTNAME],checkISNullStrings(cardObj.CustomAccountID)?@"":[NSString stringWithFormat:@","]];
    
    cell.lblTitleName.frame=CGRectMake(cell.lblTitleName.frame.origin.x, cell.lblTitleName.frame.origin.y, getTextWidth(cell.lblTitleName.text, cell.lblTitleName.font), cell.lblTitleName.frame.size.height);
    
    cell.lblEmployeeId.frame=CGRectMake(CGRectGetMaxX(cell.lblTitleName.frame), cell.lblEmployeeId.frame.origin.y,300-cell.lblTitleName.frame.size.width, cell.lblEmployeeId.frame.size.height);
    
    cell.lblEmployeeId.text=[NSString stringWithFormat:@"%@",checkISNullStrings(cardObj.CustomAccountID)?@"":[NSString stringWithFormat:@"%@",cardObj.CustomAccountID]];
    
    
    cell.lblCardNumber.text=[NSString stringWithFormat:@"%@",ChangeCardNumber(cardObj.CARDNUMBER)];
    
    cell.btnView.frame=CGRectMake(10, CGRectGetMaxY(cell.lblCardNumber.frame), 7, 13);
    cell.btnView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"imgStatusInactive"]];
    
    cell.imgArrow.hidden = YES;
    
    /*
     if index value is 114 then user can change the status else Not able to change the status and status option is dissable.
     */
    if ([AdminAccessInfo AdminAcess].updateCard == UPDATECARD)
    {
        /* If card status is Close, Stolen or Lost*/
        if (cardObj.STATUS_CARDACCOUNT==Pending_CARD  )
        {
            cell.btnState.enabled=YES;
            cell.btnView.hidden = NO;
            cell.lblStatus.frame = CGRectMake(CGRectGetMaxX(cell.btnView.frame)+5, cell.lblStatus.frame.origin.y, cell.lblStatus.frame.size.width, cell.lblStatus.frame.size.height);

        }else
        {
            cell.btnState.enabled=NO;
            cell.btnView.hidden = YES;
            cell.lblStatus.frame = CGRectMake(10, cell.lblStatus.frame.origin.y, cell.lblStatus.frame.size.width, cell.lblStatus.frame.size.height);

        }
    }
    else
    {
        cell.btnState.enabled = NO;
        cell.btnView.hidden = YES;
        cell.lblStatus.frame = CGRectMake(10, cell.lblStatus.frame.origin.y, cell.lblStatus.frame.size.width, cell.lblStatus.frame.size.height);
    }
    
    cell.lblStatus.text=CardStatusValue(cardObj.STATUS_CARDACCOUNT);
    
    
    cell.btnState.tag=indexPath.row;
    cell.lblAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(cardObj.AVAILABLEBALANCE))];
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}

@end
