//
//  FundingButtonView.m
//  CoreMoney


#import "FundingButtonView.h"

@implementation FundingButtonView
@synthesize lblName,img_view,img_Arrow,Img_view_backGround;

- (id)initWithFundingButtonFrame:(CGRect)frame title:(NSString *)BtnTitle delegate:(id)del icon:(NSString *)iconImage tag:(int)value
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        int adjustment = 0;
        
        Img_view_backGround = [[UIImageView alloc] initWithFrame:CGRectMake(5, 7, 310,45)];
        Img_view_backGround.image=[UIImage imageNamed:GetImageName(@"img_btnTabBg_home")];
        [self addSubview:Img_view_backGround];
        [Img_view_backGround release];
        
        lblName=createLabel(@"", CGRectMake(50, adjustment, 200, self.frame.size.height));
        lblName.backgroundColor=[UIColor clearColor];
        lblName.font=[UIFont systemFontOfSize:18.f];
        lblName.textColor=[UIColor blackColor];
        lblName.text=BtnTitle;
        // lblName.font=FONT_ARIAL_14;
        [self addSubview:lblName];
        [lblName release];
        
        
        img_view=[[UIImageView alloc] initWithFrame:CGRectMake(10, 14, 25,30)];
        img_view.image=[UIImage imageNamed:GetImageName(@"")];
        [self addSubview:img_view];
        [img_view release];
        
        img_Arrow=[[UIImageView alloc] initWithFrame:CGRectMake(290, 21, 10, 15)];
        img_Arrow.image=[UIImage imageNamed:GetImageName(@"img_arrow_home")];
        [self addSubview:img_Arrow];
        [img_Arrow release];
        
        UIButton *btnClick=createButton(CGRectMake(0, 0, frame.size.width, frame.size.height), @"", @"", del, @selector(ButtonFundingClick:));
        btnClick.tag=value;
        [self addSubview:btnClick];
        [btnClick release];
    }
    return self;
}


@end
