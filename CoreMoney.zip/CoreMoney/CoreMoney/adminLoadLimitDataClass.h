//
//  adminLoadLimitDataClass.h
//  CoreMoney

#import <Foundation/Foundation.h>

@interface adminLoadLimitDataClass : NSObject
{
    double DailyLimit,  DailyLimitForDayTime, MonthlyLimit,  SingleLimit;
    int BypassLoadLimitsFlag;
    NSString *DailyLoad,*MonthlyLoad,*SingleLoad;
}
@property  double DailyLimit,  DailyLimitForDayTime, MonthlyLimit,  SingleLimit ;
@property (nonatomic,retain)NSString *DailyLoad,*MonthlyLoad,*SingleLoad;
@property int BypassLoadLimitsFlag;

@end
