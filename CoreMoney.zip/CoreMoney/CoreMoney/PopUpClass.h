//
//  StatusClass.h

// Object Class for pop up view.
#import <Foundation/Foundation.h>

@interface PopUpClass : NSObject
{
    NSString *strTitle;
    BOOL isSelected;
    int StatusNo;
}
@property(nonatomic, retain) NSString *strTitle;
@property(nonatomic, assign) BOOL isSelected;
@property int StatusNo;

@end
