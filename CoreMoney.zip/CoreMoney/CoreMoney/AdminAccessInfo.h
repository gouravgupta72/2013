//
//  AdminAccessInfo.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface AdminAccessInfo : NSObject
{
    NSInteger updateCard, TerminateCard, loadCard, scheduleCard, expenseRules, initiateTransferValue, viewTransferValue,adminPageAccessValue, reportAccessValue, mgmtPolicyAccessValue, transactionHistoryValue;
}

@property(nonatomic, assign) NSInteger updateCard, TerminateCard, loadCard, scheduleCard, expenseRules,initiateTransferValue,viewTransferValue, adminPageAccessValue, reportAccessValue, mgmtPolicyAccessValue, transactionHistoryValue;
+(AdminAccessInfo *) AdminAcess;

-(void)resetPeremission;
@end
