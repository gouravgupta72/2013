//
//  DataParsingClass.h

// Class for Parsing json Data.

#import <Foundation/Foundation.h>
#import "Request.h"
#import "UserProfileDataClass.h"
#import "CardDetailClass.h"
#import "setteldTransaction.h"
#import "MemoDataClass.h"
#import "ExpenseCategoryData.h"
#import "newCardOrder.h"
#import "ReplaceCardData.h"
#import "lowBalanceSearchDataClass.h"
#import "ScheduleFundingSearchDataClass.h"

#import "AlertCountSearchClass.h"
#import "TransferDetailDataClass.h"
#import "ExternalBankDataClass.h"
#import "AlertDetailSearchClass.h"
#import "AdminDataClass.h"
#import "adminProfileData.h"
#import "adminLoadLimitDataClass.h"
#import "ExpenseRulesdata.h"
#import "MerchantCategoryClass.h"
#import "employeeDataClass.h"
#import "employeeExpenseDataClass.h"
#import "employeeExpData.h"
#import "SubCategoryDataClass.h"
#import "businessListDataClass.h"
#import "ExpenseCategory.h"

@protocol DataParsingDelegate;

@interface DataParsingClass : NSObject<RequestDelegate>
{
    id<DataParsingDelegate>Datadelegate;
    
    int RequestId;
    ExpenseRulesdata *expenseRulesData;
    NSMutableArray *DataArray;
}
@property(nonatomic,retain)id<DataParsingDelegate>Datadelegate;

-(void)SendRequest :(NSString *)Action Parameter:(NSString *)parameter ServiceName:(int)RequestName;

@end

@protocol DataParsingDelegate <NSObject>

-(void)getResponce:(id)jsonData;

@optional
-(void)getError:(id)error;

@end