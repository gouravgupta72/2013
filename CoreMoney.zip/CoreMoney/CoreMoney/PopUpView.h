//
//  ChangeStatusView.h


// Class to Design pop up view for - Select Language, Change Status, Security Questions

#import <UIKit/UIKit.h>
#import "CardDetailClass.h"
#import "ExpenseCategoryData.h"
@interface PopUpView : UIView<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *tblStatus;
    NSMutableArray *arrStatusData;
    id DELEGATE;
    BOOL isLanguage,isQuetion,isChangeStatus,ischangeAdminStatus,isExpense,isfrequency;
    int index;
}

- (id)initWithPopViewFrame:(CGRect)frame CardData:(CardDetailClass *)cardDataObj Delegate:(id)delegate;
-(void)handleStatus:(NSString *)strStatus SelectedIndex:(cardStatus)index;
- (id)initWithLanguageViewFrame:(CGRect)frame Delegate:(id)delegate;
-(id) initWithQuestionViewFram:(CGRect)frame Delegate:(id)delegate SelectedQue:(int)selectIndex;
-(void)removeChangeStatusView;
-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index;
-(id) initWithLoadFrequency:(CGRect)frame Delegate:(id)delegate SelectedQue:(int)selectIndex;
-(id) loadCalander:(CGRect) fram Delegate:(id)delegate;
-(id) initWithExpenceCategory:(CGRect)frame Delegate:(id)delegate SelectedQue:(NSString *)selectIndex Array:(NSMutableArray *)dataArray;

- (id)initWithAdminStatusViewFrame:(CGRect)frame CardData:(int )cardDataObj Delegate:(id)delegate;
-(id) initWithBypassLoad:(CGRect)frame Delegate:(id)delegate limitArray:(NSMutableArray*)arr;
@end
