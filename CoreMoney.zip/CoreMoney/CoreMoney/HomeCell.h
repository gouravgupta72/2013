//
//  HomeCell.h

//

#import <UIKit/UIKit.h>

@interface HomeCell : UITableViewCell
{
    UILabel *lblName;
    UIImageView *cellImage;
    UIImageView *cellArrowImage,*cellBgImage;
}
@property (nonatomic, retain) UILabel *lblName;
@property (nonatomic,retain) UIImageView *cellImage,*cellArrowImage,*cellBgImage;
@end
