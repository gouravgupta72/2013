//
//  CalanderView.m



#import "CalanderView.h"

@implementation CalanderView

- (id)initWithCalanderFrame:(CGRect)frame Delegate:(id)del backGroundColor:(UIColor *)bgColor date:(NSString *) selectDate
{
    self = [super initWithFrame:frame];
    if (self)
    {
        NSDate *uploadDate;// = [[NSDate alloc] init];
        if([selectDate isEqualToString:@"Date of Birth"] ||[selectDate isEqualToString:@"From"] || [selectDate isEqualToString:@"To"] ||[selectDate isEqualToString:@""] ){
            uploadDate = nil;
        }
        else
        {
            NSDateFormatter *df1=[[NSDateFormatter alloc] init];
            [df1 setDateFormat:@"MM-dd-yyyy"];
            NSDate *uploadDate1=[df1 dateFromString:selectDate];
            NSDateFormatter *df=[[NSDateFormatter alloc] init];
            [df setDateFormat:@"MM-dd-yyyy"];
            NSString *str = [df stringFromDate:uploadDate1];
            uploadDate=[df1 dateFromString:str];
        }
        delegate=del;
       viewBG =[[UIView alloc]initWithFrame:CGRectMake(8, 42,  200, 235)];
        viewBG.backgroundColor=bgColor;
        viewBG.layer.masksToBounds =  YES;
        [self addSubview:viewBG];
        
        calendarView = [[[KLCalendarView alloc] initWithFrameAndDate:CGRectMake(0, 0,  200, 235) delegate:self ChooseDate:uploadDate] autorelease];
        calendarView.backgroundColor=[UIColor clearColor];
        self.layer.masksToBounds=YES;
        [viewBG addSubview:calendarView];
        
        UIImageView *topView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 218, 315)];
        topView.image = [UIImage imageNamed:@"img_boxcalender.png"];
        [self addSubview:topView];
        [topView release];

        
        UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 3,  200, 40)];
        lblTitle.textColor = [UIColor whiteColor];
        lblTitle.backgroundColor = [UIColor clearColor];
        lblTitle.textAlignment = NSTextAlignmentCenter;
        lblTitle.text = @"Select date";
        [self addSubview:lblTitle];
        [lblTitle release];
        
        
        UIButton *btnCancel = createButton(CGRectMake(130-52, 355-80,60, 26), @"", imgNAV_CancelBtn, self, @selector(cancelBtn));
        [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [self addSubview:btnCancel];
        [btnCancel release];
        
        
        
        
        
//        calendarView.hidden=YES;
    }
    return self;
}
- (id)initWithCalanderFrame:(CGRect)frame Delegate:(id)del selectDate:(NSDate *) date
{
    self = [super initWithFrame:frame];
    if (self)
    {
        delegate=del;
        
        viewBG =[[UIView alloc]initWithFrame:CGRectMake(0, 0,  200, 220)];
       // viewBG.backgroundColor=bgColor;
        viewBG.layer.masksToBounds =  YES;
        [self addSubview:viewBG];
        
              KLCalendarView *klc = [[KLCalendarView alloc] initWithFrameAndDate:self.frame delegate:self ChooseDate:date];
        
        [viewBG addSubview:klc];
        [klc release];
        
        //        calendarView.hidden=YES;
    }
    return self;
}


-(void) cancelBtn{
    
    [delegate calanderCancelDelegate];
}
/*----- Calendar Delegates -----> */

- (void)calendarView:(KLCalendarView *)calendarView tappedTile:(KLTile *)aTile
{
	
    NSString * dStr=[NSString stringWithFormat:@"%@",[aTile date]];
    NSDateFormatter *df1=[[NSDateFormatter alloc] init];
    [df1 setDateFormat:@"yyyy-MM-dd"];
    NSDate *uploadDate=[df1 dateFromString:dStr];
    NSDateFormatter *df=[[NSDateFormatter alloc] init];
    [df setDateFormat:@"MM-dd-yyyy"];
    NSString *str = [df stringFromDate:uploadDate];
//    NSLog(@"Date Selected is %@",str);
    
    if ([delegate respondsToSelector:@selector(PickDate:)]) {
        
        [delegate PickDate:str];
    }
}

- (KLTile *)calendarView:(KLCalendarView *)calendarView createTileForDate:(KLDate *)date
{
	CheckmarkTile *tiles = [[CheckmarkTile alloc] init];
	return tiles;
}

- (void)didChangeMonths{
	
    UIView *clip = calendarView.superview;
    if (!clip)
        return;
    
    CGRect f = clip.frame;
    NSInteger weeks = [calendarView selectedMonthNumberOfWeeks];
    CGFloat adjustment = 0.f;
    
    switch (weeks) {
        case 4:
            adjustment = (92/321)*300+30;
            break;
        case 5:
            adjustment = (46/321)*300;
            break;
        case 6:
            adjustment = 0.f;
            break;
        default:
            break;
    }
    f.size.height = 300 - adjustment;
    clip.frame = f;
	
	//CGRect f2 = CGRectMake(0,260-adjustment,320,160+adjustment);
	
	tile = nil;
}
// Method put here to remove compilation error. These are the delegate methods
-(void) calanderCancelDelegate
{
    
}
-(void)PickDate: (id)sender
{
    
}
- (id)initWithCalanderFrame:(CGRect)frame Delegate:(id)del backGroundColor:(UIColor *)bgColor
{
    return self;
}

@end
