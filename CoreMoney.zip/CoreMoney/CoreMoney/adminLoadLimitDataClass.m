//
//  adminLoadLimitDataClass.m
//  CoreMoney


#import "adminLoadLimitDataClass.h"

@implementation adminLoadLimitDataClass
@synthesize DailyLimit, DailyLoad, DailyLimitForDayTime, MonthlyLimit, MonthlyLoad, SingleLimit, SingleLoad, BypassLoadLimitsFlag;
@end
