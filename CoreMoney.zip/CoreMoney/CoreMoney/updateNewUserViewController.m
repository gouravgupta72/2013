//
//  updateNewUserViewController.m
//  CoreMoney


#import "updateNewUserViewController.h"

@interface updateNewUserViewController ()

@end

@implementation updateNewUserViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        addNavigationBar(languageSelectedStringForKey(UPdate_Password) , NAV_LEFT_BACK, NAV_RIGHT_NONE, self);
        // Custom initialization
    }
    return self;
}
-(void)openBack
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)viewDidLoad
{
    
    self.pageScroll.frame=CGRectMake(self.pageScroll.frame.origin.x,IS_IPAD?IS_IOS7?59:59:IS_IOS7?89:39, self.pageScroll.frame.size.width, self.pageScroll.frame.size.height);
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    self.lblUserId.text=[UserDetailClass sharedUser].strUserId;
    [super viewWillAppear:animated];
}

-(BOOL)checkField
{
    if (self.txtNewPassword.text.length<=0)
    {
        showAlertScreen(@"Password", @"Please Enter Password");
        [self.txtNewPassword becomeFirstResponder];
        return NO;
    }
    
    if (self.txtConfirmPassword.text.length<=0)
    {
        showAlertScreen(@"Confirm Password", @"Please Enter Confirm Password");
        [self.txtConfirmPassword becomeFirstResponder];
         return NO;
    }
    
    if (![self.txtNewPassword.text isEqualToString:self.txtConfirmPassword.text])
    {
        showAlertScreen(@"Password Mismatch", @"Password and Confirm Password should be same.");
        [self.txtConfirmPassword becomeFirstResponder];
         return NO;
    }
     return YES;
}

// set page in previouse position
-(void) setOfset{

    
    self.pageScroll.contentOffset=CGPointMake(0, 0);
    
    [self.txtNewPassword resignFirstResponder];
    
    [self.txtConfirmPassword resignFirstResponder];
}
#pragma -mark UITextField Method

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isEqual:self.txtNewPassword] )
	{
        [self.txtConfirmPassword becomeFirstResponder];
        
	}
	else if ([textField isEqual:self.txtConfirmPassword])
	{
		[self.txtConfirmPassword resignFirstResponder];
        [self setOfset];
	}
    else
    {
        [self setOfset];
    }
    [self.pageScroll setContentSize:CGSizeMake(240,350)];
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
    if ([textField isEqual:self.txtNewPassword]) {
        
        //  [self.pageScroll setContentOffset:CGPointMake(0, self.txtUserName.frame.origin.y-4) animated:YES];
    }
    if ([textField isEqual:self.txtConfirmPassword])
    {
        
          [self.pageScroll setContentOffset:CGPointMake(0, self.txtConfirmPassword.frame.origin.y+10) animated:YES];
    }
    [self.pageScroll setContentSize:CGSizeMake(320,600)];
    
    return YES;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_lblUserId release];
    [_txtNewPassword release];
    [_txtConfirmPassword release];
    [_pageScroll release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setLblUserId:nil];
    [self setTxtNewPassword:nil];
    [self setTxtConfirmPassword:nil];
    [self setPageScroll:nil];
    [super viewDidUnload];
}

-(void)getResponce:(id)jsonData
{
    LoginResponceDataClass *loginDataobj=(LoginResponceDataClass *)jsonData;
    
    if (loginDataobj.Error_Code==0)
    {
        showAlertWithOkButton(nil, loginDataobj.ErrorMsg, Forget_pwd_req, self);
    }else
    {
        showAlertScreen(nil, loginDataobj.ErrorMsg);
    }

    [[AppDelegate sharedAppDelegate]removeLoadingView];
}

-(void)UpdateRequest
{
    DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
    dataParsing.Datadelegate=self;
    [[AppDelegate sharedAppDelegate] addloadingView];

    [SystemConfiguration sharedSystemConfig].dbbSystemSingleSignon=@"1";
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Update_User_Reqest;
    
    [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=%@&dbbServiceName=%@&deANAuserid=%@&deANAUsrOldPassword=&deANAUsrPassword=%@&deIVRSource=%@&deIVRIpAddress=&deIVRCallerId=&deIVRCalledId=&deIVRRequestTime=&deIVRSessionID=&deANASecOldQuestion=&deANASecOldAnswer=&deANASecQuestion=&deANASecAnswer=&deTCIVRDOB=&deBAEmailID=&de_AddressLine1=&de_AddressLine2=&deANACity=&de_Country=&de_State=&de_ZipCode=&deANAUpdateUserFlag=&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbSystemSingleSignon,[SystemConfiguration sharedSystemConfig].dbbServiceName, [UserDetailClass sharedUser].strUserId,self.txtNewPassword.text,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcUpdateNewUser];
    
    [dataParsing release];
}

#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}


- (IBAction)btnSubmitAction:(id)sender
{
    if ([self checkField])
    {
        [self UpdateRequest];
    }
}
@end
