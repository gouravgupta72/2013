//
//  alertGroupViewController.h
//  CoreMoney


#import <UIKit/UIKit.h>

@interface alertGroupViewController : SwipeViewController
{
    NSMutableArray *arrAlertCountData,*alertGroupData;
}
@property (retain, nonatomic) IBOutlet UITableView *tblAlertGroup;
@property (nonatomic,retain) NSMutableArray *arrAlertCountData;
@property (retain, nonatomic) IBOutlet UIView *backView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil Array:(NSMutableArray *) dataArr;
@end
