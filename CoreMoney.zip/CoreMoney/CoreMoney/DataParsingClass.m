//
//  DataParsingClass.m
//  CoreMoney


// Class for Parsing json Data.

#import "DataParsingClass.h"

@implementation DataParsingClass
@synthesize Datadelegate;

-(void)SendRequest :(NSString *)Action Parameter:(NSString *)parameter ServiceName:(int)RequestName
{
    RequestId=RequestName;
    Request *req=[[Request alloc] init];
    req.delegate=self;
    [req request:Action Parameter:[parameter stringByAddingPercentEscapesUsingEncoding:NSStringEncodingConversionAllowLossy]];
    [req release];
}

-(void)getResult:(id)jsonData
{
    [self DataParsing:jsonData];
}

-(void)dealloc
{
    if (self.Datadelegate!=nil)
    {
        self.Datadelegate=nil;
    }
    [expenseRulesData release];
    [super dealloc];
}

-(void)getError:(id)error{
    
}
// Parse data and send back to requested class.
-(void)DataParsing :(NSDictionary *)json
{
    switch (RequestId)
    {
        case svcAlertRead:
        {
             LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id AlertRead_Res=[json valueForKey:@"AlertRead_Res"];
            
            if (![[AlertRead_Res valueForKey:@"ErrorMessage"]isKindOfClass:[NSNull class]])
            {
                id ErrorMessage=[AlertRead_Res valueForKey:@"ErrorMessage"];
                loginDataobj.ErrorMsg=ErrorMessage;
            }
            
            if (![[AlertRead_Res valueForKey:@"ErrorCode"]isKindOfClass:[NSNull class]])
            {
                id ErrorCode=[AlertRead_Res valueForKey:@"ErrorCode"];
                loginDataobj.Error_Code=[ErrorCode intValue];
            }
          
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
        }
            break;
        case svcUserLogin:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id UserLoginResponse=[json valueForKey:@"UserLoginResponse"];
            
            if (![[UserLoginResponse valueForKey:@"Error_Code"]isKindOfClass:[NSNull class]])
            {
                id Error_Code=[UserLoginResponse valueForKey:@"Error_Code"];
                
                loginDataobj.Error_Code = [Error_Code intValue];
            }
            
            if (![[UserLoginResponse valueForKey:@"Err_Msg"]isKindOfClass:[NSNull class]])
            {
                id Err_Msg = [UserLoginResponse valueForKey:@"Err_Msg"];
                
                loginDataobj.ErrorMsg=Err_Msg;
            }
            
            if (![[UserLoginResponse valueForKey:@"LastName"]isKindOfClass:[NSNull class]])
            {
                id LastName=[UserLoginResponse valueForKey:@"LastName"];
                
                [UserDetailClass sharedUser].LastName=LastName;
            }
            
            if (![[UserLoginResponse valueForKey:@"UserName"]isKindOfClass:[NSNull class]])
            {
                id UserName=[UserLoginResponse valueForKey:@"UserName"];
                
                [UserDetailClass sharedUser].UserName=UserName;
            }
            
            if (![[UserLoginResponse valueForKey:@"LAST_ACCESSED_AT"]isKindOfClass:[NSNull class]])
            {
                id LAST_ACCESSED_AT=[UserLoginResponse valueForKey:@"LAST_ACCESSED_AT"];
                
                [UserDetailClass sharedUser].LAST_ACCESSED_AT=LAST_ACCESSED_AT;
            }
            
            if (![[UserLoginResponse valueForKey:@"GETTAGSDETAIL"]isKindOfClass:[NSNull class]])
            {
                id GETTAGSDETAIL=[UserLoginResponse valueForKey:@"GETTAGSDETAIL"];
                
                if (![GETTAGSDETAIL isKindOfClass:[NSNull class]])
                {
                    id TabDetail=[GETTAGSDETAIL valueForKey:@"TabDetail"];
                    
                    if (![TabDetail isKindOfClass:[NSNull class]])
                    {
                        if ([TabDetail isKindOfClass:[NSArray class]])
                        {
                            for (int i=0; i<[TabDetail count]; i++)
                            {
                                if (![[[TabDetail objectAtIndex:i] valueForKey:@"MenuID"] isKindOfClass:[NSNull class]])
                                {
                                    id MenuID=[[TabDetail objectAtIndex:i] valueForKey:@"MenuID"];
                                    
                                    switch ([MenuID intValue])
                                    {
                                        case UPDATECARD:
                                            [AdminAccessInfo AdminAcess].updateCard=UPDATECARD;
                                            [AdminAccessInfo AdminAcess].TerminateCard=TERMINATECARD;
                                            break;
                                        case LOADCARD:
                                            [AdminAccessInfo AdminAcess].loadCard=LOADCARD;
                                            break;
                                        case SCHEDULECARD:
                                            [AdminAccessInfo AdminAcess].scheduleCard=SCHEDULECARD;
                                            break;
                                        case EXPENSERULES:
                                            [AdminAccessInfo AdminAcess].expenseRules=EXPENSERULES;
                                            break;
                                        case INITIATETRANSFER:
                                            [AdminAccessInfo AdminAcess].initiateTransferValue=INITIATETRANSFER;
                                            break;
                                        case VIEWTRANSFER:
                                            [AdminAccessInfo AdminAcess].viewTransferValue=VIEWTRANSFER;
                                            break;
                                        case ADMINPAGEACCESS:
                                            [AdminAccessInfo AdminAcess].adminPageAccessValue=ADMINPAGEACCESS;
                                            [AdminAccessInfo AdminAcess].mgmtPolicyAccessValue=MGMTPOLICYACCESS;
                                            break;
                                        case REPORTACCESS:
                                            [AdminAccessInfo AdminAcess].reportAccessValue=REPORTACCESS;
                                            break;
                                        case TRANSACTIONHISTORY:
                                              [AdminAccessInfo AdminAcess].transactionHistoryValue=TRANSACTIONHISTORY;
                                            break;
                                                                        
                                        default:
                                            break;
                                    }
                                }
                            }
                        }else
                        {
                            if (![[TabDetail valueForKey:@"MenuID"] isKindOfClass:[NSNull class]])
                            {
                                id MenuID=[TabDetail valueForKey:@"MenuID"];
                                
                                switch ([MenuID intValue])
                                {
                                    case UPDATECARD:
                                        [AdminAccessInfo AdminAcess].updateCard=UPDATECARD;
                                        [AdminAccessInfo AdminAcess].TerminateCard=TERMINATECARD;
                                        break;
                                    case LOADCARD:
                                        [AdminAccessInfo AdminAcess].loadCard=LOADCARD;
                                        break;
                                    case SCHEDULECARD:
                                        [AdminAccessInfo AdminAcess].scheduleCard=SCHEDULECARD;
                                        break;
                                    case EXPENSERULES:
                                        [AdminAccessInfo AdminAcess].expenseRules=EXPENSERULES;
                                        break;
                                    case INITIATETRANSFER:
                                        [AdminAccessInfo AdminAcess].initiateTransferValue=INITIATETRANSFER;
                                        break;
                                    case VIEWTRANSFER:
                                        [AdminAccessInfo AdminAcess].viewTransferValue=VIEWTRANSFER;
                                        break;
                                    case ADMINPAGEACCESS:
                                        [AdminAccessInfo AdminAcess].adminPageAccessValue=ADMINPAGEACCESS;
                                        [AdminAccessInfo AdminAcess].mgmtPolicyAccessValue=MGMTPOLICYACCESS;
                                        break;
                                    case REPORTACCESS:
                                        [AdminAccessInfo AdminAcess].reportAccessValue=REPORTACCESS;
                                        break;
                                    case TRANSACTIONHISTORY:
                                        [AdminAccessInfo AdminAcess].transactionHistoryValue=TRANSACTIONHISTORY;
                                        break;
                                        
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                }
                
            }

            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
            
        case svcValidateUserID:
        {
            UserIdValidationClass *idValidDataobj=[[UserIdValidationClass alloc]init];
            id ValidateUserID_Res=[json valueForKey:@"ValidateUserID_Res"];
            
            if (![[ValidateUserID_Res valueForKey:@"ERRMSG"]isKindOfClass:[NSNull class]])
            {
                id ERRMSG=[ValidateUserID_Res valueForKey:@"ERRMSG"];
                idValidDataobj.ERRMSG=ERRMSG;
            }
            
            if (![[ValidateUserID_Res valueForKey:@"ERR_NUMBER"]isKindOfClass:[NSNull class]])
            {
                id ERR_NUMBER=[ValidateUserID_Res valueForKey:@"ERR_NUMBER"];
                idValidDataobj.ERR_NUMBER=[ERR_NUMBER intValue];
            }
            
            if (![[ValidateUserID_Res valueForKey:@"ERR_NUMBER"]isKindOfClass:[NSNull class]])
            {
                id ERROR_FOUND=[ValidateUserID_Res valueForKey:@"ERROR_FOUND"];
                idValidDataobj.ERROR_FOUND=[ERROR_FOUND boolValue];
            }
            
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:idValidDataobj];
                }
            }
            
        }
            break;
            
        case svcCCardLookUp:
        {
            if (!DataArray)
            {
                DataArray=[[NSMutableArray alloc]init];
            }else
            {
                [DataArray removeAllObjects];
            }
            
            id CCARDLOOKUP_RET=[json valueForKey:@"CCARDLOOKUP_RET"];
            
            if (![[CCARDLOOKUP_RET valueForKey:@"COMBODETAIL"]isKindOfClass:[NSNull class]])
            {
                id COMBODETAIL=[CCARDLOOKUP_RET valueForKey:@"COMBODETAIL"];
                
                if ([COMBODETAIL isKindOfClass:[NSArray class]])
                {
                    for (int i=0; i<[COMBODETAIL  count]; i++)
                    {
                        secretQustionDataClass *dataObj=[[secretQustionDataClass alloc]init];
                        
                        if (![[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTCODE"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.indexNo=[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTCODE"] ;
                        }
                        if (![[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTDESCRIPTION"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.secretQuestion=[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTDESCRIPTION"] ;
                        }
                        
                        [DataArray addObject:dataObj];
                        [dataObj release];
                    }
                }else
                {
                    secretQustionDataClass *dataObj=[[secretQustionDataClass alloc]init];
                    
                    if (![[COMBODETAIL  valueForKey:@"LUTCODE"]isKindOfClass:[NSNull class]])
                    {
                        dataObj.indexNo=[COMBODETAIL valueForKey:@"LUTCODE"] ;
                    }
                    if (![[COMBODETAIL valueForKey:@"LUTDESCRIPTION"]isKindOfClass:[NSNull class]])
                    {
                        dataObj.secretQuestion=[COMBODETAIL valueForKey:@"LUTDESCRIPTION"] ;
                    }
                    
                    [DataArray addObject:dataObj];
                    [dataObj release];

                }
                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                {
                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                    {
                        [self.Datadelegate getResponce:DataArray];
                    }
                }
                
            }
            
        }
            break;
            
        case svcCheckSecretQuestion:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id CheckQuestionResponse=[json valueForKey:@"CheckQuestionResponse"];
            
            if (![[CheckQuestionResponse valueForKey:@"Error_Code"]isKindOfClass:[NSNull class]])
            {
                id Error_Code=[CheckQuestionResponse valueForKey:@"Error_Code"];
                
                loginDataobj.Error_Code=[Error_Code intValue];
            }
            
            if (![[CheckQuestionResponse valueForKey:@"Err_Msg"]isKindOfClass:[NSNull class]])
            {
                id Err_Msg=[CheckQuestionResponse valueForKey:@"Err_Msg"];
                
                loginDataobj.ErrorMsg=Err_Msg;
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
            
        case svcBusinessAccountSearch:
        {
            
            if (!DataArray)
            {
                DataArray=[[NSMutableArray alloc]init];
            }else
            {
                [DataArray removeAllObjects];
            }
            
            id BusinessAccountSearch_Res=[json valueForKey:@"BusinessAccountSearch_Res"];
            
            if (![[BusinessAccountSearch_Res valueForKey:@"ACCT_ID"]isKindOfClass:[NSNull class]])
            {
//                id ACCT_ID=[BusinessAccountSearch_Res valueForKey:@"ACCT_ID"];
            }
            
            if (![[BusinessAccountSearch_Res valueForKey:@"Arr_Grp"]isKindOfClass:[NSNull class]])
            {
                id Arr_Grp=[BusinessAccountSearch_Res valueForKey:@"Arr_Grp"];
                
                if (![[Arr_Grp valueForKey:@"INSIDE_ARR"]isKindOfClass:[NSNull class]])
                {
                    id INSIDE_ARR=[Arr_Grp valueForKey:@"INSIDE_ARR"];
                    if ([INSIDE_ARR isKindOfClass:[NSArray class]])
                    {
                        for (int i=0; i<[INSIDE_ARR count]; i++)
                        {
                            BusinessPageDetail *dataObj=[[BusinessPageDetail alloc]init];
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"ACCTID"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.ACCTID=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"ACCTID"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"ADDRESS1"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.ADDRESS1=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"ADDRESS1"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"ADDRESSLINE2"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.ADDRESSLINE2=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"ADDRESSLINE2"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"AccountNumber"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.AccountNumber=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"AccountNumber"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"Account_Billing"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.Account_Billing=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"Account_Billing"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"ActiveAdmins"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.ActiveAdmins=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"ActiveAdmins"]  intValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"AvailableBalance"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.AvailableBalance=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"AvailableBalance"] doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BToBTransfer"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BToBTransfer=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BToBTransfer"]  doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BlockedCards"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BlockedCards=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BlockedCards"]  intValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessCurrentBalance"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BusinessCurrentBalance=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessCurrentBalance"]  doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessDesignation"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BusinessDesignation=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessDesignation"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessMTDCardSpend"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BusinessMTDCardSpend=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessMTDCardSpend"]  doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessName"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BusinessName=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessName"] ;
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessTotalAvailableCardBalance"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BusinessTotalAvailableCardBalance=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessTotalAvailableCardBalance"]  doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessTotalAvailableFunds"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BusinessTotalAvailableFunds=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessTotalAvailableFunds"] doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessTotalCurrentCardBalance"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BusinessTotalCurrentCardBalance=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessTotalCurrentCardBalance"]  doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessTotalPendingCreditTransactions"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BusinessTotalPendingCreditTransactions=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessTotalPendingCreditTransactions"] doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessTotalPendingDebitTransactions"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BusinessTotalPendingDebitTransactions=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessTotalPendingDebitTransactions"]  doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessYTDCardSpend"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.BusinessYTDCardSpend=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"BusinessYTDCardSpend"]  doubleValue];
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"Business_ID_Desc"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.Business_ID_Desc=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"Business_ID_Desc"] ;
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"CARDLINE4"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.CARDLINE4=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"CARDLINE4"] ;
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"CARD_STATUS"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.CARD_STATUS=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"CARD_STATUS"]  intValue];
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"CITY"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.CITY=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"CITY"] ;
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"COUNTRY"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.COUNTRY=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"COUNTRY"] ;
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"CRAD_LIMIT"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.CRAD_LIMIT=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"CRAD_LIMIT"]  doubleValue];
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"CURRENT_BALANCE"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.CURRENT_BALANCE=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"CURRENT_BALANCE"]  doubleValue];
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"DATE_APPROVED"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.DATE_APPROVED=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"DATE_APPROVED"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"DDANumber"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.DDANumber=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"DDANumber"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"DateOfIncorporation"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.DateOfIncorporation=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"DateOfIncorporation"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"EMAIL_ADDRESS1"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.EMAIL_ADDRESS1=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"EMAIL_ADDRESS1"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"FIRST_NAME"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.FIRST_NAME=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"FIRST_NAME"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"HOME_PHONE"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.HOME_PHONE=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"HOME_PHONE"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"HomeFaxNumber"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.HomeFaxNumber=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"HomeFaxNumber"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"InactiveCards"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.DATE_APPROVED=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"InactiveCards"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"IsEnrollmentFeePaid"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.IsEnrollmentFeePaid=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"IsEnrollmentFeePaid"]  boolValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LANGUAGE_INDICATOR"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.LANGUAGE_INDICATOR=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LANGUAGE_INDICATOR"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LAST_NAME"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.LAST_NAME=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LAST_NAME"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LastAdminLogin"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.LastAdminLogin=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LastAdminLogin"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LastCreditTransferDate"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.LastCreditTransferDate=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LastCreditTransferDate"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LastDebitTransferDate"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.LastDebitTransferDate=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LastDebitTransferDate"];
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LastTransfer"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.LastTransfer=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"LastTransfer"]  doubleValue];
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"MAX_LOAD_AMT"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.MAX_LOAD_AMT=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"MAX_LOAD_AMT"]  doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"NumberOfCards"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.NumberOfCards=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"NumberOfCards"]  intValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"OD_AMT"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.OD_AMT=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"OD_AMT"]  intValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"OwningPartner"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.OwningPartner=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"OwningPartner"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"PHONEEXTENSION"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.PHONEEXTENSION=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"PHONEEXTENSION"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"PRODUCT_PARENT"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.PRODUCT_PARENT=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"PRODUCT_PARENT"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"Parent_Bussiness"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.Parent_Bussiness=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"Parent_Bussiness"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"PendingCardTxns"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.PendingCardTxns=[[[INSIDE_ARR objectAtIndex:i] valueForKey:@"PendingCardTxns"]  doubleValue];
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"STATE"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.STATE=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"STATE"] ;
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"TaxId"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.TaxId=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"TaxId"] ;
                            }
                            
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"URL"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.URL=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"URL"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"WAREHOUSED_AMOUNT"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.WAREHOUSED_AMOUNT=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"WAREHOUSED_AMOUNT"] ;
                            }
                            
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"WaiveEnrollmentFee"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.WaiveEnrollmentFee=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"WaiveEnrollmentFee"] ;
                            }
                            if (![[[INSIDE_ARR objectAtIndex:i] valueForKey:@"ZIP_CODE"]isKindOfClass:[NSNull class]])
                            {
                                dataObj.ZIP_CODE=[[INSIDE_ARR objectAtIndex:i] valueForKey:@"ZIP_CODE"] ;
                            }
                            [DataArray addObject:dataObj];
                            [dataObj release];
                        }
                    }else
                    {
                        BusinessPageDetail *dataObj=[[BusinessPageDetail alloc]init];
                        
                        if (![[INSIDE_ARR valueForKey:@"ACCTID"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.ACCTID=[INSIDE_ARR valueForKey:@"ACCTID"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"ADDRESS1"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.ADDRESS1=[INSIDE_ARR valueForKey:@"ADDRESS1"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"ADDRESSLINE2"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.ADDRESSLINE2=[INSIDE_ARR valueForKey:@"ADDRESSLINE2"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"AccountNumber"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.AccountNumber=[INSIDE_ARR valueForKey:@"AccountNumber"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"Account_Billing"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.Account_Billing=[INSIDE_ARR valueForKey:@"Account_Billing"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"ActiveAdmins"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.ActiveAdmins=[[INSIDE_ARR valueForKey:@"ActiveAdmins"]  intValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"AvailableBalance"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.AvailableBalance=[[INSIDE_ARR valueForKey:@"AvailableBalance"] doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BToBTransfer"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BToBTransfer=[[INSIDE_ARR valueForKey:@"BToBTransfer"]  doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BlockedCards"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BlockedCards=[[INSIDE_ARR valueForKey:@"BlockedCards"]  intValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BusinessCurrentBalance"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BusinessCurrentBalance=[[INSIDE_ARR valueForKey:@"BusinessCurrentBalance"]  doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BusinessDesignation"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BusinessDesignation=[INSIDE_ARR valueForKey:@"BusinessDesignation"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BusinessMTDCardSpend"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BusinessMTDCardSpend=[[INSIDE_ARR valueForKey:@"BusinessMTDCardSpend"]  doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BusinessName"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BusinessName=[INSIDE_ARR valueForKey:@"BusinessName"] ;
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"BusinessTotalAvailableCardBalance"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BusinessTotalAvailableCardBalance=[[INSIDE_ARR valueForKey:@"BusinessTotalAvailableCardBalance"]  doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BusinessTotalAvailableFunds"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BusinessTotalAvailableFunds=[[INSIDE_ARR valueForKey:@"BusinessTotalAvailableFunds"]  doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BusinessTotalCurrentCardBalance"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BusinessTotalCurrentCardBalance=[[INSIDE_ARR valueForKey:@"BusinessTotalCurrentCardBalance"]  doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BusinessTotalPendingCreditTransactions"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BusinessTotalPendingCreditTransactions=[[INSIDE_ARR valueForKey:@"BusinessTotalPendingCreditTransactions"]  doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BusinessTotalPendingDebitTransactions"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BusinessTotalPendingDebitTransactions=[[INSIDE_ARR valueForKey:@"BusinessTotalPendingDebitTransactions"]  doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"BusinessYTDCardSpend"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.BusinessYTDCardSpend=[[INSIDE_ARR valueForKey:@"BusinessYTDCardSpend"]  doubleValue];
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"Business_ID_Desc"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.Business_ID_Desc=[INSIDE_ARR valueForKey:@"Business_ID_Desc"] ;
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"CARDLINE4"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.CARDLINE4=[INSIDE_ARR valueForKey:@"CARDLINE4"] ;
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"CARD_STATUS"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.CARD_STATUS=[[INSIDE_ARR valueForKey:@"CARD_STATUS"]  intValue];
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"CITY"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.CITY=[INSIDE_ARR valueForKey:@"CITY"] ;
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"COUNTRY"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.COUNTRY=[INSIDE_ARR valueForKey:@"COUNTRY"] ;
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"CRAD_LIMIT"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.CRAD_LIMIT=[[INSIDE_ARR valueForKey:@"CRAD_LIMIT"]  doubleValue];
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"CURRENT_BALANCE"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.CURRENT_BALANCE=[[INSIDE_ARR valueForKey:@"CURRENT_BALANCE"]  doubleValue];
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"DATE_APPROVED"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.DATE_APPROVED=[INSIDE_ARR valueForKey:@"DATE_APPROVED"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"DDANumber"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.DDANumber=[INSIDE_ARR valueForKey:@"DDANumber"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"DateOfIncorporation"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.DateOfIncorporation=[INSIDE_ARR valueForKey:@"DateOfIncorporation"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"EMAIL_ADDRESS1"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.EMAIL_ADDRESS1=[INSIDE_ARR valueForKey:@"EMAIL_ADDRESS1"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"FIRST_NAME"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.FIRST_NAME=[INSIDE_ARR valueForKey:@"FIRST_NAME"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"HOME_PHONE"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.HOME_PHONE=[INSIDE_ARR valueForKey:@"HOME_PHONE"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"HomeFaxNumber"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.HomeFaxNumber=[INSIDE_ARR valueForKey:@"HomeFaxNumber"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"InactiveCards"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.DATE_APPROVED=[INSIDE_ARR valueForKey:@"InactiveCards"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"IsEnrollmentFeePaid"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.IsEnrollmentFeePaid=[[INSIDE_ARR valueForKey:@"IsEnrollmentFeePaid"]  boolValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"LANGUAGE_INDICATOR"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.LANGUAGE_INDICATOR=[INSIDE_ARR valueForKey:@"LANGUAGE_INDICATOR"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"LAST_NAME"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.LAST_NAME=[INSIDE_ARR valueForKey:@"LAST_NAME"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"LastAdminLogin"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.LastAdminLogin=[INSIDE_ARR valueForKey:@"LastAdminLogin"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"LastCreditTransferDate"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.LastCreditTransferDate=[INSIDE_ARR valueForKey:@"LastCreditTransferDate"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"LastDebitTransferDate"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.LastDebitTransferDate=[INSIDE_ARR valueForKey:@"LastDebitTransferDate"] ;
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"LastTransfer"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.LastTransfer=[[INSIDE_ARR valueForKey:@"LastTransfer"]  doubleValue];
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"MAX_LOAD_AMT"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.MAX_LOAD_AMT=[[INSIDE_ARR valueForKey:@"MAX_LOAD_AMT"]  doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"NumberOfCards"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.NumberOfCards=[[INSIDE_ARR valueForKey:@"NumberOfCards"]  intValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"OD_AMT"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.OD_AMT=[[INSIDE_ARR valueForKey:@"OD_AMT"]  intValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"OwningPartner"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.OwningPartner=[INSIDE_ARR valueForKey:@"OwningPartner"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"PHONEEXTENSION"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.PHONEEXTENSION=[INSIDE_ARR valueForKey:@"PHONEEXTENSION"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"PRODUCT_PARENT"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.PRODUCT_PARENT=[INSIDE_ARR valueForKey:@"PRODUCT_PARENT"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"Parent_Bussiness"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.Parent_Bussiness=[INSIDE_ARR valueForKey:@"Parent_Bussiness"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"PendingCardTxns"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.PendingCardTxns=[[INSIDE_ARR valueForKey:@"PendingCardTxns"]  doubleValue];
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"STATE"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.STATE=[INSIDE_ARR valueForKey:@"STATE"] ;
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"TaxId"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.TaxId=[INSIDE_ARR valueForKey:@"TaxId"] ;
                        }
                        
                        
                        if (![[INSIDE_ARR valueForKey:@"URL"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.URL=[INSIDE_ARR valueForKey:@"URL"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"WAREHOUSED_AMOUNT"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.WAREHOUSED_AMOUNT=[INSIDE_ARR valueForKey:@"WAREHOUSED_AMOUNT"] ;
                        }
                        
                        if (![[INSIDE_ARR valueForKey:@"WaiveEnrollmentFee"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.WaiveEnrollmentFee=[INSIDE_ARR valueForKey:@"WaiveEnrollmentFee"] ;
                        }
                        if (![[INSIDE_ARR valueForKey:@"ZIP_CODE"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.ZIP_CODE=[INSIDE_ARR valueForKey:@"ZIP_CODE"] ;
                        }
                        [DataArray addObject:dataObj];
                        [dataObj release];
                    }
                    
                }
                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                {
                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                    {
                        [self.Datadelegate getResponce:DataArray];
                    }
                }
            }
        }
            break;
            
        case svcBACardHolderList:
        {
            if (!DataArray)
            {
                DataArray=[[NSMutableArray alloc]init];
            }else
            {
                [DataArray removeAllObjects];
            }
            
            id CARDSEARCH_RET=[json valueForKey:@"CARDSEARCH_RET"];
            
            if (![[CARDSEARCH_RET valueForKey:@"ResErrorCode"]isKindOfClass:[NSNull class]])
            {
                id ResErrorCode=[CARDSEARCH_RET valueForKey:@"ResErrorCode"];
                if ([ResErrorCode isEqualToString:@"Msgcs01"])
                {
                    if (![CARDSEARCH_RET isKindOfClass:[NSNull class]] && CARDSEARCH_RET!=nil)
                    {
                        id CARD_LIST=[CARDSEARCH_RET valueForKey:@"CARD_LIST"];
                        if (![CARD_LIST isKindOfClass:[NSNull class]] && CARD_LIST!=nil)
                        {
                            
                            if (![[CARD_LIST valueForKey:@"CARD_DETAIL"] isKindOfClass:[NSNull class]] && [CARD_LIST valueForKey:@"CARD_DETAIL"]!=nil)
                            {
                                id CARD_DETAIL=[CARD_LIST valueForKey:@"CARD_DETAIL"];
                                if ([CARD_DETAIL isKindOfClass:[NSArray class]])
                                {
                                    for (int i=0; i<[CARD_DETAIL count]; i++)
                                    {
                                        CardDetailClass *dataObj=[[CardDetailClass alloc]init];
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ACCOUNTNUMBER"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.ACCOUNTNUMBER=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ACCOUNTNUMBER"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ACQUISITIONSOURCE"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.ACQUISITIONSOURCE=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ACQUISITIONSOURCE"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ADDRESS1"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.ADDRESS1=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ADDRESS1"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ADDRESSLINE2"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.ADDRESSLINE2=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ADDRESSLINE2"] ;
                                        }
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ADMIN_NUMBER"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.ADMIN_NUMBER=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ADMIN_NUMBER"] ;
                                        }
                                        
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"AGENTID"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.AGENTID=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"AGENTID"] ;
                                        }
                                        
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"AVAILABLEBALANCE"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.AVAILABLEBALANCE=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"AVAILABLEBALANCE"]  doubleValue];
                                        }
                                        
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"AccountGeneratedStatus"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.AccountGeneratedStatus=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"AccountGeneratedStatus"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"AccountManualStatus"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.AccountManualStatus=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"AccountManualStatus"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"AlertEmailAddress"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.AlertEmailAddress=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"AlertEmailAddress"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"BSAcctID"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.BSAcctID=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"BSAcctID"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"BSAgentId"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.BSAgentId=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"BSAgentId"] ;
                                        }
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CARDEXPIRATIONDATE"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.CARDEXPIRATIONDATE=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CARDEXPIRATIONDATE"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CARDNUMBER"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.CARDNUMBER=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CARDNUMBER"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CARDSTATUS"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.CARDSTATUS=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CARDSTATUS"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CITY"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.CITY=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CITY"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CLIENTID"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.CLIENTID=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CLIENTID"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"COUNTRY"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.COUNTRY=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"COUNTRY"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CURRENTBALANCE"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.CURRENTBALANCE=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CURRENTBALANCE"]  doubleValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ChangeAccessCodeCounter"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.ChangeAccessCodeCounter=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ChangeAccessCodeCounter"] intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CradType"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.CradType=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CradType"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CustomAccountID"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.CustomAccountID=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CustomAccountID"] ;
                                        }
                                        
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CustomAccountIDLabel"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.CustomAccountIDLabel=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"CustomAccountIDLabel"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"DATEOFBIRTH"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.DATEOFBIRTH=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"DATEOFBIRTH"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"DDANumber"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.DDANumber=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"DDANumber"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"DecisionFlag"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.DecisionFlag=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"DecisionFlag"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"DispatchDate"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.DispatchDate=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"DispatchDate"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"EMAILID"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.EMAILID=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"EMAILID"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"EMAIL_ADDRESS2"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.EMAIL_ADDRESS2=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"EMAIL_ADDRESS2"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ErrorCounter"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.ErrorCounter=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ErrorCounter"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"FIRSTNAME"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.FIRSTNAME=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"FIRSTNAME"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"FLAG"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.FLAG=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"FLAG"]  boolValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"GOVERNMENTID"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.GOVERNMENTID=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"GOVERNMENTID"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"GeneratedStatus"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.GeneratedStatus=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"GeneratedStatus"] intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"HOMEPHONENUMBER"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.HOMEPHONENUMBER=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"HOMEPHONENUMBER"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"HOME_FAX_NO"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.HOME_FAX_NO=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"HOME_FAX_NO"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"HPhoneCountryCode"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.HPhoneCountryCode=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"HPhoneCountryCode"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"HPhoneExtension"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.HPhoneExtension=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"HPhoneExtension"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"IDEXPIRATIONDATE"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.IDEXPIRATIONDATE=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"IDEXPIRATIONDATE"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"IDISSUECOUNTRY"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.IDISSUECOUNTRY=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"IDISSUECOUNTRY"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"IDISSUEDATE"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.IDISSUEDATE=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"IDISSUEDATE"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"IDISSUESTATE"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.IDISSUESTATE=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"IDISSUESTATE"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"IDNUMBER"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.IDNUMBER=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"IDNUMBER"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LANGUAGE_INDICATOR"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.LANGUAGE_INDICATOR=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LANGUAGE_INDICATOR"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LASTNAME"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.LASTNAME=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LASTNAME"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LOSTSTOLENALLOWEDCM"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.LOSTSTOLENALLOWEDCM=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LOSTSTOLENALLOWEDCM"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastBulkOFACCheckDate"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.LastBulkOFACCheckDate=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastBulkOFACCheckDate"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastLoginDateTime"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.LastLoginDateTime=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastLoginDateTime"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastPlasticIssued"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.LastPlasticIssued=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastPlasticIssued"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastPlasticShipped"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.LastPlasticShipped=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastPlasticShipped"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastTransactionDate"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.LastTransactionDate=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastTransactionDate"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastTransfer"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.LastTransfer=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"LastTransfer"]  doubleValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"MAIDEN_NAME"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.MAIDEN_NAME=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"MAIDEN_NAME"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"MIDDLENAME"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.MIDDLENAME=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"MIDDLENAME"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"MOBILE_PHONE_NO"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.MOBILE_PHONE_NO=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"MOBILE_PHONE_NO"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ManualCardStatus"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.ManualCardStatus=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"ManualCardStatus"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"NAME_ON_CARD"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.NAME_ON_CARD=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"NAME_ON_CARD"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"NOOFPINATTEMPTS"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.NOOFPINATTEMPTS=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"NOOFPINATTEMPTS"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACInquiryDate"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.OFACInquiryDate=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACInquiryDate"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACSDNEntry1"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.OFACSDNEntry1=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACSDNEntry1"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACSDNEntry2"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.OFACSDNEntry2=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACSDNEntry2"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACSDNEntry3"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.OFACSDNEntry3=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACSDNEntry3"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACSDNEntry4"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.OFACSDNEntry4=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACSDNEntry4"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACSDNEntry5"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.OFACSDNEntry5=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACSDNEntry5"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACScore"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.OFACScore=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFACScore"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFFICE_PHONE"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.OFFICE_PHONE=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OFFICE_PHONE"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OtherIDDescription"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.OtherIDDescription=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"OtherIDDescription"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"POSTALCODE"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.POSTALCODE=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"POSTALCODE"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"PRODUCTID"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.PRODUCTID=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"PRODUCTID"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"PasswordPolicy"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.PasswordPolicy=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"PasswordPolicy"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"SECOND_LAST_NAME"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.SECOND_LAST_NAME=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"SECOND_LAST_NAME"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"SECURITY_ANSWER"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.SECURITY_ANSWER=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"SECURITY_ANSWER"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"SECURITY_QUESTION"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.SECURITY_QUESTION=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"SECURITY_QUESTION"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"SSN"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.SSN=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"SSN"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"STATE"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.STATE=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"STATE"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"STATUS_CARDACCOUNT"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.STATUS_CARDACCOUNT=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"STATUS_CARDACCOUNT"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"STOREID"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.STOREID=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"STOREID"] ;
                                        }
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"SavingAccountNumber"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.SavingAccountNumber=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"SavingAccountNumber"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"StudentChoice"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.StudentChoice=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"StudentChoice"]  intValue];
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"StudentIDCardNumber"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.StudentIDCardNumber=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"StudentIDCardNumber"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"TERMSANDCONDITIONS"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.TERMSANDCONDITIONS=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"TERMSANDCONDITIONS"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"TITLE_NAME"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.TITLE_NAME=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"TITLE_NAME"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"USERFIELD1"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.USERFIELD1=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"USERFIELD1"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"USERFIELD2"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.USERFIELD2=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"USERFIELD2"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"USERFIELD3"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.USERFIELD3=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"USERFIELD3"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"USERFIELD4"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.USERFIELD4=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"USERFIELD4"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"USERFIELD5"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.USERFIELD5=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"USERFIELD5"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"UserId"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.UserId=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"UserId"] ;
                                        }
                                        
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"UserStatus"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.UserStatus=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"UserStatus"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"WORK_FAX_NO"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.WORK_FAX_NO=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"WORK_FAX_NO"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"WPhoneCountryCode"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.WPhoneCountryCode=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"WPhoneCountryCode"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"WPhoneExtension"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.WPhoneExtension=[[CARD_DETAIL objectAtIndex:i] valueForKey:@"WPhoneExtension"] ;
                                        }
                                        
                                        if (![[[CARD_DETAIL objectAtIndex:i] valueForKey:@"dePPAccountType"]isKindOfClass:[NSNull class]])
                                        {
                                            dataObj.dePPAccountType=[[[CARD_DETAIL objectAtIndex:i] valueForKey:@"dePPAccountType"] intValue];
                                        }
                                        
                                        [DataArray addObject:dataObj];
                                        [dataObj release];
                                    }
                                }else
                                {
                                    CardDetailClass *dataObj=[[CardDetailClass alloc]init];
                                    
                                    if (![[CARD_DETAIL valueForKey:@"ACCOUNTNUMBER"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.ACCOUNTNUMBER=[CARD_DETAIL valueForKey:@"ACCOUNTNUMBER"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"ACQUISITIONSOURCE"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.ACQUISITIONSOURCE=[CARD_DETAIL valueForKey:@"ACQUISITIONSOURCE"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"ADDRESS1"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.ADDRESS1=[CARD_DETAIL valueForKey:@"ADDRESS1"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"ADDRESSLINE2"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.ADDRESSLINE2=[CARD_DETAIL valueForKey:@"ADDRESSLINE2"] ;
                                    }
                                    if (![[CARD_DETAIL valueForKey:@"ADMIN_NUMBER"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.ADMIN_NUMBER=[CARD_DETAIL valueForKey:@"ADMIN_NUMBER"] ;
                                    }
                                    
                                    
                                    if (![[CARD_DETAIL valueForKey:@"AGENTID"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.AGENTID=[CARD_DETAIL valueForKey:@"AGENTID"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"AccountGeneratedStatus"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.AccountGeneratedStatus=[[CARD_DETAIL valueForKey:@"AccountGeneratedStatus"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"AccountManualStatus"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.AccountManualStatus=[[CARD_DETAIL valueForKey:@"AccountManualStatus"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"AlertEmailAddress"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.AlertEmailAddress=[CARD_DETAIL valueForKey:@"AlertEmailAddress"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"BSAcctID"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.BSAcctID=[CARD_DETAIL valueForKey:@"BSAcctID"] ;
                                    }
                                    
                                    
                                    if (![[CARD_DETAIL valueForKey:@"AVAILABLEBALANCE"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.AVAILABLEBALANCE=[[CARD_DETAIL valueForKey:@"AVAILABLEBALANCE"]  doubleValue];
                                    }
                                    if (![[CARD_DETAIL valueForKey:@"LastTransactionDate"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.LastTransactionDate=[CARD_DETAIL valueForKey:@"LastTransactionDate"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"LastTransfer"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.LastTransfer=[[CARD_DETAIL valueForKey:@"LastTransfer"]  doubleValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"BSAgentId"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.BSAgentId=[CARD_DETAIL valueForKey:@"BSAgentId"] ;
                                    }
                                    if (![[CARD_DETAIL valueForKey:@"CARDEXPIRATIONDATE"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.CARDEXPIRATIONDATE=[CARD_DETAIL valueForKey:@"CARDEXPIRATIONDATE"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"CARDNUMBER"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.CARDNUMBER=[CARD_DETAIL valueForKey:@"CARDNUMBER"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"CARDSTATUS"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.CARDSTATUS=[[CARD_DETAIL valueForKey:@"CARDSTATUS"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"CITY"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.CITY=[CARD_DETAIL valueForKey:@"CITY"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"CLIENTID"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.CLIENTID=[CARD_DETAIL valueForKey:@"CLIENTID"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"COUNTRY"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.COUNTRY=[CARD_DETAIL valueForKey:@"COUNTRY"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"CURRENTBALANCE"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.CURRENTBALANCE=[[CARD_DETAIL valueForKey:@"CURRENTBALANCE"]  doubleValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"ChangeAccessCodeCounter"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.ChangeAccessCodeCounter=[[CARD_DETAIL valueForKey:@"ChangeAccessCodeCounter"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"CradType"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.CradType=[CARD_DETAIL valueForKey:@"CradType"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"CustomAccountID"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.CustomAccountID=[CARD_DETAIL valueForKey:@"CustomAccountID"] ;
                                    }
                                    
                                    
                                    if (![[CARD_DETAIL valueForKey:@"CustomAccountIDLabel"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.CustomAccountIDLabel=[CARD_DETAIL valueForKey:@"CustomAccountIDLabel"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"DATEOFBIRTH"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.DATEOFBIRTH=[CARD_DETAIL valueForKey:@"DATEOFBIRTH"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"DDANumber"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.DDANumber=[CARD_DETAIL valueForKey:@"DDANumber"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"DecisionFlag"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.DecisionFlag=[[CARD_DETAIL valueForKey:@"DecisionFlag"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"DispatchDate"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.DispatchDate=[CARD_DETAIL valueForKey:@"DispatchDate"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"EMAILID"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.EMAILID=[CARD_DETAIL valueForKey:@"EMAILID"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"EMAIL_ADDRESS2"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.EMAIL_ADDRESS2=[CARD_DETAIL valueForKey:@"EMAIL_ADDRESS2"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"ErrorCounter"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.ErrorCounter=[[CARD_DETAIL valueForKey:@"ErrorCounter"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"FIRSTNAME"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.FIRSTNAME=[CARD_DETAIL valueForKey:@"FIRSTNAME"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"FLAG"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.FLAG=[[CARD_DETAIL valueForKey:@"FLAG"]  boolValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"GOVERNMENTID"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.GOVERNMENTID=[CARD_DETAIL valueForKey:@"GOVERNMENTID"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"GeneratedStatus"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.GeneratedStatus=[[CARD_DETAIL valueForKey:@"GeneratedStatus"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"HOMEPHONENUMBER"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.HOMEPHONENUMBER=[CARD_DETAIL valueForKey:@"HOMEPHONENUMBER"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"HOME_FAX_NO"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.HOME_FAX_NO=[CARD_DETAIL valueForKey:@"HOME_FAX_NO"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"HPhoneCountryCode"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.HPhoneCountryCode=[CARD_DETAIL valueForKey:@"HPhoneCountryCode"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"HPhoneExtension"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.HPhoneExtension=[CARD_DETAIL valueForKey:@"HPhoneExtension"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"IDEXPIRATIONDATE"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.IDEXPIRATIONDATE=[CARD_DETAIL valueForKey:@"IDEXPIRATIONDATE"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"IDISSUECOUNTRY"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.IDISSUECOUNTRY=[CARD_DETAIL valueForKey:@"IDISSUECOUNTRY"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"IDISSUEDATE"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.IDISSUEDATE=[CARD_DETAIL valueForKey:@"IDISSUEDATE"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"IDISSUESTATE"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.IDISSUESTATE=[CARD_DETAIL valueForKey:@"IDISSUESTATE"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"IDNUMBER"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.IDNUMBER=[CARD_DETAIL valueForKey:@"IDNUMBER"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"LANGUAGE_INDICATOR"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.LANGUAGE_INDICATOR=[CARD_DETAIL valueForKey:@"LANGUAGE_INDICATOR"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"LASTNAME"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.LASTNAME=[CARD_DETAIL valueForKey:@"LASTNAME"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"LOSTSTOLENALLOWEDCM"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.LOSTSTOLENALLOWEDCM=[[CARD_DETAIL valueForKey:@"LOSTSTOLENALLOWEDCM"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"LastBulkOFACCheckDate"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.LastBulkOFACCheckDate=[CARD_DETAIL valueForKey:@"LastBulkOFACCheckDate"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"LastLoginDateTime"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.LastLoginDateTime=[CARD_DETAIL valueForKey:@"LastLoginDateTime"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"LastPlasticIssued"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.LastPlasticIssued=[CARD_DETAIL valueForKey:@"LastPlasticIssued"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"LastPlasticShipped"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.LastPlasticShipped=[CARD_DETAIL valueForKey:@"LastPlasticShipped"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"MAIDEN_NAME"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.MAIDEN_NAME=[CARD_DETAIL valueForKey:@"MAIDEN_NAME"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"MIDDLENAME"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.MIDDLENAME=[CARD_DETAIL valueForKey:@"MIDDLENAME"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"MOBILE_PHONE_NO"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.MOBILE_PHONE_NO=[CARD_DETAIL valueForKey:@"MOBILE_PHONE_NO"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"ManualCardStatus"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.ManualCardStatus=[[CARD_DETAIL valueForKey:@"ManualCardStatus"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"NAME_ON_CARD"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.NAME_ON_CARD=[CARD_DETAIL valueForKey:@"NAME_ON_CARD"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"NOOFPINATTEMPTS"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.NOOFPINATTEMPTS=[[CARD_DETAIL valueForKey:@"NOOFPINATTEMPTS"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"OFACInquiryDate"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.OFACInquiryDate=[CARD_DETAIL valueForKey:@"OFACInquiryDate"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"OFACSDNEntry1"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.OFACSDNEntry1=[CARD_DETAIL valueForKey:@"OFACSDNEntry1"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"OFACSDNEntry2"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.OFACSDNEntry2=[CARD_DETAIL valueForKey:@"OFACSDNEntry2"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"OFACSDNEntry3"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.OFACSDNEntry3=[CARD_DETAIL valueForKey:@"OFACSDNEntry3"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"OFACSDNEntry4"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.OFACSDNEntry4=[CARD_DETAIL valueForKey:@"OFACSDNEntry4"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"OFACSDNEntry5"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.OFACSDNEntry5=[CARD_DETAIL valueForKey:@"OFACSDNEntry5"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"OFACScore"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.OFACScore=[[CARD_DETAIL valueForKey:@"OFACScore"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"OFFICE_PHONE"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.OFFICE_PHONE=[CARD_DETAIL valueForKey:@"OFFICE_PHONE"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"OtherIDDescription"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.OtherIDDescription=[CARD_DETAIL valueForKey:@"OtherIDDescription"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"POSTALCODE"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.POSTALCODE=[CARD_DETAIL valueForKey:@"POSTALCODE"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"PRODUCTID"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.PRODUCTID=[CARD_DETAIL valueForKey:@"PRODUCTID"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"PasswordPolicy"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.PasswordPolicy=[CARD_DETAIL valueForKey:@"PasswordPolicy"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"SECOND_LAST_NAME"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.SECOND_LAST_NAME=[CARD_DETAIL valueForKey:@"SECOND_LAST_NAME"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"SECURITY_ANSWER"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.SECURITY_ANSWER=[CARD_DETAIL valueForKey:@"SECURITY_ANSWER"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"SECURITY_QUESTION"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.SECURITY_QUESTION=[CARD_DETAIL valueForKey:@"SECURITY_QUESTION"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"SSN"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.SSN=[CARD_DETAIL valueForKey:@"SSN"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"STATE"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.STATE=[CARD_DETAIL valueForKey:@"STATE"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"STATUS_CARDACCOUNT"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.STATUS_CARDACCOUNT=[[CARD_DETAIL valueForKey:@"STATUS_CARDACCOUNT"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"STOREID"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.STOREID=[CARD_DETAIL valueForKey:@"STOREID"] ;
                                    }
                                    if (![[CARD_DETAIL valueForKey:@"SavingAccountNumber"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.SavingAccountNumber=[CARD_DETAIL valueForKey:@"SavingAccountNumber"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"StudentChoice"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.StudentChoice=[[CARD_DETAIL valueForKey:@"StudentChoice"]  intValue];
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"StudentIDCardNumber"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.StudentIDCardNumber=[CARD_DETAIL valueForKey:@"StudentIDCardNumber"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"TERMSANDCONDITIONS"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.TERMSANDCONDITIONS=[CARD_DETAIL valueForKey:@"TERMSANDCONDITIONS"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"TITLE_NAME"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.TITLE_NAME=[CARD_DETAIL valueForKey:@"TITLE_NAME"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"USERFIELD1"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.USERFIELD1=[CARD_DETAIL valueForKey:@"USERFIELD1"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"USERFIELD2"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.USERFIELD2=[CARD_DETAIL valueForKey:@"USERFIELD2"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"USERFIELD3"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.USERFIELD3=[CARD_DETAIL valueForKey:@"USERFIELD3"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"USERFIELD4"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.USERFIELD4=[CARD_DETAIL valueForKey:@"USERFIELD4"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"USERFIELD5"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.USERFIELD5=[CARD_DETAIL valueForKey:@"USERFIELD5"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"UserId"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.UserId=[CARD_DETAIL valueForKey:@"UserId"] ;
                                    }
                                    
                                    
                                    if (![[CARD_DETAIL valueForKey:@"UserStatus"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.UserStatus=[CARD_DETAIL valueForKey:@"UserStatus"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"WORK_FAX_NO"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.WORK_FAX_NO=[CARD_DETAIL valueForKey:@"WORK_FAX_NO"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"WPhoneCountryCode"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.WPhoneCountryCode=[CARD_DETAIL valueForKey:@"WPhoneCountryCode"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"WPhoneExtension"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.WPhoneExtension=[CARD_DETAIL valueForKey:@"WPhoneExtension"] ;
                                    }
                                    
                                    if (![[CARD_DETAIL valueForKey:@"dePPAccountType"]isKindOfClass:[NSNull class]])
                                    {
                                        dataObj.dePPAccountType=[[CARD_DETAIL valueForKey:@"dePPAccountType"]  intValue];
                                    }
                                    
                                    [DataArray addObject:dataObj];
                                    [dataObj release];
                                }
                            }
                            
                        }
                        
                    }
                    if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                    {
                        if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                        {
                            [self.Datadelegate getResponce:DataArray];
                        }
                    }
                }else
                {
                    
                    id ResErrorMsg=[CARDSEARCH_RET valueForKey:@"ResErrorMsg"];
                    if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                    {
                        if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                        {
                            [self.Datadelegate getResponce:ResErrorMsg];
                        }
                    }
                }
            }
            
        }
        break;

        case svcTCIVRChangeCardStatus:
        {
                   }
        break;

            case svcCardholderDetail:
        {
            id CARDHOLDER_DETAIL_RET=[json valueForKey:@"CARDHOLDER_DETAIL_RET"];
            
            UserProfileDataClass *dataObj=[[UserProfileDataClass alloc]init];
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"ADDRESS1"]isKindOfClass:[NSNull class]])
            {
                dataObj.ADDRESS1=[CARDHOLDER_DETAIL_RET valueForKey:@"ADDRESS1"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"ADDRESS2"]isKindOfClass:[NSNull class]])
            {
                dataObj.ADDRESS2=[CARDHOLDER_DETAIL_RET valueForKey:@"ADDRESS2"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"BUSINESSNAME"]isKindOfClass:[NSNull class]])
            {
                dataObj.BUSINESSNAME=[CARDHOLDER_DETAIL_RET valueForKey:@"BUSINESSNAME"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"CARDHOLDER_IDENTIFIED"]isKindOfClass:[NSNull class]])
            {
                dataObj.CARDHOLDER_IDENTIFIED=[[CARDHOLDER_DETAIL_RET valueForKey:@"CARDHOLDER_IDENTIFIED"]  boolValue];
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"CITY"]isKindOfClass:[NSNull class]])
            {
                dataObj.CITY=[CARDHOLDER_DETAIL_RET valueForKey:@"CITY"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"COUNTRY_CODE"]isKindOfClass:[NSNull class]])
            {
                dataObj.COUNTRY_CODE=[CARDHOLDER_DETAIL_RET valueForKey:@"COUNTRY_CODE"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"CURRENTBALANCE"]isKindOfClass:[NSNull class]])
            {
                dataObj.CURRENTBALANCE=[[CARDHOLDER_DETAIL_RET valueForKey:@"CURRENTBALANCE"]  doubleValue];
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"CURRENT_CARD_BALANCE"]isKindOfClass:[NSNull class]])
            {
                dataObj.CURRENT_CARD_BALANCE=[[CARDHOLDER_DETAIL_RET valueForKey:@"CURRENT_CARD_BALANCE"]  doubleValue];
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"CUSTOMSPENDRULES"]isKindOfClass:[NSNull class]])
            {
                dataObj.CUSTOMSPENDRULES=[[CARDHOLDER_DETAIL_RET valueForKey:@"CUSTOMSPENDRULES"]  intValue];
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"CardNumberLast4Digit"]isKindOfClass:[NSNull class]])
            {
                dataObj.CardNumberLast4Digit=[[CARDHOLDER_DETAIL_RET valueForKey:@"CardNumberLast4Digit"]  intValue];
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"CardStatus"]isKindOfClass:[NSNull class]])
            {
                dataObj.CardStatus=[CARDHOLDER_DETAIL_RET valueForKey:@"CardStatus"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"DATEISSUED"]isKindOfClass:[NSNull class]])
            {
                dataObj.DATEISSUED=[CARDHOLDER_DETAIL_RET valueForKey:@"DATEISSUED"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"DOB"]isKindOfClass:[NSNull class]])
            {
                dataObj.DOB=[CARDHOLDER_DETAIL_RET valueForKey:@"DOB"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"EMAIL"]isKindOfClass:[NSNull class]])
            {
                dataObj.EMAIL=[CARDHOLDER_DETAIL_RET valueForKey:@"EMAIL"] ;
            }

            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"ERRMSG"]isKindOfClass:[NSNull class]])
            {
                dataObj.ERRMSG=[CARDHOLDER_DETAIL_RET valueForKey:@"ERRMSG"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"ERROR_FOUND"]isKindOfClass:[NSNull class]])
            {
                dataObj.ERROR_FOUND=[[CARDHOLDER_DETAIL_RET valueForKey:@"ERROR_FOUND"]  boolValue];
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"ERR_NUMBER"]isKindOfClass:[NSNull class]])
            {
                dataObj.ERR_NUMBER=[[CARDHOLDER_DETAIL_RET valueForKey:@"ERR_NUMBER"]  intValue];
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"FIRSTNAME"]isKindOfClass:[NSNull class]])
            {
                dataObj.FIRSTNAME=[CARDHOLDER_DETAIL_RET valueForKey:@"FIRSTNAME"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"FaxNumber"]isKindOfClass:[NSNull class]])
            {
                dataObj.FaxNumber=[CARDHOLDER_DETAIL_RET valueForKey:@"FaxNumber"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"ID_CODE"]isKindOfClass:[NSNull class]])
            {
                dataObj.ID_CODE=[[CARDHOLDER_DETAIL_RET valueForKey:@"ID_CODE"]  intValue];
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"ID_NUMBER"]isKindOfClass:[NSNull class]])
            {
                dataObj.ID_NUMBER=[CARDHOLDER_DETAIL_RET valueForKey:@"ID_NUMBER"] ;
            }
            
            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"LASTNAME"]isKindOfClass:[NSNull class]])
            {
                dataObj.LASTNAME=[CARDHOLDER_DETAIL_RET valueForKey:@"LASTNAME"] ;
            }

            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"MOBILE"]isKindOfClass:[NSNull class]])
            {
                dataObj.MOBILE=[CARDHOLDER_DETAIL_RET valueForKey:@"MOBILE"] ;
            }

            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"NAMEONCARD"]isKindOfClass:[NSNull class]])
            {
                dataObj.NAMEONCARD=[CARDHOLDER_DETAIL_RET valueForKey:@"NAMEONCARD"] ;
            }

            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"PHONE"]isKindOfClass:[NSNull class]])
            {
                dataObj.PHONE=[CARDHOLDER_DETAIL_RET valueForKey:@"PHONE"] ;
            }

            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"PHONEEXTENSION"]isKindOfClass:[NSNull class]])
            {
                dataObj.PHONEEXTENSION=[CARDHOLDER_DETAIL_RET valueForKey:@"PHONEEXTENSION"] ;
            }

            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"POSTALCODE"]isKindOfClass:[NSNull class]])
            {
                dataObj.POSTALCODE=[CARDHOLDER_DETAIL_RET valueForKey:@"POSTALCODE"] ;
            }

            if (![[CARDHOLDER_DETAIL_RET valueForKey:@"STATE"]isKindOfClass:[NSNull class]])
            {
                dataObj.STATE=[CARDHOLDER_DETAIL_RET valueForKey:@"STATE"] ;
            }

            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:dataObj];
                }
            }


        }
            break;
            case svcCHTransactionHistory:
        {
            
            id CHTxnDetails_Response=[json valueForKey:@"CHTxnDetails_Response"];
            
            if (![CHTxnDetails_Response isKindOfClass:[NSNull class]])
            {
                
//                if (![[CHTxnDetails_Response valueForKey:@"AVAILABLEBALANCE"]isKindOfClass:[NSNull class]])
//                {
//                    obj.AVAILABLEBALANCE=[[CHTxnDetails_Response valueForKey:@"AVAILABLEBALANCE"]] doubleValue];
//                }
//                
//                if (![[CHTxnDetails_Response valueForKey:@"AccountNumber"]isKindOfClass:[NSNull class]])
//                {
//                    obj.AccountNumber=[CHTxnDetails_Response valueForKey:@"AccountNumber"]] ;
//                }
//                
//                if (![[CHTxnDetails_Response valueForKey:@"CARD_NUMBER"]isKindOfClass:[NSNull class]])
//                {
//                    obj.CARD_NUMBER=[CHTxnDetails_Response valueForKey:@"CARD_NUMBER"]] ;
//                }
//                
//                if (![[CHTxnDetails_Response valueForKey:@"CURRENTBALANCE"]isKindOfClass:[NSNull class]])
//                {
//                    obj.CURRENTBALANCE=[[CHTxnDetails_Response valueForKey:@"CURRENTBALANCE"]] doubleValue];
//                }
//
//                if (![[CHTxnDetails_Response valueForKey:@"ClientId"]isKindOfClass:[NSNull class]])
//                {
//                    obj.ClientId=[CHTxnDetails_Response valueForKey:@"ClientId"]] ;
//                }
                                
                if (![[CHTxnDetails_Response valueForKey:@"ERROR_FOUND"]isKindOfClass:[NSNull class]])
                {
                    id ERROR_FOUND=[CHTxnDetails_Response valueForKey:@"ERROR_FOUND"]   ;
                    if ([ERROR_FOUND boolValue])
                    {
                        if (![[CHTxnDetails_Response valueForKey:@"ERRMSG"]isKindOfClass:[NSNull class]])
                        {
                           id ERRMSG=[CHTxnDetails_Response valueForKey:@"ERRMSG"]  ;
                            
                            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                            {
                                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                                {
                                    [self.Datadelegate getResponce:ERRMSG];
                                }
                            }

                        }
 
                    }else
                    {
                        if (![[CHTxnDetails_Response valueForKey:@"OtstgTxns"]isKindOfClass:[NSNull class]])
                        {
                            id OtstgTxns=[CHTxnDetails_Response valueForKey:@"OtstgTxns"] ;
                            
                            if (![[OtstgTxns valueForKey:@"CHOtstgTxns"]isKindOfClass:[NSNull class]] && [OtstgTxns valueForKey:@"CHOtstgTxns"]!=nil)
                            {
                                id CHOtstgTxns=[OtstgTxns valueForKey:@"CHOtstgTxns"];
                                
                                if ([CHOtstgTxns isKindOfClass:[NSArray class]])
                                {
                                    for (int i=0; i<[CHOtstgTxns count]; i++)
                                    {
                                        if (!DataArray)
                                        {
                                            DataArray=[[NSMutableArray alloc]init];
                                        }else
                                        {
                                            [DataArray removeAllObjects];
                                        }
                                        
                                        setteldTransaction *OutstandingDataObj=[[setteldTransaction alloc]init];
                                        
                                        
                                        OutstandingDataObj.transactionType=Outstanding_txn;
                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_TranId"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.SettledTxnTranId=[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_TranId"]  ;
                                        }
                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_TranTime"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.SettledTxnTranTime=[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_TranTime"]  ;
                                        }
                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_PostTime"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.SettledTxnPostTime=[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_PostTime"]  ;
                                        }
                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_TxnDesc"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.Transaction_Description=[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_TxnDesc"]  ;
                                        }
                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_TxnAmount"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.Transaction_Amount=[[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_TxnAmount"]  doubleValue];
                                        }
                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_TxnSrc"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.Transaction_Source=[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_TxnSrc"]  ;
                                        }
                                        
                                        
                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"HeldAmount"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.HeldAmount=[[[CHOtstgTxns objectAtIndex:i] valueForKey:@"HeldAmount"] doubleValue] ;
                                        }
                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"MerchantCity"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.MerchantCity=[[CHOtstgTxns objectAtIndex:i] valueForKey:@"MerchantCity"]  ;
                                        }
                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_CoreAuthTranId"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.COREAUTH_TRANID=[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CHOtstg_CoreAuthTranId"]  ;
                                        }
                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CATEGORY_LABEL"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.CATEGORY_LABEL=[[CHOtstgTxns objectAtIndex:i] valueForKey:@"CATEGORY_LABEL"]   ;
                                        }
                                        

                                        
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"OverLimitFlag"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.OverLimitFlag=[[[CHOtstgTxns objectAtIndex:i] valueForKey:@"OverLimitFlag"]  boolValue];
                                        }
                                        if (![[[CHOtstgTxns objectAtIndex:i] valueForKey:@"COMMENT"]isKindOfClass:[NSNull class]])
                                        {
                                            OutstandingDataObj.COMMENT=[[CHOtstgTxns objectAtIndex:i] valueForKey:@"COMMENT"]   ;
                                        }
                                        
                                        [DataArray addObject:OutstandingDataObj];
                                        [OutstandingDataObj release];
                                        
                                    }
                                    
                                    
                                }else
                                {
                                    if (!DataArray)
                                    {
                                        DataArray=[[NSMutableArray alloc]init];
                                    }else
                                    {
                                        [DataArray removeAllObjects];
                                    }
                                    
                                    setteldTransaction *OutstandingDataObj=[[setteldTransaction alloc]init];
                                    
                                    OutstandingDataObj.transactionType=Outstanding_txn;
                                    
                                                                       
                                    if (![[CHOtstgTxns valueForKey:@"CHOtstg_TranId"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.SettledTxnTranId=[CHOtstgTxns valueForKey:@"CHOtstg_TranId"]  ;
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"CHOtstg_TranTime"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.SettledTxnTranTime=[CHOtstgTxns valueForKey:@"CHOtstg_TranTime"]  ;
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"CHOtstg_PostTime"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.SettledTxnPostTime=[CHOtstgTxns valueForKey:@"CHOtstg_PostTime"]  ;
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"CHOtstg_TxnDesc"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.Transaction_Description=[CHOtstgTxns valueForKey:@"CHOtstg_TxnDesc"]  ;
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"CHOtstg_TxnAmount"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.Transaction_Amount=[[CHOtstgTxns valueForKey:@"CHOtstg_TxnAmount"]  doubleValue];
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"CHOtstg_TxnSrc"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.Transaction_Source=[CHOtstgTxns valueForKey:@"CHOtstg_TxnSrc"] ;
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"CHOtstg_CardAccNameLoc"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.CardAcceptorName_Location=[CHOtstgTxns valueForKey:@"CHOtstg_CardAccNameLoc"]  ;
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"CHOtstg_CoreAuthTranId"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.COREAUTH_TRANID=[CHOtstgTxns valueForKey:@"CHOtstg_CoreAuthTranId"]  ;
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"HeldAmount"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.HeldAmount=[[CHOtstgTxns valueForKey:@"HeldAmount"] doubleValue] ;
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"MerchantCity"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.MerchantCity=[CHOtstgTxns valueForKey:@"MerchantCity"]  ;
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"CATEGORY_LABEL"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.CATEGORY_LABEL=[CHOtstgTxns valueForKey:@"CATEGORY_LABEL"] ;
                                    }
                                    
                                    if (![[CHOtstgTxns valueForKey:@"OverLimitFlag"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.OverLimitFlag=[[CHOtstgTxns valueForKey:@"OverLimitFlag"]  boolValue];
                                    }
                                    if (![[CHOtstgTxns valueForKey:@"COMMENT"]isKindOfClass:[NSNull class]])
                                    {
                                        OutstandingDataObj.COMMENT=[CHOtstgTxns valueForKey:@"COMMENT"]   ;
                                    }

                                    [DataArray addObject:OutstandingDataObj];
                                    [OutstandingDataObj release];
                                    
                                }
                            }
                            
                        }
                        
                        
                        if (![[CHTxnDetails_Response valueForKey:@"SettledTxns"]isKindOfClass:[NSNull class]])
                        {
                            id SettledTxns=[CHTxnDetails_Response valueForKey:@"SettledTxns"] ;
                            
                            if (![[SettledTxns valueForKey:@"CHSettledTxns"]isKindOfClass:[NSNull class]] && [SettledTxns valueForKey:@"CHSettledTxns"]!=nil)
                            {
                                id CHSettledTxns=[SettledTxns valueForKey:@"CHSettledTxns"];
                                
                                if ([CHSettledTxns isKindOfClass:[NSArray class]])
                                {
                                    if (!DataArray)
                                    {
                                        DataArray=[[NSMutableArray alloc]init];
                                    }
                                    
                                    
                                    for (int i=0; i<[CHSettledTxns count]; i++)
                                    {
                                        
                                        setteldTransaction *SetteledDataObj=[[setteldTransaction alloc]init];
                                        
                                        
                                        SetteledDataObj.transactionType=Setteled_txn;
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"SettledTxnTranId"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.SettledTxnTranId=[[CHSettledTxns objectAtIndex:i] valueForKey:@"SettledTxnTranId"]  ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"SettledTxnTranTime"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.SettledTxnTranTime=[[CHSettledTxns objectAtIndex:i] valueForKey:@"SettledTxnTranTime"] ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"HeldAmount"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.HeldAmount=[[[CHSettledTxns objectAtIndex:i] valueForKey:@"HeldAmount"]  doubleValue];
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"SettledTxnPostTime"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.SettledTxnPostTime=[[CHSettledTxns objectAtIndex:i] valueForKey:@"SettledTxnPostTime"]  ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"Transaction_Description"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.Transaction_Description=[[CHSettledTxns objectAtIndex:i] valueForKey:@"Transaction_Description"]  ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"Transaction_Amount"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.Transaction_Amount=[[[CHSettledTxns objectAtIndex:i] valueForKey:@"Transaction_Amount"]  doubleValue] ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"Transaction_Source"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.Transaction_Source=[[CHSettledTxns objectAtIndex:i] valueForKey:@"Transaction_Source"]  ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"Current_Balance"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.Current_Balance=[[[CHSettledTxns objectAtIndex:i] valueForKey:@"Current_Balance"]  doubleValue];
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"CardAcceptorName_Location"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.CardAcceptorName_Location=[[CHSettledTxns objectAtIndex:i] valueForKey:@"CardAcceptorName_Location"]  ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"postingRef"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.postingRef=[[CHSettledTxns objectAtIndex:i] valueForKey:@"postingRef"]  ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"TypeOfTran"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.TypeOfTran=[[CHSettledTxns objectAtIndex:i] valueForKey:@"TypeOfTran"]  ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"MemoFlag"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.MemoFlag=[[[CHSettledTxns objectAtIndex:i] valueForKey:@"MemoFlag"]  intValue];
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"MerchantCity"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.MerchantCity=[[CHSettledTxns objectAtIndex:i] valueForKey:@"MerchantCity"]  ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"TransactionReason"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.TransactionReason=[[CHSettledTxns objectAtIndex:i] valueForKey:@"TransactionReason"]  ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"COREAUTH_TRANID"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.COREAUTH_TRANID=[[CHSettledTxns objectAtIndex:i] valueForKey:@"COREAUTH_TRANID"]  ;
                                        }
                                        
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"SPEND_CATEGORY"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.SPEND_CATEGORY=[[CHSettledTxns objectAtIndex:i] valueForKey:@"SPEND_CATEGORY"]  ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"OverLimitFlag"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.OverLimitFlag=[[[CHSettledTxns objectAtIndex:i] valueForKey:@"OverLimitFlag"]  boolValue] ;
                                        }
                                        
                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"CATEGORY_LABEL"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.CATEGORY_LABEL=[[CHSettledTxns objectAtIndex:i] valueForKey:@"CATEGORY_LABEL"]   ;
                                        }

                                        if (![[[CHSettledTxns objectAtIndex:i] valueForKey:@"COMMENT"]isKindOfClass:[NSNull class]])
                                        {
                                            SetteledDataObj.COMMENT=[[CHSettledTxns objectAtIndex:i] valueForKey:@"COMMENT"]   ;
                                        }


                                        
                                        [DataArray addObject:SetteledDataObj];
                                        [SetteledDataObj release];
                                    }
                                }else
                                {
                                    if (!DataArray)
                                    {
                                        DataArray=[[NSMutableArray alloc]init];
                                    }
                                    setteldTransaction *SetteledDataObj=[[setteldTransaction alloc]init];
                                    
                                    SetteledDataObj.transactionType=Setteled_txn;
                                    
                                    if (![[CHSettledTxns valueForKey:@"SettledTxnTranId"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.SettledTxnTranId=[CHSettledTxns valueForKey:@"SettledTxnTranId"]  ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"HeldAmount"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.HeldAmount=[[CHSettledTxns valueForKey:@"HeldAmount"]  doubleValue];
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"SettledTxnTranTime"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.SettledTxnTranTime=[CHSettledTxns valueForKey:@"SettledTxnTranTime"]  ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"SettledTxnPostTime"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.SettledTxnPostTime=[CHSettledTxns valueForKey:@"SettledTxnPostTime"]  ;
                                    }
                                    
                                    
                                    if (![[CHSettledTxns valueForKey:@"ReversibleFlag"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.ReversibleFlag=[[CHSettledTxns valueForKey:@"ReversibleFlag"] intValue];
                                    }
                                    
                                    
                                    if (![[CHSettledTxns valueForKey:@"Transaction_Description"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.Transaction_Description=[CHSettledTxns valueForKey:@"Transaction_Description"]  ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"Transaction_Amount"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.Transaction_Amount=[[CHSettledTxns valueForKey:@"Transaction_Amount"]  doubleValue] ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"Transaction_Source"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.Transaction_Source=[CHSettledTxns valueForKey:@"Transaction_Source"]  ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"Current_Balance"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.Current_Balance=[[CHSettledTxns valueForKey:@"Current_Balance"]  doubleValue];
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"CardAcceptorName_Location"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.CardAcceptorName_Location=[CHSettledTxns valueForKey:@"CardAcceptorName_Location"]  ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"postingRef"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.postingRef=[CHSettledTxns valueForKey:@"postingRef"] ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"TypeOfTran"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.TypeOfTran=[CHSettledTxns valueForKey:@"TypeOfTran"]  ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"MemoFlag"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.MemoFlag=[[CHSettledTxns valueForKey:@"MemoFlag"]  intValue];
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"MerchantCity"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.MerchantCity=[CHSettledTxns valueForKey:@"MerchantCity"]  ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"TransactionReason"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.TransactionReason=[CHSettledTxns valueForKey:@"TransactionReason"]  ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"COREAUTH_TRANID"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.COREAUTH_TRANID=[CHSettledTxns valueForKey:@"COREAUTH_TRANID"]  ;
                                    }
                                    
                                    
                                    if (![[CHSettledTxns valueForKey:@"SPEND_CATEGORY"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.SPEND_CATEGORY=[CHSettledTxns valueForKey:@"SPEND_CATEGORY"]  ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"OverLimitFlag"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.OverLimitFlag=[[CHSettledTxns valueForKey:@"OverLimitFlag"]  boolValue];
                                    }
                                    
                                    
                                    if (![[CHSettledTxns valueForKey:@"CATEGORY_LABEL"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.CATEGORY_LABEL=[CHSettledTxns valueForKey:@"CATEGORY_LABEL"]   ;
                                    }
                                    
                                    if (![[CHSettledTxns valueForKey:@"COMMENT"]isKindOfClass:[NSNull class]])
                                    {
                                        SetteledDataObj.COMMENT=[CHSettledTxns valueForKey:@"COMMENT"]   ;
                                    }
                                    

                                    [DataArray addObject:SetteledDataObj];
                                    [SetteledDataObj release];
                                }
                            }
                            
                        }
 
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:DataArray];
                            }
                        }
                    }
                }
                
                
//                if (![[CHTxnDetails_Response valueForKey:@"FIRSTNAME"]isKindOfClass:[NSNull class]])
//                {
//                    obj.FIRSTNAME=[CHTxnDetails_Response valueForKey:@"FIRSTNAME"]] ;
//                }
//                
//                if (![[CHTxnDetails_Response valueForKey:@"FieldTitle1"]isKindOfClass:[NSNull class]])
//                {
//                    obj.FieldTitle1=[CHTxnDetails_Response valueForKey:@"FieldTitle1"]] ;
//                }
//                
//                if (![[CHTxnDetails_Response valueForKey:@"LASTDEPOSITEAMOUNT"]isKindOfClass:[NSNull class]])
//                {
//                    obj.LASTDEPOSITEAMOUNT=[[CHTxnDetails_Response valueForKey:@"LASTDEPOSITEAMOUNT"]] doubleValue] ;
//                }
//                
//                if (![[CHTxnDetails_Response valueForKey:@"LASTNAME"]isKindOfClass:[NSNull class]])
//                {
//                    obj.LASTNAME=[CHTxnDetails_Response valueForKey:@"LASTNAME"]] ;
//                }
//
//                if (![[CHTxnDetails_Response valueForKey:@"LastDepositeDate"]isKindOfClass:[NSNull class]])
//                {
//                    obj.LastDepositeDate=[CHTxnDetails_Response valueForKey:@"LastDepositeDate"]] ;
//                }
//                
//                if (![[CHTxnDetails_Response valueForKey:@"LastTransactionDate"]isKindOfClass:[NSNull class]])
//                {
//                    obj.LastTransactionDate=[CHTxnDetails_Response valueForKey:@"LastTransactionDate"]] ;
//                }
//                
//                if (![[CHTxnDetails_Response valueForKey:@"MIDDLENAME"]isKindOfClass:[NSNull class]])
//                {
//                    obj.MIDDLENAME=[CHTxnDetails_Response valueForKey:@"MIDDLENAME"]] ;
//                }
//                
//                if (![[CHTxnDetails_Response valueForKey:@"NOOFTRANSACTIONS"]isKindOfClass:[NSNull class]])
//                {
//                    obj.NOOFTRANSACTIONS=[[CHTxnDetails_Response valueForKey:@"NOOFTRANSACTIONS"]] intValue] ;
//                }
//                
//                if (![[CHTxnDetails_Response valueForKey:@"ProductID"]isKindOfClass:[NSNull class]])
//                {
//                    obj.ProductID=[CHTxnDetails_Response valueForKey:@"ProductID"]] ;
//                }
                
                               
//                if (![[CHTxnDetails_Response valueForKey:@"ExpiredTxns"]isKindOfClass:[NSNull class]])
//                {
//                    id ExpiredTxns=[CHTxnDetails_Response valueForKey:@"ExpiredTxns"] ;
//                    
//                    if (![[ExpiredTxns valueForKey:@"CHExpiredTxns"]isKindOfClass:[NSNull class]] && [ExpiredTxns valueForKey:@"CHExpiredTxns"]!=nil)
//                    {
//                        id CHExpiredTxns=[ExpiredTxns valueForKey:@"CHExpiredTxns"];
//                        
//                        if ([CHExpiredTxns isKindOfClass:[NSArray class]])
//                        {
//                            if (!obj.arrSetteledTransaction)
//                            {
//                                 obj.arrSetteledTransaction=[[NSMutableArray alloc]init];
//                            }
//                           
//                            for (int i=0; i<[CHExpiredTxns count]; i++)
//                            {
//                                setteldTransaction *ExpiredDataObj=[[setteldTransaction alloc]init];
//                                
//                                if (![[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_TranId"]isKindOfClass:[NSNull class]])
//                                {
//                                    ExpiredDataObj.SettledTxnTranId=[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_TranId"]] ;
//                                }
//                                
//                                if (![[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_TranTime"]isKindOfClass:[NSNull class]])
//                                {
//                                    ExpiredDataObj.SettledTxnTranTime=[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_TranTime"]] ;
//                                }
//                                
//                                if (![[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_PostTime"]isKindOfClass:[NSNull class]])
//                                {
//                                    ExpiredDataObj.SettledTxnPostTime=[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_PostTime"]] ;
//                                }
//                                
//                                if (![[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_TxnDesc"]isKindOfClass:[NSNull class]])
//                                {
//                                    ExpiredDataObj.Transaction_Description=[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_TxnDesc"]] ;
//                                }
//                                
//                                if (![[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_TxnAmount"]isKindOfClass:[NSNull class]])
//                                {
//                                    ExpiredDataObj.Transaction_Amount=[[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_TxnAmount"]] doubleValue];
//                                }
//                                
//                                if (![[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_TxnSrc"]isKindOfClass:[NSNull class]])
//                                {
//                                    ExpiredDataObj.Transaction_Source=[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_TxnSrc"]] ;
//                                }
//                                
//                                if (![[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_CardAccNameLoc"]isKindOfClass:[NSNull class]])
//                                {
//                                    ExpiredDataObj.CardAcceptorName_Location=[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_CardAccNameLoc"]] ;
//                                }
//                                
//                                if (![[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_CoreAuthTranId"]isKindOfClass:[NSNull class]])
//                                {
//                                    ExpiredDataObj.COREAUTH_TRANID=[[CHExpiredTxns objectAtIndex:i] valueForKey:@"CHExp_CoreAuthTranId"]] ;
//                                }
//
//
//                                [obj.arrSetteledTransaction addObject:ExpiredDataObj];
//                                [ExpiredDataObj release];
//
//                            }
//
//                            
//                        }else
//                        {
//                            setteldTransaction *ExpiredDataObj=[[setteldTransaction alloc]init];
//                            
//                            if (!obj.arrSetteledTransaction)
//                            {
//                                obj.arrSetteledTransaction=[[NSMutableArray alloc]init];
//                            }
//
//
//                            if (![[CHExpiredTxns valueForKey:@"CHExp_TranId"]isKindOfClass:[NSNull class]])
//                            {
//                                ExpiredDataObj.SettledTxnTranId=[CHExpiredTxns valueForKey:@"CHExp_TranId"]] ;
//                            }
//                            
//                            if (![[CHExpiredTxns valueForKey:@"CHExp_TranTime"]isKindOfClass:[NSNull class]])
//                            {
//                                ExpiredDataObj.SettledTxnTranTime=[CHExpiredTxns valueForKey:@"CHExp_TranTime"]] ;
//                            }
//                            
//                            if (![[CHExpiredTxns valueForKey:@"CHExp_PostTime"]isKindOfClass:[NSNull class]])
//                            {
//                                ExpiredDataObj.SettledTxnPostTime=[CHExpiredTxns valueForKey:@"CHExp_PostTime"]] ;
//                            }
//                            
//                            if (![[CHExpiredTxns valueForKey:@"CHExp_TxnDesc"]isKindOfClass:[NSNull class]])
//                            {
//                                ExpiredDataObj.Transaction_Description=[CHExpiredTxns valueForKey:@"CHExp_TxnDesc"]] ;
//                            }
//                            
//                            if (![[CHExpiredTxns valueForKey:@"CHExp_TxnAmount"]isKindOfClass:[NSNull class]])
//                            {
//                                ExpiredDataObj.Transaction_Amount=[[CHExpiredTxns valueForKey:@"CHExp_TxnAmount"]] doubleValue];
//                            }
//                            
//                            if (![[CHExpiredTxns valueForKey:@"CHExp_TxnSrc"]isKindOfClass:[NSNull class]])
//                            {
//                                ExpiredDataObj.Transaction_Source=[CHExpiredTxns valueForKey:@"CHExp_TxnSrc"]] ;
//                            }
//                            
//                            if (![[CHExpiredTxns valueForKey:@"CHExp_CardAccNameLoc"]isKindOfClass:[NSNull class]])
//                            {
//                                ExpiredDataObj.CardAcceptorName_Location=[CHExpiredTxns valueForKey:@"CHExp_CardAccNameLoc"]] ;
//                            }
//                            
//                            if (![[CHExpiredTxns valueForKey:@"CHExp_CoreAuthTranId"]isKindOfClass:[NSNull class]])
//                            {
//                                ExpiredDataObj.COREAUTH_TRANID=[CHExpiredTxns valueForKey:@"CHExp_CoreAuthTranId"]] ;
//                            }
//                            
//                            
//                            [obj.arrSetteledTransaction addObject:ExpiredDataObj];
//                            [ExpiredDataObj release];
//                            
//                        }
//                    }
//                    
//                }
                
                                
//                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
//                {
//                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
//                    {
//                        [self.Datadelegate getResponce:DataArray];
//                    }
//                }

            }
            
        }
            break;
            
            case svcDeviceRegisteration:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id DeviceRegisterationResponse=[json valueForKey:@"DeviceRegisterationResponse"];
            
            if (![[DeviceRegisterationResponse valueForKey:@"Res_Code"]isKindOfClass:[NSNull class]])
            {
                id Res_Code=[DeviceRegisterationResponse valueForKey:@"Res_Code"];
                
                loginDataobj.Error_Code=[Res_Code intValue];
            }
            
            if (![[DeviceRegisterationResponse valueForKey:@"Err_Msg"]isKindOfClass:[NSNull class]])
            {
                id Err_Msg=[DeviceRegisterationResponse valueForKey:@"Err_Msg"];
                
                loginDataobj.ErrorMsg=Err_Msg;
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
            
            case svcUpdateCardStatus_CardAccount:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id UPDATECARDSTATUS_CARDACCOUNT_RET=[json valueForKey:@"UPDATECARDSTATUS_CARDACCOUNT_RET"];
            
            if (![[UPDATECARDSTATUS_CARDACCOUNT_RET valueForKey:@"ERROR_FOUND"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.Error_Found=[[UPDATECARDSTATUS_CARDACCOUNT_RET valueForKey:@"ERROR_FOUND"] boolValue];
                
            }
            
            if (![[UPDATECARDSTATUS_CARDACCOUNT_RET valueForKey:@"ERRMSG"]isKindOfClass:[NSNull class]])
            {
                id ERRMSG=[UPDATECARDSTATUS_CARDACCOUNT_RET valueForKey:@"ERRMSG"];
                
                loginDataobj.ErrorMsg=ERRMSG;
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
            
        case svcCardActivationActivateCard:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id CARDACTIVATION_RET=[json valueForKey:@"CARDACTIVATION_RET"];
            
            if (![[CARDACTIVATION_RET valueForKey:@"ERROR_FOUND"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.Error_Found=[[CARDACTIVATION_RET valueForKey:@"ERROR_FOUND"] boolValue];
                
            }
            
            if (![[CARDACTIVATION_RET valueForKey:@"ERRMSG"]isKindOfClass:[NSNull class]])
            {
                id ERRMSG=[CARDACTIVATION_RET valueForKey:@"ERRMSG"];
                
                loginDataobj.ErrorMsg=ERRMSG;
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
            
            case svcCardUpdate3:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id CardUpdate3_Res=[json valueForKey:@"CardUpdate3_Res"];
            
            if (![[CardUpdate3_Res valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                id ResCode=[CardUpdate3_Res valueForKey:@"ResCode"];
                
                loginDataobj.Error_Found=[ResCode boolValue];
            }
            
            if (![[CardUpdate3_Res valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                id ResErrorMsg=[CardUpdate3_Res valueForKey:@"ResErrorMsg"];
                
                loginDataobj.ErrorMsg=ResErrorMsg;
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
            case svcCIAMemoView:
        {
            
            id VIEWMEMO=[json valueForKey:@"VIEWMEMO"];
            
            if (![[VIEWMEMO valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                id ResCode=[VIEWMEMO valueForKey:@"ResCode"];
                if ([ResCode intValue]==1)
                {
                    id VIEWCOMMENT=[VIEWMEMO valueForKey:@"VIEWCOMMENT"];
                    
                    if (![VIEWCOMMENT isKindOfClass:[NSNull class]] && VIEWCOMMENT!=nil)
                    {
                        if (!DataArray)
                        {
                            DataArray=[[NSMutableArray alloc]init];
                        }else
                        {
                            [DataArray removeAllObjects];
                        }
                        
                        if ([VIEWCOMMENT isKindOfClass:[NSArray class]])
                        {
                            for (int i=0; i<[VIEWCOMMENT count]; i++)
                            {
                                MemoDataClass *MemoObj=[[MemoDataClass alloc]init];
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"ACCOUNTNUMBER"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.ACCOUNTNUMBER=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"ACCOUNTNUMBER"];
                                    
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"CATEGORY_ID"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.CATEGORY_ID=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"CATEGORY_ID"];
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"CATEGORY_LABEL"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.CATEGORY_LABEL=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"CATEGORY_LABEL"];
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"CATEGORY_TYPE"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.CATEGORY_TYPE=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"CATEGORY_TYPE"];
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"COMMENT"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.COMMENT=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"COMMENT"];
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"CREATIONDATE"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.CREATIONDATE=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"CREATIONDATE"];
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"CREATIONTIME"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.CREATIONTIME=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"CREATIONTIME"];
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"Captured_By"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.Captured_By=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"Captured_By"];
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"Delete_Access"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.Delete_Access=[[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"Delete_Access"] intValue];
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"EXPCAT_VALUE"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.EXPCAT_VALUE=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"EXPCAT_VALUE"];
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"EXPCAT_VALUE_ID"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.EXPCAT_VALUE_ID=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"EXPCAT_VALUE_ID"];
                                }
                                
                                if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"Edit_Access"]isKindOfClass:[NSNull class]])
                                {
                                    MemoObj.Edit_Access=[[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"Edit_Access"] intValue];
                                }

                                

                            if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"FIRSTNAME"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.FIRSTNAME=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"FIRSTNAME"] ;
                            }
                            
                            if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"LASTNAME"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.LASTNAME=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"LASTNAME"];
                            }
                            
                            if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"MemoReason"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.MemoReason=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"MemoReason"];
                            }

                            if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"MemoTranID"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.MemoTranID=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"MemoTranID"];
                            }
                            
                            if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"ReasonType"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.ReasonType=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"ReasonType"];
                            }
                            
                            if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"RoleType"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.RoleType=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"RoleType"];
                            }
                            
                            
                            if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"Source"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.Source=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"Source"];
                            }
                            
                            if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"UNIQUEID"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.UNIQUEID=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"UNIQUEID"];
                            }
                            
                            if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"UserName"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.UserName=[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"UserName"];
                            }
                            
                            if (![[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"View_Access"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.View_Access=[[[VIEWCOMMENT objectAtIndex:i] valueForKey:@"View_Access"] intValue];
                            }


                            [DataArray addObject:MemoObj];
                            [MemoObj release];
                            }
                            
                            
                        }else
                        {
                            MemoDataClass *MemoObj=[[MemoDataClass alloc]init];
                            
                            if (![[VIEWCOMMENT valueForKey:@"ACCOUNTNUMBER"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.ACCOUNTNUMBER=[VIEWCOMMENT valueForKey:@"ACCOUNTNUMBER"];
                                
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"CATEGORY_ID"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.CATEGORY_ID=[VIEWCOMMENT valueForKey:@"CATEGORY_ID"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"CATEGORY_LABEL"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.CATEGORY_LABEL=[VIEWCOMMENT valueForKey:@"CATEGORY_LABEL"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"CATEGORY_TYPE"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.CATEGORY_TYPE=[VIEWCOMMENT valueForKey:@"CATEGORY_TYPE"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"COMMENT"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.COMMENT=[VIEWCOMMENT valueForKey:@"COMMENT"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"CREATIONDATE"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.CREATIONDATE=[VIEWCOMMENT valueForKey:@"CREATIONDATE"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"CREATIONTIME"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.CREATIONTIME=[VIEWCOMMENT valueForKey:@"CREATIONTIME"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"Captured_By"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.Captured_By=[VIEWCOMMENT valueForKey:@"Captured_By"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"Delete_Access"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.Delete_Access=[[VIEWCOMMENT valueForKey:@"Delete_Access"] intValue];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"EXPCAT_VALUE"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.EXPCAT_VALUE=[VIEWCOMMENT valueForKey:@"EXPCAT_VALUE"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"EXPCAT_VALUE_ID"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.EXPCAT_VALUE_ID=[VIEWCOMMENT valueForKey:@"EXPCAT_VALUE_ID"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"Edit_Access"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.Edit_Access=[[VIEWCOMMENT valueForKey:@"Edit_Access"] intValue];
                            }
                            
                            
                            
                            if (![[VIEWCOMMENT valueForKey:@"FIRSTNAME"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.FIRSTNAME=[VIEWCOMMENT valueForKey:@"FIRSTNAME"] ;
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"LASTNAME"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.LASTNAME=[VIEWCOMMENT valueForKey:@"LASTNAME"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"MemoReason"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.MemoReason=[VIEWCOMMENT valueForKey:@"MemoReason"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"MemoTranID"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.MemoTranID=[VIEWCOMMENT valueForKey:@"MemoTranID"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"ReasonType"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.ReasonType=[VIEWCOMMENT valueForKey:@"ReasonType"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"RoleType"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.RoleType=[VIEWCOMMENT valueForKey:@"RoleType"];
                            }
                            
                            
                            if (![[VIEWCOMMENT valueForKey:@"Source"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.Source=[VIEWCOMMENT valueForKey:@"Source"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"UNIQUEID"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.UNIQUEID=[VIEWCOMMENT valueForKey:@"UNIQUEID"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"UserName"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.UserName=[VIEWCOMMENT valueForKey:@"UserName"];
                            }
                            
                            if (![[VIEWCOMMENT valueForKey:@"View_Access"]isKindOfClass:[NSNull class]])
                            {
                                MemoObj.View_Access=[[VIEWCOMMENT valueForKey:@"View_Access"] intValue];
                            }
                            
                            [DataArray addObject:MemoObj];
                            [MemoObj release];
                        }
                    
                    if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                    {
                        if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                        {
                            [self.Datadelegate getResponce:DataArray];
                        }
                    }
                    }
                }else
                {
                    id ResErrorMsg=[VIEWMEMO valueForKey:@"ResErrorMsg"];
                    if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                    {
                        if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                        {
                            [self.Datadelegate getResponce:ResErrorMsg];
                        }
                    }

                }
                
            }
            

        }
            break;
        case svcCIAMemoUpdate:
            {
                LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
        
                id MEMOUPDATE=[json valueForKey:@"MEMOUPDATE"];
        
                if (![[MEMOUPDATE valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
                {
                    id ResCode=[MEMOUPDATE valueForKey:@"ResCode"];
            
                    loginDataobj.Error_Code=[ResCode intValue];
                }
        
                if (![[MEMOUPDATE valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
                {
                    id ResErrorMsg=[MEMOUPDATE valueForKey:@"ResErrorMsg"];
                    
                    loginDataobj.ErrorMsg=ResErrorMsg;
                }
        
                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                {
                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                    {
                        [self.Datadelegate getResponce:loginDataobj];
                    }
                }
        
    }
    break;
            
            case svcViewExpenseCategory:
        {
            id ViewExpenseCategory_Res=[json valueForKey:@"ViewExpenseCategory_Res"];
            
            
            if (![[ViewExpenseCategory_Res valueForKey:@"RES_CODE"]isKindOfClass:[NSNull class]])
            {
                id RES_CODE=[ViewExpenseCategory_Res valueForKey:@"RES_CODE"];
                if ([RES_CODE intValue]==1)
                {
                    if (![[ViewExpenseCategory_Res valueForKey:@"EXPENSE_CATEGORY"]isKindOfClass:[NSNull class]])
                    {
                        id EXPENSE_CATEGORY=[ViewExpenseCategory_Res valueForKey:@"EXPENSE_CATEGORY"];
                        
                        if (![[EXPENSE_CATEGORY valueForKey:@"CATEGORY"]isKindOfClass:[NSNull class]] && [EXPENSE_CATEGORY valueForKey:@"CATEGORY"]!=nil )
                        {
                            id CATEGORY=[EXPENSE_CATEGORY valueForKey:@"CATEGORY"];
                            
                            if ([CATEGORY isKindOfClass:[NSArray class]])
                            {
                                if (!DataArray)
                                {
                                    DataArray=[[NSMutableArray alloc]init];
                                }else
                                {
                                    [DataArray removeAllObjects];
                                }
                                
                                for (int i=0; i<[CATEGORY count]; i++)
                                {
                                    ExpenseCategoryData *expenseData=[[ExpenseCategoryData alloc]init];
                                    
                                    if (![[[CATEGORY objectAtIndex:i] valueForKey:@"CATEGORY_TYPE"]isKindOfClass:[NSNull class]])
                                    {
                                        expenseData.CATEGORY_TYPE=[[[CATEGORY objectAtIndex:i] valueForKey:@"CATEGORY_TYPE"] intValue];
                                    }
                                    
                                    
                                    if (![[[CATEGORY objectAtIndex:i] valueForKey:@"CATEGORY_ID"]isKindOfClass:[NSNull class]])
                                    {
                                        expenseData.CATEGORY_ID=[[[CATEGORY objectAtIndex:i] valueForKey:@"CATEGORY_ID"] intValue];
                                    }
                                    
                                    if (![[[CATEGORY objectAtIndex:i] valueForKey:@"CATEGORY_LABEL"]isKindOfClass:[NSNull class]])
                                    {
                                        expenseData.CATEGORY_LABEL=[[CATEGORY objectAtIndex:i] valueForKey:@"CATEGORY_LABEL"] ;
                                    }
                                    
                                    if (![[[CATEGORY objectAtIndex:i] valueForKey:@"ViewExpenseCategoryDetail"]isKindOfClass:[NSNull class]])
                                    {
                                        id ViewExpenseCategoryDetail=[[CATEGORY objectAtIndex:i] valueForKey:@"ViewExpenseCategoryDetail"];
                                        
                                        if (![[ViewExpenseCategoryDetail valueForKey:@"ExpenseCategoryDetail"]isKindOfClass:[NSNull class]] && [ViewExpenseCategoryDetail valueForKey:@"ExpenseCategoryDetail"] !=nil)
                                        {
                                            id ExpenseCategoryDetail=[ViewExpenseCategoryDetail valueForKey:@"ExpenseCategoryDetail"];
                                            
                                            if ([ExpenseCategoryDetail isKindOfClass:[NSArray class]])
                                            {
                                                expenseData.SubCatArray=[[NSMutableArray alloc]init];
                                                for (int innerLoop=0; innerLoop<[ExpenseCategoryDetail count]; innerLoop++)
                                                {
                                                    
                                                    SubCategoryDataClass *subCatDta=[[SubCategoryDataClass alloc]init];
                                                    
                                                    if (![[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_STATUS"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_STATUS=[[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_STATUS"] intValue];
                                                    }
                                                    
                                                    if (![[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_VALUE"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_VALUE=[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_VALUE"];
                                                    }
                                                    
                                                    if (![[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_VALUE_ID"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_VALUE_ID=[[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_VALUE_ID"] intValue];
                                                    }
                                                    
                                                    if (![[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_UPD"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_UPD=[[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_UPD"] intValue];
                                                    }

                                                    [expenseData.SubCatArray addObject:subCatDta];
                                                    [subCatDta release];
                                                }
                                                
                                            }else
                                            {
                                              
                                                    expenseData.SubCatArray=[[NSMutableArray alloc]init];
                                                    SubCategoryDataClass *subCatDta=[[SubCategoryDataClass alloc]init];
                                                    
                                                    if (![[ExpenseCategoryDetail valueForKey:@"EXPCAT_STATUS"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_STATUS=[[ExpenseCategoryDetail valueForKey:@"EXPCAT_STATUS"] intValue];
                                                    }
                                                    
                                                    if (![[ExpenseCategoryDetail valueForKey:@"EXPCAT_VALUE"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_VALUE=[ExpenseCategoryDetail valueForKey:@"EXPCAT_VALUE"];
                                                    }
                                                    
                                                    if (![[ExpenseCategoryDetail valueForKey:@"EXPCAT_VALUE_ID"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_VALUE_ID=[[ExpenseCategoryDetail valueForKey:@"EXPCAT_VALUE_ID"] intValue];
                                                    }
                                                    
                                                    if (![[ExpenseCategoryDetail valueForKey:@"EXPCAT_UPD"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_UPD=[[ExpenseCategoryDetail valueForKey:@"EXPCAT_UPD"] intValue];
                                                    }
                                                    
                                                    [expenseData.SubCatArray addObject:subCatDta];
                                                    [subCatDta release];
                                                }
                                                
                                            }
                                                
                                            }
                                    [DataArray addObject:expenseData];
                                    [expenseData release];
                                    
                                }
                                        
                                    
                                }else
                                {
                                    if (!DataArray)
                                    {
                                        DataArray=[[NSMutableArray alloc]init];
                                    }else
                                    {
                                        [DataArray removeAllObjects];
                                    }
                                    
                                        ExpenseCategoryData *expenseData=[[ExpenseCategoryData alloc]init];
                                        
                                        if (![[CATEGORY valueForKey:@"CATEGORY_TYPE"]isKindOfClass:[NSNull class]])
                                        {
                                            expenseData.CATEGORY_TYPE=[[CATEGORY valueForKey:@"CATEGORY_TYPE"] intValue];
                                        }
                                        
                                        
                                        if (![[CATEGORY valueForKey:@"CATEGORY_ID"]isKindOfClass:[NSNull class]])
                                        {
                                            expenseData.CATEGORY_ID=[[CATEGORY valueForKey:@"CATEGORY_ID"] intValue];
                                        }
                                        
                                        if (![[CATEGORY valueForKey:@"CATEGORY_LABEL"]isKindOfClass:[NSNull class]])
                                        {
                                            expenseData.CATEGORY_LABEL=[CATEGORY valueForKey:@"CATEGORY_LABEL"] ;
                                        }
                                        
                                        if (![[CATEGORY valueForKey:@"ViewExpenseCategoryDetail"]isKindOfClass:[NSNull class]])
                                        {
                                            id ViewExpenseCategoryDetail=[CATEGORY valueForKey:@"ViewExpenseCategoryDetail"];
                                            
                                            if (![[ViewExpenseCategoryDetail valueForKey:@"ExpenseCategoryDetail"]isKindOfClass:[NSNull class]])
                                            {
                                                id ExpenseCategoryDetail=[ViewExpenseCategoryDetail valueForKey:@"ExpenseCategoryDetail"];
                                                
                                                if ([ExpenseCategoryDetail isKindOfClass:[NSArray class]])
                                                {
                                                     expenseData.SubCatArray=[[NSMutableArray alloc]init];
                                                    for (int innerLoop=0; innerLoop<[ExpenseCategoryDetail count]; innerLoop++)
                                                    {
                                                       
                                                        SubCategoryDataClass *subCatDta=[[SubCategoryDataClass alloc]init];
                                                        
                                                        if (![[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_STATUS"]isKindOfClass:[NSNull class]])
                                                        {
                                                            subCatDta.EXPCAT_STATUS=[[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_STATUS"] intValue];
                                                        }
                                                        
                                                        if (![[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_VALUE"]isKindOfClass:[NSNull class]])
                                                        {
                                                            subCatDta.EXPCAT_VALUE=[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_VALUE"];
                                                        }
                                                        
                                                        if (![[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_VALUE_ID"]isKindOfClass:[NSNull class]])
                                                        {
                                                            subCatDta.EXPCAT_VALUE_ID=[[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_VALUE_ID"] intValue];
                                                        }
                                                        
                                                        if (![[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_UPD"]isKindOfClass:[NSNull class]])
                                                        {
                                                            subCatDta.EXPCAT_UPD=[[[ExpenseCategoryDetail objectAtIndex:innerLoop] valueForKey:@"EXPCAT_UPD"] intValue];
                                                        }
                                                        
                                                        [expenseData.SubCatArray addObject:subCatDta];
                                                        [subCatDta release];
                                                        
                                                    }
                                                    
                                                }else
                                                {
                                                    expenseData.SubCatArray=[[NSMutableArray alloc]init];
                                                    SubCategoryDataClass *subCatDta=[[SubCategoryDataClass alloc]init];
                                                    
                                                    if (![[ExpenseCategoryDetail valueForKey:@"EXPCAT_STATUS"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_STATUS=[[ExpenseCategoryDetail valueForKey:@"EXPCAT_STATUS"] intValue];
                                                    }
                                                    
                                                    if (![[ExpenseCategoryDetail valueForKey:@"EXPCAT_VALUE"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_VALUE=[ExpenseCategoryDetail valueForKey:@"EXPCAT_VALUE"];
                                                    }
                                                    
                                                    if (![[ExpenseCategoryDetail valueForKey:@"EXPCAT_VALUE_ID"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_VALUE_ID=[[ExpenseCategoryDetail valueForKey:@"EXPCAT_VALUE_ID"] intValue];
                                                    }
                                                    
                                                    if (![[ExpenseCategoryDetail valueForKey:@"EXPCAT_UPD"]isKindOfClass:[NSNull class]])
                                                    {
                                                        subCatDta.EXPCAT_UPD=[[ExpenseCategoryDetail valueForKey:@"EXPCAT_UPD"] intValue];
                                                    }
                                                    
                                                    [expenseData.SubCatArray addObject:subCatDta];
                                                    [subCatDta release];
                                                }
                                                
                                            }
                                            
                                        }
                                        
                                    [DataArray addObject:expenseData];
                                    [expenseData release];

                                
                            }
                                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                                {
                                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                                    {
                                        [self.Datadelegate getResponce:DataArray];
                                    }
                                }
 
                            
                        }else
                        {
                            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                            {
                                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                                {
                                    [self.Datadelegate getResponce:nil];
                                }
                            }

                        }
                        
                    }
                }else
                {
                    if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                    {
                        if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                        {
                            [self.Datadelegate getResponce:nil];
                        }
                    }
                }
            }
        }
            break;
            
        case svcCIAMemoAdd:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id ADDMEMO=[json valueForKey:@"ADDMEMO"];
            
            if (![[ADDMEMO valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                id ResCode=[ADDMEMO valueForKey:@"ResCode"];
                
                loginDataobj.Error_Code=[ResCode intValue];
            }
            
            if (![[ADDMEMO valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                id ResErrorMsg=[ADDMEMO valueForKey:@"ResErrorMsg"];
                
                loginDataobj.ErrorMsg=ResErrorMsg;
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
            case svcNewOrder:
        {
            newCardOrder *loginDataobj=[[newCardOrder alloc]init];
            
            id NEWORDER_RES=[json valueForKey:@"NEWORDER_RES"];
            
            if (![[NEWORDER_RES valueForKey:@"ORDER_ID"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ORDER_ID=[NEWORDER_RES valueForKey:@"ORDER_ID"];
                
            }
            
            if (![[NEWORDER_RES valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ResErrorMsg=[NEWORDER_RES valueForKey:@"ResErrorMsg"];
                
            }
            
            if (![[NEWORDER_RES valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
               loginDataobj.ResCode= [[NEWORDER_RES valueForKey:@"ResCode"] intValue];
                
            }
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
        case svcReplacementCard:
        {
            ReplaceCardData *loginDataobj=[[ReplaceCardData alloc]init];
            
            id REPLACEMENTCARD_RET=[json valueForKey:@"REPLACEMENTCARD_RET"];
            
            if (![[REPLACEMENTCARD_RET valueForKey:@"CARDNUMBER"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.CARDNUMBER=[REPLACEMENTCARD_RET valueForKey:@"CARDNUMBER"];
                
            }
            
            if (![[REPLACEMENTCARD_RET valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ResErrorMsg=[REPLACEMENTCARD_RET valueForKey:@"ResErrorMsg"];
                
            }
            
            if (![[REPLACEMENTCARD_RET valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ResCode= [[REPLACEMENTCARD_RET valueForKey:@"ResCode"] intValue];
                
            }
            
            if (![[REPLACEMENTCARD_RET valueForKey:@"ResErrorCode"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ResErrorCode=[REPLACEMENTCARD_RET valueForKey:@"ResErrorCode"] ;
                
            }

            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
            case svcChargeCardFee:
        {
            ReplaceCardData *loginDataobj=[[ReplaceCardData alloc]init];
            
            id ChargedFeeRes=[json valueForKey:@"ChargedFeeRes"];
            
            if (![[ChargedFeeRes valueForKey:@"ErrorCode"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.CARDNUMBER=[ChargedFeeRes valueForKey:@"ErrorCode"];
                
            }
            
            if (![[ChargedFeeRes valueForKey:@"ErrorMessage"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ResErrorMsg=[ChargedFeeRes valueForKey:@"ErrorMessage"];
                
            }
            
            if (![[ChargedFeeRes valueForKey:@"ResponseCode"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ResCode= [[ChargedFeeRes valueForKey:@"ResponseCode"] intValue];
                
            }
            
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
            
        case svcUpdateOrder:
        {
            ReplaceCardData *loginDataobj=[[ReplaceCardData alloc]init];
            
            id REPLACEMENTCARD_RET=[json valueForKey:@"REPLACEMENTCARD_RET"];
            
            if (![[REPLACEMENTCARD_RET valueForKey:@"CARDNUMBER"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.CARDNUMBER=[REPLACEMENTCARD_RET valueForKey:@"CARDNUMBER"];
                
            }
            
            if (![[REPLACEMENTCARD_RET valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ResErrorMsg=[REPLACEMENTCARD_RET valueForKey:@"ResErrorMsg"];
                
            }
            
            if (![[REPLACEMENTCARD_RET valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ResCode= [[REPLACEMENTCARD_RET valueForKey:@"ResCode"] intValue];
                
            }
            
            if (![[REPLACEMENTCARD_RET valueForKey:@"ResErrorCode"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ResErrorCode=[REPLACEMENTCARD_RET valueForKey:@"ResErrorCode"] ;
                
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
        case svcStartSingleLoad:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id StartSingleLoadResponse=[json valueForKey:@"StartSingleLoadResponse"];
            
            if (![[StartSingleLoadResponse valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.Error_Code=[[StartSingleLoadResponse valueForKey:@"ResCode"] intValue];
                
            }
            
            if (![[StartSingleLoadResponse valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ErrorMsg=[StartSingleLoadResponse valueForKey:@"ResErrorMsg"];
                
            }
            
                        
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }

            break;
        case svcStartSingleUnload:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id StartSingleLoadResponse=[json valueForKey:@"StartSingleUnloadResponse"];
            
            if (![[StartSingleLoadResponse valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.Error_Code=[[StartSingleLoadResponse valueForKey:@"ResCode"] intValue];
                
            }
            
            if (![[StartSingleLoadResponse valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ErrorMsg=[StartSingleLoadResponse valueForKey:@"ResErrorMsg"];
                
            }
            
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            
            break;
            
            case svcBALowBalanceFundingSearch:
        {
            lowBalanceSearchDataClass *lowBalanceObj=[[lowBalanceSearchDataClass alloc]init];
            
            id LowBalFundSearch_Res=[json valueForKey:@"LowBalFundSearch_Res"];
            
            if (![[LowBalFundSearch_Res valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ResErrorMsg=[LowBalFundSearch_Res valueForKey:@"ResErrorMsg"] ;
                
            }
            
            if (![[LowBalFundSearch_Res valueForKey:@"ResErrorCode"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ResErrorCode=[[LowBalFundSearch_Res valueForKey:@"ResErrorCode"]  intValue];
                
            }
            
            if (![[LowBalFundSearch_Res valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ResCode=[[LowBalFundSearch_Res valueForKey:@"ResCode"]  intValue];
                
            }
            
            if (![[LowBalFundSearch_Res valueForKey:@"ACCOUNT_ACCT_ID"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ACCOUNT_ACCT_ID=[LowBalFundSearch_Res valueForKey:@"ACCOUNT_ACCT_ID"] ;
                
            }
            
            if (![[LowBalFundSearch_Res valueForKey:@"BA_ACCT_ID"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.BA_ACCT_ID=[LowBalFundSearch_Res valueForKey:@"BA_ACCT_ID"] ;
                
            }
            
            if (![[LowBalFundSearch_Res valueForKey:@"AMOUNT"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.AMOUNT=[[LowBalFundSearch_Res valueForKey:@"AMOUNT"]  doubleValue];
                
            }
            
            if (![[LowBalFundSearch_Res valueForKey:@"ThresholdAmount"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ThresholdAmount=[[LowBalFundSearch_Res valueForKey:@"ThresholdAmount"]  doubleValue];
                
            }
            if (![[LowBalFundSearch_Res valueForKey:@"SCHEDULE_TYPE"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.SCHEDULE_TYPE=[LowBalFundSearch_Res valueForKey:@"SCHEDULE_TYPE"];
                
            }
            
            if (![[LowBalFundSearch_Res valueForKey:@"ISACTIVE"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ISACTIVE=[[LowBalFundSearch_Res valueForKey:@"ISACTIVE"]  boolValue];
                
            }

            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:lowBalanceObj];
                }
            }
        }
            break;
            
        case svcBAScheduleFundingSearch:
        {
            ScheduleFundingSearchDataClass *lowBalanceObj=[[ScheduleFundingSearchDataClass alloc]init];
            
            id ScheduleFundSearch_Res=[json valueForKey:@"ScheduleFundSearch_Res"];
            
            if (![[ScheduleFundSearch_Res valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ResErrorMsg=[ScheduleFundSearch_Res valueForKey:@"ResErrorMsg"] ;
                
            }
            
            if (![[ScheduleFundSearch_Res valueForKey:@"ResErrorCode"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ResErrorCode=[[ScheduleFundSearch_Res valueForKey:@"ResErrorCode"]  intValue];
                
            }
            
            if (![[ScheduleFundSearch_Res valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ResCode=[[ScheduleFundSearch_Res valueForKey:@"ResCode"]  boolValue];
                
            }
            
            if (![[ScheduleFundSearch_Res valueForKey:@"ACCOUNT_ACCT_ID"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ACCOUNT_ACCT_ID=[ScheduleFundSearch_Res valueForKey:@"ACCOUNT_ACCT_ID"];
                
            }
            
            if (![[ScheduleFundSearch_Res valueForKey:@"BA_ACCT_ID"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.BA_ACCT_ID=[ScheduleFundSearch_Res valueForKey:@"BA_ACCT_ID"] ;
                
            }
            
            if (![[ScheduleFundSearch_Res valueForKey:@"AMOUNT"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.AMOUNT=[[ScheduleFundSearch_Res valueForKey:@"AMOUNT"]  doubleValue];
                
            }
            
            if (![[ScheduleFundSearch_Res valueForKey:@"FREQUENCY"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.FREQUENCY=[[ScheduleFundSearch_Res valueForKey:@"FREQUENCY"] intValue];
                
            }
            if (![[ScheduleFundSearch_Res valueForKey:@"SCHEDULE_TYPE"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.SCHEDULE_TYPE=[ScheduleFundSearch_Res valueForKey:@"SCHEDULE_TYPE"];
                
            }
            
            if (![[ScheduleFundSearch_Res valueForKey:@"SelectDay"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.SelectDay=[[ScheduleFundSearch_Res valueForKey:@"SelectDay"] intValue];
                
            }

            
            if (![[ScheduleFundSearch_Res valueForKey:@"ISACTIVE"]isKindOfClass:[NSNull class]])
            {
                lowBalanceObj.ISACTIVE=[[ScheduleFundSearch_Res valueForKey:@"ISACTIVE"]  boolValue];
                
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:lowBalanceObj];
                }
            }
        }
            break;
            
        case svcBALowBalanceFunding:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id RESPONSE=[json valueForKey:@"RESPONSE"];
            
            if (![[RESPONSE valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                id ResErrorMsg=[RESPONSE valueForKey:@"ResErrorMsg"];
                
                loginDataobj.ErrorMsg=ResErrorMsg;
            }
            
            if (![[RESPONSE valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                id ResCode=[RESPONSE valueForKey:@"ResCode"];
                
                loginDataobj.Error_Code=[ResCode intValue];
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }

            break;
            
        case svcBAScheduleFunding:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id RESPONSE=[json valueForKey:@"RESPONSE"];
            
            if (![[RESPONSE valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                id ResErrorMsg=[RESPONSE valueForKey:@"ResErrorMsg"];
                
                loginDataobj.ErrorMsg=ResErrorMsg;
            }
            
            if (![[RESPONSE valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                id ResCode=[RESPONSE valueForKey:@"ResCode"];
                
                loginDataobj.Error_Code=[ResCode intValue];
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            
        case SvcALViewAlertMsgCountAction:
        {
           
            
            id RESPONSE=[json valueForKey:@"ViewAlertMsgCnt"];
            
            if (![[RESPONSE valueForKey:@"ErrorMessage"]isKindOfClass:[NSNull class]] )
            {
                
            
                
                id ResErrorMsg=[RESPONSE valueForKey:@"ErrorMessage"];
                id errorCode = [RESPONSE valueForKey:@"ResponseCode"];
                if ([errorCode intValue] != 1) {
                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                {
                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                    {
                        [self.Datadelegate getResponce:ResErrorMsg];
                    }
                }
                
            }else
            {
            
                 NSMutableArray *data = [[NSMutableArray alloc] init];
                //*******  Value is not comming for the below content.
                // ***** Dummy value Begin
                
                // For Red Alerts
                if(![[RESPONSE valueForKey:@"FundingFailByAdminLimits"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"FundingFailByAdminLimits"] != nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"FundingFailByAdminLimits"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Auto_Funding_Faild_Admin;
                    alertDataObj.strAlertName = ALERT_AUTO_FUNDING_FAILED_ADMIN_LOAD_LIMIT;
                    alertDataObj.colorNo = RedAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else
                {
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                
                if(![[RESPONSE valueForKey:@"FraudAlertCount"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"FraudAlertCount"] != nil)
                {
                    id alertCount=[RESPONSE valueForKey:@"FraudAlertCount"];
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = enumFraudAlert;
                    alertDataObj.strAlertName = ALERT_FRAUD_ALERT;
                    alertDataObj.colorNo = RedAlert; // Red Alert According to gourav
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else
                {
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                
                if(![[RESPONSE valueForKey:@"BusinessPolicyChange"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"BusinessPolicyChange"] != nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"BusinessPolicyChange"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Business_Policy_Changed;
                    alertDataObj.strAlertName = ALERT_BUSINESS_POLICY_CHANGED;
                    alertDataObj.colorNo = RedAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else{
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                
                
                
                // For Amber Alerts
                if(![[RESPONSE valueForKey:@"Card_Profile_Update"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"Card_Profile_Update"] != nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"Card_Profile_Update"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Card_Profile_Updated;
                    alertDataObj.strAlertName = ALERT_CARD_PROFILE_UPDATE;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else
                {
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                
                if(![[RESPONSE valueForKey:@"BulkRequestLoad_Alert"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"BulkRequestLoad_Alert"] != nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"BulkRequestLoad_Alert"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Bulk_Card_Request;
                    alertDataObj.strAlertName = ALERT_BULK_CARD_REQUEST_LOAD;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else
                {
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                
                if(![[RESPONSE valueForKey:@"LOW_BAL_BUSS_ACCT"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"LOW_BAL_BUSS_ACCT"] != nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"LOW_BAL_BUSS_ACCT"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Low_Balance_on_Business;
                    alertDataObj.strAlertName = ALERT_LOW_BALANCE_ON_BUSINESS;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else
                {
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                
                if(![[RESPONSE valueForKey:@"ALERT_INTERNATIONAL_TRANSACTIONS"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"ALERT_INTERNATIONAL_TRANSACTIONS"] != nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"ALERT_INTERNATIONAL_TRANSACTIONS"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = International_Card_Transactions;
                    alertDataObj.strAlertName = ALERT_INTERNATIONAL_TRANSACTIONS;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else
                {
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = International_Card_Transactions;
                    alertDataObj.strAlertName = ALERT_INTERNATIONAL_TRANSACTIONS;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                
                // ***** Dummy Values End
                
                if(![[RESPONSE valueForKey:@"Card_Pending_Activation"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"Card_Pending_Activation"] != nil)
                {
                    id alertCount=[RESPONSE valueForKey:@"Card_Pending_Activation"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Card_Pending_Activation_Alert;
                    alertDataObj.strAlertName = ALERT_CARD_PENDING_ACTIVATION;
                    alertDataObj.colorNo = RedAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else
                {
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                if(![[RESPONSE valueForKey:@"CARD_FUND_FAIL"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"CARD_FUND_FAIL"] != nil)
                {
                    id alertCount=[RESPONSE valueForKey:@"CARD_FUND_FAIL"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Auto_Funding_Faild_Alert;
                    alertDataObj.strAlertName = ALERT_AUTO_FUNDING_FAILD_LOW_FUNDS;
                    alertDataObj.colorNo = RedAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else
                {
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                if(![[RESPONSE valueForKey:@"Low_BAL_Alert"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"Low_BAL_Alert"]!= nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"Low_BAL_Alert"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Low_Balance_Cards_Alert;
                    alertDataObj.strAlertName = ALERT_LOW_BALANCE_CARDS;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else{
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                if(![[RESPONSE valueForKey:@"CARD_HOLDER_DECLINE"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"CARD_HOLDER_DECLINE"] != nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"CARD_HOLDER_DECLINE"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Card_Transaction_Decline_Alert;
                    alertDataObj.strAlertName = ALERT_CARD_TRANSACTION_DECLINE;
                    alertDataObj.colorNo = RedAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else{
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
//                if(![[RESPONSE valueForKey:@"Fraud_Alert_OnCard"] isKindOfClass:[NSNull class]]){
//                    
//                    id alertCount=[RESPONSE valueForKey:@"Fraud_Alert_OnCard"];
//                    
//                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
//                    alertDataObj.alertTypeNo = Fradu_Alert_Alert;
//                    alertDataObj.strAlertName = @"";
//                    alertDataObj.colorNo = RedAlert; // DONT KNOW THE COLOR ACCORDING TO THE GOURAV
//                    alertDataObj.strCount = alertCount;
//                    alertDataObj.isDataNull = NO;
//                    [data addObject:alertDataObj];
//                    [alertDataObj release];
//                }
//                else{
//                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
//                    alertDataObj.alertTypeNo = -1;
//                    alertDataObj.colorNo = -1;
//                    alertDataObj.strCount = nil;
//                    alertDataObj.isDataNull = YES;
//                    [data addObject:alertDataObj];
//                    [alertDataObj release];
//                }
                if(![[RESPONSE valueForKey:@"Spend_Rules_Changed"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"Spend_Rules_Changed"]!= nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"Spend_Rules_Changed"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Card_Spend_Rules_Changed_Alert;
                    alertDataObj.strAlertName = ALERT_CARD_SPEND_RULES_CHANGED;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else{
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                if(![[RESPONSE valueForKey:@"Funding_Rules_Changed"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"Funding_Rules_Changed"] != nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"Funding_Rules_Changed"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Funding_Rules_Changed_Alert;
                    alertDataObj.strAlertName = ALERT_FUNDING_RULES_CHANGED;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else{
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                if(![[RESPONSE valueForKey:@"Card_Issued"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"Card_Issued"] != nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"Card_Issued"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = New_card_issued_Alert;
                    alertDataObj.strAlertName = ALERT_NEW_CARD_ISSUED_REISSUED;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else{
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                
                if(![[RESPONSE valueForKey:@"High_Value_Transaction"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"High_Value_Transaction"] != nil)
                {//High value transaction Alert
                    
                    id alertCount=[RESPONSE valueForKey:@"High_Value_Transaction"];//High value transaction Alert
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = High_value_transaction_Alert;
                    alertDataObj.strAlertName = ALERT_HIGH_VALUE_TRANSACTION;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else{
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                if(![[RESPONSE valueForKey:@"Frequency_Alert"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"Frequency_Alert"] != nil)
                {
                    
                    id alertCount=[RESPONSE valueForKey:@"Frequency_Alert"];
                    
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = Card_Frequency_Alert;
                    alertDataObj.strAlertName = ALERT_FREQUENCY;
                    alertDataObj.colorNo = AmberAlert;
                    alertDataObj.strCount = alertCount;
                    alertDataObj.isDataNull = NO;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }
                else{
                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
                    alertDataObj.alertTypeNo = -1;
                    alertDataObj.colorNo = -1;
                    alertDataObj.strCount = nil;
                    alertDataObj.isDataNull = YES;
                    [data addObject:alertDataObj];
                    [alertDataObj release];
                }

//                if(![[RESPONSE valueForKey:@"Business_Profile_Update"] isKindOfClass:[NSNull class]] && [RESPONSE valueForKey:@"Business_Profile_Update"] != nil)
//                {
//                    
//                    id alertCount=[RESPONSE valueForKey:@"Business_Profile_Update"];
//                    
//                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
//                    alertDataObj.alertTypeNo = Business_Profile_Update;
//                    alertDataObj.strAlertName = ALERT_BUSINESS_PROFILE_UPDATE;
//                    alertDataObj.colorNo = AmberAlert;
//                    alertDataObj.strCount = alertCount;
//                    alertDataObj.isDataNull = NO;
//                    [data addObject:alertDataObj];
//                    [alertDataObj release];
//                }
//                else{
//                    AlertCountSearchClass *alertDataObj = [[AlertCountSearchClass alloc] init];
//                    alertDataObj.alertTypeNo = -1;
//                    alertDataObj.colorNo = -1;
//                    alertDataObj.strCount = nil;
//                    alertDataObj.isDataNull = YES;
//                    [data addObject:alertDataObj];
//                    [alertDataObj release];
//                }
//                    
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:data];
                }
            }
                [data release];
            }
        }
        }

            break;
            
            case svcBAViewTransferDetail:
        {
            id ViewTransfer_Res=[json valueForKey:@"ViewTransfer_Res"];
            
            
            if (![[ViewTransfer_Res valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                id ResCode=[ViewTransfer_Res valueForKey:@"ResCode"];
                
                if ([ResCode boolValue])
                {
                    
                    if (![[ViewTransfer_Res valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
                    {
                        id ResErrorMsg=[ViewTransfer_Res valueForKey:@"ResErrorMsg"];
                        
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:ResErrorMsg];
                            }
                        }
                    }
                }else
                {
                    if (![[ViewTransfer_Res valueForKey:@"Detail"]isKindOfClass:[NSNull class]] && [ViewTransfer_Res valueForKey:@"Detail"]!=nil)
                    {
                        id Detail=[ViewTransfer_Res valueForKey:@"Detail"];
                        
                        if ([Detail isKindOfClass:[NSArray class]])
                        {
                            if (!DataArray) {
                                DataArray =[[NSMutableArray alloc]init];
                            }else
                            {
                                [DataArray removeAllObjects];
                            }
                            
                            for (int i=0; i<[Detail count]; i++)
                            {
                                TransferDetailDataClass *transferData=[[TransferDetailDataClass alloc]init];
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"AddedOnDate"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.AddedOnDate=[[Detail objectAtIndex:i] valueForKey:@"AddedOnDate"];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"BA_ACCT_ID"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.BA_ACCT_ID=[[Detail objectAtIndex:i] valueForKey:@"BA_ACCT_ID"];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"BankAccountNumber"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.BankAccountNumber=[[Detail objectAtIndex:i] valueForKey:@"BankAccountNumber"];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"Bank_Name"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.Bank_Name=[[Detail objectAtIndex:i] valueForKey:@"Bank_Name"];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"CreditDebitIndicator"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.CreditDebitIndicator=[[Detail objectAtIndex:i] valueForKey:@"CreditDebitIndicator"];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"DDHTranId"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.DDHTranId=[[Detail objectAtIndex:i] valueForKey:@"DDHTranId"];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"FundAvailableDate"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.FundAvailableDate=[[Detail objectAtIndex:i] valueForKey:@"FundAvailableDate"];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"RequestId"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.RequestId=[[Detail objectAtIndex:i] valueForKey:@"RequestId"];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"Source"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.Source=[[Detail objectAtIndex:i] valueForKey:@"Source"];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"Status"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.Status=[[[Detail objectAtIndex:i] valueForKey:@"Status"] intValue];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"Status_Desc"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.Status_Desc=[[Detail objectAtIndex:i] valueForKey:@"Status_Desc"];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"TransactionAmount"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.TransactionAmount=[[[Detail objectAtIndex:i] valueForKey:@"TransactionAmount"] doubleValue];
                                }
                                
                                if (![[[Detail objectAtIndex:i] valueForKey:@"UserName"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.UserName=[[Detail objectAtIndex:i] valueForKey:@"UserName"];
                                }
                                
                                [DataArray addObject:transferData];
                                [transferData release];
                                
                            }
                            
                        }else
                        {
                            
                            if (!DataArray) {
                                DataArray =[[NSMutableArray alloc]init];
                            }else
                            {
                                [DataArray removeAllObjects];
                            }
                            
                            TransferDetailDataClass *transferData=[[TransferDetailDataClass alloc]init];
                            
                            if (![[Detail valueForKey:@"AddedOnDate"]isKindOfClass:[NSNull class]])
                            {
                                transferData.AddedOnDate=[Detail valueForKey:@"AddedOnDate"];
                            }
                            
                            if (![[Detail valueForKey:@"BA_ACCT_ID"]isKindOfClass:[NSNull class]])
                            {
                                transferData.BA_ACCT_ID=[Detail valueForKey:@"BA_ACCT_ID"];
                            }
                            
                            if (![[Detail valueForKey:@"BankAccountNumber"]isKindOfClass:[NSNull class]])
                            {
                                transferData.BankAccountNumber=[Detail valueForKey:@"BankAccountNumber"];
                            }
                            
                            if (![[Detail valueForKey:@"Bank_Name"]isKindOfClass:[NSNull class]])
                            {
                                transferData.Bank_Name=[Detail valueForKey:@"Bank_Name"];
                            }
                            
                            if (![[Detail valueForKey:@"CreditDebitIndicator"]isKindOfClass:[NSNull class]])
                            {
                                transferData.CreditDebitIndicator=[Detail valueForKey:@"CreditDebitIndicator"];
                            }
                            
                            if (![[Detail valueForKey:@"DDHTranId"]isKindOfClass:[NSNull class]])
                            {
                                transferData.DDHTranId=[Detail valueForKey:@"DDHTranId"];
                            }
                            
                            if (![[Detail valueForKey:@"FundAvailableDate"]isKindOfClass:[NSNull class]])
                            {
                                transferData.FundAvailableDate=[Detail valueForKey:@"FundAvailableDate"];
                            }
                            
                            if (![[Detail valueForKey:@"RequestId"]isKindOfClass:[NSNull class]])
                            {
                                transferData.RequestId=[Detail valueForKey:@"RequestId"];
                            }
                            
                            if (![[Detail valueForKey:@"Source"]isKindOfClass:[NSNull class]])
                            {
                                transferData.Source=[Detail valueForKey:@"Source"];
                            }
                            
                            if (![[Detail valueForKey:@"Status"]isKindOfClass:[NSNull class]])
                            {
                                transferData.Status=[[Detail valueForKey:@"Status"] intValue];
                            }
                            
                            if (![[Detail valueForKey:@"Status_Desc"]isKindOfClass:[NSNull class]])
                            {
                                transferData.Status_Desc=[Detail valueForKey:@"Status_Desc"];
                            }
                            
                            if (![[Detail valueForKey:@"TransactionAmount"]isKindOfClass:[NSNull class]])
                            {
                                transferData.TransactionAmount=[[Detail valueForKey:@"TransactionAmount"] doubleValue];
                            }
                            
                            if (![[Detail valueForKey:@"UserName"]isKindOfClass:[NSNull class]])
                            {
                                transferData.UserName=[Detail valueForKey:@"UserName"];
                            }
                            
                            [DataArray addObject:transferData];
                            [transferData release];
                            
                        }
                        
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:DataArray];
                            }
                        }
                    }
                }
            }
            
            


        }
            break;
            
            case svcBAExternalBankList:
        {
            id EXT_RESPONSE=[json valueForKey:@"EXT_RESPONSE"];
            
            
            if (![[EXT_RESPONSE valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                id ResCode=[EXT_RESPONSE valueForKey:@"ResCode"];
                
                if ([ResCode boolValue])
                {
                    
                    if (![[EXT_RESPONSE valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
                    {
                        id ResErrorMsg=[EXT_RESPONSE valueForKey:@"ResErrorMsg"];
                        
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:ResErrorMsg];
                            }
                        }
                    }
                }else
                {
                    if (![[EXT_RESPONSE valueForKey:@"DETAIL"]isKindOfClass:[NSNull class]] && [EXT_RESPONSE valueForKey:@"DETAIL"]!=nil)
                    {
                        id DETAIL=[EXT_RESPONSE valueForKey:@"DETAIL"];
                        
                        if ([DETAIL isKindOfClass:[NSArray class]])
                        {
                            if (!DataArray) {
                                DataArray =[[NSMutableArray alloc]init];
                            }else
                            {
                                [DataArray removeAllObjects];
                            }
                            
                            for (int i=0; i<[DETAIL count]; i++)
                            {
                                ExternalBankDataClass *transferData=[[ExternalBankDataClass alloc]init];
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"BA_ACCT_ID"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.BA_ACCT_ID=[[DETAIL objectAtIndex:i] valueForKey:@"BA_ACCT_ID"];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"RecipientID"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.RecipientID=[[DETAIL objectAtIndex:i] valueForKey:@"RecipientID"];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"RoutingNumber"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.RoutingNumber=[[DETAIL objectAtIndex:i] valueForKey:@"RoutingNumber"];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"BankAccountNumber"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.BankAccountNumber=[[DETAIL objectAtIndex:i] valueForKey:@"BankAccountNumber"];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"Bank_Name"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.Bank_Name=[[DETAIL objectAtIndex:i] valueForKey:@"Bank_Name"];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"AddedOnDate"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.AddedOnDate=[[DETAIL objectAtIndex:i] valueForKey:@"AddedOnDate"];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"Bank_Owner"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.Bank_Owner=[[DETAIL objectAtIndex:i] valueForKey:@"Bank_Owner"];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"Status"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.Status=[[DETAIL objectAtIndex:i] valueForKey:@"Status"];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"IsActive"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.IsActive=[[DETAIL objectAtIndex:i] valueForKey:@"IsActive"];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"Val_Tries"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.Val_Tries=[[DETAIL objectAtIndex:i] valueForKey:@"Val_Tries"] ;
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"MicroDeposit1"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.MicroDeposit1=[[[DETAIL objectAtIndex:i] valueForKey:@"MicroDeposit1"] doubleValue];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"MicroDeposit2"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.MicroDeposit2=[[[DETAIL objectAtIndex:i] valueForKey:@"MicroDeposit2"] doubleValue];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"MicroDepostiRev"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.MicroDepostiRev=[[DETAIL objectAtIndex:i] valueForKey:@"MicroDepostiRev"];
                                }
                                
                                if (![[[DETAIL objectAtIndex:i] valueForKey:@"Description"]isKindOfClass:[NSNull class]])
                                {
                                    transferData.Description=[[DETAIL objectAtIndex:i] valueForKey:@"Description"];
                                }
                                
                                
                                [DataArray addObject:transferData];
                                [transferData release];
                                
                            }
                            
                        }else
                        {
                            if (!DataArray)
                            {
                                DataArray =[[NSMutableArray alloc]init];
                            }else
                            {
                                [DataArray removeAllObjects];
                            }
                            
                            ExternalBankDataClass *transferData=[[ExternalBankDataClass alloc]init];
                            
                            if (![[DETAIL valueForKey:@"BA_ACCT_ID"]isKindOfClass:[NSNull class]])
                            {
                                transferData.BA_ACCT_ID=[DETAIL valueForKey:@"BA_ACCT_ID"];
                            }
                            
                            if (![[DETAIL valueForKey:@"RecipientID"]isKindOfClass:[NSNull class]])
                            {
                                transferData.RecipientID=[DETAIL valueForKey:@"RecipientID"];
                            }
                            
                            if (![[DETAIL valueForKey:@"RoutingNumber"]isKindOfClass:[NSNull class]])
                            {
                                transferData.RoutingNumber=[DETAIL valueForKey:@"RoutingNumber"];
                            }
                            
                            if (![[DETAIL valueForKey:@"BankAccountNumber"]isKindOfClass:[NSNull class]])
                            {
                                transferData.BankAccountNumber=[DETAIL valueForKey:@"BankAccountNumber"];
                            }
                            
                            if (![[DETAIL valueForKey:@"Bank_Name"]isKindOfClass:[NSNull class]])
                            {
                                transferData.Bank_Name=[DETAIL valueForKey:@"Bank_Name"];
                            }
                            
                            if (![[DETAIL valueForKey:@"AddedOnDate"]isKindOfClass:[NSNull class]])
                            {
                                transferData.AddedOnDate=[DETAIL valueForKey:@"AddedOnDate"];
                            }
                            
                            if (![[DETAIL valueForKey:@"Bank_Owner"]isKindOfClass:[NSNull class]])
                            {
                                transferData.Bank_Owner=[DETAIL valueForKey:@"Bank_Owner"];
                            }
                            
                            if (![[DETAIL valueForKey:@"Status"]isKindOfClass:[NSNull class]])
                            {
                                transferData.Status=[DETAIL valueForKey:@"Status"];
                            }
                            
                            if (![[DETAIL valueForKey:@"IsActive"]isKindOfClass:[NSNull class]])
                            {
                                transferData.IsActive=[DETAIL valueForKey:@"IsActive"];
                            }
                            
                            if (![[DETAIL valueForKey:@"Val_Tries"]isKindOfClass:[NSNull class]])
                            {
                                transferData.Val_Tries=[DETAIL valueForKey:@"Val_Tries"] ;
                            }
                            
                            if (![[DETAIL valueForKey:@"MicroDeposit1"]isKindOfClass:[NSNull class]])
                            {
                                transferData.MicroDeposit1=[[DETAIL valueForKey:@"MicroDeposit1"] doubleValue];
                            }
                            
                            if (![[DETAIL valueForKey:@"MicroDeposit2"]isKindOfClass:[NSNull class]])
                            {
                                transferData.MicroDeposit2=[[DETAIL valueForKey:@"MicroDeposit2"] doubleValue];
                            }
                            
                            if (![[DETAIL valueForKey:@"MicroDepostiRev"]isKindOfClass:[NSNull class]])
                            {
                                transferData.MicroDepostiRev=[DETAIL valueForKey:@"MicroDepostiRev"];
                            }
                            
                            if (![[DETAIL valueForKey:@"Description"]isKindOfClass:[NSNull class]])
                            {
                                transferData.Description=[DETAIL valueForKey:@"Description"];
                            }
                            
                            
                            
                            [DataArray addObject:transferData];
                            [transferData release];
                            
                        }
                        
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:DataArray];
                            }
                        }
                    }
                }
            }
        }
            break;
        case svcSpendCardBAAlertDisplay:
        {
            id ALERT_RESPONSE=[json valueForKey:@"AlertResponse"];
            if (ALERT_RESPONSE !=nil)
            {
                if (![[ALERT_RESPONSE valueForKey:@"BusinessAdmin"]isKindOfClass:[NSNull class]] ) {
                    
                    id BusinessAdmin = [ALERT_RESPONSE valueForKey:@"BusinessAdmin"];
                    
                    if ([BusinessAdmin isKindOfClass:[NSArray class]])
                    {
                        if (!DataArray) {
                            DataArray = [[NSMutableArray alloc] init];
                        }
                        else{
                            [DataArray removeAllObjects];
                        }
                        
                    
                        for (int i = 0;i<[BusinessAdmin count]; i++)
                        {
                            
                            AlertDetailSearchClass *alertObj= [[AlertDetailSearchClass alloc] init];
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"AlertID"]isKindOfClass:[NSNull class]] && [[BusinessAdmin objectAtIndex:i] valueForKey:@"AlertID"] != nil)
                            {
                                alertObj.strAlertId = [[BusinessAdmin objectAtIndex:i] valueForKey:@"AlertID"];
                            }
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"CardNo"]isKindOfClass:[NSNull class]] && [[BusinessAdmin objectAtIndex:i] valueForKey:@"CardNo"] != nil)
                            {
                                alertObj.strCardNo = [[BusinessAdmin objectAtIndex:i] valueForKey:@"CardNo"];
                            }
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"NoOfTransactionPerDay"]isKindOfClass:[NSNull class]] && [[BusinessAdmin objectAtIndex:i] valueForKey:@"NoOfTransactionPerDay"] != nil)
                            {
                                alertObj.strNoOfTransactionPerDay = [[BusinessAdmin objectAtIndex:i] valueForKey:@"NoOfTransactionPerDay"];
                            }
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"PRODUCT_ID"]isKindOfClass:[NSNull class]] && [[BusinessAdmin objectAtIndex:i] valueForKey:@"PRODUCT_ID"] != nil)
                            {
                                alertObj.strProductId = [[BusinessAdmin objectAtIndex:i] valueForKey:@"PRODUCT_ID"];
                            }
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"UserID"]isKindOfClass:[NSNull class]] && [[BusinessAdmin objectAtIndex:i] valueForKey:@"UserID"] != nil)
                            {
                                alertObj.UserId = [[BusinessAdmin objectAtIndex:i] valueForKey:@"UserID"];
                            }
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"Bank_Name"]isKindOfClass:[NSNull class]] && [[BusinessAdmin objectAtIndex:i] valueForKey:@"Bank_Name"] != nil)
                            {
                                alertObj.strBankName = [[BusinessAdmin objectAtIndex:i] valueForKey:@"Bank_Name"];
                            }
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"BankAccountNo"]isKindOfClass:[NSNull class]] && [[BusinessAdmin objectAtIndex:i] valueForKey:@"BankAccountNo"] != nil)
                            {
                                alertObj.strBankAccountNo = [[BusinessAdmin objectAtIndex:i] valueForKey:@"BankAccountNo"];
                            }
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"TxnCountry"]isKindOfClass:[NSNull class]] && [[BusinessAdmin objectAtIndex:i] valueForKey:@"TxnCountry"] != nil)
                            {
                                alertObj.strTxnCountry = [[BusinessAdmin objectAtIndex:i] valueForKey:@"TxnCountry"];
                            }
                            
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"BusinessName"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.BusinessName = [[BusinessAdmin objectAtIndex:i] valueForKey:@"BusinessName"];
                            }
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"Acctid"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.strBusinessAcountID = [[BusinessAdmin objectAtIndex:i] valueForKey:@"Acctid"];
                            }
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"AlertDate"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.AlertDate = [[BusinessAdmin objectAtIndex:i] valueForKey:@"AlertDate"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"AlertEndDate"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.AlertEndDate = [[BusinessAdmin objectAtIndex:i] valueForKey:@"AlertEndDate"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"ActionDate"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.ActionDate = [[BusinessAdmin objectAtIndex:i] valueForKey:@"ActionDate"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"AlertStatus"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.AlertStatus = [[BusinessAdmin objectAtIndex:i] valueForKey:@"AlertStatus"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"Cardcategory"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.Cardcategory = [[BusinessAdmin objectAtIndex:i] valueForKey:@"Cardcategory"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"CardSubCategory"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.CardSubCategory = [[BusinessAdmin objectAtIndex:i] valueForKey:@"CardSubCategory"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"CardNumber4Digit"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.CardNumber4Digit = [[BusinessAdmin objectAtIndex:i] valueForKey:@"CardNumber4Digit"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"AccountNumber"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.AccountNumber = [[BusinessAdmin objectAtIndex:i] valueForKey:@"AccountNumber"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"FirstName"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.FirstName = [[BusinessAdmin objectAtIndex:i] valueForKey:@"FirstName"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"Lastname"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.Lastname = [[BusinessAdmin objectAtIndex:i] valueForKey:@"Lastname"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"AvailableBal"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.AvailableBal = [[BusinessAdmin objectAtIndex:i] valueForKey:@"AvailableBal"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"EmployeeId"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.EmployeeId = [[BusinessAdmin objectAtIndex:i] valueForKey:@"EmployeeId"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"FundingStatus"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.FundingStatus = [[BusinessAdmin objectAtIndex:i] valueForKey:@"FundingStatus"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"CardStatus"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.CardStatus = [[BusinessAdmin objectAtIndex:i] valueForKey:@"CardStatus"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"BusinessBal"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.BusinessBal = [[BusinessAdmin objectAtIndex:i] valueForKey:@"BusinessBal"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"BAdminFirstName"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.BAdminFirstName = [[BusinessAdmin objectAtIndex:i] valueForKey:@"BAdminFirstName"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"BAdminLastName"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.BAdminLastName = [[BusinessAdmin objectAtIndex:i] valueForKey:@"BAdminLastName"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"SpendRuleUpdate"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.SpendRuleUpdate = [[BusinessAdmin objectAtIndex:i] valueForKey:@"SpendRuleUpdate"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"FundingRuleUpdate"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.FundingRuleUpdate = [[BusinessAdmin objectAtIndex:i] valueForKey:@"FundingRuleUpdate"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"UpdatedBY"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.UpdatedBY = [[BusinessAdmin objectAtIndex:i] valueForKey:@"UpdatedBY"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"UpdatedTime"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.UpdatedTime = [[BusinessAdmin objectAtIndex:i] valueForKey:@"UpdatedTime"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"TxnRecipentAmt"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.TxnRecipentAmt = [[BusinessAdmin objectAtIndex:i] valueForKey:@"TxnRecipentAmt"];
                            }
                            
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"CardAccountNo"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.CardAccountNo = [[BusinessAdmin objectAtIndex:i] valueForKey:@"CardAccountNo"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"RoutingNo"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.RoutingNo = [[BusinessAdmin objectAtIndex:i] valueForKey:@"RoutingNo"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"TxnCountNo"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.TxnCountNo = [[BusinessAdmin objectAtIndex:i] valueForKey:@"TxnCountNo"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"DeclineReason"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.DeclineReason = [[BusinessAdmin objectAtIndex:i] valueForKey:@"DeclineReason"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"FraudType"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.FraudType = [[BusinessAdmin objectAtIndex:i] valueForKey:@"FraudType"];
                            }
                            if (![[[BusinessAdmin objectAtIndex:i] valueForKey:@"CardNo"]isKindOfClass:[NSNull class]])
                            {
                                alertObj.CardNo = [[BusinessAdmin objectAtIndex:i] valueForKey:@"CardNo"];
                            }
                            
                            [DataArray addObject:alertObj];
                            [alertObj release];
                        }
                        
                        
                    }
                    else
                    {
                        if (!DataArray) {
                            DataArray = [[NSMutableArray alloc] init];
                        }
                        else{
                            [DataArray removeAllObjects];
                        }
                        
                        
                        
                        AlertDetailSearchClass *alertObj= [[AlertDetailSearchClass alloc] init];
                        if (![[BusinessAdmin valueForKey:@"BusinessName"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.BusinessName = [BusinessAdmin valueForKey:@"BusinessName"];
                        }
                        
                        
                        if (![[BusinessAdmin valueForKey:@"AlertID"]isKindOfClass:[NSNull class]] && [BusinessAdmin valueForKey:@"AlertID"] != nil)
                        {
                            alertObj.strAlertId = [BusinessAdmin valueForKey:@"AlertID"];
                        }
                        
                        if (![[BusinessAdmin valueForKey:@"CardNo"]isKindOfClass:[NSNull class]] && [BusinessAdmin valueForKey:@"CardNo"] != nil)
                        {
                            alertObj.strCardNo = [BusinessAdmin valueForKey:@"CardNo"];
                        }
                        
                        if (![[BusinessAdmin valueForKey:@"NoOfTransactionPerDay"]isKindOfClass:[NSNull class]] && [BusinessAdmin valueForKey:@"NoOfTransactionPerDay"] != nil)
                        {
                            alertObj.strNoOfTransactionPerDay = [BusinessAdmin valueForKey:@"NoOfTransactionPerDay"];
                        }
                        
                        if (![[BusinessAdmin valueForKey:@"PRODUCT_ID"]isKindOfClass:[NSNull class]] && [BusinessAdmin valueForKey:@"PRODUCT_ID"] != nil)
                        {
                            alertObj.strProductId = [BusinessAdmin valueForKey:@"PRODUCT_ID"];
                        }
                        
                        if (![[BusinessAdmin valueForKey:@"UserID"]isKindOfClass:[NSNull class]] && [BusinessAdmin valueForKey:@"UserID"] != nil)
                        {
                            alertObj.UserId = [BusinessAdmin valueForKey:@"UserID"];
                        }
                        
                        if (![[BusinessAdmin valueForKey:@"Bank_Name"]isKindOfClass:[NSNull class]] && [BusinessAdmin valueForKey:@"Bank_Name"] != nil)
                        {
                            alertObj.strBankName = [BusinessAdmin valueForKey:@"Bank_Name"];
                        }
                        
                        if (![[BusinessAdmin valueForKey:@"BankAccountNo"]isKindOfClass:[NSNull class]] && [BusinessAdmin valueForKey:@"BankAccountNo"] != nil)
                        {
                            alertObj.strBankAccountNo = [BusinessAdmin valueForKey:@"BankAccountNo"];
                        }
                        
                        if (![[BusinessAdmin valueForKey:@"TxnCountry"]isKindOfClass:[NSNull class]] && [BusinessAdmin valueForKey:@"TxnCountry"] != nil)
                        {
                            alertObj.strTxnCountry = [BusinessAdmin valueForKey:@"TxnCountry"];
                        }
                       
                        
                        if (![[BusinessAdmin valueForKey:@"Acctid"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.strBusinessAcountID = [BusinessAdmin valueForKey:@"Acctid"];
                        }
                        
                        if (![[BusinessAdmin valueForKey:@"AlertDate"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.AlertDate = [BusinessAdmin valueForKey:@"AlertDate"];
                        }
                        if (![[BusinessAdmin valueForKey:@"AlertEndDate"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.AlertEndDate = [BusinessAdmin valueForKey:@"AlertEndDate"];
                        }
                        if (![[BusinessAdmin valueForKey:@"ActionDate"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.ActionDate = [BusinessAdmin valueForKey:@"ActionDate"];
                        }
                        if (![[BusinessAdmin valueForKey:@"AlertStatus"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.AlertStatus = [BusinessAdmin valueForKey:@"AlertStatus"];
                        }
                        if (![[BusinessAdmin valueForKey:@"Cardcategory"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.Cardcategory = [BusinessAdmin valueForKey:@"Cardcategory"];
                        }
                        if (![[BusinessAdmin valueForKey:@"CardSubCategory"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.CardSubCategory = [BusinessAdmin valueForKey:@"CardSubCategory"];
                        }
                        if (![[BusinessAdmin valueForKey:@"CardNumber4Digit"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.CardNumber4Digit = [BusinessAdmin valueForKey:@"CardNumber4Digit"];
                        }
                        if (![[BusinessAdmin valueForKey:@"AccountNumber"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.AccountNumber = [BusinessAdmin valueForKey:@"AccountNumber"];
                        }
                        if (![[BusinessAdmin valueForKey:@"FirstName"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.FirstName = [BusinessAdmin valueForKey:@"FirstName"];
                        }
                        if (![[BusinessAdmin valueForKey:@"Lastname"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.Lastname = [BusinessAdmin valueForKey:@"Lastname"];
                        }
                        if (![[BusinessAdmin valueForKey:@"AvailableBal"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.AvailableBal = [BusinessAdmin valueForKey:@"AvailableBal"];
                        }
                        if (![[BusinessAdmin valueForKey:@"EmployeeId"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.EmployeeId = [BusinessAdmin valueForKey:@"EmployeeId"];
                        }
                        if (![[BusinessAdmin valueForKey:@"FundingStatus"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.FundingStatus = [BusinessAdmin valueForKey:@"FundingStatus"];
                        }
                        if (![[BusinessAdmin valueForKey:@"CardStatus"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.CardStatus = [BusinessAdmin valueForKey:@"CardStatus"];
                        }
                        if (![[BusinessAdmin valueForKey:@"BusinessBal"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.BusinessBal = [BusinessAdmin valueForKey:@"BusinessBal"];
                        }
                        if (![[BusinessAdmin valueForKey:@"BAdminFirstName"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.BAdminFirstName = [BusinessAdmin valueForKey:@"BAdminFirstName"];
                        }
                        if (![[BusinessAdmin valueForKey:@"BAdminLastName"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.BAdminLastName = [BusinessAdmin valueForKey:@"BAdminLastName"];
                        }
                        if (![[BusinessAdmin valueForKey:@"SpendRuleUpdate"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.SpendRuleUpdate = [BusinessAdmin valueForKey:@"SpendRuleUpdate"];
                        }
                        if (![[BusinessAdmin valueForKey:@"FundingRuleUpdate"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.FundingRuleUpdate = [BusinessAdmin valueForKey:@"FundingRuleUpdate"];
                        }
                        if (![[BusinessAdmin valueForKey:@"UpdatedBY"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.UpdatedBY = [BusinessAdmin valueForKey:@"UpdatedBY"];
                        }
                        if (![[BusinessAdmin valueForKey:@"UpdatedTime"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.UpdatedTime = [BusinessAdmin valueForKey:@"UpdatedTime"];
                        }
                        if (![[BusinessAdmin valueForKey:@"TxnRecipentAmt"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.TxnRecipentAmt = [BusinessAdmin valueForKey:@"TxnRecipentAmt"];
                        }
                        
                        if (![[BusinessAdmin valueForKey:@"CardAccountNo"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.CardAccountNo = [BusinessAdmin valueForKey:@"CardAccountNo"];
                        }
                        if (![[BusinessAdmin valueForKey:@"RoutingNo"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.RoutingNo = [BusinessAdmin valueForKey:@"RoutingNo"];
                        }
                        if (![[BusinessAdmin valueForKey:@"TxnCountNo"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.TxnCountNo = [BusinessAdmin valueForKey:@"TxnCountNo"];
                        }
                        if (![[BusinessAdmin valueForKey:@"DeclineReason"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.DeclineReason = [BusinessAdmin valueForKey:@"DeclineReason"];
                        }
                        if (![[BusinessAdmin valueForKey:@"FraudType"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.FraudType = [BusinessAdmin valueForKey:@"FraudType"];
                        }
                        
                        if (![[BusinessAdmin valueForKey:@"CardNo"]isKindOfClass:[NSNull class]])
                        {
                            alertObj.CardNo = [BusinessAdmin valueForKey:@"CardNo"];
                        }
                        [DataArray addObject:alertObj];
                        [alertObj release];
                    }
                    
                    if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                    {
                        if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                        {
                            [self.Datadelegate getResponce:DataArray];
                        }
                    }
                }
            }else
            {
                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                {
                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                    {
                        [self.Datadelegate getResponce:@"No record Found"];
                    }
                }
            }
            
        }
            break;
        case svcBAFundAcctOneTimeFunding:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id OneTimeTransfer_Res=[json valueForKey:@"OneTimeTransfer_Res"];
            
            if (![[OneTimeTransfer_Res valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.Error_Found=[[OneTimeTransfer_Res valueForKey:@"ResCode"] boolValue];
            }
            
            if (![[OneTimeTransfer_Res valueForKey:@"ResErrorMsg"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ErrorMsg=[OneTimeTransfer_Res valueForKey:@"ResErrorMsg"];
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
        }
            break;
            
            case svcSearchUser:
        {
            id SearchUserResponse=[json valueForKey:@"SearchUserResponse"];
            
            if (![[SearchUserResponse valueForKey:@"Res_Code"]isKindOfClass:[NSNull class]])
            {
                id Res_Code=[SearchUserResponse valueForKey:@"Res_Code"];
                if ([Res_Code intValue]!=1)
                {
                    if (![[SearchUserResponse valueForKey:@"Err_Msg"]isKindOfClass:[NSNull class]])
                    {
                        id Err_Msg=[SearchUserResponse valueForKey:@"Err_Msg"];
                        
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:Err_Msg];
                            }
                        }

                       
                    }

                }else
                {
                    if (![[SearchUserResponse valueForKey:@"SearchUser"]isKindOfClass:[NSNull class]])
                    {
                        id SearchUser=[SearchUserResponse valueForKey:@"SearchUser"];
                        
                        if (![[SearchUser valueForKey:@"Req_Detail"]isKindOfClass:[NSNull class]])
                        {
                            id Req_Detail=[SearchUser valueForKey:@"Req_Detail"];
                            
                            if (Req_Detail !=nil)
                            {
                                if ([Req_Detail isKindOfClass:[NSArray class]])
                                {
                                    if (!DataArray)
                                    {
                                        DataArray=[[NSMutableArray alloc]init];
                                    }else
                                    {
                                        
                                        [DataArray removeAllObjects];
                                    }
                                    
                                    for (int i=0; i<[Req_Detail count]; i++)
                                    {
                                        
                                        AdminDataClass *adminList=[[AdminDataClass alloc]init];
                                        
                                        
                                        if (![[[Req_Detail objectAtIndex:i] valueForKey:@"UserId"]isKindOfClass:[NSNull class]])
                                        {
                                            adminList.UserId=[[Req_Detail objectAtIndex:i] valueForKey:@"UserId"];
                                            if ([adminList.UserId.uppercaseString isEqualToString:[UserDetailClass sharedUser].strUserId.uppercaseString])
                                            {
                                                
                                            }
                                            else
                                            {
                                                if (![[[Req_Detail objectAtIndex:i] valueForKey:@"FirstName"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.FirstName=[[Req_Detail objectAtIndex:i] valueForKey:@"FirstName"];
                                                    
                                                }
                                                
                                                if (![[[Req_Detail objectAtIndex:i] valueForKey:@"LastName"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.LastName=[[Req_Detail objectAtIndex:i] valueForKey:@"LastName"];
                                                    
                                                }
                                                
                                                if (![[[Req_Detail objectAtIndex:i] valueForKey:@"ClientName"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.ClientName=[[Req_Detail objectAtIndex:i] valueForKey:@"ClientName"];
                                                    
                                                }
                                                
                                                if (![[[Req_Detail objectAtIndex:i] valueForKey:@"ClientID"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.ClientID=[[Req_Detail objectAtIndex:i] valueForKey:@"ClientID"];
                                                    
                                                }
                                                
                                                if (![[[Req_Detail objectAtIndex:i] valueForKey:@"UserType"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.UserType=[[[Req_Detail objectAtIndex:i] valueForKey:@"UserType"] intValue];
                                                    
                                                }
                                                
                                                if (![[[Req_Detail objectAtIndex:i] valueForKey:@"UserTypeDescription"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.UserTypeDescription=[[Req_Detail objectAtIndex:i] valueForKey:@"UserTypeDescription"];
                                                    
                                                }
                                                
                                                if (![[[Req_Detail objectAtIndex:i] valueForKey:@"UserStatus"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.UserStatus=[[[Req_Detail objectAtIndex:i] valueForKey:@"UserStatus"] intValue];
                                                    
                                                }
                                                
                                                if (![[[Req_Detail objectAtIndex:i] valueForKey:@"UserStatusDescription"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.UserStatusDescription=[[Req_Detail objectAtIndex:i] valueForKey:@"UserStatusDescription"];
                                                    
                                                }
                                                
                                                if (![[[Req_Detail objectAtIndex:i] valueForKey:@"RoleType"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.RoleType=[[[Req_Detail objectAtIndex:i] valueForKey:@"RoleType"] intValue];
                                                    
                                                }
                                                
                                                if (![[[Req_Detail objectAtIndex:i] valueForKey:@"LAST_ACCESSED_AT"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.LAST_ACCESSED_AT=[[Req_Detail objectAtIndex:i] valueForKey:@"LAST_ACCESSED_AT"];
                                                    
                                                }
                                                
                                                
                                                [DataArray addObject:adminList];
                                                [adminList release];
                                            }
                                            
                                        }
                                    }
                                    
                                }else
                                {
                                    if (!DataArray)
                                    {
                                        DataArray=[[NSMutableArray alloc]init];
                                    }else
                                    {
                                        
                                        [DataArray removeAllObjects];
                                    }
                                    
                                        AdminDataClass *adminList=[[AdminDataClass alloc]init];
                                    
                                        if (![[Req_Detail valueForKey:@"UserId"]isKindOfClass:[NSNull class]])
                                        {
                                            adminList.UserId=[Req_Detail valueForKey:@"UserId"];
                                            if ([adminList.UserId.uppercaseString isEqualToString:[UserDetailClass sharedUser].strUserId.uppercaseString])
                                            {
                                                
                                            }else
                                            {
                                                if (![[Req_Detail valueForKey:@"FirstName"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.FirstName=[Req_Detail valueForKey:@"FirstName"];
                                                    
                                                }
                                                
                                                if (![[Req_Detail valueForKey:@"LastName"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.LastName=[Req_Detail valueForKey:@"LastName"];
                                                    
                                                }
                                                
                                                if (![[Req_Detail valueForKey:@"ClientName"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.ClientName=[Req_Detail valueForKey:@"ClientName"];
                                                    
                                                }
                                                
                                                if (![[Req_Detail valueForKey:@"ClientID"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.ClientID=[Req_Detail valueForKey:@"ClientID"];
                                                    
                                                }
                                                
                                                if (![[Req_Detail valueForKey:@"UserType"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.UserType=[[Req_Detail valueForKey:@"UserType"] intValue];
                                                    
                                                }
                                                
                                                if (![[Req_Detail valueForKey:@"UserTypeDescription"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.UserTypeDescription=[Req_Detail valueForKey:@"UserTypeDescription"];
                                                    
                                                }
                                                
                                                if (![[Req_Detail valueForKey:@"UserStatus"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.UserStatus=[[Req_Detail valueForKey:@"UserStatus"] intValue];
                                                    
                                                }
                                                
                                                if (![[Req_Detail valueForKey:@"UserStatusDescription"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.UserStatusDescription=[Req_Detail valueForKey:@"UserStatusDescription"];
                                                    
                                                }
                                                
                                                if (![[Req_Detail valueForKey:@"RoleType"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.RoleType=[[Req_Detail valueForKey:@"RoleType"] intValue];
                                                    
                                                }
                                                
                                                
                                                if (![[Req_Detail valueForKey:@"LAST_ACCESSED_AT"]isKindOfClass:[NSNull class]])
                                                {
                                                    adminList.LAST_ACCESSED_AT=[Req_Detail valueForKey:@"LAST_ACCESSED_AT"];
                                                    
                                                }
                                                
                                                
                                                [DataArray addObject:adminList];
                                                [adminList release];

                                            }
                                            
                                        }
                                    }
                                
                            }
                        }
                    if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                    {
                        if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                        {
                            [self.Datadelegate getResponce:DataArray];
                        }
                    }
                    }
                }
            }

            
        }
            break;
            
            case svcUpdateExistingUser:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id UpdateResponce=[json valueForKey:@"UpdateResponce"];
            
            if (![[UpdateResponce valueForKey:@"Res_Code"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.Error_Code=[[UpdateResponce valueForKey:@"Res_Code"] intValue];
            }
            
            if (![[UpdateResponce valueForKey:@"Err_Msg"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ErrorMsg=[UpdateResponce valueForKey:@"Err_Msg"];
            }

            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }

            
        }
            break;
            
        case svcBACompleteDeleteAchTxn:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id ComDel_Res=[json valueForKey:@"ComDel_Res"];
            
            if (![[ComDel_Res valueForKey:@"ERROR_CODE"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.Error_Code=[[ComDel_Res valueForKey:@"ERROR_CODE"] intValue];
            }
            
            if (![[ComDel_Res valueForKey:@"ERROR_FOUND"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.Error_Found=[[ComDel_Res valueForKey:@"ERROR_FOUND"] boolValue];
            }
            
            if (![[ComDel_Res valueForKey:@"ERROR_MSG"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ErrorMsg=[ComDel_Res valueForKey:@"ERROR_MSG"];
            }
            
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }
            
            
        }
            break;
            case svcGetIPAddrMatchIPAddrAndCheckDay:
        {
            
            id GetIPAddrMatchIPAddrAndCheckDay=[json valueForKey:@"GetIPAddrMatchIPAddrAndCheckDay"];
            
            if (![[GetIPAddrMatchIPAddrAndCheckDay valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                id ResCode=[GetIPAddrMatchIPAddrAndCheckDay valueForKey:@"ResCode"] ;
                if ([ResCode intValue]==1)
                {
                    if (![[GetIPAddrMatchIPAddrAndCheckDay valueForKey:@"IPAddrAndCheckDay"]isKindOfClass:[NSNull class]])
                    {
                        id IPAddrAndCheckDay=[GetIPAddrMatchIPAddrAndCheckDay valueForKey:@"IPAddrAndCheckDay"] ;
                        
                        adminProfileData *adminProfileObj=[[adminProfileData alloc]init];
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"ROWID"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.ROWID=[IPAddrAndCheckDay valueForKey:@"ROWID"];
                        }
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"IPADDRESS"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.IPADDRESS=[IPAddrAndCheckDay valueForKey:@"IPADDRESS"];
                        }
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"CHECKDAY"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.CHECKDAY=[IPAddrAndCheckDay valueForKey:@"CHECKDAY"];
                        }
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"AllowCookies"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.AllowCookies=[[IPAddrAndCheckDay valueForKey:@"AllowCookies"] intValue];
                        }
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"IPBYPASS_FLAG"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.IPBYPASS_FLAG=[[IPAddrAndCheckDay valueForKey:@"IPBYPASS_FLAG"] intValue];
                        }
                        if (![[IPAddrAndCheckDay valueForKey:@"DOB"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.DOB=[IPAddrAndCheckDay valueForKey:@"DOB"];
                        }
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"EMAIL_ID"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.EMAIL_ID=[IPAddrAndCheckDay valueForKey:@"EMAIL_ID"];
                        }
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"AddressLine1"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.AddressLine1=[IPAddrAndCheckDay valueForKey:@"AddressLine1"];
                        }
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"AddressLine2"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.AddressLine2=[IPAddrAndCheckDay valueForKey:@"AddressLine2"];
                        }
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"City"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.City=[IPAddrAndCheckDay valueForKey:@"City"];
                        }
                        
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"State"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.State=[IPAddrAndCheckDay valueForKey:@"State"];
                        }
                        
                        if (![[IPAddrAndCheckDay valueForKey:@"ZIPCODE"]isKindOfClass:[NSNull class]])
                        {
                            adminProfileObj.ZIPCODE=[IPAddrAndCheckDay valueForKey:@"ZIPCODE"];
                        }
                        if (![[IPAddrAndCheckDay valueForKey:@"Country"]isKindOfClass:[NSNull class]])
                        {
                           adminProfileObj.Country=[IPAddrAndCheckDay valueForKey:@"Country"];
                        }


                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:adminProfileObj];
                            }
                        }

                    }
                    
                    
                }else
                {
                     id ResErrorMsg=[GetIPAddrMatchIPAddrAndCheckDay valueForKey:@"ResErrorMsg"] ;
                    if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                    {
                        if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                        {
                            [self.Datadelegate getResponce:ResErrorMsg];
                        }
                    }

                }
            }
        }
            break;
            case svcUpdateNewUser:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id UpdateNewUserResponse=[json valueForKey:@"UpdateNewUserResponse"];
            
//            if (![[UpdateNewUserResponse valueForKey:@"Res_Code"]isKindOfClass:[NSNull class]])
//            {
//                id Res_Code=[UpdateNewUserResponse valueForKey:@"Res_Code"]];
//                
//                loginDataobj.Error_Code=[Res_Code intValue];
//            }
            
            if (![[UpdateNewUserResponse valueForKey:@"Error_Code"]isKindOfClass:[NSNull class]])
            {
                id Res_Code=[UpdateNewUserResponse valueForKey:@"Error_Code"];
                
                loginDataobj.Error_Code=[Res_Code intValue];
            }

            
            if (![[UpdateNewUserResponse valueForKey:@"Err_Msg"]isKindOfClass:[NSNull class]])
            {
                id Err_Msg=[UpdateNewUserResponse valueForKey:@"Err_Msg"];
                
                loginDataobj.ErrorMsg=Err_Msg;
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }

            
        }
            break;
            
            case svcviewloadparameter:
        {
            
            id LoadParameterDetail=[json valueForKey:@"LoadParameterDetail"];
            
            if (![[LoadParameterDetail valueForKey:@"ErrorCode"]isKindOfClass:[NSNull class]])
            {
                id ErrorCode=[LoadParameterDetail valueForKey:@"ErrorCode"];
                
                if ([ErrorCode boolValue])
                {
                    if (![[LoadParameterDetail valueForKey:@"ErrorMsg"]isKindOfClass:[NSNull class]])
                    {
                        id ErrorMsg=[LoadParameterDetail valueForKey:@"ErrorMsg"];
                        
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:ErrorMsg];
                            }
                        }
                   }
                }
                    else
                    {
                        
                        adminLoadLimitDataClass *AdminLoad=[[adminLoadLimitDataClass alloc]init];
                        
                        if (![[LoadParameterDetail valueForKey:@"DailyLimit"]isKindOfClass:[NSNull class]])
                        {
                            AdminLoad.DailyLimit=[[LoadParameterDetail valueForKey:@"DailyLimit"] doubleValue];
                            
                        }
                        
                        if (![[LoadParameterDetail valueForKey:@"DailyLoad"]isKindOfClass:[NSNull class]])
                        {
                            AdminLoad.DailyLoad=[LoadParameterDetail valueForKey:@"DailyLoad"] ;
                            
                        }

                        if (![[LoadParameterDetail valueForKey:@"DailyLimitForDayTime"]isKindOfClass:[NSNull class]])
                        {
                            AdminLoad.DailyLimitForDayTime=[[LoadParameterDetail valueForKey:@"DailyLimitForDayTime"] doubleValue];
                            
                        }

                        if (![[LoadParameterDetail valueForKey:@"MonthlyLimit"]isKindOfClass:[NSNull class]])
                        {
                            AdminLoad.MonthlyLimit=[[LoadParameterDetail valueForKey:@"MonthlyLimit"] doubleValue];
                            
                        }
                        
                        if (![[LoadParameterDetail valueForKey:@"MonthlyLoad"]isKindOfClass:[NSNull class]])
                        {
                            AdminLoad.MonthlyLoad=[LoadParameterDetail valueForKey:@"MonthlyLoad"] ;
                            
                        }
                        
                        if (![[LoadParameterDetail valueForKey:@"SingleLimit"]isKindOfClass:[NSNull class]])
                        {
                            AdminLoad.SingleLimit=[[LoadParameterDetail valueForKey:@"SingleLimit"] doubleValue];
                            
                        }
                        
                        if (![[LoadParameterDetail valueForKey:@"SingleLoad"]isKindOfClass:[NSNull class]])
                        {
                            AdminLoad.SingleLoad=[LoadParameterDetail valueForKey:@"SingleLoad"] ;
                            
                        }
                        if (![[LoadParameterDetail valueForKey:@"BypassLoadLimitsFlag"]isKindOfClass:[NSNull class]])
                        {
                            AdminLoad.BypassLoadLimitsFlag=[[LoadParameterDetail valueForKey:@"BypassLoadLimitsFlag"] intValue];
                            
                        }
                        
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:AdminLoad];
                            }
                        }

                    }
            
        }
        }
            break;
        case svcState:
        {
            if (!DataArray)
            {
                DataArray=[[NSMutableArray alloc]init];
            }else
            {
                [DataArray removeAllObjects];
            }
            
            id CCARDLOOKUP_RET=[json valueForKey:@"STATE_RET"];
            
            if (![[CCARDLOOKUP_RET valueForKey:@"COMBODETAIL"]isKindOfClass:[NSNull class]])
            {
                id COMBODETAIL=[CCARDLOOKUP_RET valueForKey:@"COMBODETAIL"];
                
                if ([COMBODETAIL isKindOfClass:[NSArray class]])
                {
                    for (int i=0; i<[COMBODETAIL  count]; i++)
                    {
                        secretQustionDataClass *dataObj=[[secretQustionDataClass alloc]init];
                        
                        if (![[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTCODE"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.indexNo=[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTCODE"] ;
                        }
                        if (![[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTDESCRIPTION"]isKindOfClass:[NSNull class]])
                        {
                            dataObj.secretQuestion=[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTDESCRIPTION"] ;
                        }
                        
                        [DataArray addObject:dataObj];
                        [dataObj release];
                    }
                }else
                {
                    secretQustionDataClass *dataObj=[[secretQustionDataClass alloc]init];
                    
                    if (![[COMBODETAIL  valueForKey:@"LUTCODE"]isKindOfClass:[NSNull class]])
                    {
                        dataObj.indexNo=[COMBODETAIL valueForKey:@"LUTCODE"] ;
                    }
                    if (![[COMBODETAIL valueForKey:@"LUTDESCRIPTION"]isKindOfClass:[NSNull class]])
                    {
                        dataObj.secretQuestion=[COMBODETAIL valueForKey:@"LUTDESCRIPTION"] ;
                    }
                    
                    [DataArray addObject:dataObj];
                    [dataObj release];
                    
                }
                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                {
                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                    {
                        [self.Datadelegate getResponce:DataArray];
                    }
                }
                
            }
        }
            break;
            
        case svcLoadParameter:
        {
            id LoadParameter=[json valueForKey:@"LoadParameter"];
            
            if (![[LoadParameter valueForKey:@"ErrorMsg"]isKindOfClass:[NSNull class]])
            {
                id ErrorMsg=[LoadParameter valueForKey:@"ErrorMsg"];
                
                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                {
                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                    {
                        [self.Datadelegate getResponce:ErrorMsg];
                    }
                }
            }
        }
            break;
            
        case svcViewAccountSpendParameter:
        {
            id expenseRulesParameter = [json valueForKey:@"Response"];
            id ViewAccountSpendRule_Res = [expenseRulesParameter valueForKey:@"ViewAccountSpendRule_Res"];
            if (![ViewAccountSpendRule_Res isKindOfClass:[NSNull class]]) {
                
                expenseRulesData = [[ExpenseRulesdata alloc]init];
                
                if (![[ViewAccountSpendRule_Res objectForKey:@"UseDailySpendLimit"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.UseDailySpendLimit =  [ViewAccountSpendRule_Res objectForKey:@"UseDailySpendLimit"] ;
                }
                
                if (![[ViewAccountSpendRule_Res objectForKey:@"UseMonthlySpendLimit"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.UseMonthlySpendLimit =  [ViewAccountSpendRule_Res objectForKey:@"UseMonthlySpendLimit"] ;
                }
                
                if (![[ViewAccountSpendRule_Res objectForKey:@"Daily_Spend_Limit"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.Daily_Spend_Limit =  [ViewAccountSpendRule_Res objectForKey:@"Daily_Spend_Limit"] ;
                }
                
                if (![[ViewAccountSpendRule_Res objectForKey:@"International_Use_Allowed"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.International_Use_Allowed = [ [ViewAccountSpendRule_Res objectForKey:@"International_Use_Allowed"] boolValue];
                }
                
                if (![[ViewAccountSpendRule_Res objectForKey:@"UseMerchantCategory"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.UseMerchantCategory =  [ViewAccountSpendRule_Res objectForKey:@"UseMerchantCategory"];
                }
                
                if (![[ViewAccountSpendRule_Res objectForKey:@"ByPass_Card_Monetary_Limit"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.ByPass_Card_Monetary_Limit = [ [ViewAccountSpendRule_Res objectForKey:@"ByPass_Card_Monetary_Limit"] boolValue];
                }
                
                               
                if (![[ViewAccountSpendRule_Res objectForKey:@"SingleTransaction_Spend_Limit"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.SingleTransaction_Spend_Limit =  [ViewAccountSpendRule_Res objectForKey:@"SingleTransaction_Spend_Limit"] ;
                }
                
                if (![[ViewAccountSpendRule_Res objectForKey:@"ByPassBusiness_BudgetLimit"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.ByPassBusiness_BudgetLimit = [ [ViewAccountSpendRule_Res objectForKey:@"ByPassBusiness_BudgetLimit"] boolValue];
                }
                
                if (![[ViewAccountSpendRule_Res objectForKey:@"BypassBusinessBugdetLimitPeriod"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.BypassBusinessBugdetLimitPeriod = [ViewAccountSpendRule_Res objectForKey:@"BypassBusinessBugdetLimitPeriod"] ;
                }

                
                if (![[ViewAccountSpendRule_Res objectForKey:@"Period"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.Period =  [ViewAccountSpendRule_Res objectForKey:@"Period"] ;
                }
                if (![[ViewAccountSpendRule_Res objectForKey:@"EXPENSE_CAT_ONE"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.EXPENSE_CAT_ONE =  [ViewAccountSpendRule_Res objectForKey:@"EXPENSE_CAT_ONE"];
                }
                if (![[ViewAccountSpendRule_Res objectForKey:@"EXPENSE_CAT_TWO"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.EXPENSE_CAT_TWO =  [ViewAccountSpendRule_Res objectForKey:@"EXPENSE_CAT_TWO"];
                }
                if (![[ViewAccountSpendRule_Res objectForKey:@"EXPENSE_CAT_THREE"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.EXPENSE_CAT_THREE =  [ViewAccountSpendRule_Res objectForKey:@"EXPENSE_CAT_THREE"];
                }
                if (![[ViewAccountSpendRule_Res objectForKey:@"ShowSpendRuleOnSS"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.ShowSpendRuleOnSS =  [ViewAccountSpendRule_Res objectForKey:@"ShowSpendRuleOnSS"];
                }
                if (![[ViewAccountSpendRule_Res objectForKey:@"Daily_Spend_Limit"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.Daily_Spend_Limit =  [ViewAccountSpendRule_Res objectForKey:@"Daily_Spend_Limit"] ;
                }
                if (![[ViewAccountSpendRule_Res objectForKey:@"Monthly_Spend_Limit"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.Monthly_Spend_Limit =  [ViewAccountSpendRule_Res objectForKey:@"Monthly_Spend_Limit"] ;
                }
                if (![[ViewAccountSpendRule_Res objectForKey:@"CATEGORY_DEF"] isKindOfClass:[NSNull class]]) {
                    expenseRulesData.CATEGORY_DEF =  [ViewAccountSpendRule_Res objectForKey:@"CATEGORY_DEF"];
                }
                
                if (![[ViewAccountSpendRule_Res objectForKey:@"ViewAccountSpendCardSetup_CM"] isKindOfClass:[NSNull class]]) {
                     id ViewAccountSpendCardSetup_CM = [ViewAccountSpendRule_Res objectForKey:@"ViewAccountSpendCardSetup_CM"];
                    
                    
                   if ([[ViewAccountSpendCardSetup_CM objectForKey:@"MerchantCategory"] isKindOfClass:[NSArray class]]) {
                       
                  id MerchantCategory = [ViewAccountSpendCardSetup_CM objectForKey:@"MerchantCategory"];
                       for(NSDictionary *dict in MerchantCategory){
                           MerchantCategoryClass *obj = [[MerchantCategoryClass alloc] init];
                           if (![[dict objectForKey:@"MerchantCategoryCodePlan"] isKindOfClass:[NSNull class]]) {
                               obj.MerchantCategoryCodePlan =  [dict objectForKey:@"MerchantCategoryCodePlan"];
                           }
                           if (![[dict objectForKey:@"Default_Selection"] isKindOfClass:[NSNull class]]) {
                               obj.Default_Selection =  [dict objectForKey:@"Default_Selection"];
                           }
                           if (![[dict objectForKey:@"SKey"] isKindOfClass:[NSNull class]]) {
                               obj.SKey =  [dict objectForKey:@"SKey"];
                           }
                           if (![[dict objectForKey:@"MCCDescription"] isKindOfClass:[NSNull class]]) {
                               obj.MCCDescription =  [dict objectForKey:@"MCCDescription"];
                           }
                           if (![[dict objectForKey:@"DefaultDescription"] isKindOfClass:[NSNull class]]) {
                               obj.DefaultDescription =  [dict objectForKey:@"DefaultDescription"];
                           }
                           if (![[dict objectForKey:@"SpendLimit_Auto"] isKindOfClass:[NSNull class]]) {
                               obj.SpendLimit_Auto =  [dict objectForKey:@"SpendLimit_Auto"];
                           }
                           if (![[dict objectForKey:@"SpendLimit_Auto_Month"] isKindOfClass:[NSNull class]]) {
                               obj.SpendLimit_Auto_Month =  [dict objectForKey:@"SpendLimit_Auto_Month"];
                           }
                           if (![[dict objectForKey:@"MCCPlanDescription"] isKindOfClass:[NSNull class]]) {
                               obj.MCCPlanDescription =  [dict objectForKey:@"MCCPlanDescription"];
                           }
                           [expenseRulesData.murchantCatData  addObject:obj];
                           //[obj release];
                       }
                   }
                    else
                    {
                        id MerchantCategory = [ViewAccountSpendCardSetup_CM objectForKey:@"MerchantCategory"];
                        
                        
                            MerchantCategoryClass *obj = [[MerchantCategoryClass alloc] init];
                            if (![[MerchantCategory objectForKey:@"MerchantCategoryCodePlan"] isKindOfClass:[NSNull class]]) {
                                obj.MerchantCategoryCodePlan =  [MerchantCategory objectForKey:@"MerchantCategoryCodePlan"];
                            }
                            if (![[MerchantCategory objectForKey:@"Default_Selection"] isKindOfClass:[NSNull class]]) {
                                obj.Default_Selection =  [MerchantCategory objectForKey:@"Default_Selection"];
                            }
                            if (![[MerchantCategory objectForKey:@"SKey"] isKindOfClass:[NSNull class]]) {
                                obj.SKey =  [MerchantCategory objectForKey:@"SKey"];
                            }
                            if (![[MerchantCategory objectForKey:@"MCCDescription"] isKindOfClass:[NSNull class]]) {
                                obj.MCCDescription =  [MerchantCategory objectForKey:@"MCCDescription"];
                            }
                            if (![[MerchantCategory objectForKey:@"DefaultDescription"] isKindOfClass:[NSNull class]]) {
                                obj.DefaultDescription =  [MerchantCategory objectForKey:@"DefaultDescription"];
                            }
                            if (![[MerchantCategory objectForKey:@"SpendLimit_Auto"] isKindOfClass:[NSNull class]]) {
                                obj.SpendLimit_Auto =  [MerchantCategory objectForKey:@"SpendLimit_Auto"];
                            }
                            if (![[MerchantCategory objectForKey:@"SpendLimit_Auto_Month"] isKindOfClass:[NSNull class]]) {
                                obj.SpendLimit_Auto_Month =  [MerchantCategory objectForKey:@"SpendLimit_Auto_Month"];
                            }
                        
                        if (![[MerchantCategory objectForKey:@"MCCPlanDescription"] isKindOfClass:[NSNull class]]) {
                            obj.MCCPlanDescription =  [MerchantCategory objectForKey:@"MCCPlanDescription"];
                        }

                            [expenseRulesData.murchantCatData  addObject:obj];
                            [obj release];
                        
                        
                    }
                   
                    
                }
                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                {
                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                    {
                        [self.Datadelegate getResponce:expenseRulesData];
                    }
                }
            }
        }
            break;
            
        case svcGetCustomerAddress:
        {
            
            id CUSTOMER_ADDRESS_RET=[json valueForKey:@"CUSTOMER_ADDRESS_RET"];
            
            UserProfileDataClass *empObj=[[UserProfileDataClass alloc]init];

            if (![[CUSTOMER_ADDRESS_RET valueForKey:@"ERROR_FOUND"]isKindOfClass:[NSNull class]])
            {
                empObj.ERROR_FOUND=[[CUSTOMER_ADDRESS_RET valueForKey:@"ERROR_FOUND"] boolValue];
            }
            
            if (![[CUSTOMER_ADDRESS_RET valueForKey:@"ERRMSG"]isKindOfClass:[NSNull class]])
            {
                empObj.ERRMSG=[CUSTOMER_ADDRESS_RET valueForKey:@"ERRMSG"];
            }

            
            if (![[CUSTOMER_ADDRESS_RET valueForKey:@"ADDRESS"]isKindOfClass:[NSNull class]])
            {
                id ADDRESS=[CUSTOMER_ADDRESS_RET valueForKey:@"ADDRESS"];
                
                if ([ADDRESS isKindOfClass:[NSArray class]])
                {
                    if ([ADDRESS count]>0)
                    {
                        if (![[[ADDRESS objectAtIndex:0] valueForKey:@"ADDRESS_TYPE"]isKindOfClass:[NSNull class]])
                        {
    //                        empObj.ACCTID=[ADDRESS valueForKey:@"ADDRESS_TYPE"]];
                        }
                        if (![[[ADDRESS objectAtIndex:0] valueForKey:@"ADDRESS_LINE1"]isKindOfClass:[NSNull class]])
                        {
                            empObj.ADDRESS1=[[ADDRESS objectAtIndex:0] valueForKey:@"ADDRESS_LINE1"];
                        }
                        if (![[[ADDRESS objectAtIndex:0] valueForKey:@"ADDRESS_LINE2"]isKindOfClass:[NSNull class]])
                        {
                            empObj.ADDRESS2=[[ADDRESS objectAtIndex:0] valueForKey:@"ADDRESS_LINE2"];
                        }
                        if (![[[ADDRESS objectAtIndex:0] valueForKey:@"CITY"]isKindOfClass:[NSNull class]])
                        {
                            empObj.CITY=[[ADDRESS objectAtIndex:0] valueForKey:@"CITY"];
                        }
                        
                        if (![[[ADDRESS objectAtIndex:0] valueForKey:@"STATE_CODE"]isKindOfClass:[NSNull class]])
                        {
                            empObj.StateCode=[[ADDRESS objectAtIndex:0] valueForKey:@"STATE_CODE"];
                        }
                        
                        if (![[[ADDRESS objectAtIndex:0] valueForKey:@"STATE_NAME"]isKindOfClass:[NSNull class]])
                        {
                            empObj.STATE=[[ADDRESS objectAtIndex:0] valueForKey:@"STATE_NAME"];
                        }
                        
                        if (![[[ADDRESS objectAtIndex:0] valueForKey:@"COUNTRY_CODE"]isKindOfClass:[NSNull class]])
                        {
                            empObj.COUNTRY_CODE=[[ADDRESS objectAtIndex:0] valueForKey:@"COUNTRY_CODE"];
                        }
                        if (![[[ADDRESS objectAtIndex:0] valueForKey:@"COUNTRY_NAME"]isKindOfClass:[NSNull class]])
                        {
                            empObj.countryName=[[ADDRESS objectAtIndex:0] valueForKey:@"COUNTRY_NAME"];
                        }
                        
                        if (![[[ADDRESS objectAtIndex:0] valueForKey:@"POSTAL_CODE"]isKindOfClass:[NSNull class]])
                        {
                            empObj.POSTALCODE=[[ADDRESS objectAtIndex:0] valueForKey:@"POSTAL_CODE"];
                        }
                    }
                }
                else
                {
                    if (![[ADDRESS valueForKey:@"ADDRESS_TYPE"]isKindOfClass:[NSNull class]])
                    {
//                        empObj.ACCTID=[ADDRESS valueForKey:@"ADDRESS_TYPE"]];
                    }
                    if (![[ADDRESS valueForKey:@"ADDRESS_LINE1"]isKindOfClass:[NSNull class]])
                    {
                        empObj.ADDRESS1=[ADDRESS valueForKey:@"ADDRESS_LINE1"];
                    }
                    if (![[ADDRESS valueForKey:@"ADDRESS_LINE2"]isKindOfClass:[NSNull class]])
                    {
                        empObj.ADDRESS2=[ADDRESS valueForKey:@"ADDRESS_LINE2"];
                    }
                    
                    if (![[ADDRESS valueForKey:@"CITY"]isKindOfClass:[NSNull class]])
                    {
                        empObj.CITY=[ADDRESS valueForKey:@"CITY"];
                    }
                    
                    if (![[ADDRESS valueForKey:@"STATE_CODE"]isKindOfClass:[NSNull class]])
                    {
                        empObj.StateCode=[ADDRESS valueForKey:@"STATE_CODE"];
                    }

                    if (![[ADDRESS valueForKey:@"STATE_NAME"]isKindOfClass:[NSNull class]])
                    {
                        empObj.STATE=[ADDRESS valueForKey:@"STATE_NAME"];
                    }
                    
                    if (![[ADDRESS valueForKey:@"COUNTRY_CODE"]isKindOfClass:[NSNull class]])
                    {
                        empObj.COUNTRY_CODE=[ADDRESS valueForKey:@"COUNTRY_CODE"];
                    }
                    if (![[ADDRESS valueForKey:@"COUNTRY_NAME"]isKindOfClass:[NSNull class]])
                    {
                        empObj.countryName=[ADDRESS valueForKey:@"COUNTRY_NAME"];
                    }
                    
                    if (![[ADDRESS valueForKey:@"POSTAL_CODE"]isKindOfClass:[NSNull class]])
                    {
                        empObj.POSTALCODE=[ADDRESS valueForKey:@"POSTAL_CODE"];
                    }
                }
                
            }
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:empObj];
                }
            }
            

         }
            break;
            case svcGetEmployees:
        {
            
            id GetEmployees_Res=[json valueForKey:@"GetEmployees_Res"];

            if (![[GetEmployees_Res valueForKey:@"ResCode"]isKindOfClass:[NSNull class]])
            {
                id ResCode=[GetEmployees_Res valueForKey:@"ResCode"];
                if ([ResCode intValue]!=0)
                {
                    if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                    {
                        if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                        {
                            [self.Datadelegate getResponce:nil];
                        }
                    }
                    

                }else
                {
                    if (![[GetEmployees_Res valueForKey:@"Employee"]isKindOfClass:[NSNull class]] && [GetEmployees_Res valueForKey:@"Employee"]!=nil)
                    {
                        id Employee=[GetEmployees_Res valueForKey:@"Employee"];
                        
                        if (!DataArray)
                        {
                            DataArray=[[NSMutableArray alloc]init];
                        }else
                        {
                            [DataArray removeAllObjects];
                        }
                        
                        if ([Employee isKindOfClass:[NSArray class]])
                        {
                            for (int i=0; i<[Employee count]; i++)
                            {
                                
                                employeeDataClass *empObj=[[employeeDataClass alloc]init];
                                
                                if (![[[Employee objectAtIndex:i] valueForKey:@"ACCTID"]isKindOfClass:[NSNull class]])
                                {
                                    empObj.ACCTID=[[Employee objectAtIndex:i] valueForKey:@"ACCTID"];
                                }
                                
                                if (![[[Employee objectAtIndex:i] valueForKey:@"EmployeeId"]isKindOfClass:[NSNull class]])
                                {
                                    empObj.EmployeeId=[[Employee objectAtIndex:i] valueForKey:@"EmployeeId"];
                                }

                                if (![[[Employee objectAtIndex:i] valueForKey:@"Name"]isKindOfClass:[NSNull class]])
                                {
                                    empObj.Name=[[Employee objectAtIndex:i] valueForKey:@"Name"];
                                }
                                [DataArray addObject:empObj];
                                [empObj release];

                            }
                            

                        }else
                        {
                            employeeDataClass *empObj=[[employeeDataClass alloc]init];
                            
                            if (![[Employee valueForKey:@"ACCTID"]isKindOfClass:[NSNull class]])
                            {
                                empObj.ACCTID=[Employee valueForKey:@"ACCTID"];
                            }
                            
                            if (![[Employee valueForKey:@"EmployeeId"]isKindOfClass:[NSNull class]])
                            {
                                empObj.EmployeeId=[Employee valueForKey:@"EmployeeId"];
                            }
                            
                            if (![[Employee valueForKey:@"Name"]isKindOfClass:[NSNull class]])
                            {
                                empObj.Name=[Employee valueForKey:@"Name"];
                            }
                            [DataArray addObject:empObj];
                            [empObj release];

                        }
                    }
                    
                    if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                    {
                        if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                        {
                            [self.Datadelegate getResponce:DataArray];
                        }
                    }
                }
            }
           
        }
            break;
            
            case svcCardSpendReportAPI:
        {
            
            id GetEmployees_Res=[json valueForKey:@"CardSpendReport_RET"];
            
            if (![GetEmployees_Res isKindOfClass:[NSNull class]])
            {
                if (![[GetEmployees_Res valueForKey:@"ERROR_FOUND"]isKindOfClass:[NSNull class]])
                {
                 id  ERROR_FOUND=[GetEmployees_Res valueForKey:@"ERROR_FOUND"];
                    
                    if ([ERROR_FOUND boolValue])
                    {
                        if (![[GetEmployees_Res valueForKey:@"ERRMSG"]isKindOfClass:[NSNull class]])
                        {
                            id  ERRMSG=[GetEmployees_Res valueForKey:@"ERRMSG"];
                            
                            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                            {
                                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                                {
                                    [self.Datadelegate getResponce:ERRMSG];
                                }
                            }

                        }
                    }else
                    {
                        employeeExpenseDataClass *empExpDataObj=[[employeeExpenseDataClass alloc]init];
                        
                        if (![[GetEmployees_Res valueForKey:@"CardSpendTotal"]isKindOfClass:[NSNull class]])
                        {
                            empExpDataObj.CardSpendTotal=[[GetEmployees_Res valueForKey:@"CardSpendTotal"] doubleValue];
                        }
                        
                        if (![[GetEmployees_Res valueForKey:@"CardSpendFundingReport"]isKindOfClass:[NSNull class]])
                        {
                            id  CardSpendFundingReport=[GetEmployees_Res valueForKey:@"CardSpendFundingReport"];
                            
                            empExpDataObj.employeeExpenseArray=[[NSMutableArray alloc]init];
                            
                            if (![[CardSpendFundingReport valueForKey:@"CardFundingReport"]isKindOfClass:[NSNull class]])
                            {
                                id  CardFundingReport=[CardSpendFundingReport valueForKey:@"CardFundingReport"];
                                
                                if ([CardFundingReport isKindOfClass:[NSArray class]])
                                {
                                    for (int i=0; i<[CardFundingReport count]; i++)
                                    {
                                        employeeExpData *expData=[[employeeExpData alloc]init];
                                        
                                        if (![[[CardFundingReport objectAtIndex:i] valueForKey:@"EmployeeName"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.EmployeeName=[[CardFundingReport objectAtIndex:i] valueForKey:@"EmployeeName"];
                                        }
                                        
                                        if (![[[CardFundingReport objectAtIndex:i] valueForKey:@"CardNumber"]isKindOfClass:[NSNull class]])
                                        {
                                           expData.CardNumber=[[CardFundingReport objectAtIndex:i] valueForKey:@"CardNumber"];
                                        }
                                        
                                        if (![[[CardFundingReport objectAtIndex:i] valueForKey:@"TotalExpenses"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.TotalExpenses=[[[CardFundingReport objectAtIndex:i] valueForKey:@"TotalExpenses"] doubleValue];
                                        }
                                        
                                        if (![[[CardFundingReport objectAtIndex:i] valueForKey:@"ExpenseLimit"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.ExpenseLimit=[[CardFundingReport objectAtIndex:i] valueForKey:@"ExpenseLimit"];
                                        }
                                        
                                        if (![[[CardFundingReport objectAtIndex:i] valueForKey:@"Diff_Limit_Expense"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.Diff_Limit_Expense=[[[CardFundingReport objectAtIndex:i] valueForKey:@"Diff_Limit_Expense"] doubleValue];
                                        }


                                        [empExpDataObj.employeeExpenseArray addObject:expData];
                                        [expData release];
                                    }
                                }else
                                {
                                        employeeExpData *expData=[[employeeExpData alloc]init];
                                        
                                        if (![[CardFundingReport valueForKey:@"EmployeeName"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.EmployeeName=[CardFundingReport valueForKey:@"EmployeeName"];
                                        }
                                        
                                        if (![[CardFundingReport valueForKey:@"CardNumber"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.CardNumber=[CardFundingReport valueForKey:@"CardNumber"];
                                        }
                                        
                                        if (![[CardFundingReport valueForKey:@"TotalExpenses"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.TotalExpenses=[[CardFundingReport valueForKey:@"TotalExpenses"] doubleValue];
                                        }
                                        
                                        if (![[CardFundingReport valueForKey:@"ExpenseLimit"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.ExpenseLimit=[CardFundingReport valueForKey:@"ExpenseLimit"];
                                        }
                                        
                                        if (![[CardFundingReport valueForKey:@"Diff_Limit_Expense"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.Diff_Limit_Expense=[[CardFundingReport valueForKey:@"Diff_Limit_Expense"] doubleValue];
                                        }
                                        
                                        [empExpDataObj.employeeExpenseArray addObject:expData];
                                        [expData release];
                                }
                            }
                        }
                        
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:empExpDataObj];
                            }
                        }
                    }
                }
            }
        }
            break;
            case svcGenerateReport_ExpenseCategoryAPI:
        {
            
            id GenerateReport_ExpenseCategory_RET=[json valueForKey:@"GenerateReport_ExpenseCategory_RET"];
            
            if (![GenerateReport_ExpenseCategory_RET isKindOfClass:[NSNull class]])
            {
                if (![[GenerateReport_ExpenseCategory_RET valueForKey:@"ERROR_FOUND"]isKindOfClass:[NSNull class]])
                {
                    id  ERROR_FOUND=[GenerateReport_ExpenseCategory_RET valueForKey:@"ERROR_FOUND"];
                    
                    if ([ERROR_FOUND boolValue])
                    {
                        if (![[GenerateReport_ExpenseCategory_RET valueForKey:@"ERRMSG"]isKindOfClass:[NSNull class]])
                        {
                            id  ERRMSG=[GenerateReport_ExpenseCategory_RET valueForKey:@"ERRMSG"];
                            
                            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                            {
                                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                                {
                                    [self.Datadelegate getResponce:ERRMSG];
                                }
                            }
                            
                        }
                    }else
                    {
                        employeeExpenseDataClass *empExpDataObj=[[employeeExpenseDataClass alloc]init];
                        
                        if (![[GenerateReport_ExpenseCategory_RET valueForKey:@"TotalExpenses"]isKindOfClass:[NSNull class]])
                        {
                            empExpDataObj.CardSpendTotal=[[GenerateReport_ExpenseCategory_RET valueForKey:@"TotalExpenses"] doubleValue];
                        }
                        
                        if (![[GenerateReport_ExpenseCategory_RET valueForKey:@"ExpenseCategoryReport"]isKindOfClass:[NSNull class]])
                        {
                            id  ExpenseCategoryReport=[GenerateReport_ExpenseCategory_RET valueForKey:@"ExpenseCategoryReport"];
                            
                            empExpDataObj.employeeExpenseArray=[[NSMutableArray alloc]init];
                            
                            if (![[ExpenseCategoryReport valueForKey:@"ExpenseCategory"]isKindOfClass:[NSNull class]])
                            {
                                id  ExpenseCategory=[ExpenseCategoryReport valueForKey:@"ExpenseCategory"];
                                
                                if ([ExpenseCategory isKindOfClass:[NSArray class]])
                                {
                                    for (int i=0; i<[ExpenseCategory count]; i++)
                                    {
                                        employeeExpData *expData=[[employeeExpData alloc]init];
                                        
                                        if (![[[ExpenseCategory objectAtIndex:i] valueForKey:@"SubExpenseCategory"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.expCateGory=[[ExpenseCategory objectAtIndex:i] valueForKey:@"SubExpenseCategory"];
                                        }
                                        
                                        if (![[[ExpenseCategory objectAtIndex:i] valueForKey:@"SubTotalExpenses"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.expCateAmount=[[[ExpenseCategory objectAtIndex:i] valueForKey:@"SubTotalExpenses"] doubleValue];
                                        }
                                        
                                                                               
                                        [empExpDataObj.employeeExpenseArray addObject:expData];
                                        [expData release];
                                    }
                                }else
                                {
                                    employeeExpData *expData=[[employeeExpData alloc]init];
                                    
                                    if (![[ExpenseCategory valueForKey:@"SubExpenseCategory"]isKindOfClass:[NSNull class]])
                                    {
                                        expData.expCateGory=[ExpenseCategory valueForKey:@"SubExpenseCategory"];
                                    }
                                    
                                    if (![[ExpenseCategory valueForKey:@"SubTotalExpenses"]isKindOfClass:[NSNull class]])
                                    {
                                        expData.expCateAmount=[[ExpenseCategory valueForKey:@"SubTotalExpenses"] doubleValue];
                                    }
                                    
                                    
                                    [empExpDataObj.employeeExpenseArray addObject:expData];
                                    [expData release];
                                }
                            }
                        }
                        
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:empExpDataObj];
                            }
                        }
                    }
                }
            }
        }
            break;
            case svcGetSpendProducts:
        {
            id SpendProducts_Res=[json valueForKey:@"SpendProducts_Res"];
            
            if (![[SpendProducts_Res valueForKey:@"COMBODETAIL"]isKindOfClass:[NSNull class]])
            {
                id COMBODETAIL=[SpendProducts_Res valueForKey:@"COMBODETAIL"];
                
                
                if (!DataArray)
                {
                    DataArray=[[NSMutableArray alloc]init];
                }else
                {
                    [DataArray removeAllObjects];
                }
                
                if ([COMBODETAIL isKindOfClass:[NSArray class]])
                {
                    for (int i=0; i<[COMBODETAIL count]; i++)
                    {
                        businessListDataClass *businessList=[[businessListDataClass alloc]init];
                        
                        if (![[[COMBODETAIL objectAtIndex:i] valueForKey:@"PRODUCT_PARENT"]isKindOfClass:[NSNull class]])
                        {
                           businessList.PRODUCT_PARENT=[[COMBODETAIL objectAtIndex:i] valueForKey:@"PRODUCT_PARENT"];
                        }
                        
                        if (![[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTCODE"]isKindOfClass:[NSNull class]])
                        {
                            businessList.LUTCODE=[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTCODE"];
                        }
                        
                        if (![[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTDESCRIPTION"]isKindOfClass:[NSNull class]])
                        {
                            businessList.LUTDESCRIPTION=[[COMBODETAIL objectAtIndex:i] valueForKey:@"LUTDESCRIPTION"];
                        }
                        [DataArray addObject:businessList];
                        [businessList release];
                    }
                }else
                {
                        businessListDataClass *businessList=[[businessListDataClass alloc]init];
                        
                        if (![[COMBODETAIL valueForKey:@"PRODUCT_PARENT"]isKindOfClass:[NSNull class]])
                        {
                            businessList.PRODUCT_PARENT=[COMBODETAIL valueForKey:@"PRODUCT_PARENT"];
                        }
                        
                        if (![[COMBODETAIL valueForKey:@"LUTCODE"]isKindOfClass:[NSNull class]])
                        {
                            businessList.LUTCODE=[COMBODETAIL valueForKey:@"LUTCODE"];
                        }
                        
                        if (![[COMBODETAIL valueForKey:@"LUTDESCRIPTION"]isKindOfClass:[NSNull class]])
                        {
                            businessList.LUTDESCRIPTION=[COMBODETAIL valueForKey:@"LUTDESCRIPTION"];
                        }
                        [DataArray addObject:businessList];
                        [businessList release];
                }
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:DataArray];
                }
            }

        }
            break;
            case svcSaveAccountSpendParameter:
        {
            LoginResponceDataClass *loginDataobj=[[LoginResponceDataClass alloc]init];
            
            id SaveAccountSpendRule_Res=[json valueForKey:@"SaveAccountSpendRule_Res"];
            
            if (![[SaveAccountSpendRule_Res valueForKey:@"ERRMSG"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.ErrorMsg=[SaveAccountSpendRule_Res valueForKey:@"ERRMSG"];
                
            }
            
            if (![[SaveAccountSpendRule_Res valueForKey:@"RES_CODE"]isKindOfClass:[NSNull class]])
            {
                loginDataobj.Error_Code=[[SaveAccountSpendRule_Res valueForKey:@"RES_CODE"] intValue];
                
            }
            
            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
            {
                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                {
                    [self.Datadelegate getResponce:loginDataobj];
                }
            }

        }
            break;
        case svcEmployeeByExpenseCategoryAPI: ///
        {
            
            id EmployeeExpenseAnalysisReport_RET=[json valueForKey:@"EmployeeExpenseAnalysisReport_RET"];
            
            if (![EmployeeExpenseAnalysisReport_RET isKindOfClass:[NSNull class]])
            {
                if (![[EmployeeExpenseAnalysisReport_RET valueForKey:@"ERROR_FOUND"]isKindOfClass:[NSNull class]])
                {
                    id  ERROR_FOUND=[EmployeeExpenseAnalysisReport_RET valueForKey:@"ERROR_FOUND"];
                    
                    if ([ERROR_FOUND boolValue])
                    {
                        if (![[EmployeeExpenseAnalysisReport_RET valueForKey:@"ERRMSG"]isKindOfClass:[NSNull class]])
                        {
                            id  ERRMSG=[EmployeeExpenseAnalysisReport_RET valueForKey:@"ERRMSG"];
                            
                            if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                            {
                                if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                                {
                                    [self.Datadelegate getResponce:ERRMSG];
                                }
                            }
                            
                        }
                    }else
                    {
                        employeeExpenseDataClass *empExpDataObj=[[employeeExpenseDataClass alloc]init];
                        if (![[EmployeeExpenseAnalysisReport_RET valueForKey:@"ExpenseAmount"]isKindOfClass:[NSNull class]])
                        {
                            //[[innerArrayValue valueForKey:@"Expense"]] doubleValue];
                            empExpDataObj.CardSpendTotal = [[EmployeeExpenseAnalysisReport_RET valueForKey:@"ExpenseAmount"] doubleValue];
                        }
                        if (![[EmployeeExpenseAnalysisReport_RET valueForKey:@"EmployeeByExpenseCategoryDetails"]isKindOfClass:[NSNull class]])
                        {
                            id EmployeeByExpenseCategoryDetails=[EmployeeExpenseAnalysisReport_RET valueForKey:@"EmployeeByExpenseCategoryDetails"];
                            
                            if (![[EmployeeByExpenseCategoryDetails valueForKey:@"EmployeeExpense"]isKindOfClass:[NSNull class]])
                            {
                                id EmployeeExpense=[EmployeeByExpenseCategoryDetails valueForKey:@"EmployeeExpense"] ;
                                
                                if (![EmployeeExpense isKindOfClass:[NSNull class]] && EmployeeExpense != nil)
                                {
                                    empExpDataObj.employeeExpenseArray=[[NSMutableArray alloc]init];
//                                    NSLog(@"%@",NSStringFromClass([EmployeeExpense class]));
                                    if ([EmployeeExpense isKindOfClass:[NSArray class]])
                                    {
                                        for (int i=0; i<[EmployeeExpense count]; i++)
                                        {
                                            employeeExpData *expData=[[employeeExpData alloc]init];
                                            
                                            
                                            if (![[[EmployeeExpense objectAtIndex:i] valueForKey:@"EmployeeName"]isKindOfClass:[NSNull class]])
                                            {
                                                expData.EmployeeName=[[EmployeeExpense objectAtIndex:i] valueForKey:@"EmployeeName"];
                                            }
                                            
                                            if (![[[EmployeeExpense objectAtIndex:i] valueForKey:@"CardNumber"]isKindOfClass:[NSNull class]])
                                            {
                                                expData.CardNumber=[[EmployeeExpense objectAtIndex:i] valueForKey:@"CardNumber"];
                                            }
                                            
                                            if (![[[EmployeeExpense objectAtIndex:i] valueForKey:@"SubTotalForEmployee"]isKindOfClass:[NSNull class]])
                                            {
                                                expData.TotalExpenses=[[[EmployeeExpense objectAtIndex:i] valueForKey:@"SubTotalForEmployee"] doubleValue];
                                            }
                                            
                                            if (![[EmployeeExpense valueForKey:@"ExpenseDetails"]isKindOfClass:[NSNull class]])
                                            {
                                                id ExpenseDetails=[[EmployeeExpense objectAtIndex:i] valueForKey:@"ExpenseDetails"];
                                                
                                                //                                                id EmployeeExpenseDetail=[ExpenseDetails valueForKey:@"EmployeeExpenseDetail"];
                                                
                                                id EmployeeExpenseDetail=[ExpenseDetails valueForKey:@"EmployeeExpenseDetail"];
                                                
                                                if (![EmployeeExpenseDetail isKindOfClass:[NSNull class]] && EmployeeExpenseDetail !=nil)
                                                {
                                                    
                                                    expData.arrEmployeCatDescExpense = [[NSMutableArray alloc] init];
                                                    
                                                    if ([EmployeeExpenseDetail isKindOfClass:[NSArray class]])
                                                    {
                                                        
                                                        for (int cnt=0; cnt < [EmployeeExpenseDetail count]; cnt++)
                                                        {                                                           
                                                            
                                                                ExpenseCategory *objExpenseCat = [[ExpenseCategory alloc] init];
                                                                objExpenseCat.expCatDesc = [[EmployeeExpenseDetail objectAtIndex:cnt] valueForKey:@"ExpCatDesc"];
                                                                objExpenseCat.expense = [[[EmployeeExpenseDetail objectAtIndex:cnt] valueForKey:@"Expense"] doubleValue];
                                                                [expData.arrEmployeCatDescExpense addObject:objExpenseCat];
                                                                [objExpenseCat release];
                                                            
                                                        }
                                                        
                                                        
                                                    }else
                                                    {
                                                        
                                                        ExpenseCategory *objExpenseCat = [[ExpenseCategory alloc] init];
                                                        objExpenseCat.expCatDesc = [EmployeeExpenseDetail valueForKey:@"ExpCatDesc"];
                                                        objExpenseCat.expense = [[EmployeeExpenseDetail valueForKey:@"Expense"] doubleValue];
                                                        [expData.arrEmployeCatDescExpense addObject:objExpenseCat];
                                                        [objExpenseCat release];
                                                    }
                                                }
                                                
                                            }
                                            
                                            
                                            
                                            
                                            
                                            
                                            [empExpDataObj.employeeExpenseArray addObject:expData];
                                            [expData release];
                                        }
                                    }else
                                    {
                                        employeeExpData *expData=[[employeeExpData alloc]init];
                                        
                                        
                                        if (![[EmployeeExpense valueForKey:@"EmployeeName"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.EmployeeName=[EmployeeExpense valueForKey:@"EmployeeName"];
                                        }
                                        
                                        if (![[EmployeeExpense valueForKey:@"CardNumber"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.CardNumber=[EmployeeExpense valueForKey:@"CardNumber"];
                                        }
                                        
                                        if (![[EmployeeExpense valueForKey:@"SubTotalForEmployee"]isKindOfClass:[NSNull class]])
                                        {
                                            expData.TotalExpenses=[[EmployeeExpense valueForKey:@"SubTotalForEmployee"] doubleValue];
                                        }
                                        
                                        if (![[EmployeeExpense valueForKey:@"ExpenseDetails"]isKindOfClass:[NSNull class]])
                                        {
                                            id ExpenseDetails=[EmployeeExpense valueForKey:@"ExpenseDetails"];
                                            
                                            //                                                id EmployeeExpenseDetail=[ExpenseDetails valueForKey:@"EmployeeExpenseDetail"];
                                            
                                            id EmployeeExpenseDetail=[ExpenseDetails valueForKey:@"EmployeeExpenseDetail"];
                                            
                                            if (![EmployeeExpenseDetail isKindOfClass:[NSNull class]] && EmployeeExpenseDetail !=nil)
                                            {
                                                expData.arrEmployeCatDescExpense = [[NSMutableArray alloc] init];
                                                
                                                
                                                if ([EmployeeExpenseDetail isKindOfClass:[NSArray class]])
                                                {
                                                    
                                                    for (int cnt=0; cnt < [EmployeeExpenseDetail count]; cnt++)
                                                    {
                                                        
                                                            ExpenseCategory *objExpenseCat = [[ExpenseCategory alloc] init];
                                                            objExpenseCat.expCatDesc = [[EmployeeExpenseDetail objectAtIndex:cnt] valueForKey:@"ExpCatDesc"];
                                                            objExpenseCat.expense = [[[EmployeeExpenseDetail objectAtIndex:cnt] valueForKey:@"Expense"] doubleValue];
                                                            [expData.arrEmployeCatDescExpense addObject:objExpenseCat];
                                                            [objExpenseCat release];
                                                        
                                                    }
                                                    
                                                    
                                                }else
                                                {
                                                    /*
                                                     expData.expCatOneText=[EmployeeExpenseDetail valueForKey:@"ExpCatDesc"]];
                                                     expData.expCatOneAmount=[[EmployeeExpenseDetail valueForKey:@"Expense"]] doubleValue];
                                                     */
                                                    ExpenseCategory *objExpenseCat = [[ExpenseCategory alloc] init];
                                                    objExpenseCat.expCatDesc = [EmployeeExpenseDetail valueForKey:@"ExpCatDesc"];
                                                    objExpenseCat.expense = [[EmployeeExpenseDetail valueForKey:@"Expense"] doubleValue];
                                                    [expData.arrEmployeCatDescExpense addObject:objExpenseCat];
                                                    [objExpenseCat release];
                                                }
                                            }
                                            /*
                                             //                                                if (![EmployeeExpenseDetail isKindOfClass:[NSNull class]] && EmployeeExpenseDetail !=nil) {
                                             //
                                             //                                                    if ([EmployeeExpenseDetail isKindOfClass:[NSArray class]])
                                             //                                                    {
                                             //                                                        id EmployeeExpenseType=[[EmployeeExpenseDetail objectAtIndex:0]valueForKey:@"EmployeeExpenseType"];
                                             //
                                             //
                                             //
                                             //                                                        if (![EmployeeExpenseType isKindOfClass:[NSNull class]] && EmployeeExpenseType !=nil) {
                                             //
                                             //                                                            id EmployeeExpenseDetail=[EmployeeExpenseType valueForKey:@"EmployeeExpenseDetail"];
                                             //
                                             //                                                            if (![EmployeeExpenseDetail isKindOfClass:[NSNull class]] && EmployeeExpenseDetail !=nil)
                                             //                                                            {
                                             //
                                             //
                                             //
                                             //                                                                if ([EmployeeExpenseDetail isKindOfClass:[NSArray class]])
                                             //                                                                {
                                             //                                                                    if ([EmployeeExpenseDetail count]>=1) {
                                             //                                                                        expData.expCatOneText=[[EmployeeExpenseDetail objectAtIndex:0] valueForKey:@"ExpCatDesc"]];
                                             //                                                                        expData.expCatOneAmount=[[[EmployeeExpenseDetail objectAtIndex:0] valueForKey:@"Expense"]] doubleValue];
                                             //                                                                    }
                                             //
                                             //                                                                    if ([EmployeeExpenseDetail count]>=2) {
                                             //                                                                        expData.expCatTwoText=[[EmployeeExpenseDetail objectAtIndex:1] valueForKey:@"ExpCatDesc"]];
                                             //
                                             //                                                                        expData.expCatTwoAmount=[[[EmployeeExpenseDetail objectAtIndex:1] valueForKey:@"Expense"]] doubleValue];
                                             //                                                                    }
                                             //
                                             //                                                                    if ([EmployeeExpenseDetail count]>=3) {
                                             //                                                                        expData.expCatThreeText=[[EmployeeExpenseDetail objectAtIndex:2] valueForKey:@"ExpCatDesc"]];
                                             //                                                                        expData.expCatThreeAmount=[[[EmployeeExpenseDetail objectAtIndex:2] valueForKey:@"Expense"]] doubleValue];
                                             //                                                                    }
                                             //
                                             //
                                             //                                                                }else
                                             //                                                                {
                                             //                                                                    expData.expCatOneText=[EmployeeExpenseDetail valueForKey:@"ExpCatDesc"]];
                                             //                                                                    expData.expCatOneAmount=[[EmployeeExpenseDetail valueForKey:@"Expense"]] doubleValue];
                                             //                                                                }
                                             //                                                            }
                                             //                                                        }
                                             //
                                             //                                                    }else
                                             //                                                    {
                                             //                                                        id EmployeeExpenseType=[ExpenseTypeDetail valueForKey:@"EmployeeExpenseType"];
                                             //
                                             //
                                             //                                                        if (![EmployeeExpenseType isKindOfClass:[NSNull class]] && EmployeeExpenseType !=nil) {
                                             //
                                             //                                                            id EmployeeExpenseDetail=[EmployeeExpenseType valueForKey:@"EmployeeExpenseDetail"];
                                             //
                                             //                                                            if (![EmployeeExpenseDetail isKindOfClass:[NSNull class]] && EmployeeExpenseDetail !=nil)
                                             //                                                            {
                                             //
                                             //
                                             //                                                                if ([EmployeeExpenseDetail isKindOfClass:[NSArray class]])
                                             //                                                                {
                                             //                                                                    if ([EmployeeExpenseDetail count]>=1) {
                                             //                                                                        expData.expCatOneText=[[EmployeeExpenseDetail objectAtIndex:0] valueForKey:@"ExpCatDesc"]];
                                             //                                                                        expData.expCatOneAmount=[[[EmployeeExpenseDetail objectAtIndex:0] valueForKey:@"Expense"]] doubleValue];
                                             //                                                                    }
                                             //
                                             //                                                                    if ([EmployeeExpenseDetail count]>=2) {
                                             //                                                                        expData.expCatTwoText=[[EmployeeExpenseDetail objectAtIndex:1] valueForKey:@"ExpCatDesc"]];
                                             //
                                             //                                                                        expData.expCatTwoAmount=[[[EmployeeExpenseDetail objectAtIndex:1] valueForKey:@"Expense"]] doubleValue];
                                             //                                                                    }
                                             //                                                                    
                                             //                                                                    if ([EmployeeExpenseDetail count]>=3) {
                                             //                                                                        expData.expCatThreeText=[[EmployeeExpenseDetail objectAtIndex:2] valueForKey:@"ExpCatDesc"]];
                                             //                                                                        expData.expCatThreeAmount=[[[EmployeeExpenseDetail objectAtIndex:2] valueForKey:@"Expense"]] doubleValue];
                                             //                                                                    }
                                             //                                                                    
                                             //                                                                    
                                             //                                                                }else
                                             //                                                                {
                                             //                                                                    expData.expCatOneText=[EmployeeExpenseDetail valueForKey:@"ExpCatDesc"]];
                                             //                                                                    expData.expCatOneAmount=[[EmployeeExpenseDetail valueForKey:@"Expense"]] doubleValue];
                                             //                                                                }
                                             //                                                            }
                                             //                                                        }
                                             //                                                        
                                             //                                                    }
                                             //                                                }  */
                                        }
                                        [empExpDataObj.employeeExpenseArray addObject:expData];
                                        [expData release];
                                    }
                                }
                            }
                        }
                        
                        
                        if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                        {
                            if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                            {
                                [self.Datadelegate getResponce:empExpDataObj];
                            }
                        }
                    }
                }
            }
        }
            break;
        case svcBusinessExpense:
        {
            id BusinessExpense_Res = [json valueForKey:@"BusinessExpense_Res"];
            if (![BusinessExpense_Res isKindOfClass:[NSNull class]])
            {
                employeeExpenseDataClass *empExpDataObj = [[employeeExpenseDataClass alloc] init];
                if (![[BusinessExpense_Res valueForKey:@"BusinessDetail"] isKindOfClass:[NSNull class]])
                {
                    id BusinessDetail = [BusinessExpense_Res valueForKey:@"BusinessDetail"];
                    if (![[BusinessDetail valueForKey:@"ExpenseAmount"] isKindOfClass:[NSNull class]])
                    {
                        empExpDataObj.CardSpendTotal = [[BusinessDetail valueForKey:@"ExpenseAmount"] doubleValue];
                    }
                    if (![[BusinessDetail valueForKey:@"RecordArray"] isKindOfClass:[NSNull class]])
                    {
                        id RecordArray = [BusinessDetail valueForKey:@"RecordArray"];
                        if (![[RecordArray valueForKey:@"Record"] isKindOfClass:[NSNull class]])
                        {
                            id Record = [RecordArray valueForKey:@"Record"];
                            if (![Record isKindOfClass:[NSNull class]] && Record != nil)
                            {
                                empExpDataObj.employeeExpenseArray = [[NSMutableArray alloc] init];
                                if ([Record isKindOfClass:[NSArray class]])
                                {
//                                    NSLog(@"Record is array");
                                    for (int count = 0; count < [Record count]; count++)
                                    {
                                        employeeExpData *expData = [[employeeExpData alloc] init];
                                        if (![[[Record objectAtIndex:count] valueForKey:@"ExpenseAmount"] isKindOfClass:[NSNull class]])
                                        {
                                            expData.TotalExpenses = [[[Record objectAtIndex:count] valueForKey:@"ExpenseAmount"] doubleValue];
                                        }
                                        if (![[[Record objectAtIndex:count] valueForKey:@"ExpenseAllowed"] isKindOfClass:[NSNull class]])
                                        {
                                            expData.ExpenseLimit = [[Record objectAtIndex:count] valueForKey:@"ExpenseAllowed"];
                                        }
                                        if (![[[Record objectAtIndex:count] valueForKey:@"SummarizedPeriod"] isKindOfClass:[NSNull class]])
                                        {
                                            // Assigning summarized period to Employee Name
                                            expData.EmployeeName = [[Record objectAtIndex:count] valueForKey:@"SummarizedPeriod"];
                                        }
                                        [empExpDataObj.employeeExpenseArray addObject:expData];
                                        [expData release];
                                    }
                                }
                                else
                                {
                                    employeeExpData *expData = [[employeeExpData alloc] init];
                                    if (![[Record  valueForKey:@"ExpenseAmount"] isKindOfClass:[NSNull class]])
                                    {
                                        expData.TotalExpenses = [[Record  valueForKey:@"ExpenseAmount"] doubleValue];
                                    }
                                    if (![[Record valueForKey:@"ExpenseAllowed"] isKindOfClass:[NSNull class]])
                                    {
                                        double expenseAllowed = [[Record valueForKey:@"ExpenseAllowed"] doubleValue];
                                        expData.Diff_Limit_Expense = expData.TotalExpenses - expenseAllowed;
                                    }
                                    if (![[Record valueForKey:@"SummarizedPeriod"] isKindOfClass:[NSNull class]])
                                    {
                                        expData.EmployeeName = [Record valueForKey:@"SummarizedPeriod"];
                                    }
                                    [empExpDataObj.employeeExpenseArray addObject:expData];
                                    [expData release];
                                }

                            }
                        }

                    }
                }
                if ([self.Datadelegate conformsToProtocol:@protocol(DataParsingDelegate)])
                {
                    if ([self.Datadelegate respondsToSelector:@selector(getResponce:)])
                    {
                        [self.Datadelegate getResponce:empExpDataObj];
                    }
                }
            }
            
        }
            break;
        
        default:
            break;
    }
}/**/

@end
