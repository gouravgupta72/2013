//
//  expenseAnalyisCell.h
//  CoreMoney


#import <UIKit/UIKit.h>

@interface expenseAnalyisCell : UITableViewCell
{
    UILabel *lblEmployeeName, *lblEmployeeId, *lblExpenseAmount, *lblBudgetAmout, *lblCategory, *lblCategoryAmount, *lblCategory1, *lblCategory2, *lblCategory3, *lblCategoryAmount1, *lblCategoryAmount2, *lblCategoryAmonut3, *lblSummarizedPeriod, *lblSummrizedAmount;
    UIImageView *imgBudget;
    
    UIView *subCategoryView;
    UIView *bgView;
}

@property (nonatomic,retain) UILabel *lblEmployeeName, *lblEmployeeId, *lblExpenseAmount, *lblBudgetAmout, *lblCategory, *lblCategoryAmount, *lblCategory1, *lblCategory2, *lblCategory3, *lblCategoryAmount1, *lblCategoryAmount2, *lblCategoryAmonut3, *lblSummarizedPeriod, *lblSummrizedAmount;
@property (nonatomic,retain)UIView *bgView;
@property (nonatomic,retain) UIImageView *imgBudget;
@property (nonatomic,retain) UIView *subCategoryView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier analysisType:(int)analysis;
@end
