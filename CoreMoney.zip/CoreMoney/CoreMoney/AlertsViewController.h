//
//  AlertsViewController.h
//  CoreMoney
//
//Class used for showing alerts

#import <UIKit/UIKit.h>
#import "DataParsingClass.h"

@interface AlertsViewController : SwipeViewController<DataParsingDelegate>
{
    NSMutableArray *arrAlertCountData, *arrTemp;
    Alert_Type alertTag;
    int alertColor;
}
@property int alertColor;
@property (nonatomic,retain)NSMutableArray *arrAlertCountData;
@property (retain, nonatomic) IBOutlet UITableView *listTableView;
@property (retain, nonatomic) IBOutlet UIView *backView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil Array:(NSMutableArray *) dataArr colorGroup:(int)Color;
@end
