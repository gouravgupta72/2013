//
//  ExpenseRulesViewController.h
//  CoreMoney
// Class is used for displaying the expense rules .

#import <UIKit/UIKit.h>
#import "CardDetailClass.h"
#import "MerchantCategoryClass.h"
//#import "MerchantView.h"
#import "CustomScrollView.h"
#import "ExpenseRulesdata.h"
#import "DataParsingClass.h"
#import "PopUpView.h"
@interface ExpenseRulesViewController : SwipeViewController<UITextFieldDelegate,ScrollDelegate,DataParsingDelegate>
{
    CardDetailClass *cardDataObj;
    UIScrollView *merchantListScrollView;
    MerchantCategoryClass *objMerchantCategory;
    NSMutableArray *arrMerchantCategoryData;
    UITableView *merchantTableView;
    ExpenseRulesdata *expenseRulesData;
    UIButton *doneButton;
    BOOL switchOnOffValues,checkByPassMonetaryAndBudget;//new bool variable added for checking swich of bypass view
    int selectedSwitchNo;
    int request_Id;
    UIView *comboView;
    NSMutableArray *limitArray;
    NSMutableArray *arrSecretQuestion;
    int selectedIndex;
    
    int requestType;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil CardData:(ExpenseRulesdata *) carddata;

@property (retain, nonatomic) IBOutlet UISwitch *switch_IntUse;
@property (retain, nonatomic) IBOutlet UISwitch *switch_BypMonetoryLimit;
@property (nonatomic, retain) UIButton *doneButton;
@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (retain, nonatomic) IBOutlet UISwitch *switch_BypBussBudgLmt;
@property (nonatomic,retain) ExpenseRulesdata *expenseRulesData;
@property (retain, nonatomic) IBOutlet UIView *internationalView;
@property (retain, nonatomic) IBOutlet UIView *allowanceView;
@property (retain, nonatomic) IBOutlet UIView *transactionView;
@property (retain, nonatomic) IBOutlet UIView *merchantView;


@property (retain, nonatomic) IBOutlet UILabel *lblName;
@property (retain, nonatomic) IBOutlet UILabel *lblCardNumber;
@property (retain, nonatomic) IBOutlet UILabel *lblCardStatus;
@property (retain, nonatomic) IBOutlet UILabel *lblAmount;

@property (retain, nonatomic) CardDetailClass *cardDataObj;

@property (retain, nonatomic) IBOutlet UIView *internationUseView;
@property (retain, nonatomic) IBOutlet UIView *dailyMonthlyView;
@property (retain, nonatomic) IBOutlet UIView *singleTransactionLimitView;
@property (retain, nonatomic) IBOutlet UIView *MerchantCategoryView;

@property (retain, nonatomic) IBOutlet CustomScrollView *expenseScrollView;

@property (retain, nonatomic) IBOutlet UILabel *lblExpenseTitle;
@property (retain, nonatomic) IBOutlet UIView *bottomView;

@property (retain, nonatomic) IBOutlet UIView *byPassView;
@property (retain, nonatomic) IBOutlet UITextField *txtDailyAllowanceLimit;

@property (retain, nonatomic) IBOutlet UITextField *txtMonthlyAllowanceLimit;
@property (retain, nonatomic) IBOutlet UITextField *txtSingleTransactionAmount;
@property (nonatomic, retain) NSString *strDayName;

@property (retain, nonatomic) IBOutlet UILabel *lblByPassCardMonetaryLimitItem;
@property (retain, nonatomic) IBOutlet UILabel *lblByPassBussBudgetLimitItem;

- (IBAction)singleLoadLimitAction:(id)sender;
- (IBAction)dailyMonthlySpendLimitAction:(id)sender;
- (IBAction)merchantCategoryAction:(id)sender;

@property (retain, nonatomic) IBOutlet UIButton *btnOutSideTouchBtn;

@end
