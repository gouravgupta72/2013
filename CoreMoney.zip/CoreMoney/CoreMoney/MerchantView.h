//
//  MerchantView.h
//  CoreMoney

#import <UIKit/UIKit.h>
#import "MerchantCategoryClass.h"

@protocol MerchantViewdlegate <NSObject>
@required
-(void)settingScrollPosition :(int)tag;
-(void)getTextValue :(NSString *)value Tag:(int)tagValue;
-(void)submitData;

@end

@interface MerchantView : UIView<UITextFieldDelegate>
{
    id<MerchantViewdlegate>delegate;
    UILabel *titleName,*subTitleName,*DailyLimit,*MonthlyLimit;
    UIButton *btnSwitch;
    UITextField *txtDailyLimit,*txtMonthlyLimit;
    
}
@property (nonatomic, retain) UILabel *titleName,*subTitleName,*DailyLimit,*MonthlyLimit;
@property (nonatomic, retain) UIButton *btnSwitch;
@property (nonatomic, assign) id<MerchantViewdlegate>delegate;
@property (nonatomic, retain) UITextField *txtDailyLimit,*txtMonthlyLimit;

- (id)initWithMerchantViewFrame:(CGRect)frame MerchantObject:(MerchantCategoryClass *)merchantCategoryObj Delegate:(id)del viewTag:(int)vTag;
@end
