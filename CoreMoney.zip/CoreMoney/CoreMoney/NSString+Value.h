//
//  NSString+Value.h
//  CoreMoney
// Class for overWrite nsstring class.
#import <Foundation/Foundation.h>

@interface NSString (Value)
+(id)ValueForDictionary:(NSDictionary *)dic;
@end