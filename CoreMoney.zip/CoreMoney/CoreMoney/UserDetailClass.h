//
//  UserDetailClass.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface UserDetailClass : NSObject
{
    NSString *strUserId,*StrPassword, *UserName, *LastName, *LAST_ACCESSED_AT;
}
@property (nonatomic,retain) NSString *strUserId,*StrPassword, *UserName, *LastName, *LAST_ACCESSED_AT;

+(UserDetailClass *)sharedUser;
@end
