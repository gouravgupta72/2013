//
//  alertGroupViewController.m
//  CoreMoney


#import "alertGroupViewController.h"
#import "AlertViewCell.h"
#import "alertGroupCount.h"
#import "AlertsViewController.h"
@interface alertGroupViewController ()
-(void)openBack;
-(void)openSlide;
-(void)fillAlertData;
@end

@implementation alertGroupViewController
@synthesize arrAlertCountData;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil Array:(NSMutableArray *) dataArr
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        addNavigationBar(ADMIN_ALERT_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);

       self.arrAlertCountData = [[NSMutableArray alloc] initWithArray:dataArr];
    }
    [self fillAlertData];

    return self;
}

// method use for send to previus view
-(void)openBack
{
    [self.navigationController popViewControllerAnimated:YES];
}
// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

-(void)storeLocationAdded:(NSNotification *)sender
{
    NSMutableArray *objStoreData = [sender object];
    [self.arrAlertCountData removeAllObjects];
    self.arrAlertCountData=objStoreData;
    [self fillAlertData];
//    self.arrAlertCountData=objStoreData;

    [self.tblAlertGroup reloadData];
    //
//    [self initlaizeAlerArr];
//    
//    [self.listTableView reloadData];
}

- (void)viewDidLoad
{
    [AppDelegate sharedAppDelegate].classType = ADMIN_ALERTS_PAGE ;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector (storeLocationAdded:) name:@"WineDetailsStoreLocationFirst" object:nil];
    self.backView.frame = CGRectMake(0,IS_IPAD?30:0, self.backView.frame.size.width,IS_IPAD?self.backView.frame.size.height-30:self.backView.frame.size.height);
        [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"WineDetailsStoreLocationFirst" object:nil];
    
    [_tblAlertGroup release];
    //memory release for arrAlertCountData
    [self.arrAlertCountData release];
    [alertGroupData release];
    [_backView release];
        [super dealloc];
}
- (void)viewDidUnload {
    [self setTblAlertGroup:nil];
    [self setBackView:nil];
    [super viewDidUnload];
}


-(void)fillAlertData
{
    if (!alertGroupData)
    {
        alertGroupData=[[NSMutableArray alloc]init];
    }
    else
    {
        [alertGroupData removeAllObjects];
    }
    
    int redAlertCount=0,greenAlertCount=0,amberAlertCount=0;
    
    for (int i=0; i<[self.arrAlertCountData count]; i++)
    {
        AlertCountSearchClass *alertCountObj=[self.arrAlertCountData objectAtIndex:i];
        switch (alertCountObj.alertTypeNo)
        {
            case Card_Pending_Activation_Alert:
                redAlertCount=redAlertCount+[alertCountObj.strCount intValue];
                break;
            case Auto_Funding_Faild_Alert:
                redAlertCount=redAlertCount+[alertCountObj.strCount intValue];
                break;
            case Card_Transaction_Decline_Alert:
                redAlertCount=redAlertCount+[alertCountObj.strCount intValue];
                break;
            case Auto_Funding_Faild_Admin:
                redAlertCount=redAlertCount+[alertCountObj.strCount intValue];
                break;
            case Business_Policy_Changed:
                redAlertCount=redAlertCount+[alertCountObj.strCount intValue];
                break;
            case enumFraudAlert://Fradu_Alert_Alert:
                redAlertCount=redAlertCount+[alertCountObj.strCount intValue];
                break;
            case Low_Balance_Cards_Alert:
                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
                break;
            case Card_Spend_Rules_Changed_Alert:
                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
                break;
            case Funding_Rules_Changed_Alert:
                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
                break;
            case New_card_issued_Alert:
                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
                break;
            case High_value_transaction_Alert:
                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
                break;
//            case Business_Profile_Update:
//                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
//                break;
            case Card_Profile_Updated:
                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
                break;
            case Bulk_Card_Request:
                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
                break;
            case Low_Balance_on_Business:
                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
                break;
            case Card_Frequency_Alert:
                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
            case International_Card_Transactions:
                amberAlertCount=amberAlertCount+[alertCountObj.strCount intValue];
                break;
                break;
            default:
                break;
        }
    }
    
    alertGroupCount *alertCountObj;
    
    alertCountObj=[[alertGroupCount alloc]init];
    alertCountObj.alertColorName=@"Red";
    alertCountObj.alertTag=RedAlert;
    alertCountObj.alertCount=redAlertCount;
    [alertGroupData addObject:alertCountObj];
    [alertCountObj release];
   
    
    alertCountObj=[[alertGroupCount alloc]init];
    alertCountObj.alertColorName=@"Amber";
    alertCountObj.alertTag=AmberAlert;
    alertCountObj.alertCount=amberAlertCount;
    [alertGroupData addObject:alertCountObj];
    [alertCountObj release];
    
    alertCountObj=[[alertGroupCount alloc]init];
    alertCountObj.alertColorName=@"Green";
    alertCountObj.alertTag=GreenAlert;
    alertCountObj.alertCount=greenAlertCount;
    [alertGroupData addObject:alertCountObj];
    [alertCountObj release];
    
}

#pragma mark- Table View Delegates
// Delegate method to set the number of sections in table.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
// Delegate method to set the height of the cell.
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 60;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [alertGroupData count] - 1;/* Temporary removing Green Alert */
}

// Delegate method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"Cell";
    
	AlertViewCell *cell = (AlertViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[[AlertViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
    alertGroupCount *alertCountObj=[alertGroupData objectAtIndex:indexPath.row];
    
    if (alertCountObj.alertTag==RedAlert)
    {
        cell.imgView.image=[UIImage imageNamed:@"red_Alert_BG"];
    }else if (alertCountObj.alertTag==AmberAlert)
    {
        cell.imgView.image=[UIImage imageNamed:@"amber_alert_BG"];
    }else if (alertCountObj.alertTag==GreenAlert)
    {
        cell.imgView.image=[UIImage imageNamed:@"greenAlert_BG"];
    }

    cell.lblAlertName.text = alertCountObj.alertColorName;
   // added 10 pixel to  Red, amber and green label origin x
    cell.lblAlertName.frame=CGRectMake(25, cell.lblAlertName.frame.origin.y,cell.lblAlertName.frame.size.width , cell.lblAlertName.frame.size.height);
    
    cell.lblAlertCount.text = @" ";
    
    if (alertCountObj.alertCount == 0)
    {
        cell.lblAlertCount.text = @" ";
    }
    else
    {
        cell.lblAlertCount.text = [NSString stringWithFormat:@"(%d)",alertCountObj.alertCount];
    }
    cell.tag = alertCountObj.alertTag;
    
    return cell;
}
// Delegate method called when the row selects.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    alertGroupCount *alertCountObj=[alertGroupData objectAtIndex:indexPath.row];
    
    if (alertCountObj.alertTag==GreenAlert)
    {
        showAlertScreen(nil, @"No record found.");
    }else
    {
        AlertsViewController *avc = [[AlertsViewController alloc] initWithNibName:@"AlertsViewController" bundle:nil Array:self.arrAlertCountData colorGroup:alertCountObj.alertTag];
        [self.navigationController pushViewController:avc animated:YES];
        [avc release];

    }
}
@end
