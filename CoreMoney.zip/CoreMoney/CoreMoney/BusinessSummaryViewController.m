//
//  BusinessSummaryViewController.m


// Class for handling Business Summary 
#import "BusinessSummaryViewController.h"
@interface BusinessSummaryViewController ()
-(void)openSlide;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(void) changeContain;
-(void)openBack;
-(void)AddViewOnScroll;

-(void)PutDataToView :(int)index;
-(void)btnNextClickEvent;
-(void)addApprovalAlert;
-(void)addBudgetReachedAlert;
-(void)AddLowBalnaceAlert;

@end

@implementation BusinessSummaryViewController
@synthesize pageNumber;




// Open/Close slider menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO) {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else{
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}


// Initialize view
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        addNavigationBar(BUSINESS_SUMMARY_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        
        [self.navigationItem setHidesBackButton:NO animated:NO];        
    }
    return self;
}

// change data in select language
-(void) changeContain{
    
    self.lblTxtAvlCardBal.text = languageSelectedStringForKey(@"Available card balance");
    self.lblTxtBalane.text = languageSelectedStringForKey(@"Balance");
    self.lblTxtMTDCard.text=languageSelectedStringForKey(@"MTD card Spend");
    self.lblTxtPendCrdtTransfer.text=languageSelectedStringForKey(@"Pending credit transfer");
    
    self.lblTxtTotalAvlFund.text=languageSelectedStringForKey(@"Total available fund");
    self.lblTxtUnusedBudget.text=languageSelectedStringForKey(@"Unused budget");
    
    
    self.lblAvailBalanceDetail.text = [NSString stringWithFormat:@"( %@ )",languageSelectedStringForKey(@"Available card balance")];
    self.lblBalanceDetail.text = [NSString stringWithFormat:@"( %@ )",languageSelectedStringForKey(@"Funds in the business account")];
    self.lblMtdDetail.text= [NSString stringWithFormat:@"( %@ )",languageSelectedStringForKey(@"Total card expenses since beginning of month")];
    self.lblPendingTransferDetail.text= [NSString stringWithFormat:@"( %@ )",languageSelectedStringForKey(@"From external bank to CoreMONEY account")];
    self.lblTotalAvailFundDetail.text= [NSString stringWithFormat:@"( %@ )",languageSelectedStringForKey(@"In business account & all cards")];
    self.lblUnusedDetail.text= [NSString stringWithFormat:@"( %@ )",languageSelectedStringForKey(@"Monthly business budget – all card expenses")];
}

// Navigate to previous view
-(void)openBack
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat pageWidth =self.UserDetailScroll.frame.size.width;
    int page = floor((self.UserDetailScroll.contentOffset.x - pageWidth / 3) / pageWidth) + 1;
    
    [AppDelegate sharedAppDelegate].HomePageIndexNo=page;
    
    if (page<[[AppDelegate sharedAppDelegate].arrBusinessData count])
    {
        [[AppDelegate sharedAppDelegate] addloadingView];
        [self PutDataToView:page];
    }
    if (page==0) {
        self.leftView.hidden=YES;
        self.rightview.hidden=YES;
    }
    else if (page == [[AppDelegate sharedAppDelegate].arrBusinessData count]-1)
    {
        self.leftView.hidden=YES;
        self.rightview.hidden=YES;
    }
    else{
        self.leftView.hidden=YES;
        self.rightview.hidden=YES;
    }

}

-(void)AddViewOnScroll
{
    int xpos=0;
        UserDetailView=[[BusinessSummaryScrollView alloc]initWithUserDetailFrame:CGRectMake(xpos, 0, 320, 71)];
        [self.UserDetailScroll addSubview:UserDetailView];
        [UserDetailView release];
        
        BusinessPageDetail *obj=[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:self.pageNumber];
    
        UserDetailView.lblBusinessName.text=[NSString stringWithFormat:@"%@",checkISNullStrings(obj.Business_ID_Desc)?@"":[NSString stringWithFormat:@"%@ ",obj.Business_ID_Desc]];
        
    xpos=CGRectGetMaxX(UserDetailView.frame);
        
    [self.UserDetailScroll setContentSize:CGSizeMake(0, 0)];
    [self.UserDetailScroll setContentOffset:CGPointMake(0, 0)];
    [self PutDataToView:self.pageNumber];
    
    self.leftView.hidden=YES;
    self.rightview.hidden=YES;
    
//    if (self.pageNumber==0)
//    {
//        self.leftView.hidden=YES;
//    }
//    if ([[AppDelegate sharedAppDelegate].arrBusinessData count]==1) {
//        self.leftView.hidden=YES;
//        self.rightview.hidden=YES;
//    }
}


// Fill data into Summary view
-(void)PutDataToView :(int)index
{
    BusinessPageDetail *obj=[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:index];
    
    self.lblBalance.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(obj.BusinessCurrentBalance))];
    
    self.lblPendingTransfer.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(obj.BusinessTotalPendingCreditTransactions )) ];
    
    self.lblAvailCardBlnc.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(obj.BusinessTotalAvailableCardBalance ) )];
    
    self.lblMTDcard.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(obj.BusinessMTDCardSpend )) ];
    
    self.lblTotalAvailfund.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(obj.BusinessTotalAvailableFunds) ) ];
    
    self.lblUnUsed.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(obj.UnusedBudget )) ];
    
    [[AppDelegate sharedAppDelegate] removeLoadingView];
}


// Alert Click Event
-(void)btnNextClickEvent
{
    
}


// Add Alert of Approval pending
-(void)addApprovalAlert
{
    _scrolLBGVIEW.frame=CGRectMake(0, CGRectGetMaxY(_myBusinessView.frame), 320,(IS_IPHONE_5?438-40:438-40));
    _scrollBusiness.frame=CGRectMake(0, 0, 320,(IS_IPAD?430:435));
    alertObj=[[BusinessAlertView alloc]initWithAlertFrame:CGRectMake(5, (IS_DEVICE_IPAD?450:430)-40, 310, 40) delegate:self Title:languageSelectedStringForKey(ALERT_APPROVAL)];
    alertObj.btnNext.hidden=NO;
    alertObj.btnClick.enabled=YES;
    [self.view addSubview:alertObj];
    [alertObj release];
    AlertCount++;
}

 
// Add Alert of Budget reached limit

-(void)addBudgetReachedAlert
{
    _scrolLBGVIEW.frame=CGRectMake(0, CGRectGetMaxY(_myBusinessView.frame), 320,(IS_IPHONE_5?438:438));
    _scrollBusiness.frame=CGRectMake(0, 0, 320,(IS_IPAD?440:440));
    alertObj=[[BusinessAlertView alloc]initWithAlertFrame:CGRectMake(5, (IS_DEVICE_IPAD?450:430)-40, 310, 40) delegate:self Title:languageSelectedStringForKey(ALERT_BUDGET_REACHED)];
    [self.view addSubview:alertObj];
    [alertObj release];
    AlertCount++;
}

// Add Alert of Low Balance
-(void)AddLowBalnaceAlert
{
    _scrolLBGVIEW.frame=CGRectMake(0, CGRectGetMaxY(_myBusinessView.frame), 320,(IS_IPAD?438:438));
    _scrollBusiness.frame=CGRectMake(0, 0, 320,(IS_IPAD?440:440));
    alertObj=[[BusinessAlertView alloc]initWithAlertFrame:CGRectMake(5, (IS_DEVICE_IPAD?450:430)-40, 310, 40) delegate:self Title:languageSelectedStringForKey(ALERT_LOW_BALANCE)];
    [self.view addSubview:alertObj];
    [alertObj release];
    AlertCount++;
}


-(void)viewWillAppear:(BOOL)animated
{
     [AppDelegate sharedAppDelegate].classType=BUSINESS_SUMMARY_PAGE;
    [super viewWillAppear:animated];
}


- (void)viewDidLoad
{
    AlertCount=0;
    
    [AppDelegate sharedAppDelegate].classType=BUSINESS_SUMMARY_PAGE;
    self.navigationController.navigationBarHidden=NO;
    self.bgView.frame = CGRectMake(0, IS_IPAD?20:0, 320, 480);
    
    _myBusinessView.frame=CGRectMake(0,(IS_IOS7?(IS_IPAD?0:60):0), [AppDelegate sharedAppDelegate].screenWidth,71);
    
    _scrolLBGVIEW.frame=CGRectMake(0,(IS_IOS7?(IS_IPAD?CGRectGetMaxY(_myBusinessView.frame):CGRectGetMaxY(_myBusinessView.frame)-60):CGRectGetMaxY(_myBusinessView.frame)), 320,(IS_IPHONE_5?438:438));
    _scrollBusiness.contentSize=CGSizeMake(0,IS_IPAD?550:(IS_IPHONE_5?500:500) );
    _scrollBusiness.layer.masksToBounds=YES;
    _scrolLBGVIEW.layer.masksToBounds=YES;
    
    self.pageNumber=[AppDelegate sharedAppDelegate].HomePageIndexNo;
    
    [self changeContain];
    [self AddViewOnScroll];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_lblBalance release];
    [_lblTotalAvailfund release];
    [_lblUnUsed release];
    [_lblPendingTransfer release];
    [_lblAvailCardBlnc release];
    [_lblMTDcard release];
    [_lblTxtBalane release];
    [_lblTxtTotalAvlFund release];
    [_lblTxtUnusedBudget release];
    [_lblTxtPendCrdtTransfer release];
    [_lblTxtAvlCardBal release];
    [_lblTxtMTDCard release];
    [_myBusinessView release];
    [_scrollBusiness release];
    [_scrolLBGVIEW release];
    [_lblBalanceDetail release];
    [_lblTotalAvailFundDetail release];
    [_lblUnusedDetail release];
    [_lblPendingTransferDetail release];
    [_lblAvailBalanceDetail release];
    [_lblMtdDetail release];
//    [_UserDetailScroll release];
//    [_leftView release];
//    [_rightview release];
//    [_bgView release];
    [super dealloc];
}

- (void)viewDidUnload
{
    [self setLblBalance:nil];
    [self setLblTotalAvailfund:nil];
    [self setLblUnUsed:nil];
    [self setLblPendingTransfer:nil];
    [self setLblAvailCardBlnc:nil];
    [self setLblMTDcard:nil];
    [self setLblTxtBalane:nil];
    [self setLblTxtTotalAvlFund:nil];
    [self setLblTxtUnusedBudget:nil];
    [self setLblTxtPendCrdtTransfer:nil];
    [self setLblTxtAvlCardBal:nil];
    [self setLblTxtMTDCard:nil];
    [self setMyBusinessView:nil];
    [self setScrollBusiness:nil];
    [self setScrolLBGVIEW:nil];
    [self setLblBalanceDetail:nil];
    [self setLblTotalAvailFundDetail:nil];
    [self setLblUnusedDetail:nil];
    [self setLblPendingTransferDetail:nil];
    [self setLblAvailBalanceDetail:nil];
    [self setLblMtdDetail:nil];
    [self setUserDetailScroll:nil];
    [self setLeftView:nil];
    [self setRightview:nil];
    
    alertObj=nil;
    Dataobj=nil;
    
    [self setBgView:nil];
    [super viewDidUnload];
}
@end
