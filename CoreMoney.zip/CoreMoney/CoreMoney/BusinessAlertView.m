//
//  BusinessAlertView.m


// Class to show alert on business Summary view
#import "BusinessAlertView.h"

@implementation BusinessAlertView
@synthesize btnNext,btnClick;

// Design Alert view
- (id)initWithAlertFrame:(CGRect)frame delegate:(id)del Title:(NSString *)title
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_B_Summary_white_bg"]];
        self.layer.masksToBounds=YES;
        self.layer.borderColor=[UIColor colorWithRed:3.0/255.0 green:45.0/255.0 blue:85.0/255.0 alpha:1.0].CGColor;
        self.layer.cornerRadius=5.0f;
        self.layer.borderWidth=1.0f;
    
        
        UIImageView *imgAlertIcon=[[UIImageView alloc]initWithFrame:CGRectMake(7, 5, 30, 30)];
        imgAlertIcon.backgroundColor=[UIColor clearColor];
        imgAlertIcon.image=[UIImage imageNamed:@"alert_icon"];
        [self addSubview: imgAlertIcon];
        [imgAlertIcon release];
        
        
        UILabel *lblTitle=[[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(imgAlertIcon.frame)+5, 0, frame.size.width-50, frame.size.height)];
        lblTitle.backgroundColor=[UIColor clearColor];
        lblTitle.text=title;
        lblTitle.font=FONT_ARIAL_12;
        lblTitle.textAlignment=NSTextAlignmentLeft;
        lblTitle.textColor=[UIColor darkGrayColor];
        
        [self addSubview:lblTitle];
        [lblTitle release];
        
        
        btnNext=[[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lblTitle.frame)+5, 10, 20, 20)];
        btnNext.backgroundColor=[UIColor clearColor];
        btnNext.hidden=YES;
        [btnNext setImage:[UIImage imageNamed:@"img_arrow_home"] forState:UIControlStateNormal];
        [btnNext addTarget:del action:@selector(btnNextClickEvent) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btnNext];
        [btnNext release];
        
        btnClick=[[UIButton alloc]initWithFrame:CGRectMake(0,0, frame.size.width, frame.size.height)];
        btnClick.backgroundColor=[UIColor clearColor];
        btnClick.enabled=NO;
        [btnClick addTarget:del action:@selector(btnNextClickEvent) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btnClick];
        [btnClick release];
        
    }
    return self;
}


@end
