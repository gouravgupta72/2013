//
//  BusinessAlertView.h



// Class to show alert on business Summary view

#import <UIKit/UIKit.h>

@interface BusinessAlertView : UIView
{
    UIButton *btnNext,*btnClick;
}
@property(nonatomic,retain)UIButton *btnNext,*btnClick;
- (id)initWithAlertFrame:(CGRect)frame delegate:(id)del Title:(NSString *)title;
@end
