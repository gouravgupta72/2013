//
//  ExpenseAnalysisViewController.h
//  CoreMoney
// class create for expense analysis menu view

#import <UIKit/UIKit.h>
#import "DataParsingClass.h"
#import "SwipeViewController.h"


@interface ExpenseAnalysisViewController : SwipeViewController <DataParsingDelegate>
{
    NSMutableArray *cellArray,*dataArray, *empArray, *businessListArray, *categoryArray;
    int selectedExpense;
    int RequestId;
    
}
@property (retain, nonatomic) IBOutlet UIView *bgView;

@end
