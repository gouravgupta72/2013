//
//  MerchantCategoryClass.h
//  CoreMoney

#import <Foundation/Foundation.h>

@interface MerchantCategoryClass : NSObject
{
    NSString *strTitle,*strsubTitle;
    BOOL isEnabled;
    double dailyLimit,monthlyLimit;
    int tagValue;
    NSString *MerchantCategoryCodePlan,*Default_Selection,*SKey,*MCCDescription,*DefaultDescription,*SpendLimit_Auto,*SpendLimit_Auto_Month, *MCCPlanDescription;
    
}
@property (nonatomic, retain) NSString *strTitle,*strsubTitle;
@property (nonatomic, assign) BOOL isEnabled;
@property (nonatomic, assign) double dailyLimit,monthlyLimit;
@property (nonatomic, assign) int tagValue;
@property (nonatomic,retain) NSString *MerchantCategoryCodePlan,*Default_Selection,*SKey,*MCCDescription,*DefaultDescription,*SpendLimit_Auto,*SpendLimit_Auto_Month,  *MCCPlanDescription;
@end
