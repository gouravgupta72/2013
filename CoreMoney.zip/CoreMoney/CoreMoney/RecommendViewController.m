//
//  RecommendViewController.m
//  CoreMoney
// Class use for create recommend page 

#import "RecommendViewController.h"

@interface RecommendViewController ()

@end

@implementation RecommendViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        addNavigationBar(Recommend_title, NAV_LEFT_BACK, NAV_RIGHT_NONE, self);

    }
    return self;
}
-(void)openBack
{
    [self setOfset];
    [self.navigationController setNavigationBarHidden:YES];
    [self.navigationController popViewControllerAnimated:YES];
}
-(void) viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO];
//    NavigationBarStyle();
}

- (void)viewDidLoad
{
    
    self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, 320,IS_IOS7?410:480);
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_txtEnterEmailid release];
    [_pageScroll release];
    [_txtvMessag release];
    [_bgView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setTxtEnterEmailid:nil];
    [self setPageScroll:nil];
    [self setTxtvMessag:nil];
    [self setBgView:nil];
    [super viewDidUnload];
}
- (IBAction)sendRecommendMail:(id)sender {
    [self setOfset];
    if (validateEmailString(self.txtEnterEmailid.text)) {
        [self openMailComposer];
    }
    else
    {
        showAlertScreen(@"", @"Please enter valid email id");
    }
    
}
// Open Mail composer and set mail
-(void)openMailComposer
{
    
    
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    picker.mailComposeDelegate = self;
    
    // mobileWineDetail *obj=[wineDetailsArray objectAtIndex:0];
    
    NSString *subject = @"Expense Management With COREMONEY";
    [picker setSubject:subject];
    // picker.delegate = self;
    
    NSString *emailBody = [NSString stringWithFormat:@" </br> <br/> We have provided CoreMONEY Expense Card to our employees for controlling & managing business related expenses. I believe that your business can also benefit from this product. Please click on the link below for more information and signing up </br> <br/>www.corecard.com/PrepaidCards.html "];
        [picker setMessageBody:emailBody isHTML:YES];
    

    [picker setToRecipients:[NSArray arrayWithObject:self.txtEnterEmailid.text]];
    AppDelegate *appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    if(picker){
        [appDelegate.naviGationController.topViewController presentModalViewController:picker animated:YES];
    }
        [picker release];
}

// Mail composer result delegate
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    [self dismissModalViewControllerAnimated:YES];
   
}
-(void) setOfset
{
    self.txtvMessag.scrollEnabled = YES;
    [self.pageScroll setContentSize:CGSizeMake(320,356)];
    [self.txtEnterEmailid resignFirstResponder];
    [self.pageScroll setContentOffset:CGPointMake(0, 0) animated:YES];

}
#pragma -mark UITextField Method

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    //[self.pageScroll setContentSize:CGSizeMake(240,350)];
    if ([textField isEqual:self.txtEnterEmailid] )
	{
		[self setOfset];
        //  [self logIn];
                 
	}
	    
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if ([textField isEqual:self.txtEnterEmailid]) {
        self.txtvMessag.scrollEnabled = NO;
        [self.pageScroll setContentOffset:CGPointMake(0, self.txtEnterEmailid.frame.origin.y-40) animated:YES];
    }
        [self.pageScroll setContentSize:CGSizeMake(320,490)];
    
    return YES;
}

@end
