//
//  UserDetailClass.m
//  CoreMoney


#import "UserDetailClass.h"

@implementation UserDetailClass

@synthesize strUserId,StrPassword,UserName,LastName,LAST_ACCESSED_AT;

static UserDetailClass *UserDetail;

// Create Singlton Object.
+(UserDetailClass *)sharedUser
{
    if (!UserDetail)
    {
        UserDetail=[[UserDetailClass alloc]init];
    }
    return UserDetail;
}

// Initialize object.
-(id)init
{
    if (!UserDetail)
    {
        UserDetail=[super init];
    }
    return UserDetail;
}
@end
