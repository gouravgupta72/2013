//
//  AlertDetailSearchClass.m
//  CoreMoney
//

#import "AlertDetailSearchClass.h"

@implementation AlertDetailSearchClass
@synthesize  strBusinessName, strBAdminName,strBusinessBal,strBusinessAcount,strCardHolderName,strCardBal,strAcountNumber,strDateTime,strActivitReason,strstatus,strEmpId,strTransactinAmt,strCardNumb,strBusinessAcountID;
@synthesize AlertDate,AlertEndDate,ActionDate,AlertStatus,Cardcategory,CardSubCategory,CardNumber4Digit,AccountNumber,FirstName,Lastname,AvailableBal,EmployeeId,
BusinessName,FundingStatus,CardStatus,BusinessBal,BAdminFirstName,BAdminLastName,  SpendRuleUpdate,FundingRuleUpdate,UpdatedBY,UpdatedTime,TxnRecipentAmt,CardAccountNo,
RoutingNo,TxnCountNo,DeclineReason,FraudType;
@synthesize strAlertId,strCardNo, strNoOfTransactionPerDay, strProductId, UserId, strBankName, strBankAccountNo, strTxnCountry, CardNo;

-(void) dealloc
{
    strBusinessName = nil;
    strBAdminName = nil;
    strBusinessBal = nil;
    strBusinessAcount = nil;
    strCardHolderName = nil;
    strCardBal= nil;
    strAcountNumber = nil;
    strDateTime = nil;
    strActivitReason = nil;
    strstatus = nil;
    strEmpId = nil;
    strTransactinAmt = nil;
    strCardNumb = nil;
    AlertDate = nil;AlertEndDate = nil;ActionDate = nil;AlertStatus = nil;Cardcategory=nil;CardSubCategory= nil;CardNumber4Digit=nil;AccountNumber=nil;FirstName=nil;Lastname=nil;AvailableBal=nil;EmployeeId=nil;
    BusinessName=nil;FundingStatus=nil;CardStatus=nil;BusinessBal=nil;BAdminFirstName=nil;BAdminLastName=nil;  SpendRuleUpdate=nil;
    FundingRuleUpdate=nil;UpdatedBY=nil;UpdatedTime=nil;TxnRecipentAmt=nil;CardAccountNo=nil;
    RoutingNo = nil;TxnCountNo=nil;DeclineReason=nil;FraudType=nil;
    [super dealloc];
}

@end
