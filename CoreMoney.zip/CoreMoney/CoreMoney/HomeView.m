//
//  HomeView.m
//  CoreMoney
// Class to design the home page top view.

#import "HomeView.h"

@implementation HomeView
@synthesize lblBusinessName,lblLastLogin,lblUserName,lblAmount;

// Method to design the Home View.
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"img_balance_bg_home"]];

        lblBusinessName = createLabel(@"Prashant Bhushan", CGRectMake(12, 5, 180, 40));
        lblBusinessName.textColor=Name_color_Code;
        lblBusinessName.font=FONT_ARIAL_18;
        lblBusinessName.numberOfLines = 2;
        
        [self addSubview:lblBusinessName];
        [lblBusinessName release];
        
        UILabel *lblLastLoginTitle = createLabel(languageSelectedStringForKey(@"last login"), CGRectMake(CGRectGetMaxX(lblBusinessName.frame)+10, 5, 110, 20));
        lblLastLoginTitle.textColor=Card_no_colore_code;
        lblLastLoginTitle.font=FONT_ARIAL_13;
        lblLastLoginTitle.textAlignment=UITextAlignmentRight;
        [self addSubview:lblLastLoginTitle];
        [lblLastLoginTitle release];
        
        lblLastLogin = createLabel(@"26-Aug-13 06:23 PM", CGRectMake(32, CGRectGetMaxY(lblLastLoginTitle.frame), 280, 22));
        lblLastLogin.textColor=Card_no_colore_code;
        lblLastLogin.textAlignment=UITextAlignmentRight;
        lblLastLogin.font=FONT_ARIAL_13;
        [self addSubview:lblLastLogin];
        [lblLastLogin release];
        
        UILabel *lblUserNameTitle = createLabel(languageSelectedStringForKey(@"you're logged in as"), CGRectMake(12, CGRectGetMaxY(lblLastLogin.frame)+5, 211, 20));
        lblUserNameTitle.textColor=Card_no_colore_code;
        lblUserNameTitle.font=FONT_ARIAL_16;
        lblUserNameTitle.textAlignment=UITextAlignmentLeft;
        [self addSubview:lblUserNameTitle];
        [lblUserNameTitle release];
        
        lblUserName = createLabel(@"John Smith", CGRectMake(12, CGRectGetMidY(lblUserNameTitle.frame)+5, 120, 40));
        lblUserName.textColor=Name_color_Code; 
        lblUserName.font=[UIFont fontWithName:@"Arial" size:15.0f];
        lblUserName.textAlignment=UITextAlignmentLeft;
        lblUserName.numberOfLines = 2;
        [self addSubview:lblUserName];
        [lblUserName release];
        
        lblAmount = createLabel(@"Amount", CGRectMake(CGRectGetMaxX(lblUserName.frame)+5, CGRectGetMidY(lblUserNameTitle.frame)+5, 180, 20));
        lblAmount.textColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:1.0];
        lblAmount.font=[UIFont fontWithName:@"Arial" size:15.0f];
        lblAmount.textAlignment=UITextAlignmentRight;
        [self addSubview:lblAmount];
        [lblAmount release];
        
        // Initialization code
    }
    return self;
}
-(void)dealloc
{
    [super dealloc];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
