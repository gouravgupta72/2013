//
//  TransactionCell.m


#import "TransactionCell.h"

@implementation TransactionCell
@synthesize lblStatus,lblAmount,lblDate,lblMemo,lblMerchant,lblTxnType, imgOverLimit;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
        //UIImageView *bgImage =[[UIImageView alloc] initWithFrame:self.frame];
       // bgImage.image = [UIImage imageNamed:@"img_B_Summary_gRAY_bg.png"];
        //[self addSubview:bgImage];
        
        lblDate=createLable(CGRectMake(10, 5, 100, 17), [UIFont systemFontOfSize:15.0]);
        lblDate.textAlignment=NSTextAlignmentLeft;
        lblDate.textColor=Name_color_Code;
        [self addSubview:lblDate];
        [lblDate release];
        
        lblStatus=createLable(CGRectMake(CGRectGetMaxX(lblDate.frame)+10, 8, 45, 10), [UIFont systemFontOfSize:10.0]);
        lblStatus.textAlignment=NSTextAlignmentLeft;
        lblStatus.textColor=[UIColor colorWithRed:201.0/255.0 green:41.0/255.0 blue:41.0/255.0 alpha:1.0];
        [self addSubview:lblStatus];
        [lblStatus release];
        
        lblAmount=createLable(CGRectMake(CGRectGetMaxX(lblStatus.frame), 5, 150, 15), [UIFont systemFontOfSize:12.0]);
        lblAmount.textAlignment=NSTextAlignmentRight;
        lblAmount.textColor=[UIColor blackColor];
        [self addSubview:lblAmount];
        [lblAmount release];
        
        lblMerchant=createLable(CGRectMake(10, CGRectGetMaxY(lblDate.frame), 240, 10), [UIFont systemFontOfSize:10.0]);
        lblMerchant.textAlignment=NSTextAlignmentLeft;
        lblMerchant.textColor=Card_no_colore_code;
        [self addSubview:lblMerchant];
        [lblMerchant release];
        
        lblMemo=createLable(CGRectMake(10, CGRectGetMaxY(lblMerchant.frame), 145, 15), [UIFont systemFontOfSize:12.0]);
        lblMemo.textAlignment=NSTextAlignmentLeft;
        lblMemo.textColor=[UIColor blackColor];
        [self addSubview:lblMemo];
        [lblMemo release];
        
        imgOverLimit=[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lblAmount.frame)-20, CGRectGetMaxY(lblAmount.frame)+2, 10, 10)];
        imgOverLimit.image=[UIImage imageNamed:@"over_limit_flag"];
        [self addSubview:imgOverLimit];
        [imgOverLimit release];

        
        lblTxnType=createLable(CGRectMake(CGRectGetMaxX(lblMemo.frame)+5, CGRectGetMaxY(lblMerchant.frame), 150, 15), [UIFont systemFontOfSize:13.0]);
        lblTxnType.textAlignment=NSTextAlignmentRight;
        lblTxnType.textColor=Txn_Type_Color_code;
        [self addSubview:lblTxnType];
        [lblTxnType release];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
