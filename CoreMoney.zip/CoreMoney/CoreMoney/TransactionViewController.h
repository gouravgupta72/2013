//
//  TransactionViewController.h

//class is used for Transaction view

#import <UIKit/UIKit.h>
#import "DataParsingClass.h"
#import "CardDetailClass.h"

@interface TransactionViewController : SwipeViewController<DataParsingDelegate>
{
    
    NSString *fDate,*lDate, *strminAmount ,*strMaxAmount, *strDescription;
    
    UIView *DatePickerBGView;
    
    int LastIndex, selectedTrans;
    
    CardDetailClass *cardDataObj;
    
    BOOL IsSearch;
    BOOL isViewPop;
    int PageNumber,requestID, selectedIndex;
    NSString *strNavigatedFrom;
    NSMutableArray *expenseCategoryArray, *MemoArray, *transactionArray;
}
@property (nonatomic,retain)NSString *fDate,*lDate, *strminAmount ,*strMaxAmount, *strDescription, *strNavigatedFrom;
@property BOOL isAlertRequest;// check request from alert or cardlist
@property (nonatomic,retain) CardDetailClass *cardDataObj;
@property (retain, nonatomic) IBOutlet UIImageView *imgLogo;
@property (retain, nonatomic) IBOutlet UILabel *lblName;
@property (retain, nonatomic) IBOutlet UILabel *lblCardNumber;



@property (retain, nonatomic) IBOutlet UILabel *lblStatus;
@property (retain, nonatomic) IBOutlet UILabel *lblAmount;
@property (retain, nonatomic) IBOutlet UITableView *tblTransaction;
@property (retain, nonatomic) IBOutlet UIView *myTransactionView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil trasactionData:(NSMutableArray *)transctObj isAlertRequest:(BOOL)isalertreq;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil trasactionData:(NSMutableArray *)transctObj isAlertRequest:(BOOL)isalertreq objectOfCardDetailClass:(CardDetailClass *)objCardDetail navigatedFrom:(NSString *)strNavFrom;



-(void)UpdateDateSelection :(NSString *)fstDate :(NSString *)lstDate :(NSString*)min :(NSString *)max :(NSString*)desc;

@end
