//
//  PopUpClass.m

//
// Object Class for pop up view.

#import "PopUpClass.h"

@implementation PopUpClass
@synthesize strTitle,isSelected,StatusNo;

-(void)dealloc
{
    self.strTitle=nil;
    [super dealloc];
}
@end
