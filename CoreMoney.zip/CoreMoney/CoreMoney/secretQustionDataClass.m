//
//  secretQustionDataClass.m
//  CoreMoney


#import "secretQustionDataClass.h"

@implementation secretQustionDataClass
@synthesize secretQuestion,indexNo;
-(void)dealloc
{
    self.secretQuestion=nil;
    [super dealloc];
}
@end
