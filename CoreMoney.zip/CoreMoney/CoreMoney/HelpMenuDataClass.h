//
//  HelpMenuDataClass.h


// Class For hold data of Help Menu Design.

#import <Foundation/Foundation.h>

@interface HelpMenuDataClass : NSObject
{
    NSString *strimgName,*strTitle;
    int tag;
}
-(id)initwithHelpData :(NSString *)imgName :(NSString *)title :(int)tags;
@property(nonatomic,retain) NSString *strimgName,*strTitle;
@property int tag;
@end
