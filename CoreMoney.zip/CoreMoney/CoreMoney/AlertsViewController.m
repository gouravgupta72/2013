//
//  AlertsViewController.m
//  CoreMoney
//
//Class use for showing alerts

#import "AlertsViewController.h"
#import "AlertViewCell.h"
#import "AlertCountSearchClass.h"
#import "AlertsDetailViewController.h"

@interface AlertsViewController ()
//following methods added in interface
-(void)openBack;
-(void)openSlide;
-(void) initlaizeAlerArr;
-(void) getRequest;
-(void) getResponce:(id)jsonData;
@end

@implementation AlertsViewController
@synthesize  alertColor,arrAlertCountData;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil Array:(NSMutableArray *) dataArr colorGroup:(int)Color
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        addNavigationBar(ADMIN_ALERT_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        // Custom initialization
        alertColor = Color;
        self.arrAlertCountData = [[NSMutableArray alloc] initWithArray:dataArr];
    }
    return self;
}

- (void)viewDidLoad
{
    self.backView.frame = CGRectMake(0,IS_IPAD?30:0, self.backView.frame.size.width,IS_IPAD?self.backView.frame.size.height-30:self.backView.frame.size.height);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector (storeLocationAdded:) name:@"WineDetailsStoreLocation" object:nil];
    
     [self initlaizeAlerArr];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void) viewWillAppear:(BOOL)animated
{
    [AppDelegate sharedAppDelegate].classType = ADMIN_ALERTS_PAGE ;
    [self.listTableView reloadData];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"WineDetailsStoreLocation" object:nil];
    
    [self.arrAlertCountData release];
    [arrTemp release];
    [_backView release];
    [_listTableView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setBackView:nil];
    [self setListTableView:nil];
    [super viewDidUnload];
}
// method use for send to previus view
-(void)openBack
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"WineDetailsStoreLocationFirst" object:self.arrAlertCountData];
    
    [self.navigationController popViewControllerAnimated:YES];
}
// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}
// method use for initializ the alert name array
-(void) initlaizeAlerArr
{
    if (!arrTemp)
    {
        arrTemp = [[NSMutableArray alloc] init];
    }
    else
    {
        [arrTemp removeAllObjects];
    }
    for (int i=0; i<[self.arrAlertCountData count]; i++)
    {
        AlertCountSearchClass *alertCountObj=[self.arrAlertCountData objectAtIndex:i];
        if (alertCountObj.colorNo == alertColor)
        {
            [arrTemp addObject:alertCountObj];
        }
    }
}

-(void)storeLocationAdded:(NSNotification *)sender
{
    NSMutableArray *objStoreData = [sender object];
    [self.arrAlertCountData removeAllObjects];
    self.arrAlertCountData=objStoreData;
    
     [self initlaizeAlerArr];
    
    [self.listTableView reloadData];
}
// method use for send request
-(void) getRequest
{
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    
    DataReq.Datadelegate=self;
    
//    if (alertTag == Card_Pending_Activation_Alert) {
//        [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
//        [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
//        
//        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=&deBsAccountNumber=&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=%d&deBusinessName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,Pending_CARD,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBACardHolderList];
//
//    }
//    else
//    {
    
        [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
        [SystemConfiguration sharedSystemConfig].dbbServiceName=ALERT_DISPLAY_REQUEST;

        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deANAuserid=%@&deAlertType=%d&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,alertTag,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcSpendCardBAAlertDisplay];
//    }
    [DataReq release];
}

// method use for got responce from the server
-(void) getResponce:(id)jsonData
{
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    
    
    
    if ([jsonData isKindOfClass:[NSArray class]])
    {  
        if ([jsonData count]>0)
        {
        //new alertGroup parameter passed in alert detail view controller for identifing alert card
        AlertsDetailViewController *advc = [[AlertsDetailViewController alloc] initWithNibName:@"AlertsDetailViewController" bundle:nil alertType:alertTag array:jsonData alertGroup:alertColor];
        [self.navigationController pushViewController:advc animated:YES];
        [advc release];
                
            
        }
    }
    else
    {
        showAlertScreen(@"", @"No records found");
    }
}
#pragma mark- Table View Delegates
// Delegate method to set the number of sections in table.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
// Delegate method to set the height of the cell.
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 60;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [arrTemp count];
//    return alertColor == RedAlert?6:10;
}
// Delegate method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"Cell";
	AlertViewCell *cell = (AlertViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[AlertViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
     [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    AlertCountSearchClass *alertCountObj=nil;

    alertCountObj  = [arrTemp objectAtIndex:indexPath.row];
    if (alertCountObj!=nil)
    {
        cell.lblAlertName.text = languageSelectedStringForKey(alertCountObj.strAlertName);
        cell.tag = alertCountObj.alertTypeNo;

        if ([alertCountObj.strCount intValue] == 0)
        {
            cell.lblAlertCount.text = @" ";
        }
        else
        {
            cell.lblAlertCount.text = [NSString stringWithFormat:@"(%@)",alertCountObj.strCount];
        }
    }
    
    
    if (alertColor==RedAlert)
    {
        cell.imgView.image=[UIImage imageNamed:@"red_Alert_BG"];
    }else if (alertColor==AmberAlert)
    {
        cell.imgView.image=[UIImage imageNamed:@"amber_alert_BG"];
    }else if (alertColor==GreenAlert)
    {
        cell.imgView.image=[UIImage imageNamed:@"greenAlert_BG"];
    }
    
    return cell;
}
// Delegate method called when the row selects.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    [[AppDelegate sharedAppDelegate] addloadingView];
    AlertViewCell *cell = (AlertViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    alertTag = cell.tag;
    
    if ([self.arrAlertCountData count]>indexPath.row)
    {
        AlertCountSearchClass *alertCountObj = [arrTemp objectAtIndex:indexPath.row];
//        alertCountObj.strCount = @"";
        alertCountObj.isDataNull = YES;
        [self.arrAlertCountData replaceObjectAtIndex:indexPath.row withObject:alertCountObj];
    }
    
    [self getRequest];
}

@end
