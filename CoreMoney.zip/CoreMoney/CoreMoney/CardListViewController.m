//
//  CardListViewController.m


// Class for displaying the Card Lists.

#import "CardListViewController.h"
#import "CardDataCell.h"
#import "CardListDetailViewController.h"


@interface CardListViewController ()
-(void)openSlide;
-(void)openBack;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(void)changeCardStatus :(int)chagedStatus;
-(void)getCardList;
-(void)getResponce:(id)jsonData;
-(void)removeChangeStatusView;

-(void) removePopUpview;
-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index;
-(void)openStatusView:(int)index;


@end

@implementation CardListViewController

static int cardCellHeight = 70; // Set the height of the card cell.

@synthesize selectedIndex;

// Method to open the slide menu on button click.
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}
// Method called on back button pressed.
-(void)openBack
{
    [self requestBusinessData];
}
// Method to initialise the class with the nib/xib file.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=[NSString stringWithFormat:@"%@ (%d)",languageSelectedStringForKey(@"Cards"),[[AppDelegate sharedAppDelegate].arrCardDetailArray count]];
        addNavigationBar(self.title, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        
        // Custom initialization
    }
    return self;
}
// Method for the view to load.
- (void)viewDidLoad
{
    [AppDelegate sharedAppDelegate].classType = CARD_LIST_PAGE;
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _tblCardList.separatorColor=[UIColor clearColor];
}

// Method called for the view to appear.
-(void)viewWillAppear:(BOOL)animated
{
//    NavigationBarStyle();
    
    [AppDelegate sharedAppDelegate].classType=CARD_LIST_PAGE;
    
     BusinessPageObject=[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];


    _myCardListView.frame=CGRectMake(0,IS_IPAD?IS_IOS7?20:23:IS_IOS7?5:0, [AppDelegate sharedAppDelegate].screenWidth, (IS_IPAD?IS_IOS7?487:487:[AppDelegate sharedAppDelegate].screenHeight-[AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame.size.height+(IS_IOS7?(IS_IPAD?0:20):45)));

    [[AppDelegate sharedAppDelegate] removeLoadingView];
    [_tblCardList reloadData];
}

-(void)changeCardStatus :(int)chagedStatus
{
    [self removePopUpview];
    
    newCardStatus=chagedStatus;
    
    CardDetailClass *card = [[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:selectedIndex];
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    RequestId=ChangeCardStatus;
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    if (newCardStatus==ACTIVE_CARD && oldCardStatus== Pending_CARD )
    {
        RequestId=CARD_ACTIVE_STATUS;
        [SystemConfiguration sharedSystemConfig].dbbServiceName=CARD_ACTIVE_REQUEST;
        
        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deTCIVRPrimaryAccountNumber=%@&deTCIVRCardRegistrationFirstName=&deTCIVRCardRegistrationMiddleName=&deTCIVRCardRegistrationLastName=&deTCIVRCardRegistrationAddress1=&deTCIVRCardRegistrationAddress2=&deTCIVRCardActivationEmail1=&deTCIVRCardActivationHomePhone=&deTCIVRCardActivationWorkPhone=&deTCIVRCardActivationPostalCode=&deTCIVRCardActivationBirthDate=&deTCIVRCardActivationLangIndiactor=&deTCIVRCardActivationSocialSecurity=&deTCIVRCardActivationCardExpirDate=&deTCIVRCardActivationCurrentPin=&deTCIVRCardActivationCurrentAccess=&deTCIVRCardActivationNewPin=&deTCIVRCardActivationNewAccess=&deTCIVRCardActivationLast4DigitsSSN=&deTCIVRCardActivationCVV=&deTCIVRCardActivationBirthYear=&deTCIVRCardActivationIdentification=&deTCIVRANI=&deTCIVRDNS=&deTCIVRInputLang=&deIVRSource=%@&deIVRIpAddress=&deIVRCallerId=&deIVRCalledId=&deIVRRequestTime=&deIVRSessionID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[NSString stringWithFormat:@"%@",checkISNullStrings(card.CARDNUMBER)?@"":card.CARDNUMBER],[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCardActivationActivateCard];
        
    }else  if (newCardStatus==Inactive_Card || newCardStatus == BLOCKED_CARD || newCardStatus== Closed_CARD || newCardStatus==ACTIVE_CARD)
    {
        [SystemConfiguration sharedSystemConfig].dbbServiceName=Change_Card_Status_Update;
        
        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deTCIVRCLIENT_ID=%@&deTCIVRCLIENT_PASSWORD=&deTCIVRLOCATION_ID=&deTCIVRLOCATION_CITY=&deTCIVRLOCATION_STATE=&deTCIVRLOCATION_COUNTRY=&deTCIVREMPLOYEE_PIN=&deTCIVRPrimaryAccountNumber=%@&deTCIVRAccountNumber=%@&deTCIVRCARD_STATUS=%d&deTCIVRANI=&deTCIVRDNS=&deIVRSource=%@&deIVRIpAddress=&deIVRCallerId=&deIVRCalledId=&deIVRRequestTime=&deIVRSessionID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[NSString stringWithFormat:@"%@",checkISNullStrings(card.CLIENTID)?@"":card.CLIENTID],[NSString stringWithFormat:@"%@",checkISNullStrings(card.CARDNUMBER)?@"":card.CARDNUMBER],[NSString stringWithFormat:@"%@",checkISNullStrings(card.ADMIN_NUMBER)?@"":card.ADMIN_NUMBER], ChangeCardStatusForRequest(newCardStatus),[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcUpdateCardStatus_CardAccount];
        
        
    }else if(newCardStatus== Lost_CARD || newCardStatus == Stolen_CARD  )
    {
        RequestId=NEW_CARD_ORDER;
        
        [SystemConfiguration sharedSystemConfig].dbbServiceName=NEW_CARD_ORDER_Request;
        
        // In place of ORTOrderState_x = 40
        // We have place card.STATE value
        
        NSDate *today = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MM/dd/YYYY"];
        NSString *strDateToday = [dateFormatter stringFromDate:today];
//        self.txtFldName.text = [dateFormatter stringFromDate:today];
        
        
        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deORTDate_x=%@&deORTNumberOfCard_x=1&deORTAddressLine1_x=%@&deORTAddressLine2_x=%@&deORTCity_x=%@&deORTPOBox_x=%@&deORTCountry_x=%@&deORTStateorProvince_x=&deORTOrderState_x=%@&deORTClientId_x=%@&deORTUserId_x=%@&deORTProductID=&deORTNameLine1=%@&deORTNameLine2=%@&deORTInitialCardStatus=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[strDateToday stringByReplacingOccurrencesOfString:@"/" withString:@""],[NSString stringWithFormat:@"%@",checkISNullStrings(card.ADDRESS1)?@"":card.ADDRESS1],[NSString stringWithFormat:@"%@",checkISNullStrings(card.ADDRESSLINE2)?@"":card.ADDRESSLINE2],[NSString stringWithFormat:@"%@",checkISNullStrings(card.CITY)?@"":card.CITY],[NSString stringWithFormat:@"%@",checkISNullStrings(card.POSTALCODE)?@"":card.POSTALCODE],[NSString stringWithFormat:@"%@",checkISNullStrings(card.COUNTRY)?@"":card.COUNTRY],@"40",[NSString stringWithFormat:@"%@",checkISNullStrings(card.CLIENTID)?@"":card.CLIENTID],[UserDetailClass sharedUser].strUserId,[NSString stringWithFormat:@"%@",checkISNullStrings(card.FIRSTNAME)?@"":card.FIRSTNAME],[NSString stringWithFormat:@"%@",checkISNullStrings(card.LASTNAME)?@"":card.LASTNAME]] ServiceName:svcNewOrder];
        
    }    
    [DataReq release];
}


-(void)requestForChargeFee
{
    
    CardDetailClass *card = [[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:selectedIndex];
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    RequestId=Charge_FEE;
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Charge_Card_Fee_REq;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deFClientID=%@&deFCardNumber=%@&deFCardFeeFlag=0&deFCardFeeType=&deFGenCardFlag=&deFCardType=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,card.CLIENTID, card.CARDNUMBER] ServiceName:svcChargeCardFee];
    
    [DataReq release];
    
    
}

-(void)getAddressField
{
    
    CardDetailClass *card = [[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:selectedIndex];
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    RequestId=customer_detail;
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getCustomerAddress;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deTCIVRPrimaryAccountNumber=%@&deTCIVRAccountNumber=&deTCIVRANI=&deTCIVRDNS=&deIVRSource=%@&deIVRIpAddress=&deIVRRequestTime=&deIVRCallerId=&deIVRCalledId=&deIVRSessionID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,card.CARDNUMBER,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcGetCustomerAddress];
    
    [DataReq release];
}


-(void)requestForReplacementCard
{
    
    CardDetailClass *card = [[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:selectedIndex];
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    RequestId=Card_Replace;
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=REplaceCard_Request;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deCIAClientID=%@&deCIAPrimaryAccountNumber=%@&deCIAReason=%d&deCIADecisionFlag=1&deCIADeliveryMachanism=0&deCIACardFee=&deCIAOrderID=%@&deCIAInstancePersionalize=1&deCIACardNumber=&deShippingAddressCompanyName=&deShippingAddressContactName=&deCustomerAddrAddressLine1=%@&deCustomerAddrAddressLine2=%@&deCustomerAddrCity=%@&deCustomerAddrState=%@&deCustomerAddrCountry=%@&deCustomerAddrPostalCode=%@&deShippingAddressFlag=1&deCM_StudentIDCardNumber=&deIVRSource=%@&deIVRIpAddress=&deIVRRequestTime=&deIVRCallerId=&deIVRCalledId=&deIVRSessionID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,card.CLIENTID, card.CARDNUMBER ,(newCardStatus==Stolen_CARD?1:(newCardStatus==Lost_CARD?2:4)),card_Order_Obj.ORDER_ID,checkISNullStrings(userDetailObj.ADDRESS1)?@"":userDetailObj.ADDRESS1,checkISNullStrings(userDetailObj.ADDRESS2)?@"":userDetailObj.ADDRESS2,checkISNullStrings(userDetailObj.CITY)?@"":userDetailObj.CITY,checkISNullStrings(userDetailObj.StateCode)?@"":userDetailObj.StateCode,checkISNullStrings(userDetailObj.COUNTRY_CODE)?@"":userDetailObj.COUNTRY_CODE,checkISNullStrings(userDetailObj.POSTALCODE)?@"":userDetailObj.POSTALCODE,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcReplacementCard];
    
    [DataReq release];
    
    
}

-(void) requestBusinessData
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    RequestId=back_homeCardlist;
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;

    [SystemConfiguration sharedSystemConfig].dbbServiceName=Business_Search_Request;
    [SystemConfiguration sharedSystemConfig].deFlagShowDetails=@"1";
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPProductParent=&deBusinessName=&deCIASDDANumber=&deAADAccountNumber=&dePPCardStatus=&deCIASFirstName=&deCIASLastName=&deCIAAddressLine1=&deCIAAddressLine2=&deCIASCity=&deCIASState=&deCIASCountry=&deCIASZipCode=&deBSAcctId=&deFlagShowDetails=%@&deRequestBatchSize=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].deFlagShowDetails,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBusinessAccountSearch];
    
    [DataReq release];

}
-(void)requestForUpdateOrder
{
    
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    RequestId=Update_Order;
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    // In place of ORTOrderState_x = 40
    // We have to place card.STATE value

    [SystemConfiguration sharedSystemConfig].dbbServiceName=Update_CARD_ORder_Request;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deORTOrderId_x=%@&deORTAddressLine1_x=&deORTAddressLine2_x=&deORTCity_x=&deORTPOBox_x=&deORTCountry_x&deORTStateorProvince_x=&deORTOrderState_x=41&deORTReceivedDate_x=&deORTEmbossingDate_x=&deORTShippingDate_x=&deORTTrackingNumber_x=&deORTShippingCompany_x=&deORTNumberOfCard_x=&deORTNameLine1=&deORTNameLine2=&deORTInitialCardStatus=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,card_Order_Obj.ORDER_ID] ServiceName:svcUpdateOrder];
    
    [DataReq release];

    
}
#pragma mark - Request Work
// Method to send the request for the card list.
-(void)getCardList
{
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    RequestId=GetCardList;
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    

    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=%@&deBsAccountNumber=&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=&deBusinessName=%@",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.BusinessName,BusinessPageObject.Business_ID_Desc] ServiceName:svcBACardHolderList];

    [DataReq release];
    
}


-(void)getResponce:(id)jsonData
{
    switch (RequestId) {
        case GetCardList:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    [AppDelegate sharedAppDelegate].arrCardDetailArray=jsonData;
                }else
                {
                    showAlertScreen(@"No Records", @"There is no card Available for the Account.");
                }
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            _tblCardList.separatorColor=Card_no_colore_code;
            
            [_tblCardList reloadData];
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
        break;
        case ChangeCardStatus:
        {
            
            LoginResponceDataClass *dataObj=(LoginResponceDataClass *)jsonData;
            
            if (dataObj.Error_Found)
            {
                showAlertScreen(nil, dataObj.ErrorMsg);
            }else
            {
                CardDetailClass *card = [[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:selectedIndex];
                
                card.STATUS_CARDACCOUNT=newCardStatus;
                
                _tblCardList.separatorColor=[UIColor clearColor];
                showAlertScreen(nil, dataObj.ErrorMsg);
            }

//            if ([jsonData isKindOfClass:[NSArray class]])
//            {
//                if ([jsonData count]>0)
//                {
//                    [AppDelegate sharedAppDelegate].arrCardDetailArray=jsonData;
//                }else
//                {
//                    showAlertScreen(@"No Records", @"There is no card Available for the Account.");
//                }
//            }else
//            {
//                showAlertScreen(nil, jsonData);
//            }
//            _tblCardList.separatorColor=Card_no_colore_code;
            
            [_tblCardList reloadData];
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
        break;
        case CARD_ACTIVE_STATUS:
        {
            LoginResponceDataClass *dataObj=(LoginResponceDataClass *)jsonData;
            
            if (dataObj.Error_Found)
            {
                showAlertScreen(nil, dataObj.ErrorMsg);
            }else
            {
                CardDetailClass *card = [[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:selectedIndex];
                
                card.STATUS_CARDACCOUNT=newCardStatus;
                
                _tblCardList.separatorColor=[UIColor clearColor];
                showAlertScreen(nil, dataObj.ErrorMsg);
            }
            
            [_tblCardList reloadData];
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
        }
        break;
        case NEW_CARD_ORDER:
        {
            if ([jsonData isKindOfClass:[newCardOrder class]])
            {
                card_Order_Obj=(newCardOrder *)jsonData;
                
                if (card_Order_Obj.ResCode==0)
                {
                    showAlertScreen(nil, card_Order_Obj.ResErrorMsg);
                }else
                {
                    [self getAddressField];
                }
            }
        }
        break;
        case customer_detail:
        {
            if ([jsonData isKindOfClass:[UserProfileDataClass class]])
            {
                userDetailObj=(UserProfileDataClass *)jsonData;
                
                if (userDetailObj.ERROR_FOUND)
                {
                    showAlertScreen(nil, userDetailObj.ERRMSG);
                }else
                {
                    [self requestForReplacementCard];
                }
            }
        }
        break;
        case Card_Replace:
        {
            if ([jsonData isKindOfClass:[ReplaceCardData class]])
            {
                Replace=(ReplaceCardData *)jsonData;
                
                if (Replace.ResCode==1)
                {
                    [self requestForChargeFee];
                }else
                {
                    showAlertScreen(nil, Replace.ResErrorMsg);
                    
                    [self requestForUpdateOrder];
                }
            }
            
        }
        break;
        case Update_Order:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case Charge_FEE:
        {
            if ([jsonData isKindOfClass:[ReplaceCardData class]])
            {
                Replace=(ReplaceCardData *)jsonData;
                if (Replace.ResCode==0)
                {
                    CardDetailClass *card = [[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:selectedIndex];
                    
                    card.STATUS_CARDACCOUNT=newCardStatus;
                    
                    _tblCardList.separatorColor=[UIColor clearColor];
                    
                    [_tblCardList reloadData];
                }else
                {
                    showAlertScreen(nil, Replace.ResErrorMsg);
                }
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
        break;
        case back_homeCardlist:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            if ([jsonData isKindOfClass:[NSArray class]]) {
                
                if (![AppDelegate sharedAppDelegate].arrBusinessData)
                {
                    [AppDelegate sharedAppDelegate].arrBusinessData=[[NSMutableArray alloc] init];
                }
                else
                {
                    [[AppDelegate sharedAppDelegate].arrBusinessData removeAllObjects];
                }
                [AppDelegate sharedAppDelegate].arrBusinessData=jsonData;
                [self.navigationController popViewControllerAnimated:YES];
            }
            else
            {
                showAlertScreen(@"", @"No records found");
            }
        }
        break;
    }
}


-(void)removeChangeStatusView
{
    
    [self removePopUpview];
    
}

// method use for remove popup view
-(void) removePopUpview{
    
    if (statusSelectView) {
        [statusSelectView removeFromSuperview];
        [statusSelectView release];
        statusSelectView = nil;
    }
    CardDetailClass *card = [[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:selectedIndex];
    card.isActiveButtonShow=NO;
    _tblCardList.separatorColor=[UIColor clearColor];
    [_tblCardList reloadData];

}




-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index
{
           newCardStatus=index;
        showAlertWithOtherButtons(nil,languageSelectedStringForKey(@"Do you want to change the Status ?") , 1, self);
   
}
#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0)
    {
         [self changeCardStatus:newCardStatus];
    }else
    {
        [self removePopUpview];
    }
    
}

// method use for create popup view for change status
-(void)openStatusView:(int)index
{
    selectedIndex=index;
    CardDetailClass *card = [[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:selectedIndex];
    oldCardStatus=card.STATUS_CARDACCOUNT;
    if (card.STATUS_CARDACCOUNT==Closed_CARD || card.STATUS_CARDACCOUNT==Stolen_CARD || card.STATUS_CARDACCOUNT==Lost_CARD )
    {
        
    }else
    {
        statusSelectView = [[UIView alloc] initWithFrame:self.view.frame];
        statusSelectView.backgroundColor = [UIColor clearColor];
        statusSelectView.center = self.view.center;
        [self.view addSubview:statusSelectView];
        
        PopUpView *csv = [[PopUpView alloc] initWithPopViewFrame:CGRectMake(0, 0, 320, 480) CardData:card Delegate:self];
        
        [statusSelectView addSubview:csv];
        [csv release];
    }
}

#pragma mark - Touch Methods

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self removePopUpview];
}

#pragma mark - UITableView Delegate Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return cardCellHeight;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[AppDelegate sharedAppDelegate].arrCardDetailArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"Cell";
	
    CardDataCell *cell = (CardDataCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        cell = [[[CardDataCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier Delegate:self] autorelease];
    }
    cell.contentView.backgroundColor=(indexPath.row %2 == 0)? [UIColor colorWithPatternImage:[UIImage imageNamed:@"imgCellBackground"]] : [UIColor whiteColor];
    
    CardDetailClass *cardObj;
    cardObj =(CardDetailClass *)[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:indexPath.row];
    
    cell.lblTitleName.text=[NSString stringWithFormat:@"%@%@%@",checkISNullStrings(cardObj.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@ ",cardObj.FIRSTNAME],checkISNullStrings(cardObj.LASTNAME)?@"":[NSString stringWithFormat:@"%@ ",cardObj.LASTNAME],checkISNullStrings(cardObj.CustomAccountID)?@"":[NSString stringWithFormat:@","]];
    
    cell.lblTitleName.frame=CGRectMake(cell.lblTitleName.frame.origin.x, cell.lblTitleName.frame.origin.y, getTextWidth(cell.lblTitleName.text, cell.lblTitleName.font), cell.lblTitleName.frame.size.height);
    
    cell.lblEmployeeId.frame=CGRectMake(CGRectGetMaxX(cell.lblTitleName.frame), cell.lblEmployeeId.frame.origin.y,300-cell.lblTitleName.frame.size.width, cell.lblEmployeeId.frame.size.height);
    
    cell.lblEmployeeId.text=[NSString stringWithFormat:@"%@",checkISNullStrings(cardObj.CustomAccountID)?@"":[NSString stringWithFormat:@"%@",cardObj.CustomAccountID]];

    
    cell.lblCardNumber.text=[NSString stringWithFormat:@"%@",ChangeCardNumber(cardObj.CARDNUMBER)];
    
        cell.btnView.frame=CGRectMake(10, CGRectGetMaxY(cell.lblCardNumber.frame), 7, 13);
        cell.btnView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"imgStatusInactive"]];

    /*
     if index value is 114 then user can change the status else Not able to change the status and status option is dissable.
     */
    if ([AdminAccessInfo AdminAcess].updateCard == UPDATECARD)
    {
        /* If card status is Close, Stolen or Lost*/
        if (cardObj.STATUS_CARDACCOUNT==Closed_CARD || cardObj.STATUS_CARDACCOUNT==Stolen_CARD || cardObj.STATUS_CARDACCOUNT==Lost_CARD )
        {
            cell.btnState.enabled=NO;
            cell.btnView.hidden = YES;
            cell.lblStatus.frame = CGRectMake(10, cell.lblStatus.frame.origin.y, cell.lblStatus.frame.size.width, cell.lblStatus.frame.size.height);
        }else
        {
            cell.btnState.enabled=YES;
            cell.btnView.hidden = NO;
            cell.lblStatus.frame = CGRectMake(CGRectGetMaxX(cell.btnView.frame)+5, cell.lblStatus.frame.origin.y, cell.lblStatus.frame.size.width, cell.lblStatus.frame.size.height);
        }
    }
    else
    {
//        if (cardObj.STATUS_CARDACCOUNT==Closed_CARD || cardObj.STATUS_CARDACCOUNT==Stolen_CARD || cardObj.STATUS_CARDACCOUNT==Lost_CARD )
//        {
//            cell.btnState.enabled=NO;
//            cell.btnView.hidden = YES;
//            cell.lblStatus.frame = CGRectMake(10, cell.lblStatus.frame.origin.y, cell.lblStatus.frame.size.width, cell.lblStatus.frame.size.height);
//        }
//        else
//        {
//            cell.btnState.enabled = YES;
//            cell.btnView.hidden = NO;
//            cell.lblStatus.frame = CGRectMake(10, cell.lblStatus.frame.origin.y, cell.lblStatus.frame.size.width, cell.lblStatus.frame.size.height);
//        }
        
        cell.btnState.enabled = NO;
        cell.btnView.hidden = YES;
        cell.lblStatus.frame = CGRectMake(10, cell.lblStatus.frame.origin.y, cell.lblStatus.frame.size.width, cell.lblStatus.frame.size.height);
    }
    
    
    
    
    cell.lblStatus.text=CardStatusValue(cardObj.STATUS_CARDACCOUNT);

    
    cell.btnState.tag=indexPath.row;
    cell.lblAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(cardObj.AVAILABLEBALANCE))];
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    CardListDetailViewController *CLDvc=[[CardListDetailViewController alloc]init];
    
    
    [AppDelegate sharedAppDelegate].CardDetailPageIndex=indexPath.row;
    
    CLDvc.ProductId=BusinessPageObject.Business_ID_Desc;
    
    [self.navigationController pushViewController:CLDvc animated:YES];
    [CLDvc release];
       
}

//-(void) openCardListDetailview:(id) index
//{
//    
//    int ind= [index integerValue];
//    CardListDetailViewController *CLDvc=[[CardListDetailViewController alloc]init];
//    
//    
//    [AppDelegate sharedAppDelegate].CardDetailPageIndex=ind;
//    
//    CLDvc.ProductId=BusinessPageObject.Business_ID_Desc;
//    
//    [self.navigationController pushViewController:CLDvc animated:YES];
//    [CLDvc release];
//
//}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [_tblCardList release];
    [_myCardListView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setTblCardList:nil];
    [self setMyCardListView:nil];
    
    BusinessPageObject=nil;
    
    if ([AppDelegate sharedAppDelegate].arrCardDetailArray!=nil)
    {
        [[AppDelegate sharedAppDelegate].arrCardDetailArray removeAllObjects];
        [[AppDelegate sharedAppDelegate].arrCardDetailArray release];
        [AppDelegate sharedAppDelegate].arrCardDetailArray=nil;
    }
    [super viewDidUnload];
}
@end
