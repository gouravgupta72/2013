//
//  expenseAnalyisCell.m
//  CoreMoney


#import "expenseAnalyisCell.h"

@implementation expenseAnalyisCell
@synthesize lblEmployeeName, lblEmployeeId, lblExpenseAmount, lblBudgetAmout, lblCategory, lblCategoryAmount, lblCategory1, lblCategory2, lblCategory3, lblCategoryAmount1, lblCategoryAmount2, lblCategoryAmonut3, lblSummarizedPeriod, lblSummrizedAmount, imgBudget, subCategoryView,bgView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier analysisType:(int)analysis
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        bgView = [[UIView alloc] initWithFrame:CGRectMake(7, 4, 306, 44)];
        bgView.layer.borderWidth = 1;
        bgView.layer.borderColor =  [UIColor grayColor].CGColor;
        [self addSubview:bgView];
        [bgView release];

        
        lblEmployeeName = createLabel(@"Allen Broun", CGRectMake(15, 16, 80, 20));
        lblEmployeeName.textColor = Name_color_Code;
        lblEmployeeName.font=FONT_ARIAL_14;
        [self addSubview:lblEmployeeName];
        
        lblEmployeeId =createLabel(@"54564", CGRectMake(CGRectGetMaxX(lblEmployeeName.frame), 18, 120, 20));
        lblEmployeeId.textColor = Card_no_colore_code;
        lblEmployeeId.font = FONT_ARIAL_11;
        [self addSubview:lblEmployeeId];
        
        
        imgBudget = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(bgView.frame)-200, 25, 100, 20)];
        
        imgBudget.image = [UIImage imageNamed:@"green-box.png"];
        [self addSubview:imgBudget];
        
        
        lblExpenseAmount =createLabel(@"$300.00", CGRectMake(CGRectGetMaxX(bgView.frame)-105, 16, 100, 20));
//        lblExpenseAmount.backgroundColor = [UIColor magentaColor];
        lblExpenseAmount.textColor = [UIColor darkGrayColor];
        lblExpenseAmount.textAlignment=UITextAlignmentRight;
        lblExpenseAmount.font = FONT_ARIAL_11;
        [self addSubview:lblExpenseAmount];
        
        lblBudgetAmout =createLabel(@"$300.00", CGRectMake(CGRectGetMinX(imgBudget.frame), 16, 50, 20));
//        lblBudgetAmout.backgroundColor = [UIColor greenColor];
        lblBudgetAmout.textColor = [UIColor grayColor];
        lblBudgetAmout.textAlignment=UITextAlignmentRight;
        lblBudgetAmout.font = FONT_ARIAL_10;
        [self addSubview:lblBudgetAmout];
        
        
        lblCategory = createLabel(@"Food", CGRectMake(15, 16, 80, 20));
        lblCategory.textColor = Status_Color_Code;
        lblCategory.font=FONT_ARIAL_14;
        [self addSubview:lblCategory];
        
        lblCategoryAmount =createLabel(@"$300.00", CGRectMake(CGRectGetMaxX(bgView.frame)-105, 16, 100, 20));
//        lblCategoryAmount.backgroundColor = [UIColor blueColor];
        lblCategoryAmount.textColor = [UIColor grayColor];
        lblCategoryAmount.textAlignment=UITextAlignmentRight;
        lblCategoryAmount.font = FONT_ARIAL_11;
        [self addSubview:lblCategoryAmount];
        
        subCategoryView =[[UIView alloc]initWithFrame:CGRectMake(7, CGRectGetMaxY(lblEmployeeId.frame), 306, 44)];
        subCategoryView.backgroundColor=[UIColor clearColor];
        [self addSubview:subCategoryView];
        
        
        lblCategory1 = createLabel(@"Food", CGRectMake(0, 2, 102, 20));
        lblCategory1.textColor = Status_Color_Code;
        lblCategory1.font=FONT_ARIAL_14;
        lblCategory1.textAlignment=UITextAlignmentCenter;
        [subCategoryView addSubview:lblCategory1];
        
        lblCategory2 = createLabel(@"Travel", CGRectMake(CGRectGetMaxX(lblCategory1.frame), 2, 102, 20));
        lblCategory2.textColor = Status_Color_Code;
        lblCategory2.font=FONT_ARIAL_14;
        lblCategory2.textAlignment=UITextAlignmentCenter;
        [subCategoryView addSubview:lblCategory2];
        
        lblCategory3 = createLabel(@"Hotel", CGRectMake(CGRectGetMaxX(lblCategory2.frame), 2, 102, 20));
        lblCategory3.textColor = Status_Color_Code;
        lblCategory3.font=FONT_ARIAL_14;
        lblCategory3.textAlignment=UITextAlignmentCenter;
        [subCategoryView addSubview:lblCategory3];
        
        
        lblCategoryAmount1 = createLabel(@"$300.00", CGRectMake(0, CGRectGetMaxY(lblCategory1.frame)+2, 102, 20));
        lblCategoryAmount1.textColor = [UIColor grayColor];
        lblCategoryAmount1.font=FONT_ARIAL_11;
        lblCategoryAmount1.textAlignment=UITextAlignmentCenter;
        [subCategoryView addSubview:lblCategoryAmount1];
        
        lblCategoryAmount2 = createLabel(@"$150.00", CGRectMake(CGRectGetMaxX(lblCategoryAmount1.frame), CGRectGetMaxY(lblCategory1.frame)+2, 102, 20));
        lblCategoryAmount2.textColor = [UIColor grayColor];
        lblCategoryAmount2.font=FONT_ARIAL_11;
        lblCategoryAmount2.textAlignment=UITextAlignmentCenter;
        [subCategoryView addSubview:lblCategoryAmount2];
        
        lblCategoryAmonut3 = createLabel(@"$$120.12", CGRectMake(CGRectGetMaxX(lblCategoryAmount2.frame), CGRectGetMaxY(lblCategory1.frame)+2, 102, 20));
        lblCategoryAmonut3.textColor = [UIColor grayColor];
        lblCategoryAmonut3.font=FONT_ARIAL_11;
        lblCategoryAmonut3.textAlignment=UITextAlignmentCenter;
        [subCategoryView addSubview:lblCategoryAmonut3];


        lblSummarizedPeriod = createLabel(@"1st sep 2010", CGRectMake(15, 16, 150, 20));
        lblSummarizedPeriod.textColor = Status_Color_Code;
        lblSummarizedPeriod.font=FONT_ARIAL_14;
        [self addSubview:lblSummarizedPeriod];
        
        lblSummrizedAmount =createLabel(@"$250.21", CGRectMake(CGRectGetMaxX(bgView.frame)-105, 16, 100, 20));
//        lblSummrizedAmount.backgroundColor = [UIColor yellowColor];
        lblSummrizedAmount.textColor = [UIColor grayColor];
        
        lblSummrizedAmount.textAlignment=UITextAlignmentRight;
        lblSummrizedAmount.font = FONT_ARIAL_11;
        [self addSubview:lblSummrizedAmount];

        switch (analysis)
        {
            case Employee_analysis:
            {
                lblCategory.hidden=YES;
                lblCategoryAmount.hidden=YES;
                subCategoryView.hidden=YES;
                lblSummrizedAmount.hidden=YES;
                lblSummarizedPeriod.hidden=YES;
                imgBudget.hidden=YES;
                lblBudgetAmout.hidden=YES;
            }
                break;
            case Employee_Expense_Category:
            {
                lblEmployeeName.frame=CGRectMake(15, 5, 80, 32);
                lblEmployeeId.frame= CGRectMake(CGRectGetMaxX(lblEmployeeName.frame), 5, 60, 32);
                lblExpenseAmount.frame=CGRectMake(CGRectGetMaxX(bgView.frame)-105, 5, 100, 32);
                bgView.frame=CGRectMake(7, 4, 306, 88);
                
                lblCategory.hidden=YES;
                lblCategoryAmount.hidden=YES;
                lblSummrizedAmount.hidden=YES;
                lblSummarizedPeriod.hidden=YES;
                imgBudget.hidden=YES;
                lblBudgetAmout.hidden=YES;
            }
                break;
                
            case Employee_Business_Expense:
            {
//                lblCategory.hidden=YES;
//                lblCategoryAmount.hidden=YES;
//                subCategoryView.hidden=YES;
//                lblEmployeeId.hidden=YES;
//                lblEmployeeName.hidden=YES;
//                imgBudget.hidden=YES;
//                lblExpenseAmount.hidden=YES;
//                lblBudgetAmout.hidden=YES;
                
                lblCategory.hidden=YES;
                lblCategoryAmount.hidden=YES;
                subCategoryView.hidden=YES;
                lblSummrizedAmount.hidden=YES;
                lblSummarizedPeriod.hidden=YES;
                imgBudget.hidden=YES;
                lblBudgetAmout.hidden=YES;

            }
                break;
                
            case Employee_by_Expense_analysis:
            {
                lblSummarizedPeriod.hidden=YES;
                lblSummrizedAmount.hidden=YES;
                subCategoryView.hidden=YES;
                lblEmployeeName.hidden=YES;
                imgBudget.hidden=YES;
                lblExpenseAmount.hidden=YES;
                lblBudgetAmout.hidden=YES;
            }
                break;
                
            default:
                break;
        }

    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
