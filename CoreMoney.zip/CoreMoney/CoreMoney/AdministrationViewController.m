//
//  AdministrationViewController.m
//  CoreMoney
// Class use for create administration page

#import "AdministrationViewController.h"
#import "HomeCell.h"
#import "AdminProfileViewController.h"
#import "AdminListViewController.h"
#import "AlertsViewController.h"
#import "alertGroupViewController.h"

@interface AdministrationViewController ()
-(void)openBack;
-(void)openSlide;
-(void) getRequest;
-(void)getResponce:(id)jsonData;
-(void)getAdminsProfile;
-(void)getAdminLoadLimit;
@end

@implementation AdministrationViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        addNavigationBar(ADMINISTRATION_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        cellArray = [[NSMutableArray alloc] init];
        
        [self addObjectToArray:@"imgAdminsProfileicon" Label:languageSelectedStringForKey(@"User Profile") ];
        [self addObjectToArray:@"imgAdminsIcon" Label:languageSelectedStringForKey(@"Admins")];
        [self addObjectToArray:@"imgAdminAlertsIcon" Label:languageSelectedStringForKey(@"Alerts")];
        
        
    }
    return self;
}
// Method to initialise the cell array.
-(void) addObjectToArray:(NSString *) imgName Label:(NSString *)lblString
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:imgName forKey:@"imgName"];
    [dict setObject:languageSelectedStringForKey(lblString) forKey:@"lblString"];
    
    [cellArray addObject:dict];
    [dict release];
}

-(void)openBack
{
    requestID= back_homadmin;
    
    [self getRequest];
}
// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

- (void)viewDidLoad
{
//    if ([AppDelegate sharedAppDelegate].isNotification == YES) {
//        [[AppDelegate sharedAppDelegate] addloadingView];
//        requestID=AlertList;
//
//        [self getRequest];
//    }
     self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:40:IS_IOS7?0:0, 320, 480);
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void) viewWillAppear:(BOOL)animated
{
     [AppDelegate sharedAppDelegate].classType = ADMINISTRATION_PAGE;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) getRequest
{
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    
    DataReq.Datadelegate=self;
    switch (requestID) {
        case AlertList :
        {
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            [SystemConfiguration sharedSystemConfig].dbbServiceName=ALERT_COUNT_REQUEST;
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPAdminPortalClientID=&deAlertUserID=%@&deAlertDirection=2&deAlertType=&deAlertDate=&deAlertActionDate=&deAlertStatus=NEW&deRFCount=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:SvcALViewAlertMsgCountAction];
        }
            break;
        case ADMINList:
        {
            
            BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];

            
            if ([AppDelegate sharedAppDelegate].ArrayAdmin !=nil)
            {
                [[AppDelegate sharedAppDelegate].ArrayAdmin removeAllObjects];
                [[AppDelegate sharedAppDelegate].ArrayAdmin release];
                [AppDelegate sharedAppDelegate].ArrayAdmin =nil;
            }
            
            [SystemConfiguration sharedSystemConfig].dbbServiceName=GEt_Admin_List_Request;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deANAClientID=%@&deANAuserStatus=&deANAInternalId=6&deANAuserid=&deANASearchInternalId=&deANAUserName=&deANAUserSurName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.OwningPartner,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcSearchUser];
        }
            break;

            case back_homadmin:
        {
            [[AppDelegate sharedAppDelegate] addloadingView];
            [SystemConfiguration sharedSystemConfig].dbbServiceName=Business_Search_Request;
            [SystemConfiguration sharedSystemConfig].deFlagShowDetails=@"1";
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPProductParent=&deBusinessName=&deCIASDDANumber=&deAADAccountNumber=&dePPCardStatus=&deCIASFirstName=&deCIASLastName=&deCIAAddressLine1=&deCIAAddressLine2=&deCIASCity=&deCIASState=&deCIASCountry=&deCIASZipCode=&deBSAcctId=&deFlagShowDetails=%@&deRequestBatchSize=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].deFlagShowDetails,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBusinessAccountSearch];
        }
            
            break;
        default:
            break;
    }
    [DataReq release];
}


#pragma mark - Data parsing responce method
-(void)getResponce:(id)jsonData
{
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    
    switch (requestID) {
        case AlertList:
        {
            NSMutableArray *dataArray = nil;
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                dataArray=jsonData;
            }
            
            alertGroupViewController *avc = [[alertGroupViewController alloc] initWithNibName:@"alertGroupViewController" bundle:nil Array:dataArray];
            [self.navigationController pushViewController:avc animated:YES];
            [avc release];
        }
            break;
            
        case ADMINList:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    if (![AppDelegate sharedAppDelegate].ArrayAdmin)
                    {
                        [AppDelegate sharedAppDelegate].ArrayAdmin=[[NSMutableArray alloc]init];
                    }else
                    {
                        [[AppDelegate sharedAppDelegate].ArrayAdmin removeAllObjects];
                    }
                    [AppDelegate sharedAppDelegate].ArrayAdmin=jsonData;
                    
                    AdminListViewController *apvc = [[AdminListViewController alloc] initWithNibName:@"AdminListViewController" bundle:nil];
                    
                    [self.navigationController pushViewController:apvc animated:YES];
                    [apvc release];

                }else
                {
                    showAlertScreen(nil, @"No record Found");
                }
                
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
           
        }
            break;
            case Self_Profile:
        {
            
            if ([jsonData isKindOfClass:[adminProfileData class]])
            {
                
                adminProfileData *profile=(adminProfileData *)jsonData;
                
                AdminProfileViewController *adPVC=[[AdminProfileViewController alloc] initWithNibName:@"AdminProfileViewController" bundle:nil admin:YES];
                
                adPVC.adminProfileObj=profile;
                 adPVC.adminLoadDataObj=adminLoadObj;
                [self.navigationController pushViewController:adPVC animated:YES];
                [adPVC release];
                
                
                [[AppDelegate sharedAppDelegate] removeLoadingView];
                
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case get_load_LImit:
        {
            if ([jsonData isKindOfClass:[adminLoadLimitDataClass class]])
            {
                adminLoadObj=(adminLoadLimitDataClass *)jsonData;
                 [self getAdminsProfile];
            }else
            {
                showAlertScreen(nil, jsonData);
                [[AppDelegate sharedAppDelegate] removeLoadingView];
            }
            
        }
            break;
        case back_homadmin:
        {
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            if ([jsonData isKindOfClass:[NSArray class]]) {
                
                if (![AppDelegate sharedAppDelegate].arrBusinessData)
                {
                    [AppDelegate sharedAppDelegate].arrBusinessData=[[NSMutableArray alloc] init];
                }
                else
                {
                    [[AppDelegate sharedAppDelegate].arrBusinessData removeAllObjects];
                }
                [AppDelegate sharedAppDelegate].arrBusinessData=jsonData;
                [self.navigationController popViewControllerAnimated:YES];
            }
            else
            {
                showAlertScreen(@"", @"No records found");
            }
            
            
        }
            break;

               default:
            break;
    }
       
}
//method use for get admin profile
-(void)getAdminsProfile
{
    requestID=Self_Profile;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getAdminProfile_Request;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dePPAdminPortalFilterID=1&dePPAdminPortalUserID=%@&dePPAdminPortalIPAddress=&dePPAdminPortalClientID=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource];
       
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcGetIPAddrMatchIPAddrAndCheckDay];
    [Datareq release];
    
}
//method to get admin load limit
-(void)getAdminLoadLimit
{
    requestID=get_load_LImit;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getAdmin_load_par_req;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deLoadParameter_Acctid=%@&deLoadParameter_Type=User&deValueOFDay=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource];

    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcviewloadparameter];
    [Datareq release];
    
}


#pragma mark- Table View Delegates
// Delegate method to set the number of sections in table.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
// Delegate method to set the height of the cell.
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 58;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [cellArray count];
}
// Delegate method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"Cell";
	HomeCell *cell = (HomeCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[HomeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    NSMutableDictionary *dict = [cellArray objectAtIndex:indexPath.row];
    
    
    cell.lblName.text=[dict objectForKey:@"lblString"];
    cell.cellImage.image=[UIImage imageNamed:[dict objectForKey:@"imgName"]];
    cell.lblName.textColor=[UIColor blackColor];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}
// Delegate method called when the row selects.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case ADMIN_USERPROFILE_BUTTON:
        {
            [self getAdminLoadLimit];
        }
            break;
        case ADMIN_ADMINS_BUTTON:
        {
            [[AppDelegate sharedAppDelegate] addloadingView];
            requestID=ADMINList;
            [self getRequest];
            
        }
            break;
        case ADMIN_ALERTS_BUTTON:
        {
           [[AppDelegate sharedAppDelegate] addloadingView];
            requestID=AlertList;
            [self getRequest];
        }
            break;
       
        default:
            break;
    }
}

- (void)dealloc {
    [_bgView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setBgView:nil];
    [super viewDidUnload];
}
@end
