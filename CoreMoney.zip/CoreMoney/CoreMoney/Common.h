//
//  Common.h

#import <UIKit/UIKit.h>
#import "LoginResponse.h"
#import "Reachability.h"

//#define SERVER_DOMAIN
//#define API_DOMAIN

// Server Domain

// UAT
//#define SERVER_DOMAIN @"http://10.205.10.85:81"
//#define API_DOMAIN @"appCNBMobile.aspx?"

//#if DEVEXT
#define SERVER_DOMAIN @"http://115.114.121.165/"
#define API_DOMAIN @"appScale4425.aspx?"
//#endif

//#if DEVINT
//#define SERVER_DOMAIN @"http://10.155.0.2/"
//#define API_DOMAIN @"appScale4425.aspx?"
//#endif

//#if MPEUAT
//#define SERVER_DOMAIN @"http://10.206.0.77/MPE5_Mobile/"
//#define API_DOMAIN @"appScale4421.aspx?"
//#endif

//#if STAGING
//#define SERVER_DOMAIN @"https://stageapi.corecard.com/"
//#define API_DOMAIN @"appSTGMobileService.aspx?"
//#endif

//#if USERTEST
//#define SERVER_DOMAIN @"http://115.114.121.165/"
//#define API_DOMAIN @"appScale4425.aspx?"
//#endif

//#if PRODUCTION
//#define SERVER_DOMAIN @"http://115.114.121.165/"
//#define API_DOMAIN @"appScale4425.aspx?"
//#endif


#define LOGIN_ACTION @"login.php?"
#define REGITER_ACTION @"register.php?"
#define GET_STORE_ACTION @"getStores.php?"
#define GET_USER_UPLOAD_ACTION @"getUserUploads.php?"
#define SET_SENSOR @"setSensors.php?"
#define GET_SENSOR_SETTINGS @"getSensorsSettings.php?"
#define RESET_PASSWORD @"ResetUserPassword.php?"
#define CHANGE_PASSWORD @"ChangeUserPassword.php?"
#define USERID @"USERID"
#define PARSE_RESPONSE @"Response"
#define PARSE_STATUS @"Status"
#define PARSE_SUCCESS @"Success"
#define PARSE_MESSAGE @"Message"
#define degreesToRadians(x) (M_PI * (x) / 180.0)
#define RadiansTodegree(x) (180 * (x) / M_PI)
#define APP_BACKGROUND_IMAGE @"appbackground"
#define LOGIN_PANEL_BACKGROUND @"loginBack"


// Server Test User
#define Test_User @"portalsuperuser"
#define Test_Password @"Test123!"


// App Resource
#define APP_SOURCE @"MobileCoreMoney"
#define APP_SCALE_ID @"appScale4883"



// Request API's name
#define Login_Request @"svcUserLogin"
#define ValidateUserId_request @"svcValidateUserID"
#define CardLookUp_Request @"svcCCardLookUp"
#define Check_Security_Que @"svcCheckSecretQuestion"
#define Update_User_Reqest @"svcUpdateNewUser"
#define Business_Search_Request @"svcBusinessAccountSearch";
#define CardHolderList_Request @"svcCardSearch";
#define Card_holder_Detail_Request @"svcCardholderDetail"
#define Card_update_profile_Request @"svcCardUpdate3"
#define TransactionHistory_Request @"svcCHTransactionHistory"
#define RegisterDevice @"svcDeviceRegisteration"
#define Change_Card_Status_Update @"svcUpdateCardStatus_CardAccount"
#define REplaceCard_Request @"svcReplacementCard"
#define GetEXpenseCategory @"svcViewExpenseCategory"
#define GetMEmoREcord @"svcCIAMemoView"
#define UpdateMemo @"svcCIAMemoUpdate"
#define AddMemo @"svcCIAMemoAdd"
#define AddExpenseCategory @"svcSaveExpenseCategory"
#define CARD_ACTIVE_REQUEST @"svcCardActivationActivateCard"
#define NEW_CARD_ORDER_Request @"svcNewOrder"
#define Charge_Card_Fee_REq @"svcChargeCardFee"
#define Update_CARD_ORder_Request @"svcUpdateOrder"
#define Search_LowBalance_REquest @"svcBALowBalanceFundingSearch"
#define Search_Schedule_funding_Request @"svcBAScheduleFundingSearch"
#define AddLOW_BALANCE_FUNDING_Req @"svcBALowBalanceFunding"
#define AddScheduling_Fund_Req @"svcBAScheduleFunding"
#define Fund_Card_Add_Request @"svcStartSingleLoad"
#define Fund_Card_Delete_Request @"svcStartSingleUnload"
#define ALERT_COUNT_REQUEST @"svcALViewAlertMsgCount"
#define ALERT_DISPLAY_REQUEST @"svcSpendCardBAAlertDisplay"
#define getBusiness_List @"svcGetSpendProducts"
#define getBusiness_Expense @"svcBusinessExpense"
#define getCustomerAddress @"svcGetCustomerAddress"  
#define ViewTransferDetail_Request @"svcBAViewTransferDetail"
#define GetExternal_Bank_list @"svcBAExternalBankList"
#define Transfer_To_business_REquest @"svcBAFundAcctOneTimeFunding"
#define GEt_Admin_List_Request @"svcSearchUser"
#define Complete_Delete_transfer_req @"svcBACompleteDeleteAchTxn"
#define Update_Existing_Admin_user @"svcUpdateExistingUser"
#define getAdminProfile_Request @"svcGetIPAddrMatchIPAddrAndCheckDay"
#define getAdmin_load_par_req @"svcViewLoadParameter"
#define getStateCode @"svcState"
#define loadAdminParameter @"svcLoadParameter"
#define Expense_rules_req @"svcViewAccountSpendParameter"
#define getEmployeeList @"svcGetEmployees"
#define getEmployee_Expense @"svcCardSpendReportAPI"
#define getExpenseCategory_Expense @"svcGenerateReport_ExpenseCategoryAPI"
#define saveSpendParameter @"svcSaveAccountSpendParameter"
#define getEmployeeByExpenceAnalysisReport @"svcEmployeeByExpenseCategoryAPI"
#define alertReadDeleteService @"svcAlertRead"

#define IS_IOS7 ([[[UIDevice currentDevice] systemVersion] floatValue]>=7.0)

#define IS_IPHONE ( [ [ [ UIDevice currentDevice ] model ] rangeOfString: @"iPhone" ].location != NSNotFound)
#define IS_IPOD ( [ [ [ UIDevice currentDevice ] model ] rangeOfString: @"iPod" ].location != NSNotFound)
#define IS_WIDESCREEN ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 ) < DBL_EPSILON )
#define IS_IPHONE_5 ( IS_IPHONE && IS_WIDESCREEN )
#define IS_IPAD ( [ [ [ UIDevice currentDevice ] model ] rangeOfString: @"iPad" ].location != NSNotFound)

#define LOGIN_PANEL_BACK_COLOR [UIColor colorWithPatternImage:[UIImage imageNamed:GetImageName(LOGIN_PANEL_BACKGROUND)]];
#define BACKGROUND_THEME self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:GetImageName(APP_BACKGROUND_IMAGE)]];
#define LOGIN_BACKGROUND_THEME self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:GetImageName(BACKGROUND_IMAGE)]];
#define TITLE_FONT [UIFont fontWithName:@"Futura Md BT" size:20]
#define APP_FONT_15  [UIFont boldSystemFontOfSize:15]
#define APP_FONT_16  [UIFont boldSystemFontOfSize:16]
#define APP_FONT_14  [UIFont systemFontOfSize:14]
#define APP_FONT_17  [UIFont systemFontOfSize:17]

//LoginView
#define BACKGROUND_IMAGE @"Loginbackground"
#define LOGIN_IMAGE @"btnLogin"
#define CREATE_IMAGE @"btnRegister"
#define LOGIN_TEXT @"Sign In"
#define CREATE_TEXT @"Create Account"
#define FORGOT_IMAGE @"btnForgotPassword"
#define EMAIL_PLACEHOLDER @"Email"
#define PASSWORD_PLACEHOLDER @"Password"

//Registration
#define INFO_VERIFY @"Verify Account Information"
#define EMAIL_CHECK_EXP @"[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?"
#define LASTNAME_MESSAGE @"The last name you entered exceeds the amount of characters allowed."
#define LASTNAME_TITLE @"Last Name Too Long Alert"
#define FIRSTNAME_MESSAGE @"The first name you entered exceeds the amount of characters allowed."
#define FIRSTNAME_TITLE @"First Name Too Long Alert"
#define EMAIL_TEXT @"Email Address"
#define NAME_TEXT @"Name"

#define ZIPCODE_CHECK_EXP @"^[0-9]{5}(-?[0-9]{4})?$"

#define PHONE_CHECK_EXP @"^((\\+)|(00))[0-9]{6,14}$"
#define REGISTRATION_TITLE @"Create Account"
#define BUSINESS_SUMMARY_TITLE @"Business Summary"
#define HOME_TITLE @"Home"
#define TRANSFER_TITLE @"Transfer"
#define CARD_LIST_TITLE @"Cards"
#define CARDS_SUMMARY_TITLE @"Cards Summary"
#define CARD_LIST_DETAIL_TITLE @"Card Detail"
#define CARD_TRANSACTION_TITLE @"Transactions"
#define FORGOT_USER_ID @"Forgot User ID"
#define REGISTER_DEVICE @"Register Device"
#define FORGOT_PASSWORD @"Forgot Password"
#define UPdate_Password @"Update Password"
#define FUND_CARD_TITLE @"Fund Card"
#define AUTOMATIC_FUNDING @"Automatic Funding"
#define EXPENSE_RULES @"Expense Rules"
#define ADMIN_LIST @"Admin List"
#define ADMIN_PROFILE_TITLE @"Admin Profile"
#define ADMIN_USERPROFILE_TITLE @"User Profile"
#define ADMINISTRATION_TITLE @"Administration"
#define ADMIN_ALERT_TITLE @"Alerts"
#define EXPENSE_ANALYSIS_TITLE @"Expense Analysis"
#define EMP_EXPENSE_TITLE @"Employee Expense"
#define Business_Expense_Title @"Business Expense"
#define Expense_category_Title @"Expense Category"
#define Employee_Expense_category_Title @"Employee Expense Category"
#define Term_And_Condition_Title @"Terms & Conditions"
#define Contact_us_Title @"Contact Us"
#define Aboutus_Title @"About us"
#define FAQs_Title @"FAQs"
#define Recommend_title @"Recommend"

#define VALIDATE_EMAIL_MESSAGE @"The email address you entered exceeds the amount of characters allowed. Please provide an alternate email address."
#define BLANK_FIELD @"Fields should not be blank"
#define VERIFY_EMAIL_ALERT @"Email address does not match."
#define ERROR_MSG @"Error"
#define VERIFY_PLACEHOLDER @"Verify"
#define CONFIRM_PASSWORD_PLACEHOLDER @"Confirm Password"
#define FIRSTNAME_PLACEHOLDER @"First Name"
#define LASTNAME_PLACEHOLDER @"Last Name"
#define INVALID_PASSWORD @"Invalid Password"
#define INVALID_PASSWORD_MSG @"Please make sure you entered your password correctly."
#define INVALID_EMAIL @"Please make sure you entered correct email id"

#define TITLE_NOCONNECTION           @"No Connection"
#define NETWORK_ERROR @"A connection could not be established with CoreMoney online services. Check your internet connection and try again."




#define IS_DEVICE_IPAD	UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad

#define UIColorFromARGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 \
alpha:((float)((rgbValue & 0xFF000000) >> 24))/255.0]

#define SIZE_PADDING_DEFAULT    10
#define SIZE_PADDING_SMALL      5

#define Name_color_Code [UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:138.0/255.0 alpha:1.0f]
#define Card_no_colore_code [UIColor colorWithRed:85.0/255.0 green:85.0/255.0 blue:85.0/255.0 alpha:1.0f]
#define Status_Color_Code [UIColor colorWithRed:56.0/255.0 green:142.0/255.0 blue:212.0/255.0 alpha:1.0]
#define Txn_Type_Color_code [UIColor colorWithRed:120.0/255.0 green:179.0/255.0 blue:226.0/255.0 alpha:1.0]
#define Color132 [UIColor colorWithRed:132.0/255.0 green:132.0/255.0 blue:132.0/255.0 alpha:1.0]
#define Color127 [UIColor colorWithRed:127.0/255.0 green:127.0/255.0 blue:127.0/255.0 alpha:1.0f]

#define FONT_FOR_LABEL_DESC [UIFont fontWithName:@"Arial" size:15]
#define FONT_ARIAL_12 [UIFont fontWithName:@"Arial" size:12]
#define FONT_ARIAL_11 [UIFont fontWithName:@"Arial" size:11]
#define FONT_ARIAL_16 [UIFont fontWithName:@"Arial" size:16]
#define FONT_ARIAL_17 [UIFont fontWithName:@"Arial" size:17]
#define FONT_ARIAL_18 [UIFont fontWithName:@"Arial" size:18]
#define FONT_ARIAL_19 [UIFont fontWithName:@"Arial" size:19]
#define FONT_ARIAL_20 [UIFont fontWithName:@"Arial" size:20]
#define FONT_ARIAL_23 [UIFont fontWithName:@"Arial" size:23]
#define FONT_ARIAL_25 [UIFont fontWithName:@"Arial" size:25]
#define FONT_ARIAL_14 [UIFont fontWithName:@"Arial" size:14]
#define FONT_ARIAL_ITALIC_9 [UIFont fontWithName:@"Arial-ItalicMT" size:9]
#define FONT_ARIAL_ITALIC_10 [UIFont fontWithName:@"Arial-ItalicMT" size:10]
#define FONT_ARIAL_ITALIC_11 [UIFont fontWithName:@"Arial-ItalicMT" size:11]
#define FONT_ARIAL_ITALIC_12 [UIFont fontWithName:@"Arial-ItalicMT" size:12]
#define FONT_ARIAL_ITALIC_14 [UIFont fontWithName:@"Arial-ItalicMT" size:14]
#define FONT_ARIAL_ITALIC_15 [UIFont fontWithName:@"Arial-ItalicMT" size:15]
#define FONT_ARIAL_ITALIC_16 [UIFont fontWithName:@"Arial-ItalicMT" size:16]
#define FONT_ARIAL_BOLD_18 [UIFont fontWithName:@"Arial-BoldMT" size:18]
#define FONT_ARIAL_BOLD_16 [UIFont fontWithName:@"Arial-BoldMT" size:16]
#define FONT_BOLD_12 [UIFont boldSystemFontOfSize:12]
#define FONT_ARIAL_BOLD_20 [UIFont fontWithName:@"Arial-BoldMT" size:20]
#define FONT_ARIAL_BOLD_14 [UIFont fontWithName:@"Arial-BoldMT" size:14]
#define FONT_ARIAL_BOLD_16 [UIFont fontWithName:@"Arial-BoldMT" size:16]
#define FONT_ARIAL_BOLD_20 [UIFont fontWithName:@"Arial-BoldMT" size:20]
#define FONT_ARIAL_BOLD_22 [UIFont fontWithName:@"Arial-BoldMT" size:22]

#define FONT_ARIAL_BOLD_10 [UIFont fontWithName:@"Arial-BoldMT" size:10]
#define FONT_ARIAL_BOLD_11 [UIFont fontWithName:@"Arial-BoldMT" size:11]
#define FONT_ARIAL_BOLD_12 [UIFont fontWithName:@"Arial-BoldMT" size:12]
#define FONT_ARIAL_BOLD_13 [UIFont fontWithName:@"Arial-BoldMT" size:13]
#define ACTIONBAR_TITLE_FONT [UIFont fontWithName:@"Arial" size:20]
#define FONT_ARIAL_10 [UIFont fontWithName:@"Arial" size:10]
#define FONT_ARIAL_7 [UIFont fontWithName:@"Arial" size:7]

#define FONT_ARIAL_13 [UIFont fontWithName:@"Arial" size:13]

#define FontSize        14
#define boldFontSize    15

#define UI_COLOR_TEXT_LIGHT UIColorFromARGB(COLOR_TEXT_LIGHT)
#define UI_COLOR_TEXT_LIGHTGRAY UIColorFromARGB(COLOR_TEXT_LIGHTGRAY)

#define MARk_ALL_READ @"Mark all Alert Read"
#define MARk_ALL_DELETE @"Delete All Alert"

#define COLOR_TEXT_LIGHT        0xFFFFFFFF
#define COLOR_TEXT_LIGHTGRAY    0xFFCCCCCC

#define STATUSBAR_HEIGHT     20
#define NAVIGATIONBAR_HEIGHT 44
#define TOOLBAR_HEIGHT       44
#define BUTTONBAR_HEIGHT     44
#define ALERTBAR_HEIGHT      20
#define PAGECONTROL_HEIGHT   20
#define IPHONE_HEIGHT        480
#define IPHONE5_HEGIHT       568
#define IPHONE_WIDTH         320

#define FONT_XXSMALL FONT_ARIAL_10;
#define FONT_SMALL_BOLD FONT_ARIAL_BOLD_16;

//#define TESTING_APPLICATION YES
#define TESTING_APPLICATION NO
#define NavigationBarStyle() float version = [[[UIDevice currentDevice] systemVersion] floatValue];\
UIImage *backgroundImage = [UIImage imageNamed:@""];\
if (version >= 5.0 && version < 7.0) {\
}\
else\
{\
}
typedef enum
{
    EMP_TODAYS=0,
    EMP_THIS_MONTHS,
    EMP_LAST_MONTH,
    EMP_LAST_QUARTER,
    
}empPeriodType;


typedef enum
{
    RedAlert=0,
    AmberAlert,
    GreenAlert,
    
}alertColorGroup;


typedef enum
{
    FORGOT_PWD_PAGE=0,
    FORGOT_USER_PAGE,
    REGISTER_DEVICE_PAGE
} forgotPage;

typedef enum
{
    EXP_CAT_ADD_FIRST=0,
    EXP_CAT_ADD_SECOND,
    EXP_CAT_ADD_THIRD
} expenseCategoryTyped;


typedef enum
{
    Employee_analysis=0,
    Employee_by_Expense_analysis,
    Employee_Expense_Category,
    Employee_Business_Expense,
    
}expenseAnalysisPageType;

typedef enum
{
    CurrentMonth_First=0,
    CurrentMonth_Lats,
    LastMonth_First,
    LastMonth_last,
    
}Filter_Period;


typedef enum
{
    ADD_TRANSFER=0,
    REFRESH_TRANSFER_LIST,
    change_Status,
    back_homeTransfer,
} Transfer_Request;

typedef enum
{
    BankName_Combo=2,
    BankNumber_Combo,
} comboBoxType;

typedef enum
{
    Employee_list_combo=0,
    Period_list_combo,
    Category_List_combo,
    Category_Sub_List,
    summarized_List_combo
} Expense_combo_type;

typedef enum
{
    DAILY = 0,
    FIRSTDAY_MONTH,
    WEEKLY,
    MONTHLY,
    
}loadFrequencyType;

typedef enum
{
    cardList = 0,
    transfer_list,
    Bank_list,
    Alert_Detail,
    back_HomePage,
        
}HomePage_requests;

//enum for alert detail request
typedef enum
{
    alert_Bank_list=0,
    alert_transfer_list,
    alert_change_card_status,
    alert_Frquency_Request,
    alertCardPendingActivation,  /* For, We have to go to Card List Page from CPA alert */
    alertCardProfileUpdate,
    alertFrequency,
    alertReadAlert,
    alertDeleteAlert,
    alertListCount,
    Mark_All_Read_Alert,
    Mark_ALL_Delete_Alert,
    
}Alert_Detail_Request;

typedef enum
{
    ADMINList = 0,
    AlertList,
    Self_Profile,
    get_load_LImit,
    back_homadmin,
    
}Admin_Requests;

typedef enum
{
    transactionList = 0,
    GetMemo_data,
    GetExpense_data,
}Transaction_Page_request;

typedef enum
{
    UPDATECARD = 114,
    TERMINATECARD = 114,
    LOADCARD = 121,
    SCHEDULECARD = 148,
    EXPENSERULES = 167,
    INITIATETRANSFER = 170,
    VIEWTRANSFER = 171,
    ADMINPAGEACCESS = 129,
    REPORTACCESS = 105,
    MGMTPOLICYACCESS = 129,
    TRANSACTIONHISTORY = 115,
}AdminAccess;

typedef enum
{
    svcUserLogin=0,
    svcValidateUserID,
    svcCCardLookUp,
    svcCheckSecretQuestion,
    svcBusinessAccountSearch,
    svcBACardHolderList,
    svcTCIVRChangeCardStatus,
    svcCardholderDetail,
    svcCardUpdate3,
    svcCHTransactionHistory,
    svcDeviceRegisteration,
    svcUpdateCardStatus_CardAccount,
    svcCIAMemoView,
    svcCIAMemoUpdate,
    svcCIAMemoAdd,
    svcSaveExpenseCategory,
    svcViewExpenseCategory,
    svcCardActivationActivateCard,
    svcNewOrder,
    svcReplacementCard,
    svcChargeCardFee,
    svcUpdateOrder,
    svcBALowBalanceFundingSearch,
    svcBAScheduleFundingSearch,
    svcBALowBalanceFunding,
    svcBAScheduleFunding,
    svcStartSingleLoad,
    svcStartSingleUnload,
    svcGetSpendProducts,
    SvcALViewAlertMsgCountAction,
    svcSaveAccountSpendParameter,
    svcSpendCardBAAlertDisplay,
    svcBAViewTransferDetail,
    svcBAExternalBankList,
    svcBAFundAcctOneTimeFunding,
    svcSearchUser,
    svcBACompleteDeleteAchTxn,
    svcUpdateExistingUser,
    svcGetIPAddrMatchIPAddrAndCheckDay,
    svcUpdateNewUser,
    svcviewloadparameter,
    svcState,
    svcLoadParameter,
    svcViewAccountSpendParameter,
    svcGetEmployees,
    svcCardSpendReportAPI,
    svcGenerateReport_ExpenseCategoryAPI,
    svcBusinessExpense,
    svcEmployeeByExpenseCategoryAPI,
    svcGetCustomerAddress,
    svcAlertRead
}Request_Type;


typedef enum
{
    term_and_Condition_Page = 0,
    about_Page,
    FAQs_Page,
    recommend_Page,
} helpMenuPageType;

typedef enum
{
    Auto_Funding_Faild_Alert = 17,          /* Auto Funding Failed (due to low fund) */
    Card_Pending_Activation_Alert = 18,
    Negative_Card_Balance_Alert = 20,
    enumFraudAlert = 21,                    /* Fraud Alert for the value of <FraudAlertCount> */
    Card_Spend_Rules_Changed_Alert = 22,    /* Card Spend rules changed <Spend_Rules_Changed> */
    Funding_Rules_Changed_Alert = 23,       /* Funding Rules Changed <Funding_Rules_Changed> */
    New_card_issued_Alert = 24,             /* New Card Issued/Reissued <Card_Issued> */
    Card_Profile_Updated = 25,              /* Card Profile Update <Card_Profile_Update> */
    International_Card_Transactions = 36,   /* International Transactions <TxnCountry> */
//    Frequency_Alert = 27,
    Low_Balance_on_Business=29,             /* Low Balance on Business */
//    enumLowBalanceOnBusiness = 29,        
    Low_Balance_Cards_Alert = 28,           /* Low balance cards <Low_BAL_Alert> */
    Card_Transaction_Decline_Alert = 16,    // Card Txn Decline <CARD_HOLDER_DECLINE>
    Fradu_Alert_Alert = 21,
    Auto_Funding_Faild_Admin = 32,          /* Auto Funding Failed (due to admin load limit) */
    High_value_transaction_Alert = 31,      /* High Value Transaction Alert */
    Business_Policy_Changed = 33,           /* Business policy changed */
    //new alert added in Amber category
    Bulk_Card_Request = 37,                 /* Bulk Card Request/Load <BulkRequestLoad_Alert> */
    Card_Frequency_Alert = 27,              /* Frequency Alert <Frequency_Alert> */
    Business_Profile_Update = 60,           //Dont know the Value will be change when value will come
} Alert_Type;



typedef enum
{
    EmployeeList_Request = 0,
    Employee,
    EmployeeByExpense,
    EmployeeExpenseCategor,
    EmployeeBusinessExpense,
    BAckToHome,
    Exp_Cate_List,
    exp_Business_List,
} Expense_Analysis_Request;


typedef enum
{
    GetCardList=0,
    ChangeCardStatus,
    CARD_ACTIVE_STATUS,
    NEW_CARD_ORDER,
    Card_Replace,
    Charge_FEE,
    Update_Order,
    back_homeCardlist,
    customer_detail,
}CardList_Request;

typedef enum
{
    getSecurityQuestion=0,
    change_Pwd,
    Check_SecurityQue,
    Change_Admin_load_limit,
}Admin_Profile_Request;

typedef enum
{
    changeAdminStatus=0,
    getAdminProfile,
    getAdminLoad,
}AdminList_Request;

typedef enum
{
    STORENAME=0,
    AISLENUMBER,
    BAYNUMBER
} dropDowntype;


typedef enum
{
    Login_Req=0,
    Forget_pwd_req,
    Forget_user_ID_req,
    GetSEcurity_Question,
    Reg_Device_Req,
    HOME_PAGE_Req,
    Alert_Req,
}Login_page_request;


typedef enum
{
    Daily_f=0,
    Monday_f=1,
    Tuesday_f=2,
    Wednesday_f=3,
    Thursday_f=4,
    Friday_f=5,
    Saturday_f=6,
    Sunday_f=7,
    first_OM_f=10,
    Weekly_f=9,
    Monthly_f=8,
}Frequency_Enum;

typedef enum
{
    DEFAULT_PAGE=0,
    LOGIN_PAGE,
    REGISTRATION_PAGE,
    HOME_PAGE,
    BUSINESS_SUMMARY_PAGE,
    CARD_LIST_PAGE,
    CARD_CREATE_NEW_PAGE,
    CARDS_TRANSACTION_PAGE,
    CARDS_FUND_CARD_PAGE,
    CARDS_AUTOMATIC_FUNDING_PAGE,
    CARDS_EXPENSE_RULE_PAGE,
    CARDS_PROFILE_PAGE,
    TRANSFER_PAGE,
    ADMINISTRATION_PAGE,
    ADMIN_PROFILE_PAGE,
    ADMINS_PAGE,
    ADMIN_CREATE_NEW_PAGE,
    ADMIN_ALERTS_PAGE,
    ADMINT_CATEGORY_MANAGEMENT_PAGE,
    EXPENCE_ANALYSIS_PAGE,
    CARD_LIST_DETAIL_PAGE,
    LOGOUT_PAGE,
    AUTOMATIC_FUNDING_PAGE,
    UPDATE_PROFILE_PAGE,
    PAGE_TRANSACTIONS_DETAILS,
    EXP_EMPLOYEE_PAGE,
    EXP_EMP_BY_EXPENSE_PAGE,
    EXP_EXPENSE_CAT_PAGE,
    EXP_BUSINESS_EXP_PAGE,
}pageType;

typedef enum
{
    HEADERS,
    SUBHEADERS,
}slideIndexType;

typedef enum
{
    SLIDE_HOME,
    SLIDE_BUSINESS_SUMMARY,
    SLIDE_CARDS,
    SLIDE_TRANSFERS,
    SLIDE_ADMINISTRATION,
    SLIDE_EXPENSE_ANALYSIS,
    SLIDE_DEFAULT_CONTENT,
}slideMenuContent;

typedef enum
{
    ACTIVE_CARD=2,
    BLOCKED_CARD=10,
    Inactive_Card=48,
    Lost_CARD=9,
    Stolen_CARD=8,
    Closed_CARD=11,
    Pending_CARD=1111,
}cardStatus;

typedef enum
{
    ACtive_Admin=0,
    Blocked_Admin,
    Closed_Admin,
}Admin_Status;

typedef enum
{
    PRIMARY_CARD_TYPE,
    SECONDARY_CARD_TYPE,
    BUSINESS_CARD_TYPE,
}cardType;

typedef enum
{
    NAV_RIGHT_NONE,
    NAV_RIGHT_SLIDE,
    NAV_RIGHT_DONE,
}rightNavigationButtonType;

typedef enum
{
    NAV_LEFT_NONE,
    NAV_LEFT_BACK,
    NAV_LEFT_CANCEL,
}leftNavigationButtonType;

typedef enum
{
    LANG_ENGLISH,
    LANG_SPANISH,
} languageType;
typedef enum
{
    TYPICAL_PURCHASE_TRANSACTION,
    NON_NETWORK_TRANSACTION,
}transactionType;

typedef enum
{
    ADMIN_USERPROFILE_BUTTON,
    ADMIN_ADMINS_BUTTON,
    ADMIN_ALERTS_BUTTON,
}adminsPageBtns ;

typedef enum
{
    BUSINESS_SUMMARY_BUTTON,
    CARDS_LIST_BUTTON,
    TRANSFERS_BUTTON,
    ADMINISTRATION_BUTTON,
    EXPENSE_ANALYSIS_BUTTON,
}HOME_PAGE_BUTTONS;

typedef enum
{
    CARDS_TRANSACTION_BUTTON,
    CARDS_PROFILE_BUTTON,
    CARDS_FUND_BUTTON,
    CARDS_AUTOMATIC_FUNDING_BUTTON,
    CARDS_EXPENSE_RULE_BUTTON,
    CARD_STATE_CODE,
}CARD_DETAILS_BUTTONS;


typedef enum
{
    emp_List_Req=0,
    category_list_req,
    report_list,
}analysis_Page_Request_Type;

typedef enum
{
    TRAVEL_TRANSPORT,
    FUEL_CONVENCE_STORE,
    ASSOCIATION_ORGANIZATION,
    AUTOMOTIVE_DEALERS,
    PROFESSIONAL_SERVICE,
    RETAIL_STORES,
    EDUCATIONAL_SERVICES,
    ENTERTAINMENT_CATEGORY,
    GROCERY_STORES,
    RESTAURANTS_CATEGORY,
    HEALTHCARE_CHILDCARE_SERVICES
}EXPENCE_RULES_MERCHANT_CATEGORY;


typedef enum
{
    international_Use,
    Daily_Monthly_Limit,
    Single_Transaction_Limit,
    Merchant_Category,
    Bypass_Card_money,
    bypass_Business_Budget,
}save_spend_Rules;


typedef enum
{
    GetMemo=0, 
    GetExpense,
    Add_Memo,
    Update_Memo,
    ADD_ExpenseCategory,
    Update_Expense_Categories,
    Add_Memo_Only,
}TransactionDetail;

typedef enum
{
    LowBalanceSearch=0,
    SchedulingSearch,
    Add_Lowbalance,
    Add_scheduling,
}AutoMaticFunding;


typedef enum
{
    Setteled_txn=0,
    Expired_txn,
    Outstanding_txn,
}Transaction_Type;

typedef enum
{
    State=0,
    selectQuestion,
    emp_List,
    other,
    Category_List,
    subCategory_List,
    business_List,
    yearList,
    summarizedBy,
    alert_Read
}ComboBoxEnum;

typedef enum
{
    EMPLOYEE_PAGE=0,
    EMP_BY_EXP_PAGE,
    EMP_EXP_CAT_PAGE,
    EMP_BUSSINESS_EXP_PAGE,
    EMP_BACK_HOME,
}expAnalysisPageType;



#pragma mark - NaviGation

#define imgNAV_DoneBtn @"img_nav_done"
#define imgNAV_CancelBtn @"img_nav_cancel"
#define imgNAV_BG @"img_nav_Bar"
#define imgNav_BackButton @"img_back_btn"
#define imgNav_Slider @"imgslideView_btn"





// This Method take amount as Text and Convert it into Double Value
// and befor converting if amount contains the $ sign it removes the
// dollar sign before converting it into double value
inline static double changeTextToAmount(NSString *strAmount)
{
    double dblAmount = 0.0f;
  
        strAmount = [strAmount stringByReplacingOccurrencesOfString:@"$" withString:@""];
        
        strAmount = [strAmount stringByReplacingOccurrencesOfString:@"," withString:@""];
        
        dblAmount = [strAmount doubleValue];
    
    return dblAmount;
}


inline static NSString * languageSelectedStringForKey(NSString *strKeyValue)
{
    NSString *path = nil;
	if(1==[[NSUserDefaults standardUserDefaults] integerForKey:@"applicationLanguage"] )
    {
        path = [[NSBundle mainBundle] pathForResource:@"en" ofType:@"lproj"];
        [AppDelegate sharedAppDelegate].isSpanish=NO;
    }
    
	else if(2==[[NSUserDefaults standardUserDefaults] integerForKey:@"applicationLanguage"])
    {
        path = [[NSBundle mainBundle] pathForResource:@"es" ofType:@"lproj"];
        [AppDelegate sharedAppDelegate].isSpanish=YES;
    }
    
    
	NSBundle* languageBundle = [NSBundle bundleWithPath:path];
	NSString* str=[languageBundle localizedStringForKey:strKeyValue value:@"" table:nil];
	return str;
}



inline static BOOL digitValidationOnNumKeyboard (UITextField *textField,NSRange range, NSString  * string)
 
{
    NSCharacterSet *nonNumberSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    if ([string rangeOfCharacterFromSet:nonNumberSet].location != NSNotFound)
    {
        if ([string rangeOfString:@"."].length>0)
        {
            NSArray *number = [textField.text componentsSeparatedByString: @"."];
            if([number count]>1)
            {
                return NO;
            }else
            {
                return YES;
            }
        }else
        {
            return NO;
        }
        return YES;
    }
    
    NSArray *number = [textField.text componentsSeparatedByString: @"."];
    if([number count]>1)
    {
        NSString *value=[number objectAtIndex:1];
        for(int i=0;value.length;i++)
        {
            return YES;
        }
        
    }
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    NSUInteger length = newString.length;
    if (length<=12) {
        return YES;
    }
    if( (length==13 )&& !([string isEqualToString:@"."]))
    {
        return NO;
    }
    if(length>13 )//[string isEqualToString:@"."])
    {
        return YES;
    }
    return YES;


}

inline static int  getAlertColorForNotification (int flagValue)
{
    
    
   switch (flagValue) {
    case Auto_Funding_Faild_Alert:
    {
        return RedAlert;
    }
        break;
        
    case Card_Pending_Activation_Alert:
    {
        return RedAlert;
    }
        break;
    case Negative_Card_Balance_Alert:
    {
        return RedAlert;
    }
        break;
    case Card_Spend_Rules_Changed_Alert:
    {
        return AmberAlert;
    }
        break;
    case Funding_Rules_Changed_Alert:
    {
        return AmberAlert;
    }
        break;
    case New_card_issued_Alert:
    {
        return AmberAlert;
    }
        break;
    case Card_Profile_Updated:
    {
        return AmberAlert;
    }
        break;
    case International_Card_Transactions:
    {
        return AmberAlert;
    }
        break;
    case Low_Balance_on_Business:
    {
        return AmberAlert;
    }
        break;case Low_Balance_Cards_Alert:
    {
        return AmberAlert;
    }
        break;case Card_Transaction_Decline_Alert:
    {
        return RedAlert;
    }
        break;
    case Fradu_Alert_Alert:
    {
        return RedAlert;
    }
    break;
   case Auto_Funding_Faild_Admin:
   {
       return RedAlert;
   }
       break;
   case High_value_transaction_Alert:
   {
       return AmberAlert;
   }
       break;
   case Business_Policy_Changed:
   {
       return RedAlert;
   }
       break;
   case Bulk_Card_Request:
   {
       return AmberAlert;
   }
       break;
   case Card_Frequency_Alert:
   {
       return AmberAlert;
   }
       break;

   case Business_Profile_Update:
   {
       return GreenAlert;
   }
       break;

    default:
        return 6;
        break;
           
    }
}

inline static int  ChangeCardStatusForRequest (int flagValue)
{
    switch (flagValue) {
        case ACTIVE_CARD:
        {
            return 0;
        }
            break;
            
        case Inactive_Card:
        {
            return 1;
        }
            break;
        case BLOCKED_CARD:
        {
            return 2;
        }
            break;
        case Lost_CARD:
        {
            return 3;
        }
            break;
        case Stolen_CARD:
        {
            return 4;
        }
            break;
        case Closed_CARD:
        {
            return 5;
        }
            break;
        default:
            return 6;
            break;
    }
}



inline static NSString * AdminStatusValue (int flagValue)
{
    switch (flagValue) {
        case ACtive_Admin:
        {
            return languageSelectedStringForKey(@"Active");
        }
            break;
       
        case Blocked_Admin:
        {
            return languageSelectedStringForKey(@"Locked");
        }
            break;
        case Closed_Admin:
        {
            return languageSelectedStringForKey(@"Close");
        }
            break;
               default:
            return @"";
            break;
    }
}


inline static NSString * setFrequencyCombo (int flagValue)
{
    switch (flagValue) {
        case Daily_f:
        {
            return languageSelectedStringForKey(@"Daily");
        }
            break;
            
        case Monday_f:
        {
            return languageSelectedStringForKey(@"Monday");
        }
            break;
        case Tuesday_f:
        {
            return languageSelectedStringForKey(@"Tuesday");
        }
            break;
        case Wednesday_f:
        {
            return languageSelectedStringForKey(@"Wednesday");
        }
            break;
            
        case Thursday_f:
        {
            return languageSelectedStringForKey(@"Thursday");
        }
            break;
            
        case Friday_f:
        {
            return languageSelectedStringForKey(@"Friday");
        }
            break;
            
        case Saturday_f:
        {
            return languageSelectedStringForKey(@"Saturday");
        }
            break;
            
        case Sunday_f:
        {
            return languageSelectedStringForKey(@"Sunday");
        }
            break;
            
        case first_OM_f:
        {
            return languageSelectedStringForKey(@"1st day of Month");
        }
            break;
            
        default:
            return @"";
            break;
    }

}


inline static NSString * ChangeFrequencyData (int flagValue)
{
    switch (flagValue) {
        case Daily_f:
        {
            return languageSelectedStringForKey(@"Daily");
        }
            break;
            
        case Weekly_f:
        {
            return languageSelectedStringForKey(@"Weekly");
        }
            break;
       
        case first_OM_f:
        {
            return languageSelectedStringForKey( @"1st day of Month");
        }
            break;
        case Monthly_f:
        {
            return languageSelectedStringForKey( @"Monthly");
        }
            break;

        default:
            return languageSelectedStringForKey(@"Weekly");
            break;
    }
}


inline static NSString * CardStatusValue (int flagValue)
{
    switch (flagValue) {
        case ACTIVE_CARD:
        {
            return languageSelectedStringForKey(@"Active");
        }
            break;
        case BLOCKED_CARD:
        {
            return languageSelectedStringForKey(@"Blocked");
        }
            break;
        case Closed_CARD:
        {
            return languageSelectedStringForKey(@"Closed");
        }
            break;
        case Inactive_Card:
        {
           return languageSelectedStringForKey(@"Inactive");
        }
            break;
        case Lost_CARD:
        {
            return languageSelectedStringForKey(@"Lost");
        }
            break;
        case Stolen_CARD:
        {
            return languageSelectedStringForKey(@"Stolen");
        }
            break;
        case Pending_CARD:
        {
            return languageSelectedStringForKey(@"Pending Activation");
        }
            break;
        default:
            return @"";
            break;
    }
}


inline static BOOL checkISNullStrings(NSString *checkString)
{
    if ([checkString isKindOfClass:[NSNull class]] || [checkString isEqualToString:@"(null)"] || [checkString isEqualToString:@"(null)"] || checkString==nil) {
        return YES;
    }
    return NO;
}


//Method which tells whether given date is Future Date or not 
inline static BOOL isFutureDateWithFormat(NSString *strDate, NSString *dateFormat)
{
    BOOL isDateIsFutureDate;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:dateFormat];
    NSTimeInterval secondsBetween;
    NSDate *today = [NSDate date];
    NSDate *date = [dateFormatter dateFromString:strDate];
    secondsBetween = [today timeIntervalSinceDate:date];
    isDateIsFutureDate = secondsBetween < 0 ?YES: NO;
    return isDateIsFutureDate;
}


inline static int daysDifferenceBetweenDates(NSString *strToDate, NSString *strFromDate, NSString *dateFormat)
{
    int numberOfDays;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:dateFormat];
    NSTimeInterval secondsBetween;
    NSDate *dateFrom = [dateFormatter dateFromString:strFromDate];
    NSDate *dateTo = [dateFormatter dateFromString:strToDate];
    secondsBetween = [dateTo timeIntervalSinceDate:dateFrom];
    numberOfDays = secondsBetween / 86400;
    return numberOfDays;
//    isDateIsFutureDate = secondsBetween < 0 ?NO:YES;
//    return isDateIsFutureDate;
}


inline static BOOL validateEmailField( UITextField *emailAddressField)
{
    BOOL emailValid = NO;
    NSString *emailRegEx=EMAIL_CHECK_EXP;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
	emailValid = ([emailAddressField.text length] > 0);
    emailValid = [emailTest evaluateWithObject:emailAddressField.text];
    
    if( !([emailAddressField.text length] < 101) )
    {
//        showAlertScreen(languageSelectedStringForKey(INFO_VERIFY),languageSelectedStringForKey(@"Valid_email_message"));
        UIAlertView  *myAlert = [[UIAlertView alloc] initWithTitle:languageSelectedStringForKey (INFO_VERIFY) message:languageSelectedStringForKey(@"Valid_email_message") delegate:nil cancelButtonTitle:languageSelectedStringForKey(@"ok") otherButtonTitles:nil];
		[myAlert  show];
		[myAlert  release];
		myAlert =nil;
        emailValid = NO;
    }
    
    return emailValid;
}


inline static BOOL validateNetwork (id Self)
{
    [[Reachability sharedReachability] setHostName:@"www.google.com"];
	NetworkStatus internetStatus = [[Reachability sharedReachability] remoteHostStatus];
    if (internetStatus == ReachableViaWiFiNetwork)
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"WiFi" forKey:@"internetStatus"];
    }
	if((internetStatus != ReachableViaWiFiNetwork) && (internetStatus != ReachableViaCarrierDataNetwork))
	{
        
		UIAlertView  *myAlert = [[UIAlertView alloc] initWithTitle:languageSelectedStringForKey (@"No Connection") message:languageSelectedStringForKey(@"NETWORK_ERROR") delegate:nil cancelButtonTitle:languageSelectedStringForKey(@"ok") otherButtonTitles:nil];
		[myAlert  show];
		[myAlert  release];
		myAlert =nil;
		
		return YES;
	}
	
	return NO;
}


inline static NSString * ChangeCardNumber (NSString *cardNumber)
{
    NSInteger starUpTo = [cardNumber length] - 4;
    if (starUpTo > 0)
    {
            NSString *stars = [@"" stringByPaddingToLength:starUpTo withString:@"x" startingAtIndex:0];
            NSString *str4;
            
            if ([stars length]%4!=0&&[stars length]>8  )
            {
                str4=[NSString stringWithFormat:@"%@ %@ %@ ",[stars substringToIndex:[stars length]-8],[stars substringWithRange:NSMakeRange(3, 4)],[stars substringFromIndex:[stars length ]-4]];
            }
            else if ([stars length]%4==0&&[stars length]==8)
            {
                str4=[NSString stringWithFormat:@"%@ %@ ",[stars substringToIndex:4],[stars substringFromIndex:4]];
            }
            else if ([stars length]%4!=0&&[stars length]>4)
            {
                str4=[NSString stringWithFormat:@"%@ %@ ",[stars substringToIndex:[stars length]-4],[stars substringFromIndex:[stars length ]-4]];
            }
            else if (([stars length]%4!=0||[stars length]%4==0)&&[stars length]<=4)
            {
                str4=[NSString stringWithFormat:@"%@ ",stars];
            }
            
            else
            {
                str4=[NSString stringWithFormat:@"%@ %@ %@ ",[stars substringToIndex:4],[stars substringWithRange:NSMakeRange(4, 4)],[stars substringWithRange:NSMakeRange(8, 4)]];
            }
            return [cardNumber stringByReplacingCharactersInRange:NSMakeRange(0, starUpTo) withString:str4];
        
    } else
    {
        if (checkISNullStrings(cardNumber))
        {
            return @"";
        }
        return cardNumber;
    }
}

inline static void addNavigationBarwithStrNavFrom(NSString *strtitle,leftNavigationButtonType leftButton,rightNavigationButtonType rightButton,id delegate, NSString *strNavFrom)
{
    UIViewController *target=(UIViewController *)delegate;
    target.title = languageSelectedStringForKey(strtitle);
    // target.navigationController.navigationBar.frame = CGRectMake(0, 0, 320, (IS_IPAD?92:44));
    UILabel *lblTitle = [[[UILabel alloc] initWithFrame:CGRectMake(0,(IS_IOS7?(IS_IPAD?:30):IS_IPHONE_5?20:0), 280, (IS_IPAD?44:44))] autorelease];
    lblTitle.backgroundColor = [UIColor clearColor];
    lblTitle.font = [UIFont boldSystemFontOfSize:22.0];
    lblTitle.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    lblTitle.textAlignment = UITextAlignmentCenter;
    lblTitle.adjustsFontSizeToFitWidth=YES;
    lblTitle.textColor =[UIColor whiteColor];
    lblTitle.text = target.title;
    target.navigationItem.titleView = lblTitle;
    UIButton *btnLeft=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 44)];
    UIBarButtonItem *navBtnLeft=[[UIBarButtonItem alloc]initWithCustomView:btnLeft];
    target.navigationItem.leftBarButtonItem=navBtnLeft;
    if (leftButton == NAV_LEFT_NONE) {
        btnLeft.hidden=YES;
        lblTitle.frame=CGRectMake(-50 ,IS_IPHONE_5?20:0,230,44);
    }
    else if(leftButton == NAV_LEFT_BACK){
        [btnLeft setImage:[UIImage imageNamed:imgNav_BackButton] forState:UIControlStateNormal];
        [btnLeft addTarget:delegate action:@selector(openBack) forControlEvents:UIControlEventTouchUpInside];
    }
    else if(leftButton == NAV_LEFT_CANCEL){
        btnLeft.frame=CGRectMake(0, 7, 60, 30);
        btnLeft.titleLabel.font=[UIFont boldSystemFontOfSize:14.0f];
        [btnLeft setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        [btnLeft setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        [btnLeft setBackgroundImage:[UIImage imageNamed:imgNAV_CancelBtn] forState:UIControlStateNormal];
        [btnLeft addTarget:delegate action:@selector(openBack) forControlEvents:UIControlEventTouchUpInside];
    }
    UIView *vieww1 =[[UIView alloc] initWithFrame:CGRectMake(0, 0, 40, 44)];
    [vieww1 addSubview:btnLeft];
    
    UIBarButtonItem *btnNavSearch1=[[UIBarButtonItem alloc]initWithCustomView:vieww1];
    target.navigationItem.leftBarButtonItem = btnNavSearch1;
    [btnNavSearch1 release];
    
    UIButton *btnRight=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 44)];
    UIBarButtonItem *btnNavRight=[[UIBarButtonItem alloc]initWithCustomView:btnRight];
    UIButton *btnSearch;
    
    if (rightButton == NAV_RIGHT_NONE)
    {
        btnRight.hidden=YES;
        lblTitle.frame=CGRectMake(-150 ,IS_IPHONE_5?20:0,230,44);
    }
    else if (rightButton == NAV_RIGHT_SLIDE)
    {
        
        [btnRight setImage:[UIImage imageNamed:imgNav_Slider] forState:UIControlStateNormal];
        [btnRight addTarget:delegate action:@selector(openSlide) forControlEvents:UIControlEventTouchUpInside];
        
        
        if ([strtitle isEqualToString:CARD_TRANSACTION_TITLE] || [strtitle isEqualToString:EMP_EXPENSE_TITLE] || [strtitle isEqualToString:Business_Expense_Title] || [strtitle isEqualToString:Expense_category_Title] || [strtitle isEqualToString:Employee_Expense_category_Title])
        {
            btnSearch=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 44)];
            btnSearch.titleLabel.font=[UIFont boldSystemFontOfSize:14.0f];
            [btnSearch setBackgroundImage:[UIImage imageNamed:@"img_Date_search"] forState:UIControlStateNormal];
            [btnSearch addTarget:delegate action:@selector(opensearch) forControlEvents:UIControlEventTouchUpInside];
            
            btnRight.frame=CGRectMake(CGRectGetMaxX(btnSearch.frame), 0, 30, 44);
            
            UIView *vieww =[[UIView alloc] initWithFrame:CGRectMake(0, 0, 70, 44)];
            [vieww addSubview:btnRight];
            [vieww addSubview:btnSearch];
            btnSearch.hidden = YES;
            
            UIBarButtonItem *btnNavSearch=[[UIBarButtonItem alloc]initWithCustomView:vieww];
            target.navigationItem.rightBarButtonItem = btnNavSearch;
            
        }
        else{
            target.navigationItem.rightBarButtonItem = btnNavRight;
        }
    }
    else if (rightButton == NAV_RIGHT_DONE) {
        btnRight.frame=CGRectMake(0, 7, 60, 30);
        [btnRight setTitle:languageSelectedStringForKey(@"Done") forState:UIControlStateNormal];
        btnRight.titleLabel.font=[UIFont boldSystemFontOfSize:14.0f];
        [btnRight setBackgroundImage:[UIImage imageNamed:imgNAV_DoneBtn] forState:UIControlStateNormal];
        [btnRight addTarget:delegate action:@selector(openDone) forControlEvents:UIControlEventTouchUpInside];
        //        btnRight.hidden=NO;
        target.navigationItem.rightBarButtonItem = btnNavRight;
    }
    [btnLeft release];
    [navBtnLeft release];
    [btnRight release];
    [btnNavRight release];
}

inline static void addNavigationBar(NSString *strtitle,leftNavigationButtonType leftButton,rightNavigationButtonType rightButton,id delegate)
{
    UIViewController *target=(UIViewController *)delegate;
    target.title = languageSelectedStringForKey(strtitle);
   // target.navigationController.navigationBar.frame = CGRectMake(0, 0, 320, (IS_IPAD?92:44));
    UILabel *lblTitle = [[[UILabel alloc] initWithFrame:CGRectMake(0,(IS_IOS7?(IS_IPAD?:40):IS_IPHONE_5?20:0), 280, (IS_IPAD?44:44))] autorelease];
    lblTitle.backgroundColor = [UIColor clearColor];
    lblTitle.font = [UIFont boldSystemFontOfSize:22.0];
    lblTitle.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    lblTitle.textAlignment = UITextAlignmentCenter;
    lblTitle.adjustsFontSizeToFitWidth=YES;
    lblTitle.textColor =[UIColor whiteColor];
    lblTitle.text = target.title;
    target.navigationItem.titleView = lblTitle;
    UIButton *btnLeft=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 44)];
    UIBarButtonItem *navBtnLeft=[[UIBarButtonItem alloc]initWithCustomView:btnLeft];
    target.navigationItem.leftBarButtonItem=navBtnLeft;
    if (leftButton == NAV_LEFT_NONE) {
        btnLeft.hidden=YES;
        lblTitle.frame=CGRectMake(-50 ,IS_IPHONE_5?20:0,230,44);
    }
    else if(leftButton == NAV_LEFT_BACK){
        [btnLeft setImage:[UIImage imageNamed:imgNav_BackButton] forState:UIControlStateNormal];
        [btnLeft addTarget:delegate action:@selector(openBack) forControlEvents:UIControlEventTouchUpInside];
    }
    else if(leftButton == NAV_LEFT_CANCEL){
        btnLeft.frame=CGRectMake(0, 7, 60, 30);
        btnLeft.titleLabel.font=[UIFont boldSystemFontOfSize:14.0f];
        [btnLeft setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        [btnLeft setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        [btnLeft setBackgroundImage:[UIImage imageNamed:imgNAV_CancelBtn] forState:UIControlStateNormal];
        [btnLeft addTarget:delegate action:@selector(openBack) forControlEvents:UIControlEventTouchUpInside];
    }
    UIView *vieww1 =[[UIView alloc] initWithFrame:CGRectMake(0, 0, 40, 44)];
    [vieww1 addSubview:btnLeft];
    
    UIBarButtonItem *btnNavSearch1=[[UIBarButtonItem alloc]initWithCustomView:vieww1];
    target.navigationItem.leftBarButtonItem = btnNavSearch1;
    [btnNavSearch1 release];
    
    UIButton *btnRight=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 44)];
    UIBarButtonItem *btnNavRight=[[UIBarButtonItem alloc]initWithCustomView:btnRight];
    UIButton *btnSearch;
    
    if (rightButton == NAV_RIGHT_NONE)
    {
        btnRight.hidden=YES;
        lblTitle.frame=CGRectMake(-150 ,IS_IPHONE_5?20:0,230,44);
    }
    else if (rightButton == NAV_RIGHT_SLIDE)
    {
        
        [btnRight setImage:[UIImage imageNamed:imgNav_Slider] forState:UIControlStateNormal];
        [btnRight addTarget:delegate action:@selector(openSlide) forControlEvents:UIControlEventTouchUpInside];
        
        
        if ([strtitle isEqualToString:CARD_TRANSACTION_TITLE] || [strtitle isEqualToString:EMP_EXPENSE_TITLE] || [strtitle isEqualToString:Business_Expense_Title] || [strtitle isEqualToString:Expense_category_Title] || [strtitle isEqualToString:Employee_Expense_category_Title])
        {
            btnSearch=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 44)];
            btnSearch.titleLabel.font=[UIFont boldSystemFontOfSize:14.0f];
            [btnSearch setBackgroundImage:[UIImage imageNamed:@"img_Date_search"] forState:UIControlStateNormal];
            [btnSearch addTarget:delegate action:@selector(opensearch) forControlEvents:UIControlEventTouchUpInside];
            
            btnRight.frame=CGRectMake(CGRectGetMaxX(btnSearch.frame), 0, 30, 44);
            
            UIView *vieww =[[UIView alloc] initWithFrame:CGRectMake(0, 0, 70, 44)];
            [vieww addSubview:btnRight];
            [vieww addSubview:btnSearch];
            
            
            UIBarButtonItem *btnNavSearch=[[UIBarButtonItem alloc]initWithCustomView:vieww];
            target.navigationItem.rightBarButtonItem = btnNavSearch;
            
        } else if([strtitle isEqualToString: @"Frequency Alert"] || [strtitle isEqualToString: @"International Transactions"] || [strtitle isEqualToString: @"Low Balance on Business"] || [strtitle isEqualToString: @"Bulk Card Request/Load"] || [strtitle isEqualToString:@"Card Profile Updated"] || [strtitle isEqualToString:@"Business policy changed"] || [strtitle isEqualToString:@"High Value Transaction Alert"] || [strtitle isEqualToString:@"Auto Funding Faild (Admin Load Limit)"] || [strtitle isEqualToString:@"New Card Issued/Reissued"] || [strtitle isEqualToString:@"Funding Rules Changed"] || [strtitle isEqualToString:@"Card Spend Rules Changed"] || [strtitle isEqualToString:@"Fraud Alert"] || [strtitle isEqualToString:@"Card Transaction Decline"] || [strtitle isEqualToString:@"Negative Card Balance"] || [strtitle isEqualToString:@"Low Balance Cards"] || [strtitle isEqualToString:@"Auto Funding Faild (Low Funds)"] || [strtitle isEqualToString:@"Card Pending Activation"])
        {
            btnSearch=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 44)];
            btnSearch.titleLabel.font=[UIFont boldSystemFontOfSize:14.0f];
            [btnSearch setBackgroundImage:[UIImage imageNamed:@"img_Date_delete"] forState:UIControlStateNormal];
            [btnSearch addTarget:delegate action:@selector(markAll) forControlEvents:UIControlEventTouchUpInside];
            
            btnRight.frame=CGRectMake(CGRectGetMaxX(btnSearch.frame), 0, 30, 44);
            
            UIView *vieww =[[UIView alloc] initWithFrame:CGRectMake(0, 0, 70, 44)];
            [vieww addSubview:btnRight];
            [vieww addSubview:btnSearch];
            
            
            UIBarButtonItem *btnNavSearch=[[UIBarButtonItem alloc]initWithCustomView:vieww];
            target.navigationItem.rightBarButtonItem = btnNavSearch;

        }
        else{
            target.navigationItem.rightBarButtonItem = btnNavRight;
        }
    }
   else if (rightButton == NAV_RIGHT_DONE) {
        btnRight.frame=CGRectMake(0, 7, 60, 30);
        [btnRight setTitle:languageSelectedStringForKey(@"Done") forState:UIControlStateNormal];
        btnRight.titleLabel.font=[UIFont boldSystemFontOfSize:14.0f];
        [btnRight setBackgroundImage:[UIImage imageNamed:imgNAV_DoneBtn] forState:UIControlStateNormal];
        [btnRight addTarget:delegate action:@selector(openDone) forControlEvents:UIControlEventTouchUpInside];
        //        btnRight.hidden=NO;
        target.navigationItem.rightBarButtonItem = btnNavRight;
    }
    [btnLeft release];
    [navBtnLeft release];
    [btnRight release];
    [btnNavRight release];
}


inline static NSString * GetImageName(NSString *imageName)
{
    return [NSString stringWithFormat:@"%@.png",imageName];
}


inline static UITextField *createTextField(CGRect frame,NSString* placeholder)
{
    UITextField *txtField = [[UITextField alloc] initWithFrame:frame];
	if (![placeholder isEqualToString:@""]) {
		[txtField setPlaceholder:placeholder];
	}
    txtField.font=APP_FONT_14;
    txtField.autocapitalizationType=UITextAutocapitalizationTypeNone;
	[txtField setTextColor:[UIColor whiteColor]];
	[txtField setTextAlignment:UITextAlignmentLeft];
    return txtField;
}


inline static UIButton * createButton(CGRect frame ,NSString *title,NSString *imageName,id target,SEL action){
    UIButton *Btn=[[UIButton alloc]initWithFrame:frame];
    if (title.length>0) {
        [Btn setTitle:title forState:UIControlStateNormal];
        [Btn setTitle:title forState:UIControlStateSelected];
        Btn.titleLabel.font=APP_FONT_16;
        Btn.titleLabel.textColor=[UIColor whiteColor];
    }
    [Btn setBackgroundImage:[UIImage imageNamed:GetImageName(imageName)] forState:UIControlStateNormal];
    [Btn setBackgroundImage:[UIImage imageNamed:GetImageName(imageName)] forState:UIControlStateHighlighted];
    [Btn setBackgroundImage:[UIImage imageNamed:GetImageName(imageName)] forState:UIControlStateSelected];
    [Btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return Btn;
}


inline static UILabel * createLabel(NSString *string, CGRect rect) {
    UILabel *lbl=[[UILabel alloc]initWithFrame:rect];
    lbl.textColor=[UIColor whiteColor];
	lbl.backgroundColor=[UIColor clearColor];
	lbl.text=string;
	return lbl;
}


inline static void showAlertWithOtherButtons(NSString*title,NSString*alertMessage,int tag,id delegt){
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:alertMessage
                                                       delegate:delegt
                                              cancelButtonTitle: languageSelectedStringForKey(@"ok")
                                              otherButtonTitles: languageSelectedStringForKey(@"Cancel"), nil];
                                                                                             alertView.tag = tag;
    
    [alertView show];
    [alertView release];
}


inline static void showAlertWithOkButton(NSString*title,NSString*alertMessage,int tag,id delegt){
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:alertMessage
                                                       delegate:delegt
                                              cancelButtonTitle: languageSelectedStringForKey(@"ok")
                                              otherButtonTitles: nil];
    alertView.tag = tag;
    
    [alertView show];
    [alertView release];
}


inline static void showAlertScreen(NSString *title,NSString* alertMessage){
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:alertMessage
                                                       delegate:nil
                                              cancelButtonTitle: languageSelectedStringForKey(@"ok")
                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];
}


inline static UITableView * createTableView(CGRect frame ,id target)
{
    UITableView *tblSample= [[UITableView alloc] initWithFrame:frame];
    tblSample.dataSource=target;
    tblSample.delegate=target;
    tblSample.showsVerticalScrollIndicator=NO;
    tblSample.backgroundColor=[UIColor clearColor];
    tblSample.separatorColor=[UIColor clearColor];
    return tblSample;
}


inline static BOOL validateEmailString(NSString* email)
{
    NSString *emailRegEx=@"[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?";
    
    
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
    return [emailTest evaluateWithObject:email];
}


inline static LoginResponse *UserInfo()

{
    LoginResponse *lRes=nil;
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSData *imageData = [prefs objectForKey:USERID];
    
    if ((imageData.length>0)&&(imageData!= nil )){
        lRes = [NSKeyedUnarchiver unarchiveObjectWithData:imageData];
    }
    if (imageData != nil) {
        imageData = nil;
    }
    return lRes;
}


inline static NSString *displayCurrency(NSString *imageName)
{
    if([imageName doubleValue]<0)
        return [NSString stringWithFormat:@"($%@)",[imageName stringByReplacingOccurrencesOfString:@"-" withString:@""]];
    else
    {
        return    [NSString stringWithFormat:@"$%@",imageName];
    }
    
}


inline static unsigned long long int folderSize(NSString *folderPath)
{
    NSArray *filesArray = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:folderPath error:nil];
    NSEnumerator *filesEnumerator = [filesArray objectEnumerator];
    NSString *fileName;
    unsigned long long int fileSize = 0;
    while (fileName = [filesEnumerator nextObject]) {
        NSDictionary *fileDictionary = [[NSFileManager defaultManager] attributesOfItemAtPath:[folderPath stringByAppendingPathComponent:fileName] error:nil];
        fileSize += [fileDictionary fileSize];
    }
    return fileSize;
}


inline static NSString *getImageForDevice(NSString *imageName)
{
    if(IS_DEVICE_IPAD)
        return ([imageName stringByAppendingString:@".png"]);
    else
        return ([imageName stringByAppendingString:@".png"]);
    
}


inline static CGFloat	scaleFacterForHeight()
{
    //	if (IS_DEVICE_IPAD)
    //	{
    //		return 2.1333f;
    //	}
    
	return 1.0f;
}


inline static CGFloat	scaleFacterForWidth()
{
    //	if (IS_DEVICE_IPAD)
    //	{
    //		return 2.4f;
    //	}
	return 1.0f;
}


inline static int  getFont()
{
    if (IS_DEVICE_IPAD) {
        return 30;
    }
    return 15;
}


inline static int getAppHeight()
{
    return [[UIScreen mainScreen] applicationFrame].size.height;
}


inline static BOOL isWidescreenEnabled()
{
    
    static int isWideScreenEnabled = -1;
    if (isWideScreenEnabled == -1)
    {
        isWideScreenEnabled =(BOOL)(fabs((double)[UIScreen mainScreen].bounds.size.height -
                                         (double)568) < DBL_EPSILON);
    }
    return isWideScreenEnabled;
}


inline static UIImage * scaleAndRotateImage(UIImage *image)
{
    int kMaxResolution = 960; // Or whatever
    CGImageRef imgRef = image.CGImage;
    CGFloat width = CGImageGetWidth(imgRef);
    CGFloat height = CGImageGetHeight(imgRef);
    
    CGAffineTransform transform = CGAffineTransformIdentity;
    CGRect bounds = CGRectMake(0, 0, width, height);
    if (width > kMaxResolution || height > kMaxResolution) {
        CGFloat ratio = width/height;
        if (ratio > 1) {
            bounds.size.width = kMaxResolution;
            bounds.size.height = roundf(bounds.size.width / ratio);
        }
        else {
            bounds.size.height = kMaxResolution;
            bounds.size.width = roundf(bounds.size.height * ratio);
        }
    }
    CGFloat scaleRatio = bounds.size.width / width;
    CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
    CGFloat boundHeight;
    boundHeight = bounds.size.height;
    bounds.size.height = bounds.size.width;
    bounds.size.width = boundHeight;
    transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
    transform = CGAffineTransformRotate(transform, M_PI / 2.0);
    
    UIGraphicsBeginImageContext(bounds.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextScaleCTM(context, -scaleRatio, scaleRatio);
    CGContextTranslateCTM(context, -height, 0);
    CGContextConcatCTM(context, transform);
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return imageCopy;
}


inline static NSString * ChangeTocurrency(double amount)
{
    NSString *temp2 = [NSString stringWithFormat:@"%.2f",amount];
    
    NSArray *arr = [temp2 componentsSeparatedByString:@"."];
    NSString *temp=nil;
    if (!temp)
    {
        temp=[[NSString alloc]init];
    }else
    {
        temp=nil;
    }
    NSString *strHi = [arr objectAtIndex:0];
    
    int len = strHi.length;
    int count=0;
    for (int i=len-1; i>=0; i--)
    {
        count++;
        temp=[temp stringByAppendingString:[NSString stringWithFormat:@"%c",[strHi characterAtIndex:i]]];
        if(count%3==0)
        {
            if (i!=0)
            {
                
               // NSString *check=[NSString stringWithFormat:@"%c",[strHi characterAtIndex:i] ];
                NSString *check1=[NSString stringWithFormat:@"%c",[strHi characterAtIndex:0] ];
                
                if (strHi.length-1==count&&[check1 isEqualToString:@"-"])
                {
                    
                }else
                {
                    temp=[temp stringByAppendingString:[NSString stringWithFormat:@","]];
                }
            }
        }
    }
    
    NSString *temp1 = nil;
    if (!temp1) {
        temp1=[[NSString alloc]init];
    }else
    {
        temp1=nil;
    }
    
    len = temp.length;
    for (int i=len-1; i>=0; i--)
    {
        temp1=[temp1 stringByAppendingString:[NSString stringWithFormat:@"%c",[temp characterAtIndex:i]]];
    }
    
    if ([arr count]==2)
    {
        strHi = [arr objectAtIndex:1];
        temp1=[temp1 stringByAppendingString:[NSString stringWithFormat:@".%@",strHi]];
    }else
    {
        temp1=[temp1 stringByAppendingString:[NSString stringWithFormat:@".00"]];
    }
    return temp1;
}


inline static NSString * ConvertDateFormate(NSString *dates)
{
    
    NSArray *components = [dates componentsSeparatedByString:@" "];
    
    dates=[components objectAtIndex:0];
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [dateFormat dateFromString:dates];
    [dateFormat setDateFormat:@"dd/MM/yyyy"];
    NSString *dateVal = [dateFormat stringFromDate:date];

    return dateVal;
}


typedef enum
{
    green=0,
    yellow,
    red,
}BarChartColor;


inline static int compareBudgetFaire(double limit, double spendAmount)
{
    float compareFare=(spendAmount/limit)*100;
    
    if (compareFare<50)
    {
        return green;
    }else if(compareFare>80)
    {
        return red;
    }
    else
    {
        return yellow;
    }
}


inline static NSString * ConvertFromTimeStamp(NSString *dates)
{
    
     return [NSString stringWithFormat:@" %@:%@:%@",[dates substringToIndex:2],[[dates substringToIndex:4] substringFromIndex:2],[dates substringFromIndex:4]];
}


inline static NSString * removeFirstSpaces(NSString *dates)
{
    if ([dates hasPrefix:@" "] && [dates length] > 1)
    {
        dates = [dates substringFromIndex:1];
    }
    
    if ([dates hasPrefix:@" "] && [dates length] > 1)
    {
        dates = [dates substringFromIndex:1];
    }
    
    dates=[dates stringByReplacingOccurrencesOfString:@"  " withString:@" "];
    
    return [dates stringByReplacingOccurrencesOfString:@"  " withString:@" "];
}


inline static NSString * ConvertDateFormatemmddyyyy(NSString *dates)
{
    
    NSArray *components = [dates componentsSeparatedByString:@" "];
    
    dates=[components objectAtIndex:0];
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
    [dateFormat setDateFormat:@"MM/dd/yyyy"];
    NSDate *date = [dateFormat dateFromString:dates];
    [dateFormat setDateFormat:@"dd/MM/yyyy"];
    NSString *dateVal = [dateFormat stringFromDate:date];
    
    return dateVal;
}


inline static NSDate * GetDateFromSTring(NSString *date)
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    // this is imporant - we set our input date format to match our input string
    // if format doesn't match you'll get nil from your string, so be careful
    [dateFormatter setDateFormat:@"MM-dd-yyyy"];
    NSDate *dateFromString = [[NSDate alloc] init];
    // voila!
    dateFromString = [dateFormatter dateFromString:date];
    [dateFormatter release];
    return dateFromString;
}


inline static NSString * getStringFromDate(NSDate *date)
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MM-dd-YYYY"];
    return [dateFormatter stringFromDate:date];
}


inline static NSString * RemoveExtraSpace(NSString *datastring)
{
    datastring = [datastring stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return datastring;
}


inline static int getHeight(int y)
{
    if (IS_IPHONE_5)
    {
        return y;
    }
    CGRect screenBound = [[UIScreen mainScreen] bounds];
    CGSize screenSize = screenBound.size;
    CGFloat screenHeight = screenSize.height;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad && [[UIScreen mainScreen] respondsToSelector:@selector(scale)] && [UIScreen mainScreen].scale > 1)
    {
        return y*(screenHeight/440);
    }else if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        return y*(screenHeight/440);
    }
    return y*(screenHeight/480);
}


inline static int getWidth(int x)
{
    if (IS_IPHONE_5)
    {
        return x;
    }
    CGRect screenBound = [[UIScreen mainScreen] bounds];
    CGSize screenSize = screenBound.size;
    CGFloat screenWidth = screenSize.width;
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad && [[UIScreen mainScreen] respondsToSelector:@selector(scale)] && [UIScreen mainScreen].scale > 1)
    {
        return x*(screenWidth/320);
    }else if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        return x*(screenWidth/320);
    }
    return x*(screenWidth/320);
}


//width =  [cell.lbldistance.text sizeWithFont:(CheckdeviceType()==IPHONE_DEVICE || CheckdeviceType()==IPHONE_RETINA_DEVICE)?FONT_14:FONT_40].width;
//frame=cell.lbldistance.frame;
//cell.lbldistance.frame=CGRectMake(frame.origin.x, frame.origin.y, width, frame.size.height);
inline static UILabel *createLable(CGRect frame,UIFont *fonts)
{
    UILabel *txtField = [[UILabel alloc] initWithFrame:frame];
    txtField.font=fonts;
    txtField.backgroundColor=[UIColor clearColor];
    return txtField;
}


inline static NSString *getCurrentDate()
{
    NSDate *currDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"MM-dd-YYYY"];
    NSString *dateString = [dateFormatter stringFromDate:currDate];
    return dateString;
}


inline static NSString *dateForAnalysis(NSString *date)
{
    return [date stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
}


inline static NSDate * returnDateForMonth(NSInteger month, NSInteger year, NSInteger day)
{
    
    NSDateComponents *components = [[NSDateComponents alloc] init];
    
    [components setDay:day];
    [components setMonth:month];
    [components setYear:year];
    
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSGregorianCalendar];
    return [gregorian dateFromComponents:components];
}


inline static NSDate* returnDate(NSDate *date,int dayType)
{
    NSCalendar * calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    unsigned unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit;
    NSDateComponents *comps = [calendar components:unitFlags fromDate:date];
    
    NSDate * getDate = nil;
    
    switch (dayType) {
        case CurrentMonth_First:
            getDate = returnDateForMonth(comps.month,comps.year,1);
            break;
            
        case CurrentMonth_Lats:
            getDate =returnDateForMonth(comps.month+1,comps.year,0);
            break;
            
        case LastMonth_First:
            getDate =returnDateForMonth(comps.month-1,comps.year,1);
            break;
            
        case LastMonth_last:
            getDate =returnDateForMonth(comps.month,comps.year,0);
            break;
            
        default:
            break;
    }
    return getDate;
}


typedef enum
{
    Q1=0,
    Q2,
    Q3,
    Q4,
    
}quarter;


inline static int getCurrentQuarter(int month)
{
    int quarter ;
    
    if (month >= 1 && month <= 3)
    {
        quarter = Q4;
    }
    if (month >= 4 && month <= 6)
    {
        quarter = Q1;
    }
    if (month >= 7 && month <= 9)
    {
        quarter = Q2;
    }
    if (month >= 10 && month <= 12)
    {
        quarter = Q3;
    }
    
    return quarter;
}

inline static NSString* getWeekFirstLastDate(NSString *strDateIndicator)
{
    NSDate *today = [NSDate date];
    NSCalendar *gregorian = [[NSCalendar alloc]        initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [gregorian components:NSWeekdayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
    
    int dayofweek = [[[NSCalendar currentCalendar] components:NSWeekdayCalendarUnit fromDate:today] weekday];// this will give you current day of week
    
    [components setDay:([components day] - ((dayofweek) - 2))];// for beginning of the week.
    NSDate *beginningOfWeek = [gregorian dateFromComponents:components];
    NSDateComponents *dayComponent = [[NSDateComponents alloc] init];
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"MM-dd-yyyy"];// you can use your format.
    NSString *strRequirdDate = @"";
    
    if ([strDateIndicator isEqualToString:@"BeginningOfCurrentWeek"])
    {
        dayComponent.day = 0;
        beginningOfWeek = [gregorian dateByAddingComponents:dayComponent toDate:beginningOfWeek options:0];
        strRequirdDate = [dateFormat stringFromDate:beginningOfWeek];
    }
    else if([strDateIndicator isEqualToString:@"EndOfCurrentWeek"])
    {
//        dayComponent.day = 6;
//        NSDate *dateEndOfWeek = [gregorian dateByAddingComponents:dayComponent toDate:beginningOfWeek options:0];
        strRequirdDate = [dateFormat stringFromDate:today];
    }
    else if ([strDateIndicator isEqualToString:@"EndOfLastWeek"])
    {
        dayComponent.day = -1;
        NSDate *dateEndOfLastWeek = [gregorian dateByAddingComponents:dayComponent toDate:beginningOfWeek options:0];
        strRequirdDate = [dateFormat stringFromDate:dateEndOfLastWeek];
    }
    else if ([strDateIndicator isEqualToString:@"BeginningOfLastWeek"])
    {
        dayComponent.day = -7;
        NSDate *dateBeginningOfLastWeek = [gregorian dateByAddingComponents:dayComponent toDate:beginningOfWeek options:0];
        strRequirdDate = [dateFormat stringFromDate:dateBeginningOfLastWeek];
    }
    return strRequirdDate;
}


inline static NSString* getQuarterDate(BOOL isStart)
{
    
    NSDate *date = [NSDate date];
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [calendar components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) fromDate:date];
    NSInteger month = [components month];
    NSInteger year = [components year];
    
    int quarter;
    
    NSString * startMonth = @"0";
    int startYear=year;
    NSString * startDay = @"01";
    NSString *endMonth = @"0";
    int endYear=year;
    NSString * endDay = @"31";
    
    quarter=getCurrentQuarter(month);
    
    switch (quarter) {
        case Q1:
            startMonth = @"01";
            endMonth = @"03";
            endDay = @"30";
            break;
            
        case Q2:
            startMonth = @"04";
            endMonth = @"06";
            break;
            
        case Q3:
            startMonth = @"07";
            endMonth =@"09";
            endDay = @"30";
            break;
            
        case Q4:
            startMonth = @"10";
            startYear =year-1;
            endMonth = @"12";
            endYear=year-1;
        break;
    }
    
    if (isStart)
    {
        return [NSString stringWithFormat:@"%@-%@-%d", startMonth, startDay, startYear];
    }else
    {
        return [NSString stringWithFormat:@"%@-%@-%d", endMonth, endDay ,endYear];
    }
    
}



inline static CGFloat getTextWidth(NSString *text, UIFont *fonts)
{
    return [text sizeWithFont:fonts].width;
}


inline static UIImageView *createImageview(CGRect frame , NSString * image)
{
    UIImageView *imgVw = [[UIImageView alloc] initWithFrame:frame];
    imgVw.image = [UIImage imageNamed:image];
    return imgVw;
}


inline static NSString * removeOtherSymbolsFromString(NSString *strValue)
{
//    if ([strValue rangeOfString:@"("].length>0) {
//        strValue=[strValue stringByReplacingOccurrencesOfString:@"(" withString:@""];
//    }
//    if ([strValue rangeOfString:@")"].length>0) {
//        strValue=[strValue stringByReplacingOccurrencesOfString:@")" withString:@""];
//    }
//    if ([strValue rangeOfString:@"-"].length>0) {
//        strValue=[strValue stringByReplacingOccurrencesOfString:@"-" withString:@""];
//    }
    return strValue;
}
inline static NSString * changePhoneNumberToUS(NSString * number)
{
//    NSMutableString *stringts = [NSMutableString stringWithString:number];
//    [stringts insertString:@"(" atIndex:0];
//    [stringts insertString:@")" atIndex:4];
//    [stringts insertString:@"-" atIndex:5];
//    [stringts insertString:@"-" atIndex:9];
    return number;
}



#pragma mark - Help Menu Images and Text

typedef enum
{
    ABOUT=0,
    CONTACT,
    FAQ,
    TERM_CONDITION,
    RECOMMEND,
    SELECT_LANG,
    MORE_OPTION,
}HELP_MENU;


typedef enum
{
    
    BANK_NAME = 0,
    BANK_NUMBER,
    TRANSFER_TYPE,
    Change_Status_Admin,
    
}transferMethodType;


//enum for cell height
typedef enum
{
    SMALL_HEIGHT=80,
    MEDIUM_HEIGHT=115,
    BETWEEN_MEDIUM_AND_LARGE_HEIGHT=100,
    LARGE_HEIGHT=130,
}cellHeight;



#define imgHelp_About @"login-registerbtn"
#define imgHelp_Contact @"logincontact-icon"
#define imgHelp_FAQ @"img_help_faq"
#define imgHelp_TERMCondition @"img_help_T&c"
#define imgHelp_Recommend @"img_help_recommend"
#define imgHelp_SelectLang @"img_help_Lang"
#define imgHelp_Help @"login-help"
#define imgHelp_More @"login-more-icon"
#define imgHelp_Tab_footer @"img_help_footer_line"
#define imgHelp_Footer_BG @"login-footer"


#define txtHelp_About @"About"
#define txtHelp_Contact @"Contact"
#define txtHelp_Faq @"FAQs"
#define txtHelp_Term_Condition @"T&Cs"
#define txtHelp_Recommend @"Recommend"
#define txtHelp_Select_language @"Select Language"
#define txtHelp_More @"More"


#pragma mark - AlertText

#define ALERT_APPROVAL @"Approval Pending"
#define ALERT_LOW_BALANCE @"Low card balance"
#define ALERT_BUDGET_REACHED @"Company budget reached"

#define DATE_ALERT @"First Date should be greater then or equal to Last date."
// Alert Name Array Card_Pending_Activation_Alert
#define ALERT_CARD_PENDING_ACTIVATION @"Card Pending Activation" //RED
#define ALERT_AUTO_FUNDING_FAILD_LOW_FUNDS @"Auto Funding Faild (Low Funds)" //RED
#define ALERT_LOW_BALANCE_CARDS @"Low Balance Cards"
#define ALERT_NEGATIVE_CARD_BALANCE @"Negative Card Balance"
#define ALERT_CARD_TRANSACTION_DECLINE @"Card Transaction Decline" //RED
#define ALERT_FRAUD_ALERT @"Fraud Alert"
#define ALERT_CARD_SPEND_RULES_CHANGED @"Card Spend Rules Changed"
#define ALERT_FUNDING_RULES_CHANGED @"Funding Rules Changed"
#define ALERT_NEW_CARD_ISSUED_REISSUED @"New Card Issued/Reissued"
#define ALERT_AUTO_FUNDING_FAILED_ADMIN_LOAD_LIMIT @"Auto Funding Faild (Admin Load Limit)"  //RED
#define ALERT_HIGH_VALUE_TRANSACTION @"High Value Transaction Alert"
#define ALERT_BUSINESS_POLICY_CHANGED @"Business policy changed"
#define ALERT_CARD_PROFILE_UPDATE @"Card Profile Updated"
#define ALERT_BUSINESS_PROFILE_UPDATE @"Business Profile Update"
#define ALERT_BULK_CARD_REQUEST_LOAD @"Bulk Card Request/Load"
#define ALERT_LOW_BALANCE_ON_BUSINESS @"Low Balance on Business"
#define ALERT_INTERNATIONAL_TRANSACTIONS @"International Transactions"
#define ALERT_FREQUENCY @"Frequency Alert"
//#define

