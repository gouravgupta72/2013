//
//  MerchantCategoryCell.m
//  CoreMoney
// class use for create cell for merchant category

#import "MerchantCategoryCell.h"

@implementation MerchantCategoryCell
@synthesize lblTitle,lblDailyLimit,lblMonthluLimit,lblSubTitle,slider,txtDailyLimit,txtMonthlyLimit,delegate;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        delegate = del;
        lblTitle = createLabel(@"Travel/Transportation", CGRectMake(20, 10, 220, 37));
        lblTitle.numberOfLines = 2;
        lblTitle.font = FONT_ARIAL_17;
        lblTitle.textColor = [UIColor blackColor];
        [self addSubview:lblTitle];

        lblSubTitle = createLabel(@"Hotels, rental car agencies, tolls, buses, railroads, taxis and airlines", CGRectMake(20, 42, 275, 35));
        lblSubTitle.font = FONT_ARIAL_12;
        lblSubTitle.numberOfLines = 2;
        lblSubTitle.textColor = [UIColor lightGrayColor];
        [self addSubview:lblSubTitle];

        lblDailyLimit = createLabel(@"Daily limit", CGRectMake(20, 90, 88, 20));
        lblDailyLimit.textColor = [UIColor lightGrayColor];
        lblDailyLimit.font = FONT_ARIAL_17;
        [self addSubview:lblDailyLimit];

        
        lblMonthluLimit = createLabel(@"Monthly limit", CGRectMake(162, 90, 103, 20));
        lblMonthluLimit.textColor = [UIColor lightGrayColor];
        lblMonthluLimit.font = FONT_ARIAL_17;
        [self addSubview:lblMonthluLimit];
        
        slider = [[UISwitch alloc] initWithFrame:CGRectMake(219, 17, 79, 27)];
        [slider addTarget:self action:@selector(switchingBtn:) forControlEvents:UIControlEventValueChanged];
        [self addSubview:slider];
        
        
        UIImageView *imgBgdaily = createImageview(CGRectMake(20, 121, 113, 40), @"img_inputbg_Expense.png");
    
        [self addSubview:imgBgdaily];
        [imgBgdaily release];
        
        txtDailyLimit = createTextField(CGRectMake(22, 131, 109, 20), @"");
        txtDailyLimit.textAlignment = UITextAlignmentRight;
        txtDailyLimit.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        txtDailyLimit.font = FONT_ARIAL_17;
        txtDailyLimit.returnKeyType = UIReturnKeyNext;
        txtDailyLimit.textColor = [UIColor blackColor];
        
    
        [self addSubview:txtDailyLimit];
        
        UIImageView *imgBgMonth =  createImageview(CGRectMake(162, 121, 113, 40), @"img_inputbg_Expense.png");
        [self addSubview:imgBgMonth];
        [imgBgMonth release];
        
        txtMonthlyLimit = createTextField(CGRectMake(164, 131, 109, 20), @"");
        txtMonthlyLimit.textAlignment = UITextAlignmentRight;
        txtMonthlyLimit.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        txtMonthlyLimit.font = FONT_ARIAL_17;
        txtMonthlyLimit.returnKeyType = UIReturnKeyDone;
        txtMonthlyLimit.textColor = [UIColor blackColor];
        [self addSubview:txtMonthlyLimit];
        
        [self addSubview:createImageview(CGRectMake(9, 177, 284, 1), @"img_Line_FUID.png")];
        
        
    }
    return self;
}

-(void) dealloc
{
    [lblSubTitle release];
    [lblTitle release];
    [lblMonthluLimit release];
    [lblDailyLimit release];
    [slider release];
    
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void) switchDelegateMethod:(id) sender{}

-(void) switchingBtn:sender
{
    UISwitch *swch = (UISwitch *)sender;
    if ([delegate respondsToSelector:@selector(switchDelegateMethod:)]) {
        [delegate switchDelegateMethod:swch];
    }
}
@end
