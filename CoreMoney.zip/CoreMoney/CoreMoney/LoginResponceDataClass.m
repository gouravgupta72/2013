//
//  LoginResponceDataClass.m
//  CoreMoney

// Hold data of login request.
#import "LoginResponceDataClass.h"

@implementation LoginResponceDataClass
@synthesize Error_Code,ErrorMsg,Error_Found;

-(void)dealloc
{
    self.ErrorMsg=nil;
    [super dealloc];
}
@end
