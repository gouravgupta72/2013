//
//  alertGroupCount.h
//  CoreMoney

// Class used for Keeping Alert color group data
#import <Foundation/Foundation.h>

@interface alertGroupCount : NSObject
{
    NSString *alertColorName;
    int alertTag,alertCount;
}
@property(nonatomic,retain)NSString *alertColorName;
@property int alertTag, alertCount;
@end
