//
//  ForgotPasswordViewController.m


#import "ForgotPasswordViewController.h"

@interface ForgotPasswordViewController ()
-(void)openBack;
-(BOOL)checkEmptyTextField;
-(void)openDone;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(void)sendForgetPasswordRequest:(NSString *)parameters;
@end

@implementation ForgotPasswordViewController

-(void)openBack
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(BOOL)checkEmptyTextField
{
    if ([self.txtSecretAnswer.text length]==0) {
        [self.txtSecretAnswer becomeFirstResponder];
        showAlertScreen(@"Bank A/C", @"Please enter bank account");
        return YES;
    }
    else if ([self.txtUserID.text length]==0) {
        [self.txtUserID becomeFirstResponder];
        showAlertScreen(@"Answer", @"Please enter User ID");
        return YES;
    }
    return NO;
}
-(void)openDone
{
    if ([self checkEmptyTextField] == NO) {
        NSString *strParameter = [NSString stringWithFormat:@"USER_ID=%@&SetFlag=%@",self.txtUserID.text,self.txtSecretAnswer.text];
        
        [self sendForgetPasswordRequest:strParameter];
    }
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        addNavigationBar(FORGOT_PASSWORD, NAV_LEFT_BACK, NAV_RIGHT_DONE, self);
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _txtSecretAnswer.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
}
-(void)viewWillAppear:(BOOL)animated
{
//    NavigationBarStyle();
    [self.navigationController setNavigationBarHidden:NO];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_txtUserID release];
    [_txtSecretAnswer release];
    [_txtEmail release];
    [_myScrollView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setTxtUserID:nil];
    [self setTxtEmail:nil];
    [self setTxtSecretAnswer:nil];
    [self setMyScrollView:nil];
    [super viewDidUnload];
}

#pragma mark - Request Delegate Methods
-(void)sendForgetPasswordRequest:(NSString *)parameters
{
}
#pragma mark - UITextField Delegate Method
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isEqual:_txtSecretAnswer]) {
        [_txtUserID becomeFirstResponder];
    }
    else if ([textField isEqual:_txtUserID])
    {
        [_txtUserID resignFirstResponder];
    }
    return YES;
}

@end
