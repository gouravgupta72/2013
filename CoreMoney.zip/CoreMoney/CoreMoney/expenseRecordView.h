//
//  expenseRecordView.h
//  CoreMoney

#import <UIKit/UIKit.h>
#import "expenseAnalyisCell.h"
@interface expenseRecordView : UIView< UITableViewDataSource,UITableViewDelegate>
{
    UITableView *tblRecord;
    int analysisType;
    NSMutableArray *dataArray;
    int selectedPeriod;
    
    int searchByEmployee;
    int searchByCategory;
}
//- (id)initwithExpenseRecordFrame:(CGRect)frame analysisType:(int)analysis analysisSubType:(int)analysisSubCat dataArray:(NSMutableArray*)analysisArray period:(int)period;
- (id)initwithExpenseRecordFrame:(CGRect)frame analysisType:(int)analysis dataArray:(NSMutableArray*)analysisArray period:(int)period searchForEmployee:(int) searchByEmployee searchForCategory:(int)searchByCategory;
@end
