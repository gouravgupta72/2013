//
//  employeeExpenseDataClass.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface employeeExpenseDataClass : NSObject
{
    NSMutableArray *employeeExpenseArray;
    double CardSpendTotal;
}
@property (nonatomic,assign) NSMutableArray *employeeExpenseArray;
@property double CardSpendTotal;
@end
