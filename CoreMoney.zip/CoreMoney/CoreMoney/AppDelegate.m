//
//  AppDelegate.m



#import "AppDelegate.h"

#import "LoginViewController.h"
#import "HomeViewController.h"
#import "ExpenseRulesViewController.h"
#import "AlertsDetailViewController.h"


@implementation AppDelegate
@synthesize naviGationController,lview,isSlideViewVisible,isIphone5,classType,screenWidth,screenHeight,selectedDate,arrBusinessData,HomePageIndexNo, CardDetailPageIndex,arrCardDetailArray,isSpanish,ArraybankList,Arraytransfer,ArrayAdmin,isNotification;
@synthesize notificationTag,notificationType, isUserLogin, isInactive;

- (void)dealloc
{
    [_window release];
    [_loginviewController release];
    [super dealloc];
}

+(AppDelegate *)sharedAppDelegate{
    return (AppDelegate *)[UIApplication sharedApplication].delegate;
}
//method to add login page
-(void)addLoginPage
{    
//    ExpenseRulesViewController * ervc = [[ExpenseRulesViewController alloc] initWithNibName:@"ExpenseRulesViewController" bundle:nil ];
    
    self.loginviewController = [[[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil] autorelease];
    naviGationController = [[UINavigationController alloc] initWithRootViewController:self.loginviewController];
    naviGationController.delegate = self;
    self.window.rootViewController = naviGationController;
    [self.window makeKeyAndVisible];
}
//method to add home page
-(void)addHomePage
{
     self.homeviewController = [[[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil] autorelease];
    naviGationController = [[UINavigationController alloc] initWithRootViewController:self.homeviewController];
    naviGationController.delegate = self;
    self.window.rootViewController = naviGationController;
    [self.window makeKeyAndVisible];
}
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    
}
- (void)application:(UIApplication *)application
didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSString* dataDesc = [[NSMutableString alloc] initWithString:[deviceToken description]];
//    NSLog(@"dataDesc---%@",dataDesc);
    [SystemConfiguration sharedSystemConfig].deDeviceId=dataDesc;

    [dataDesc release];
    
    [[NSUserDefaults standardUserDefaults] setObject:dataDesc forKey:@"DeviceToken"];
}
-(void) getRequest
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
    dataParsing.Datadelegate=self;

//    if ([AppDelegate sharedAppDelegate].notificationTag == Card_Pending_Activation_Alert)
//    {
//        [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
//        [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
//        
//        [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=&deBsAccountNumber=&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=%d&deBusinessName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,Pending_CARD,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBACardHolderList];
//        
//    }
//    else{
    
        [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
        [SystemConfiguration sharedSystemConfig].dbbServiceName=ALERT_DISPLAY_REQUEST;
        
        [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deANAuserid=%@&deAlertType=%d&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[AppDelegate sharedAppDelegate].notificationTag,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcSpendCardBAAlertDisplay];
        
//    }

}
#pragma mark - Response Methods
-(void) getResponce:(id)jsonData
{
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    
    if ([jsonData isKindOfClass:[NSArray class]])
    {
        if ([jsonData count]>0)
        {
            AlertsDetailViewController *advc = [[AlertsDetailViewController alloc] initWithNibName:@"AlertsDetailViewController" bundle:nil alertType:[AppDelegate sharedAppDelegate].notificationTag array:jsonData alertGroup:getAlertColorForNotification([AppDelegate sharedAppDelegate].notificationTag)];
            [[AppDelegate sharedAppDelegate].naviGationController pushViewController:advc animated:YES];
            [advc release];
            [AppDelegate sharedAppDelegate].notificationTag = 0;
        }
        
    }
    else
    {
        AlertsDetailViewController *advc = [[AlertsDetailViewController alloc] initWithNibName:@"AlertsDetailViewController" bundle:nil alertType:[AppDelegate sharedAppDelegate].notificationTag array:nil alertGroup:getAlertColorForNotification([AppDelegate sharedAppDelegate].notificationTag)];
        [[AppDelegate sharedAppDelegate].naviGationController pushViewController:advc animated:YES];
        [advc release];
        [AppDelegate sharedAppDelegate].notificationTag = 0;
        showAlertScreen(@"", @"No records found");
    }
    
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    NSDictionary *result = nil;
    if ([result isKindOfClass:[NSDictionary class]]) {
    
        id address_components=[result valueForKey:@"address_components"];
        
        if ([address_components isKindOfClass:[NSArray class]])
        {
            for (int i=0; i<[address_components count]; i++)
            {
                if(![[[address_components objectAtIndex:i] valueForKey:@"long_name"] isKindOfClass:[NSNull class]])
                {
//                     id long_name=[[address_components objectAtIndex:i] valueForKey:@"long_name"];
                }
                if(![[[address_components objectAtIndex:i] valueForKey:@"short_name"] isKindOfClass:[NSNull class]])
                {
//                    id short_name=[[address_components objectAtIndex:i] valueForKey:@"short_name"];
                }
                if(![[[address_components objectAtIndex:i] valueForKey:@"types"] isKindOfClass:[NSNull class]])
                {
                    id types=[[address_components objectAtIndex:i] valueForKey:@"types"];
                    if ([types isKindOfClass:[NSArray class]])
                    {
                        for (int j=0; j<[types count]; j++)
                        {
                            
                        }
                        
                    }
                }
            }
        }
    }
    
}



- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
//    NSLog(@"%@",userInfo);
    
        NSDictionary *dict = [userInfo objectForKey:@"aps"];
        
        [AppDelegate sharedAppDelegate].notificationType = [dict objectForKey:@"type"];
        [AppDelegate sharedAppDelegate].notificationTag = [[dict objectForKey:@"tag"] intValue];
        [AppDelegate sharedAppDelegate].isNotification = YES;
    if ([AppDelegate sharedAppDelegate].isInactive == YES)
    {
        if (![AppDelegate sharedAppDelegate].isUserLogin)
        {
            [self addLoginPage];
        }
        else
        {
            [self getRequest];
        }
    }else
    {
        showAlertWithOtherButtons(nil, @"You have a new Notification", 0, self);
    }
}

#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
        if (buttonIndex == 0)
        {
            if (![AppDelegate sharedAppDelegate].isUserLogin)
            {
                [self addLoginPage];
            }
            else
            {
                [self getRequest];
            }
        }
}

static void uncaughtExceptionHandler(NSException *exception)
{
    NSLog(@"Uncaught:Crash:%@", [exception description]);
    NSLog(@"callStackSymbols:crash:%@",[exception callStackSymbols]);
 }

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
//    [UIApplication sharedApplication].applicationIconBadgeNumber=0;
//    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    
    
    [AppDelegate sharedAppDelegate].isInactive = NO;
    
    int notificationTypes = (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert);
    
    if ([[NSUserDefaults standardUserDefaults] stringForKey:@"DeviceToken"] != nil)
    {
        [SystemConfiguration sharedSystemConfig].deDeviceId=[[NSUserDefaults standardUserDefaults] stringForKey:@"DeviceToken"];
    }else
    {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:notificationTypes];
    }
    
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    
    float version2 = [[[UIDevice currentDevice] systemVersion] floatValue];
    UIImage *imageBack = [UIImage imageNamed:@"img_nav_Bar.png"];
    if (version2>=7.0)
    {
        imageBack = [UIImage imageNamed:@"img_nav_Bar_ios7.png"];
    }
    [[UINavigationBar appearance] setBackgroundImage:imageBack forBarMetrics:UIBarMetricsDefault];
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];

    [AppDelegate sharedAppDelegate].screenWidth=screenBounds.size.width;
    [AppDelegate sharedAppDelegate].screenHeight=screenBounds.size.height;
    [AppDelegate sharedAppDelegate].isIphone5=isWidescreenEnabled();
    notificationType = nil;
    notificationTag = 0;
    [AppDelegate sharedAppDelegate].isNotification = NO;
    if ([[NSUserDefaults standardUserDefaults] integerForKey:@"applicationLanguage"]==0)
    {
         [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"applicationLanguage"];
    }
    if (![AppDelegate sharedAppDelegate].isUserLogin)
    {
        [self addLoginPage];
    }
    else{
        [self addHomePage];
    }
    self.lview=[[loadingView alloc] initWithMyFrame:CGRectMake(0, 0, [AppDelegate sharedAppDelegate].screenWidth,[AppDelegate sharedAppDelegate].screenHeight)];
    
    return YES;
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    
    [AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:20,[UIScreen mainScreen].applicationFrame.size.width , IS_IPAD?IS_IOS7?44:92:44);
    
    [AppDelegate sharedAppDelegate].naviGationController.navigationBar.transform = CGAffineTransformMakeScale([UIScreen mainScreen].applicationFrame.size.width / 320.0f, [UIScreen mainScreen].applicationFrame.size.height / 480.0f);
    
 
    viewController.view.transform = CGAffineTransformMakeScale([UIScreen mainScreen].applicationFrame.size.width / 320.0f, [UIScreen mainScreen].applicationFrame.size.height / 480.0f);
    
}
// method use for add loading view
-(void)addLoginLoadingView
{
    if ([self.lview isDescendantOfView:self.window]) {
        [self.lview removeFromSuperview];
    }
    self.lview.lblMsg.text=@"Log In...";
    [self.lview.activityIndicator startAnimating];
    [self.window addSubview:self.lview];
}
// method use for add loading view
-(void)addloadingView
{
    if ([self.lview isDescendantOfView:self.window]) {
        [self.lview removeFromSuperview];
    }
    self.lview.lblMsg.text=@"Loading...";
    [self.lview.activityIndicator startAnimating];
    [self.window addSubview:self.lview];
}
// method use for remove loading view
-(void)removeLoadingView
{
    if ([self.lview isDescendantOfView:self.window]) {
        [self.lview.activityIndicator stopAnimating];
        [self.lview removeFromSuperview];
    }
}                 

- (void)applicationWillResignActive:(UIApplication *)application
{
     [AppDelegate sharedAppDelegate].isInactive = YES;
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    [AppDelegate sharedAppDelegate].isInactive = YES;
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application
{
   // [self navigationController:naviGationController willShowViewController:naviGationController.topViewController animated:YES];
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

-(void) navigationScaleSet
{
    //UIViewController *view = naviGationController.topViewController;
    [AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:20,[UIScreen mainScreen].applicationFrame.size.width , IS_IPAD?IS_IOS7?44:92:44);
    [AppDelegate sharedAppDelegate].naviGationController.navigationBar.transform = CGAffineTransformMakeScale([UIScreen mainScreen].applicationFrame.size.width / 320.0f, [UIScreen mainScreen].applicationFrame.size.height / 480.0f);
    
}
- (void)applicationDidBecomeActive:(UIApplication *)application
{
    
    [AppDelegate sharedAppDelegate].isInactive = NO;
    [self performSelector:@selector(navigationScaleSet) withObject:nil afterDelay:0.0];
   // [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setNavigationScaling:) name:UIKeyboardWillShowNotification object:nil];
    
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
