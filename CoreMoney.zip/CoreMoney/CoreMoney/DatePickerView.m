//
//  DatePickerView.m


#import "DatePickerView.h"

@implementation DatePickerView
@synthesize btnFirstDate,btnLastDate,lblLastDate,lblFirstDate,strFirstDate,strLastDate,minAmount,maxAmount,strDescription,delegate;

- (id)initWithDatePickerViewFrame:(CGRect)frame delegate:(id)del fDate:(NSString *)firstDate lDate:(NSString *)lastDate minimumAmount:(NSString *)min maximumAmount:(NSString *)max description:(NSString *)desc
{
    self = [super initWithFrame:frame];
    
    
//    NSLog(@"%@",desc);
    self.layer.cornerRadius=5.0f;
    self.layer.masksToBounds=YES;
    self.layer.borderColor=Name_color_Code.CGColor;
    self.layer.borderWidth=1.0f;
    self.backgroundColor=[UIColor whiteColor];
    
    if (!self.strFirstDate)
    {
        self.strFirstDate=[[NSString alloc]init];
    }
        self.strFirstDate=firstDate;
    
    if (!self.strLastDate)
    {
        self.strLastDate=[[NSString alloc]init];
    }
        self.strLastDate=lastDate;
    
    if (!self.minAmount)
    {
        self.minAmount=[[NSString alloc]init];
    }
    self.minAmount=min;
    
    if (!self.maxAmount)
    {
        self.maxAmount=[[NSString alloc]init];
    }
    self.maxAmount=max;
    
    if (!self.strDescription)
    {
        self.strDescription=[[NSString alloc]init];
    }
    self.strDescription=desc;
    
    
    if (self)
    {
        self.delegate=del;
        
        UIView *topTitleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, 30)];
        topTitleView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [self addSubview:topTitleView];
        [topTitleView release];
        
        UILabel *lblTitle = createLabel(languageSelectedStringForKey(@"Search"), CGRectMake(5, 0, frame.size.width-10, 30));
        lblTitle.backgroundColor=[UIColor clearColor];
        lblTitle.textColor=[UIColor whiteColor];
        lblTitle.font=[UIFont systemFontOfSize:18];
        lblTitle.textAlignment=NSTextAlignmentCenter;
        [topTitleView addSubview:lblTitle];
        [lblTitle release];
        
        UILabel *lblText=createLabel(languageSelectedStringForKey(@"From"), CGRectMake(10, CGRectGetMaxY(topTitleView.frame)+12, 50, 30));
        lblText.textColor=[UIColor grayColor];
        lblText.backgroundColor=[UIColor clearColor];
        [self addSubview:lblText];
        [lblText release];


        UIImageView *bgImgae=[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lblText.frame), CGRectGetMaxY(topTitleView.frame)+12, 90, 30)];
        bgImgae.image=[UIImage imageNamed:@"img_Search_text_bg"];
        bgImgae.contentMode = UIViewContentModeScaleToFill;
        [self addSubview:bgImgae];
        [bgImgae release];
        
        lblFirstDate=createTextField(CGRectMake(CGRectGetMaxX(lblText.frame)+3, CGRectGetMaxY(topTitleView.frame)+17, 90, 20), languageSelectedStringForKey(@"dd/mm/yyyy"));
        if (!checkISNullStrings(self.strFirstDate)) {
            lblFirstDate.text=self.strFirstDate;
        }
        lblFirstDate.delegate=self;
        lblFirstDate.enabled=NO;
        lblFirstDate.textColor=[UIColor blackColor];
        lblFirstDate.font=[UIFont systemFontOfSize:15.0f];
        lblFirstDate.textAlignment=NSTextAlignmentLeft;
        [self addSubview:lblFirstDate];
        [lblFirstDate release];
        
        btnCrossFirstDate=createButton(CGRectMake(CGRectGetMaxX(lblFirstDate.frame)+3, CGRectGetMinY(lblFirstDate.frame), 20, 20), @"", @"img_search_clear", self, @selector(ClearCall:));
        btnCrossFirstDate.tag=1;
        [self addSubview:btnCrossFirstDate];
        [btnCrossFirstDate release];
        
        btnFirstDate=createButton(CGRectMake(CGRectGetMaxX(btnCrossFirstDate.frame), CGRectGetMaxY(topTitleView.frame)+6, 40, 40), nil, @"img_cal_trans", self, @selector(OpenCalender:));
        btnFirstDate.tag=1;
        [btnFirstDate setImage:[UIImage imageNamed:@"img_cal_trans"] forState:UIControlStateNormal];
        [self addSubview:btnFirstDate];
        [btnFirstDate release];

        lblText=createLabel(languageSelectedStringForKey(@"To"), CGRectMake(10, CGRectGetMaxY(btnFirstDate.frame)+5, 50, 30));
        lblText.textColor=[UIColor grayColor];
        lblText.backgroundColor=[UIColor clearColor];
        [self addSubview:lblText];
        [lblText release];

        bgImgae=[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lblText.frame), CGRectGetMaxY(btnFirstDate.frame)+5, 90, 30)];
        bgImgae.image=[UIImage imageNamed:@"img_Search_text_bg"];
        bgImgae.contentMode = UIViewContentModeScaleToFill;
        [self addSubview:bgImgae];
        [bgImgae release];
        
        lblLastDate=createTextField(CGRectMake(CGRectGetMaxX(lblText.frame)+3, CGRectGetMaxY(btnFirstDate.frame)+10, 90, 20),languageSelectedStringForKey(@"dd/mm/yyyy"));
        if (!checkISNullStrings(lastDate))
        {
            lblLastDate.text=lastDate;
        }
        lblLastDate.enabled=NO;
        lblLastDate.delegate=self;
        lblLastDate.textAlignment=NSTextAlignmentLeft;
        lblLastDate.textColor=[UIColor blackColor];
        lblLastDate.font=[UIFont systemFontOfSize:15.0f];
        [self addSubview:lblLastDate];
        [lblLastDate release];
        
        btnCrossLastDate=createButton(CGRectMake(CGRectGetMaxX(lblLastDate.frame)+3, CGRectGetMinY(lblLastDate.frame), 20, 20), @"", @"img_search_clear", self, @selector(ClearCall:));
        btnCrossLastDate.tag=2;
        [self addSubview:btnCrossLastDate];
        [btnCrossLastDate release];

               
        btnLastDate=createButton(CGRectMake(CGRectGetMaxX(btnCrossLastDate.frame), CGRectGetMaxY(btnFirstDate.frame), 40, 40), nil, @"img_cal_trans", self, @selector(OpenCalender:));
         btnLastDate.tag=2;
        [btnLastDate setImage:[UIImage imageNamed:@"img_cal_trans"] forState:UIControlStateNormal];
        [self addSubview:btnLastDate];
        [btnLastDate release];
        
        
        UILabel *lblTextFrom=createLabel(languageSelectedStringForKey(@"Description"),CGRectMake(10, CGRectGetMaxY(btnLastDate.frame)+20, 100, 15));
        lblTextFrom.textColor=[UIColor darkGrayColor];
        lblTextFrom.font=[UIFont systemFontOfSize:15.0f];
        lblTextFrom.textAlignment=NSTextAlignmentLeft;
        [self addSubview:lblTextFrom];
        [lblTextFrom release];
        
        
        bgImgae=[[UIImageView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(lblTextFrom.frame)+5, 180, 30)];
        bgImgae.image=[UIImage imageNamed:@"img_inputbg_FUID.png"];
        bgImgae.contentMode = UIViewContentModeScaleToFill;
        [self addSubview:bgImgae];
        [bgImgae release];

        txtDescription=createTextField(CGRectMake(13, CGRectGetMaxY(lblTextFrom.frame)+10, 175, 20),languageSelectedStringForKey(@""));
        txtDescription.textAlignment=NSTextAlignmentLeft;
        txtDescription.delegate=self;
        txtDescription.enabled = YES;
        txtDescription.textColor=[UIColor blackColor];
        txtDescription.returnKeyType=UIReturnKeyNext;
        txtDescription.keyboardType=UIKeyboardTypeDefault;
        txtDescription.font=[UIFont systemFontOfSize:15.0f];
        
        if (!checkISNullStrings(self.strDescription))
        {
            txtDescription.text=self.strDescription;
        }

        [self addSubview:txtDescription];
        [txtDescription release];
        
      
        
        lblTextFrom=createLabel(languageSelectedStringForKey(@"Amount"),CGRectMake(10, CGRectGetMaxY(txtDescription.frame)+20, 100, 15));
        lblTextFrom.textColor=[UIColor darkGrayColor];
        lblTextFrom.font=[UIFont systemFontOfSize:15.0f];
        lblTextFrom.textAlignment=NSTextAlignmentLeft;
        [self addSubview:lblTextFrom];
        [lblTextFrom release];
        
        bgImgae=[[UIImageView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(lblTextFrom.frame)+5, 80, 30)];
        bgImgae.image=[UIImage imageNamed:@"img_Search_text_bg"];
        bgImgae.contentMode = UIViewContentModeScaleToFill;
        [self addSubview:bgImgae];
        [bgImgae release];
        
        
        txtAmountmin=createTextField(CGRectMake(13, CGRectGetMaxY(lblTextFrom.frame)+10, 80, 20),languageSelectedStringForKey(@"Min"));
        txtAmountmin.textAlignment=NSTextAlignmentLeft;
        txtAmountmin.delegate=self;
        txtAmountmin.enabled = YES;
        txtAmountmin.textColor=[UIColor blackColor];
        txtAmountmin.returnKeyType=UIReturnKeyDone;
        txtAmountmin.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
        txtAmountmin.font=[UIFont systemFontOfSize:15.0f];
        
        if (!checkISNullStrings(self.minAmount))
        {
            txtAmountmin.text=self.minAmount;
        }
        
        [self addSubview:txtAmountmin];
        [txtAmountmin release];
        
        bgImgae=[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(txtAmountmin.frame)+10, CGRectGetMaxY(lblTextFrom.frame)+5, 80, 30)];
        bgImgae.image=[UIImage imageNamed:@"img_Search_text_bg"];
        bgImgae.contentMode = UIViewContentModeScaleToFill;
        [self addSubview:bgImgae];
        [bgImgae release];
        
        txtAmountMax=createTextField(CGRectMake(CGRectGetMaxX(txtAmountmin.frame)+14, CGRectGetMaxY(lblTextFrom.frame)+10, 80, 20),languageSelectedStringForKey(@"Max"));
        txtAmountMax.textAlignment=NSTextAlignmentLeft;
        txtAmountMax.delegate=self;
        txtAmountMax.enabled = YES;
        txtAmountMax.textColor=[UIColor blackColor];
        txtAmountMax.returnKeyType=UIReturnKeyDone;
        txtAmountMax.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
        txtAmountMax.font=[UIFont systemFontOfSize:15.0f];
        
        if (!checkISNullStrings(self.maxAmount))
        {
            txtAmountMax.text=self.maxAmount;
        }
        
        [self addSubview:txtAmountMax];
        [txtAmountMax release];
  
        
        
        bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(txtAmountmin.frame)+25, frame.size.width, 45)];
        bottomView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [self addSubview:bottomView];
        [bottomView release];
        
        
        UIButton *btnCancel = createButton(CGRectMake(20, 10, 60, 25), @"", imgNAV_CancelBtn, self, @selector(CancelDate));
        [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [bottomView addSubview:btnCancel];
        
        [btnCancel release];
        
        UIButton *btnSubmit = createButton(CGRectMake(frame.size.width-83, 10, 60, 25), @"", imgNAV_CancelBtn, self, @selector(SubmitDate));
        [btnSubmit setTitle:languageSelectedStringForKey(@"Submit") forState:UIControlStateNormal];
        btnSubmit.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [bottomView addSubview:btnSubmit];
        
        [btnSubmit release];
        }
    
    [self checkForEmptyField];
    return self;
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isEqual:txtDescription])
    {
        [txtAmountmin becomeFirstResponder];
    }else if ([textField isEqual:txtAmountmin])
    {
        [txtAmountMax becomeFirstResponder];
    }else if ([textField isEqual:txtAmountMax])
    {
        [txtAmountMax resignFirstResponder];
        CGRect fra;
        fra=self.frame;
        self.frame=CGRectMake(fra.origin.x,10 , fra.size.width, fra.size.height);
    }
    [self checkForEmptyField];
    return YES;
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([textField isEqual:txtAmountmin])
    {
        CGRect fra;
        fra=self.frame;
        self.frame=CGRectMake(fra.origin.x,-50, fra.size.width, fra.size.height);
    }else if ([textField isEqual:txtAmountMax])
    {
        CGRect fra;
        fra=self.frame;
        self.frame=CGRectMake(fra.origin.x,-50, fra.size.width, fra.size.height);
    }else
    {
        CGRect fra;
        fra=self.frame;
        self.frame=CGRectMake(fra.origin.x,10 , fra.size.width, fra.size.height);
    }
    
    [self checkForEmptyField];
  return YES;
}


-(void)ClearCall :(id)sender
{
    UIButton *tmp=(UIButton *)sender;
    switch (tmp.tag) {
        case 1:
            lblFirstDate.text=@"";
            self.strFirstDate=nil;
            break;
        case 2:
            lblLastDate.text=@"";
            self.strLastDate=nil;
            break;
        case 3:
            txtDescription.text=@"";
            break;

        case 4:
            txtAmountmin.text=@"";
            txtAmountMax.text=@"";
            break;

            
        default:
            break;
    }
    [self checkForEmptyField];
}

-(void)CancelDate
{
    if ([self.delegate respondsToSelector:@selector(DateSelectorcancel)])
    {
        [self.delegate DateSelectorcancel];
    }
}

-(void)checkForEmptyField
{
    if ([lblFirstDate.text isEqualToString:@""])
    {
        btnCrossFirstDate.hidden=YES;
    }else
    {
        btnCrossFirstDate.hidden=NO;
    }
    
    if ([lblLastDate.text isEqualToString:@""])
    {
        btnCrossLastDate.hidden=YES;
    }else
    {
        btnCrossLastDate.hidden=NO;
    }
    
}

-(void)SubmitDate
{
    NSComparisonResult result = [GetDateFromSTring(strFirstDate) compare:GetDateFromSTring(strLastDate)];
    if (result == NSOrderedAscending)
    {
        // Last date > First Date
        [self SendDateTocaller :self.strFirstDate toDate:self.strLastDate minimumAmount:txtAmountmin.text maximumAmount:txtAmountMax.text description:txtDescription.text];
        
    } else if (result == NSOrderedDescending)
    {
        //  Last date < First Date
        showAlertScreen(nil,languageSelectedStringForKey(DATE_ALERT));
        return;
    }  else
    {
        // Last date == First Date
        [self SendDateTocaller :self.strFirstDate toDate:self.strLastDate minimumAmount:txtAmountmin.text maximumAmount:txtAmountMax.text description:txtDescription.text];
    }
    
}


-(void)UpdateDateSelection :(NSString *)fstDate :(NSString *)lstDate :(NSString*)min :(NSString *)max :(NSString*)desc
{
    
}

-(void)SendDateTocaller :(NSString *)fDate toDate:(NSString *)lDate minimumAmount:(NSString *)min maximumAmount:(NSString *)max description:(NSString *)desc
{
    if ([min doubleValue]>[max doubleValue] || [min isEqualToString:@"0.00"] || [max isEqualToString:@"0.00"])
    {
        showAlertScreen(nil, @"Maximum amount should be gretaer than or equal to Minimum amount and both amount should be greater than zero...");
    }else
    {
        if ([self.lblFirstDate.text isEqualToString:@""] && ![self.lblLastDate.text isEqualToString:@""])
        {
            showAlertScreen(nil,@"Please select FromDate ");
        }else if ([self.lblLastDate.text isEqualToString:@""] && ![self.lblFirstDate.text isEqualToString:@""])
        {
            showAlertScreen(nil,@"Please select ToDate ");
        }else if ([self.delegate respondsToSelector:@selector(UpdateDateSelection:::::)])
        {
            [self.delegate UpdateDateSelection:fDate :lDate :min :max :desc];
        }
    }
}

-(void)OpenCalender :(id)sender
{
    
    UIButton *tmp=(UIButton *)sender;
    
    if (tmp.tag==1)
    {
        isFirstDate=YES;
       
        [AppDelegate sharedAppDelegate].selectedDate=GetDateFromSTring(self.strFirstDate);
        
    }else
    {
        isFirstDate=NO;
       
        [AppDelegate sharedAppDelegate].selectedDate=GetDateFromSTring(self.strLastDate);

    }
    
    if (!calnderObj)
    {
        calnderObj=[[CalanderView alloc]initWithCalanderFrame:CGRectMake(0, 0, 216, 315) Delegate:self backGroundColor:[UIColor whiteColor] date:(tmp.tag==1)?self.strFirstDate:self.strLastDate];
        [self addSubview:calnderObj];
        [calnderObj release];

    }
    [txtAmountMax resignFirstResponder];
    [txtAmountmin resignFirstResponder];
    [txtDescription resignFirstResponder];
    CGRect fra;
    fra=self.frame;
    self.frame=CGRectMake(fra.origin.x,10 , fra.size.width, fra.size.height);
}

-(void) calanderCancelDelegate{
    [self removeCalanderView];
    
}
// Remove calander view
-(void) removeCalanderView
{
    if (calnderObj)
    {
        [calnderObj removeFromSuperview];
        calnderObj = nil;
    }
}

-(void)PickDate: (id)sender
{
    if ([calnderObj isDescendantOfView:self])
    {
        [calnderObj removeFromSuperview];
        calnderObj=nil;
    }
    if (isFirstDate)
    {
        self.strFirstDate=nil;
        self.strFirstDate=sender;
        lblFirstDate.text=sender;
        isFirstDate=YES;
    }else
    {
        self.strLastDate=nil;
        self.strLastDate=sender;
        lblLastDate.text=sender;
        isFirstDate=NO;
    }
    [self checkForEmptyField];
}
// Method put here to remove compilation error. These are the delegate methods
-(void)DateSelectorcancel
{
    
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([textField isEqual:txtAmountMax] || [textField isEqual:txtAmountmin] )
    {
        return digitValidationOnNumKeyboard(textField,range,string);
    }
    else
    {
        return YES;
    }
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if ([textField isEqual:txtAmountMax] || [textField isEqual:txtAmountmin] )
    {
        if ([textField.text isEqualToString:@""])
        {
            textField.text=@"";
        }else
        {
            textField.text=[NSString stringWithFormat:@"%0.2f",changeTextToAmount(textField.text)];
        }
    }
}

-(void)dealloc
{
    if (self.delegate!=nil) {
        self.delegate=nil;
    }
    [super dealloc];
}
@end
