//
//  LoginResponse.m
//
// class used for get response from the server
#import "LoginResponse.h"

@implementation LoginResponse
@synthesize UserId,firstName,LastName,Email;

-(void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.UserId forKey:@"UserId"];
    [encoder encodeObject:self.firstName forKey:@"firstName"];
    [encoder encodeObject:self.LastName forKey:@"LastName"];
    [encoder encodeObject:self.Email forKey:@"Email"];
}

-(id)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if ( self != nil ) {
        self.UserId = [decoder decodeObjectForKey:@"UserId"];
        self.firstName = [decoder decodeObjectForKey:@"firstName"];
        self.LastName=[decoder decodeObjectForKey:@"LastName"];
        self.Email=[decoder decodeObjectForKey:@"Email"];
    }
    return self;
}
-(void)dealloc
{
    self.UserId=nil;
    self.firstName=nil;
    self.Email=nil;
    self.LastName=nil;
    [super dealloc];
}
@end
