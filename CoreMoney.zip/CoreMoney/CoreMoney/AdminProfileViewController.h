//
//  AdminProfileViewController.h
//  CoreMoney


#import <UIKit/UIKit.h>
#import "CustomScrollView.h"
#import "AdminDataClass.h"
#import "adminProfileData.h"
@interface AdminProfileViewController : SwipeViewController<ScrollDelegate,DataParsingDelegate>
{
    BOOL isAdminProfile,switchOnOffValues;
    UIView *comboParentView;
    NSMutableArray *SecretQuestionArr;
    AdminDataClass *AdminDataObj;
    adminProfileData *adminProfileObj;
    adminLoadLimitDataClass *adminLoadDataObj;
    int requestId,SelectedQuestionIndex;
}

@property (nonatomic,retain)adminProfileData *adminProfileObj;
@property (nonatomic,retain)  AdminDataClass *AdminDataObj;
@property (nonatomic, retain) adminLoadLimitDataClass *adminLoadDataObj;
@property (retain, nonatomic) IBOutlet UIView *userDetailView;
@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (retain, nonatomic) IBOutlet CustomScrollView *AdminScrollView;
@property (retain, nonatomic) IBOutlet UIImageView *imgTop;
@property (retain, nonatomic) IBOutlet UIView *viewPersonalDetail;
@property (retain, nonatomic) IBOutlet UIView *viewAddress;
@property (retain, nonatomic) IBOutlet UILabel *lblUserInfo;
@property (retain, nonatomic) IBOutlet UIButton *btnLoadLimit;
@property (retain, nonatomic) IBOutlet UIButton *btnUserInfo;
@property (retain, nonatomic) IBOutlet UILabel *lblLoadLimit;
@property (retain, nonatomic) IBOutlet UIView *loadLimitCompleteView;
@property (retain, nonatomic) IBOutlet UIView *viewLoadLimit;
@property (retain, nonatomic) IBOutlet UIView *btnView;
@property (retain, nonatomic) IBOutlet UILabel *lblBtnStatus;
@property (retain, nonatomic) IBOutlet UIImageView *imgArrow;
@property (retain, nonatomic) IBOutlet UIView *loadLimitView;
@property (retain, nonatomic) IBOutlet UIButton *btnChangePwd;
@property (retain, nonatomic) IBOutlet UILabel *lblUserDate;
@property (retain, nonatomic) IBOutlet CustomScrollView *scrollLoadLimit;

@property (retain, nonatomic) IBOutlet UILabel *lblChangePassword;
@property (retain, nonatomic) IBOutlet UITextField *txtDaily;
@property (retain, nonatomic) IBOutlet UITextField *txtMonthly;
@property (retain, nonatomic) IBOutlet UIView *changePasswordView;
@property (retain, nonatomic) IBOutlet UITextField *txtSingle;
@property (retain, nonatomic) IBOutlet UIButton *btnPasswordSubmit;
@property (retain, nonatomic) IBOutlet UIView *changePwdParentView;
@property (retain, nonatomic) IBOutlet UIScrollView *changePwdScrollView;

@property (retain, nonatomic) IBOutlet UILabel *lblChangePwdHeader;
@property (retain, nonatomic) IBOutlet UILabel *lblOldChangPwdHeader;
@property (retain, nonatomic) IBOutlet UILabel *lblConfirmPwdHeader;
@property (retain, nonatomic) IBOutlet UITextField *txtOldPwd;
@property (retain, nonatomic) IBOutlet UITextField *txtNewPwd;
@property (retain, nonatomic) IBOutlet UITextField *txtConfirmPwd;
@property (retain, nonatomic) IBOutlet UITextField *txtSecretAnswer;
@property (retain, nonatomic) IBOutlet UILabel *lblSecretQuetionPwd;
@property (retain, nonatomic) IBOutlet UILabel *lblAddress;
@property (retain, nonatomic) IBOutlet UIButton *btnUpdate;

@property (retain, nonatomic) IBOutlet UILabel *lblPersonalDetail;
@property (retain, nonatomic) IBOutlet UILabel *lblMonthlyLoadLimit;
@property (retain, nonatomic) IBOutlet UILabel *lblDailyLoadLimit;
@property (retain, nonatomic) IBOutlet UILabel *lblSingleloadLimit;
@property (retain, nonatomic) IBOutlet UILabel *lblBypassLoadLimit;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil admin:(BOOL)isAdmin;

@property (retain, nonatomic) IBOutlet UILabel *lblBusinessName;
@property (retain, nonatomic) IBOutlet UILabel *lblUserName;
@property (retain, nonatomic) IBOutlet UILabel *lblEmailId;
@property (retain, nonatomic) IBOutlet UILabel *lblLastLogin;

@property (retain, nonatomic) IBOutlet UILabel *lblUser;

@property (retain, nonatomic) IBOutlet UILabel *lblAddressLine1;

@property (retain, nonatomic) IBOutlet UILabel *lblAddressLine2;
@property (retain, nonatomic) IBOutlet UILabel *lblAddressLine3;
@property (retain, nonatomic) IBOutlet UILabel *lblLoadClientId;
@property (retain, nonatomic) IBOutlet UILabel *lblLoadStatus;

@property (retain, nonatomic) IBOutlet UILabel *lblLoadBusinessName;
@property (retain, nonatomic) IBOutlet UILabel *lblLoadUserName;
- (IBAction)clickChangePwdRequest:(id)sender;
- (IBAction)changeAdminLoadLimit:(id)sender;


-(void) redesignAdminInfoUI;

@end
