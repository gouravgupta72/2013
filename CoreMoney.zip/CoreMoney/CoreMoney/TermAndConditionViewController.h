//
//  TermAndConditionViewController.h
//  CoreMoney
// class use for create term and condition page
//

#import <UIKit/UIKit.h>

@interface TermAndConditionViewController : UIViewController
{
    NSString *strForTCUrl;
}
@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (retain, nonatomic) IBOutlet UIWebView *webView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil pageType:(helpMenuPageType )pageType;
@end
