//
//  employeeDataClass.m
//  CoreMoney


#import "employeeDataClass.h"

@implementation employeeDataClass
@synthesize ACCTID, EmployeeId, Name;

-(void)dealloc
{
    self.ACCTID=nil;
    self.EmployeeId=nil;
    self.Name=nil;
    
    [super dealloc];
}
@end
