//
//  MerchantCategoryCell.h
//  CoreMoney
// class use for create cell for merchant category

#import <UIKit/UIKit.h>

@interface MerchantCategoryCell : UITableViewCell
{
    UILabel *lblTitle;
    UILabel *lblSubTitle;
    UILabel *lblDailyLimit;
    UILabel *lblMonthluLimit;
    UISwitch *slider;
    UITextField *txtDailyLimit,*txtMonthlyLimit;
    id delegate;
}
@property(nonatomic, assign)id delegate;
@property (retain,nonatomic) UILabel *lblTitle,*lblSubTitle,*lblDailyLimit,*lblMonthluLimit;
@property (retain , nonatomic) UISwitch *slider;
@property (retain, nonatomic)  UITextField *txtDailyLimit,*txtMonthlyLimit;
-(void) switchDelegateMethod:(id) sender;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del;
@end
