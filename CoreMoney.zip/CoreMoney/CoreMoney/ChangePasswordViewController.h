//
//  ChangePasswordViewController.h
// Class use for change password
#import <UIKit/UIKit.h>
#import "Request.h"
@interface ChangePasswordViewController : SwipeViewController<UITextFieldDelegate,DataParsingDelegate>
{
    BOOL passwordValid;
}
@property (retain, nonatomic) IBOutlet UITextField *txtPassword;
@property (retain, nonatomic) IBOutlet UITextField *txtVerifyPassword;
@property (retain, nonatomic) IBOutlet UILabel *lblChangePwd;
@property (retain, nonatomic) IBOutlet UIButton *btnChange;
@property (retain, nonatomic) IBOutlet UIView *myChangePasswordView;
@end
