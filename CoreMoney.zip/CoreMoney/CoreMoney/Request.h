//
//  Request.h
//

#import <Foundation/Foundation.h>
#import "LoginResponceDataClass.h"
#import "UserIdValidationClass.h"
#import "secretQustionDataClass.h"
#import "BusinessPageDetail.h"

@protocol RequestDelegate;
@interface Request : NSObject
{
    NSURLConnection *conn;
    NSMutableData *webData;
    id<RequestDelegate>delegate;
    int RequestId;
    NSString *a,*b;
    NSMutableArray *DataArray;
}
@property(nonatomic,retain)id<RequestDelegate>delegate;
-(void)request:(NSString *)Action Parameter:(NSString *)parameter ;
@end

@protocol RequestDelegate <NSObject>
-(void)getResult:(id)jsonData;
-(void)getError:(id)error;
@end