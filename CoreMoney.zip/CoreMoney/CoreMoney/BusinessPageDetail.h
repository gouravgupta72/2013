//
//  BusinessPageDetail.h
//  CoreMoney

// Class used for hold data of business summary.


#import <Foundation/Foundation.h>

@interface BusinessPageDetail : NSObject
{
    NSString *ACCTID, *ADDRESS1, *ADDRESSLINE2, *AccountNumber, *Account_Billing,   *BusinessDesignation, *BusinessName,  *Business_ID_Desc, *CARDLINE4, *CITY, *COUNTRY, *DATE_APPROVED, *DDANumber, *DateOfIncorporation, *EMAIL_ADDRESS1, *FIRST_NAME, *HOME_PHONE, *HomeFaxNumber, *LANGUAGE_INDICATOR, *LAST_NAME, *LastAdminLogin, *LastCreditTransferDate, *LastDebitTransferDate, *OwningPartner, *PHONEEXTENSION, *PRODUCT_PARENT, *Parent_Bussiness, *STATE, *TaxId, *URL, *WAREHOUSED_AMOUNT, *WaiveEnrollmentFee, *ZIP_CODE;
    
    double AvailableBalance, BToBTransfer, BusinessCurrentBalance, BusinessMTDCardSpend,BusinessTotalAvailableCardBalance, BusinessTotalAvailableFunds, BusinessTotalCurrentCardBalance, BusinessTotalPendingCreditTransactions, BusinessTotalPendingDebitTransactions, BusinessYTDCardSpend, CRAD_LIMIT, CURRENT_BALANCE, InactiveCards, LastTransfer, MAX_LOAD_AMT,  OD_AMT, PendingCardTxns, UnusedBudget;
    
    int ActiveAdmins,BlockedCards, CARD_STATUS, NumberOfCards;
    
    BOOL IsEnrollmentFeePaid;
}
@property(nonatomic,retain) NSString *ACCTID, *ADDRESS1, *ADDRESSLINE2, *AccountNumber, *Account_Billing,   *BusinessDesignation, *BusinessName,  *Business_ID_Desc, *CARDLINE4, *CITY, *COUNTRY, *DATE_APPROVED, *DDANumber, *DateOfIncorporation, *EMAIL_ADDRESS1, *FIRST_NAME, *HOME_PHONE, *HomeFaxNumber, *LANGUAGE_INDICATOR, *LAST_NAME, *LastAdminLogin, *LastCreditTransferDate, *LastDebitTransferDate, *OwningPartner, *PHONEEXTENSION, *PRODUCT_PARENT, *Parent_Bussiness, *STATE, *TaxId, *URL, *WAREHOUSED_AMOUNT, *WaiveEnrollmentFee, *ZIP_CODE;

@property double AvailableBalance, BToBTransfer, BusinessCurrentBalance, BusinessMTDCardSpend,BusinessTotalAvailableCardBalance, BusinessTotalAvailableFunds, BusinessTotalCurrentCardBalance, BusinessTotalPendingCreditTransactions, BusinessTotalPendingDebitTransactions, BusinessYTDCardSpend, CRAD_LIMIT, CURRENT_BALANCE, InactiveCards, LastTransfer, MAX_LOAD_AMT,  OD_AMT, PendingCardTxns, UnusedBudget;

@property int ActiveAdmins,BlockedCards, CARD_STATUS, NumberOfCards;

@property  BOOL IsEnrollmentFeePaid;
@end
