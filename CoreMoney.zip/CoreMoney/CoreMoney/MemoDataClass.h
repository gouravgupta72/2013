//
//  MemoDataClass.h
//  CoreMoney

#import <Foundation/Foundation.h>

@interface MemoDataClass : NSObject
{
    NSString *ACCOUNTNUMBER, *CATEGORY_ID, *CATEGORY_LABEL, *CATEGORY_TYPE, *COMMENT, *CREATIONDATE, *CREATIONTIME, *Captured_By, *EXPCAT_VALUE, *EXPCAT_VALUE_ID, *FIRSTNAME, *LASTNAME, *MemoReason, *MemoTranID, *ReasonType, *RoleType, *Source, *UNIQUEID, *UserName;
    
    int Delete_Access, Edit_Access, View_Access;
}

@property (nonatomic,retain)NSString *ACCOUNTNUMBER, *CATEGORY_ID, *CATEGORY_LABEL, *CATEGORY_TYPE, *COMMENT, *CREATIONDATE, *CREATIONTIME, *Captured_By, *EXPCAT_VALUE, *EXPCAT_VALUE_ID, *FIRSTNAME, *LASTNAME, *MemoReason, *MemoTranID, *ReasonType, *RoleType, *Source, *UNIQUEID, *UserName;

@property  int Delete_Access, Edit_Access, View_Access;
@end
