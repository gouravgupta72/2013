//
//  AppDelegate.h
//

#import <UIKit/UIKit.h>
#import "loadingView.h"
#import "DataParsingClass.h"

@class LoginViewController;
@class HomeViewController;


@interface AppDelegate : UIResponder <UIApplicationDelegate,UINavigationControllerDelegate,DataParsingDelegate>
{
    loadingView *lview;
    BOOL isSlideViewVisible,isIphone5,isSpanish;
    int classType,screenWidth,screenHeight;
    
    
    NSMutableArray *arrBusinessData,*arrCardDetailArray,*Arraytransfer,*ArraybankList,*ArrayAdmin;
    int HomePageIndexNo, CardDetailPageIndex;
    
    NSDate *selectedDate;
    NSString *notificationType;
    int notificationTag;
    BOOL isNotification;
    
    BOOL isUserLogin,isInactive;
}
@property int HomePageIndexNo,CardDetailPageIndex;
@property (nonatomic,retain) NSMutableArray *arrBusinessData,*arrCardDetailArray,*Arraytransfer,*ArraybankList,*ArrayAdmin;
@property (nonatomic,retain)  NSDate *selectedDate;
@property (nonatomic, retain) loadingView *lview;
@property (nonatomic, retain) UINavigationController *naviGationController;
@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, assign) BOOL isSlideViewVisible,isIphone5,isSpanish,isNotification, isUserLogin, isInactive;
@property (strong, nonatomic) LoginViewController *loginviewController;
@property (strong, nonatomic) HomeViewController *homeviewController;
@property (nonatomic,retain)  NSString *notificationType;
@property (nonatomic, assign) int classType,screenWidth,screenHeight,notificationTag;

+(AppDelegate *)sharedAppDelegate;
-(void)addLoginLoadingView;
-(void)addloadingView;
-(void)removeLoadingView;
-(void)addLoginPage;
-(void)addHomePage;
@end