//
//  ScheduleFundingSearchDataClass.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface ScheduleFundingSearchDataClass : NSObject
{
    NSString *ResErrorMsg, *ACCOUNT_ACCT_ID, *BA_ACCT_ID, *SCHEDULE_TYPE;
    int ResErrorCode,  FREQUENCY, SelectDay;
    double AMOUNT;
    BOOL ISACTIVE, ResCode;
}

@property (nonatomic,retain)NSString *ResErrorMsg, *ACCOUNT_ACCT_ID, *BA_ACCT_ID, *SCHEDULE_TYPE;
@property int ResErrorCode, FREQUENCY,SelectDay;
@property double AMOUNT;
@property BOOL ISACTIVE, ResCode;
@end