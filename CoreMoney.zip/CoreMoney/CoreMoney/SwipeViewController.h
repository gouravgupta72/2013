//
//  SwipeViewController.h
//  WinePoynt


#import <UIKit/UIKit.h>

@interface SwipeViewController : UIViewController<UIGestureRecognizerDelegate>
{
    UISwipeGestureRecognizer *leftSwipe, *rightSwipe;
}

-(void)cancelTouchesInView:(bool)cancel;

@end
