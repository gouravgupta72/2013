//
//  ContactUSViewController.m
//  CoreMoney
// Class use for create Contact us page.
//

#import "ContactUSViewController.h"

@interface ContactUSViewController ()

@end

@implementation ContactUSViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        addNavigationBar(Contact_us_Title, NAV_LEFT_BACK, NAV_RIGHT_NONE, self);

        // Custom initialization
    }
    return self;
}
-(void)openBack
{
    [self.navigationController setNavigationBarHidden:YES];
    [self.navigationController popViewControllerAnimated:YES];
}
-(void) viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO];
//    NavigationBarStyle();
}

- (void)viewDidLoad
{
    self.emailView.layer.borderWidth = 1;
    self.emailView.layer.borderColor = [UIColor grayColor].CGColor;
    self.emailView.layer.cornerRadius = 8;
    
    self.callView.layer.borderWidth = 1;
    self.callView.layer.borderColor = [UIColor grayColor].CGColor;
    self.callView.layer.cornerRadius = 8;


    self.contactPopView.layer.borderWidth = 1;
    self.contactPopView.layer.borderColor = [UIColor grayColor].CGColor;
    self.contactPopView.layer.cornerRadius = 8;
    
    self.emailUsMsgview.layer.borderWidth = 1;
    self.emailUsMsgview.layer.borderColor = [UIColor grayColor].CGColor;
    self.emailUsMsgview.layer.cornerRadius = 8;
    
     self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, 320, 480);
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_emailView release];
    [_callView release];
    [_contactPopView release];
    [_lblCallusMsg release];
    [_btnHideCallPopup release];
    [_bgView release];
    [_emailUsMsgview release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setEmailView:nil];
    [self setCallView:nil];
    [self setContactPopView:nil];
    [self setLblCallusMsg:nil];
    [self setBtnHideCallPopup:nil];
    [self setBgView:nil];
    [self setEmailUsMsgview:nil];
    [super viewDidUnload];
}
- (IBAction)tapEmailBtn:(id)sender {
    [self removeExtraView];
    [self openMailComposer];
}

- (IBAction)tapContactBtn:(id)sender {
    
    [self removeExtraView];
    
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tel:+11111"]])
    {
        
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel:+17705648000"]];
    }
    else 
    {
        self.callView.frame = CGRectMake(20, 197, self.callView.frame.size.width, self.callView.frame.size.height);

        
        self.contactPopView.frame = CGRectMake(20, 197, self.contactPopView.frame.size.width, self.contactPopView.frame.size.height);
        [self.bgView addSubview:self.contactPopView];
        self.lblCallusMsg.frame = CGRectMake(self.contactPopView.frame.origin.x+10, self.contactPopView.frame.origin.y-10, self.lblCallusMsg.frame.size.width, self.lblCallusMsg.frame.size.height);
        self.lblCallusMsg.text = @"Call us";
        [self.bgView addSubview:self.lblCallusMsg];
        
        self.btnHideCallPopup.frame = self.lblCallusMsg.frame;
        [self.bgView addSubview:self.btnHideCallPopup];
        //NSLog(@"Phone Not Supportted");
        
    }
}
-(void) removeExtraView
{
    self.callView.frame = CGRectMake(20, 197, self.callView.frame.size.width, self.callView.frame.size.height);
    [self.emailUsMsgview removeFromSuperview];
    [self.contactPopView removeFromSuperview];
    [self.lblCallusMsg removeFromSuperview];
    [self.btnHideCallPopup removeFromSuperview];

}

- (IBAction)hideContactPopup:(id)sender {
    
    [self removeExtraView];
    
    }

// Mail composer result delegate
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    [self dismissModalViewControllerAnimated:YES];
//    NSString *str;
//    switch (result)
//    {
//        case MFMailComposeResultCancelled:
//            str=@"Mail Cancelled";
//            break;
//        case MFMailComposeResultSaved:
//            str=@"Mail saved";
//            break;
//        case MFMailComposeResultSent:
//            str=@"Mail sent";
//            break;
//        case MFMailComposeResultFailed:
//            str=@"Mail failed";
//            break;
//        default:
//            str=@"Mail not sent";
//            break;
//    }
   // [self showAlert:str];
}
- (IBAction)openMail:(id)sender
{
    if ([MFMailComposeViewController canSendMail])
    {
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Failure"
                                                        message:@"Your device doesn't support the composer sheet"
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
}
// Open Mail composer and set mail
-(void)openMailComposer
{
    
    
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    picker.mailComposeDelegate = self;
    
   // mobileWineDetail *obj=[wineDetailsArray objectAtIndex:0];
    
    NSString *subject = @"Feedback";
    [picker setSubject:subject];
   // picker.delegate = self;
    
    // Fill out the email body text
   // NSString *emailBody = [NSString stringWithFormat:@"%@ </br> <br/> Rated : %.1f Rating out of 5 </br> <br/> <a href=%@>%@</a>",obj.Text,obj.FormCompatibilityRating,obj.WineDotComProductUrl,(obj.WineDotComProductUrl!=NULL?obj.WineDotComProductUrl:@"")];
    
//     NSString *emailBody = [NSString stringWithFormat:@"%@ </br> <br/> Rated : %.1f Rating out of 5 </br> <br/> <a href=%@>%@</a>",@"hello",2.0,@"manish.gupta@corecard.com",@""];
//    [picker setMessageBody:emailBody isHTML:YES];
    
    [picker setToRecipients:[NSArray arrayWithObject:@"manish.gupta@corecard.com"]];
    AppDelegate *appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    if(picker){
    [appDelegate.naviGationController.topViewController presentModalViewController:picker animated:YES];
    }
    else{
       
        
        self.emailUsMsgview.frame = CGRectMake(self.emailView.frame.origin.x, self.emailView.frame.origin.y, self.emailUsMsgview.frame.size.width, self.emailUsMsgview.frame.size.height);
        [self.bgView addSubview:self.emailUsMsgview];
        
        self.lblCallusMsg.frame = CGRectMake(self.emailUsMsgview.frame.origin.x+10, self.emailUsMsgview.frame.origin.y-10, self.lblCallusMsg.frame.size.width, self.lblCallusMsg.frame.size.height);
        self.lblCallusMsg.text = @"Email us";
        [self.bgView addSubview:self.lblCallusMsg];
        
        self.btnHideCallPopup.frame = self.lblCallusMsg.frame;
        [self.bgView addSubview:self.btnHideCallPopup];
        
         self.callView.frame = CGRectMake(20, 247, self.callView.frame.size.width, self.callView.frame.size.height);
    }
//    else {
//     //   showAlertScreen(@"", @"Please change settings");
//    }
    [picker release];
}


@end
