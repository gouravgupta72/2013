//
//  SlideMenuClass.m
// Object class for Slide menu objects.

#import "SlideMenuClass.h"

@implementation SlideMenuClass
@synthesize strImage,strMenuTitle,pageName,indexType,isShow,isEnable,count;

-(id)initWithTitle:(NSString *)titleImage title:(NSString *)titleName selectedMenu:(pageType)menu Type:(slideIndexType)type Show:(BOOL)show Enabled:(BOOL)enable ListSize:(int)size
{
    if (!self) {
        self=[super init];
    }
    self.strImage=titleImage;
    self.strMenuTitle=titleName;
    self.pageName=menu;
    self.indexType=type;
    self.isShow=show;
    self.isEnable=enable;
    self.count=size;
    return self;
}
-(void)dealloc
{
    self.strImage=nil;
    self.strMenuTitle=nil;
    [super dealloc];
}
@end
