//
//  setteldTransaction.h
//  CoreMoney

// Class used for holding data of transaction Detail.

#import <Foundation/Foundation.h>

@interface setteldTransaction : NSObject
{
    NSString *SettledTxnTranId, *SettledTxnTranTime, *SettledTxnPostTime, *Transaction_Description, *Transaction_Source, *CardAcceptorName_Location, *postingRef, *TypeOfTran, *TransactionReason, *COREAUTH_TRANID, *SPEND_CATEGORY, *MerchantCity, *CATEGORY_LABEL, *COMMENT;
    
    double Transaction_Amount, Current_Balance, HeldAmount;
    
    int MemoFlag, transactionType, ReversibleFlag;
    
    BOOL OverLimitFlag;
}

@property (nonatomic,retain)NSString *SettledTxnTranId, *SettledTxnTranTime, *SettledTxnPostTime, *Transaction_Description, *Transaction_Source, *CardAcceptorName_Location, *postingRef, *TypeOfTran, *TransactionReason, *COREAUTH_TRANID, *SPEND_CATEGORY, *MerchantCity, *CATEGORY_LABEL, *COMMENT;

@property  double Transaction_Amount, Current_Balance, HeldAmount;

@property int MemoFlag, transactionType, ReversibleFlag;
@property BOOL OverLimitFlag;
@end
