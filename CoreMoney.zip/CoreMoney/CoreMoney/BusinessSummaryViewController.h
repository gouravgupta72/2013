//
//  BusinessSummaryViewController.h



// Class for handling Business Summary

#import <UIKit/UIKit.h>
#import "BusinessPageDetail.h"
#import "BusinessAlertView.h"
#import "BusinessSummaryScrollView.h"

@interface BusinessSummaryViewController : SwipeViewController
{
    BusinessSummaryScrollView *UserDetailView;
    BusinessAlertView *alertObj;
    BusinessPageDetail *Dataobj;
    int AlertCount,pageNumber;
}
@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (retain, nonatomic) IBOutlet UIView *rightview;
@property (retain, nonatomic) IBOutlet UIView *leftView;
@property (retain, nonatomic) IBOutlet UIScrollView *UserDetailScroll;
@property (retain, nonatomic) IBOutlet UILabel *lblBalance;
@property (retain, nonatomic) IBOutlet UILabel *lblTotalAvailfund;
@property (retain, nonatomic) IBOutlet UILabel *lblUnUsed;
@property (retain, nonatomic) IBOutlet UILabel *lblPendingTransfer;
@property (retain, nonatomic) IBOutlet UILabel *lblAvailCardBlnc;
@property (retain, nonatomic) IBOutlet UILabel *lblMTDcard;
@property (retain, nonatomic) IBOutlet UILabel *lblTxtUnusedBudget;
@property (retain, nonatomic) IBOutlet UILabel *lblTxtTotalAvlFund;
@property (retain, nonatomic) IBOutlet UILabel *lblTxtBalane;
@property (retain, nonatomic) IBOutlet UILabel *lblTxtPendCrdtTransfer;
@property (retain, nonatomic) IBOutlet UILabel *lblTxtAvlCardBal;
@property (retain, nonatomic) IBOutlet UILabel *lblTxtMTDCard;
@property (retain, nonatomic) IBOutlet UIView *myBusinessView;
@property (retain, nonatomic) IBOutlet UIScrollView *scrollBusiness;
@property (retain, nonatomic) IBOutlet UIView *scrolLBGVIEW;
@property (retain, nonatomic) IBOutlet UILabel *lblUnusedDetail;
@property (retain, nonatomic) IBOutlet UILabel *lblBalanceDetail;
@property (retain, nonatomic) IBOutlet UILabel *lblTotalAvailFundDetail;
@property (retain, nonatomic) IBOutlet UILabel *lblPendingTransferDetail;
@property (retain, nonatomic) IBOutlet UILabel *lblAvailBalanceDetail;
@property (retain, nonatomic) IBOutlet UILabel *lblMtdDetail;
@property (nonatomic, assign) int pageNumber;

@end
