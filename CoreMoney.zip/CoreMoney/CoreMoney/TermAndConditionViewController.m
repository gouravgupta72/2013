//
//  TermAndConditionViewController.m
//  CoreMoney
// class use for create term and condition page

#import "TermAndConditionViewController.h"

@interface TermAndConditionViewController ()

@end

@implementation TermAndConditionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil pageType:(helpMenuPageType )pageType
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        NSString *strTitle;
        
        switch (pageType) {
            case about_Page:
            {
                strTitle = Aboutus_Title;
                strForTCUrl = @"http://115.114.121.165/CCMobileApp/aboutus.html";
            }
                break;
            case term_and_Condition_Page:
            {
                strTitle = Term_And_Condition_Title;
                strForTCUrl = @"TermsandConditons";
            }
                break;
            case FAQs_Page:
            {
                strTitle = FAQs_Title;
                strForTCUrl = @"http://115.114.121.165/CCMobileApp/faqs.html";
            }
                break;
            case recommend_Page:
            {
                strTitle = Recommend_title;
                strForTCUrl = @"TermsandConditons";
            }
                break;
            default:
                break;
        }
        
        
        
        addNavigationBar(strTitle, NAV_LEFT_BACK, NAV_RIGHT_NONE, self);
        // Custom initialization
       // strForTCUrl = @"file:///CoreMoney/TermsandConditons.html";
        
        
    }
    return self;
}
-(void)openBack
{
    [self.navigationController setNavigationBarHidden:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [[AppDelegate sharedAppDelegate] removeLoadingView];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    showAlertScreen(@"Error", @"Request Time Out !!");
    
    NSString *htmlFile = [[NSBundle mainBundle] pathForResource:@"Error" ofType:@"html"];
    NSString* htmlString = [NSString stringWithContentsOfFile:htmlFile encoding:NSUTF8StringEncoding error:nil];
    [self.webView loadHTMLString:htmlString baseURL:nil];
    
    [[AppDelegate sharedAppDelegate] removeLoadingView];
}
//This method should get called when you want to add and load the web view
- (void)loadUIWebView
{
    [[AppDelegate sharedAppDelegate] addloadingView];
   // UIWebView *webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    if([strForTCUrl isEqualToString:@"TermsandConditons"]){
    NSString *htmlFile = [[NSBundle mainBundle] pathForResource:strForTCUrl ofType:@"html"];
    NSString* htmlString = [NSString stringWithContentsOfFile:htmlFile encoding:NSUTF8StringEncoding error:nil];
    [self.webView loadHTMLString:htmlString baseURL:nil];
    }
    else{
        //Change self.view.bounds to a smaller CGRect if you don't want it to take up the whole screen
        
        NSURLRequest *requestObject = [NSURLRequest requestWithURL:[NSURL URLWithString:strForTCUrl] cachePolicy:NSURLCacheStorageAllowed timeoutInterval:30]; // timeoutInterval is in seconds
        
        [self.webView loadRequest:requestObject];
    }
    
     //Change self.view.bounds to a smaller CGRect if you don't want it to take up the whole screen
   // [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:strForTCUrl]]];
    //[self.view addSubview:webView];
    //[webView release];
}

- (void)viewDidLoad
{
    self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, 320,IS_IPAD?IS_IOS7?450:450:IS_IOS7?410:450);
    [self loadUIWebView];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void) viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO];
//    NavigationBarStyle();
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_bgView release];
    [_webView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setBgView:nil];
    [self setWebView:nil];
    [super viewDidUnload];
}
@end
