//
//  CalanderSingleView.h
//  CoreMoney


#import <UIKit/UIKit.h>

@interface CalanderSingleView : UIView
{
    id delgate;
}

- (id)initWithFrame:(CGRect)frame Delegate:(id) del;
-(void) getDateforFrequency:(int) dat;
@end
