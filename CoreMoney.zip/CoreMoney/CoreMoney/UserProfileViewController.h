//
//  UserProfileViewController.h


#import <UIKit/UIKit.h>
#import "UserProfileDataClass.h"
#import "CardDetailClass.h"
#import "DataParsingClass.h"
@interface UserProfileViewController : SwipeViewController<DataParsingDelegate>
{
    UserProfileDataClass *dataObj;
    CardDetailClass *CardDataObj;
    CardDetailClass *objCardDetail;
    NSString *AcctId;
    int Request_id;
    BOOL isPopView;
    /* Contains a string in case of when it is navigated from Alert View Controller */
    NSString *strNavigatedFrom;
}
@property (retain, nonatomic)NSString *strNavigatedFrom;

@property (nonatomic,retain)UserProfileDataClass *dataObj;
@property (nonatomic,retain)CardDetailClass *CardDataObj;
@property(nonatomic,retain)NSString *AcctId;;

@property (retain, nonatomic) IBOutlet UILabel *lblUserName;
@property (retain, nonatomic) IBOutlet UILabel *lblCardNo;
@property (retain, nonatomic) IBOutlet UILabel *lblCardStatus;
@property (retain, nonatomic) IBOutlet UILabel *lblAvailBalance;
@property (retain, nonatomic) IBOutlet UILabel *lblEmpId;
@property (retain, nonatomic) IBOutlet UILabel *lblEmail;
@property (retain, nonatomic) IBOutlet UILabel *lblAddress;
@property (retain, nonatomic) IBOutlet UILabel *lblWorkPhone;
@property (retain, nonatomic) IBOutlet UILabel *lblPhone;
@property (retain, nonatomic) IBOutlet UIView *myUserProfileView;
// New Views
@property (retain, nonatomic) IBOutlet UIView *topView;
@property (retain, nonatomic) IBOutlet UIView *bottomView;
@property (retain, nonatomic) IBOutlet UILabel *lblTopTitle;
@property (retain, nonatomic) IBOutlet UILabel *lblBottomTitle;
@property (retain, nonatomic) IBOutlet UILabel *lblAddressLine2;
@property (retain, nonatomic) IBOutlet UILabel *lblAddressCity;
- (IBAction)updateUserProfile:(id)sender;
- (IBAction)terminateUserProfile:(id)sender;
@property (retain, nonatomic) IBOutlet UILabel *lblZipcode;
@property (retain, nonatomic) IBOutlet UIButton *btnUpdate;
@property (retain, nonatomic) IBOutlet UIButton *btnTerminate;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil userProfileData:(UserProfileDataClass *)updObj;
/* When we are comming from AlertView Controller */
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil CardDetailClassObject:(CardDetailClass *) objCardDetailClass navigatedFrom:(NSString *)strNavFrom;
@end
