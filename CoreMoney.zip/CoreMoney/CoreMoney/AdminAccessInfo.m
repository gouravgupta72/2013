//
//  AdminAccessInfo.m
//  CoreMoney


#import "AdminAccessInfo.h"

@implementation AdminAccessInfo

@synthesize updateCard, TerminateCard, loadCard, scheduleCard;
@synthesize expenseRules, initiateTransferValue, viewTransferValue;
@synthesize adminPageAccessValue, mgmtPolicyAccessValue;
@synthesize transactionHistoryValue, reportAccessValue;

static AdminAccessInfo * objAdminAccess;

//This method will return the object of this class
+(AdminAccessInfo *) AdminAcess
{
    if (!objAdminAccess) {
        objAdminAccess = [[AdminAccessInfo alloc] init];
    }
    return objAdminAccess;
}

-(void)resetPeremission
{
    self.updateCard=0;
    self.TerminateCard=0;
    self.loadCard=0;
    self.scheduleCard=0;
    self.expenseRules=0;
    self.initiateTransferValue=0;
    self.viewTransferValue=0;
    self.adminPageAccessValue=0;
    self.mgmtPolicyAccessValue=0;
    self.transactionHistoryValue=0;
    self.reportAccessValue=0;
}

@end
