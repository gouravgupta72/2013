//
//  ChangePasswordViewController.m
// Class use for change password

#import "ChangePasswordViewController.h"
#import "LoginResponse.h"
@interface ChangePasswordViewController ()
-(void)openBack;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(void)sendChangePasswordRequest;

-(IBAction)changePassword:(id)sender;
- (BOOL)validateEmailAndPassword:(UITextField *)passwordField;
@end

@implementation ChangePasswordViewController
//@synthesize _txtPassword, _txtVerifyPassword, _lblChangePwd, _btnChange, _myChangePasswordView;

-(void)openBack
{
    [self.navigationController dismissModalViewControllerAnimated:YES];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
//        self.title=@"Change Password";
//        self.navigationItem.leftBarButtonItem=nil;
        addNavigationBar(languageSelectedStringForKey(@"Change Password"), NAV_LEFT_BACK, NAV_RIGHT_DONE, self);
        
    }
    return self;
}

// send the request to server for change password
-(void)sendChangePasswordRequest
{
//    LoginResponse *lres=nil;
//    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
//    NSData *cData = [prefs objectForKey:USERID];
//    
//    if ((cData.length>0)&&(cData!= nil )){
//        lres = [NSKeyedUnarchiver unarchiveObjectWithData:cData];
//    }
//    if (cData != nil) {
//        cData = nil;
//    }
//    Request *req=[[Request alloc] init];
//    req.delegate=self;
//    [req request:CHANGE_PASSWORD Parameter:[NSString stringWithFormat:@"email=%@&password=%@",lres.Email,self.txtPassword.text]];
//    [req release];
}
#pragma mark - Response Methods
// Delegate methods of request class to get response data
-(void)getResponce:(id)jsonData
{
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"PasswordChange"];
    [self dismissModalViewControllerAnimated:YES];
}
// action mwthod of change password button
-(IBAction)changePassword:(id)sender{
    if (![self.txtPassword.text isEqualToString:self.txtVerifyPassword.text ] || [self.txtVerifyPassword.text length]<5 ||[self.txtPassword.text length]<5 ){
        showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(@"INV_PWD_MESSAGE"));
        return;
    }
    [self sendChangePasswordRequest];
}

// check validation of password
- (BOOL)validateEmailAndPassword:(UITextField *)passwordField
{
    NSString *password = passwordField.text;
    passwordValid=[password length]<15;
    if ([password length] < 15)
    {
        return YES;
    }
    else
    {
        showAlertScreen(languageSelectedStringForKey(INVALID_PASSWORD),languageSelectedStringForKey(@"INV_PWD_MESSAGE"));
        return NO;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void) viewWillAppear:(BOOL)animated{
//    NavigationBarStyle();
    _myChangePasswordView.frame=CGRectMake(0, IS_IPAD?5:-10, [AppDelegate sharedAppDelegate].screenWidth, [AppDelegate sharedAppDelegate].screenHeight-[AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame.size.height+20);
    
    
    
    self.navigationController.navigationBar.transform = CGAffineTransformMakeScale([UIScreen mainScreen].applicationFrame.size.width / 320.0f, [UIScreen mainScreen].applicationFrame.size.height / 479.0f);
    
    self.navigationController.navigationBar.frame = CGRectMake(0, 20,[AppDelegate sharedAppDelegate].screenWidth,IS_IPAD?92:44);
    
    
    [AppDelegate sharedAppDelegate].naviGationController.visibleViewController.view.frame = CGRectMake(0, 0,[AppDelegate sharedAppDelegate].screenWidth,[AppDelegate sharedAppDelegate].screenHeight-60);
    
    self.view.frame=CGRectMake(0, 561, 768, 1024);
    
	self.view.transform = CGAffineTransformMakeScale([UIScreen mainScreen].applicationFrame.size.width / 320.0f, [UIScreen mainScreen].applicationFrame.size.height / 479.0f);

        
    
    self.lblChangePwd.text= languageSelectedStringForKey(@"Change Password");
    self.txtPassword.placeholder = languageSelectedStringForKey(@"password");
    self.txtVerifyPassword.placeholder = languageSelectedStringForKey(@"Verify Password");
    [self.btnChange setTitle:languageSelectedStringForKey(@"Change Password") forState:UIControlStateNormal];
    
}
-(void)viewDidUnload
{
    NSString *str=@"hjbhjx";
    
    str=[str commonPrefixWithString:@" " options:NSCaseInsensitiveSearch];
    
    self.btnChange=nil;
    self.txtPassword=nil;
    self.txtVerifyPassword=nil;
    
    [self setLblChangePwd:nil];
    [self setMyChangePasswordView:nil];
    [super viewDidUnload];
}
-(void)dealloc
{
    self.btnChange=nil;
    self.txtPassword=nil;
    self.txtVerifyPassword=nil;
    [_lblChangePwd release];
    [_myChangePasswordView release];
    [super dealloc];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark- Text field methods
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isEqual:self.txtPassword])
    {
        [self.txtVerifyPassword becomeFirstResponder];
    }
    else if ([textField isEqual:self.txtVerifyPassword])
    {
        [self.txtVerifyPassword resignFirstResponder];
    }
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([textField isEqual:self.txtPassword] && [self validateEmailAndPassword:self.txtPassword])
    {
        return passwordValid;
    }
    else if ([textField isEqual:self.txtVerifyPassword] && [self validateEmailAndPassword:self.txtVerifyPassword])
    {
        return passwordValid;
    }
    return YES;
}

@end
