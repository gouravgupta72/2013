//
//  AdminListViewController.h
//  CoreMoney
// Class use for create admin list
#import <UIKit/UIKit.h>
#import "PopUpView.h"
#import "AdminProfileViewController.h"
#import "adminLoadLimitDataClass.h"
@interface AdminListViewController : SwipeViewController<DataParsingDelegate>
{
    
    int selectedIndex, newStatus, RequestId;
    UIView *statusSelectView;
    adminLoadLimitDataClass *adminLoadObj;
}
@property (retain, nonatomic) IBOutlet UITableView *tableViewAdminList;
@end
