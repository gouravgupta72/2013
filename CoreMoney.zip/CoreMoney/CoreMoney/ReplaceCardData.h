//
//  ReplaceCardData.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface ReplaceCardData : NSObject
{
    NSString *CARDNUMBER, *ResErrorCode, *ResErrorMsg;
    int ResCode;
}

@property (nonatomic,retain)NSString *CARDNUMBER, *ResErrorCode, *ResErrorMsg;
@property int ResCode;
@end
