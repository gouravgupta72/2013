//
//  Request.m
//

#import "Request.h"
#import "XMLReader.h"
@implementation Request
@synthesize delegate;


-(void)request:(NSString *)Action Parameter:(NSString *)parameter 
{
    if (!validateNetwork(self))
    {
        NSString *queryForServer=[NSString stringWithFormat:@"%@%@%@",SERVER_DOMAIN,Action,parameter];
       
        
        NSLog(@"%@",queryForServer);
        
        NSMutableURLRequest* urlRequest = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:queryForServer]
                                                                       cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                                                   timeoutInterval:120];
        conn = [[NSURLConnection alloc]initWithRequest:urlRequest delegate:self];
        [urlRequest setHTTPMethod:@"GET"];
        
        if(conn)
        {
            
            webData = [[NSMutableData data] retain];
        }
        else
        {
            NSLog(@"theConnection is NULL");
        }
        
    }
    else
    {
        [[AppDelegate sharedAppDelegate] removeLoadingView];
    }
    
}

    
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [webData setLength: 0];
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [webData appendData:data];
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    if (error!=nil) {
        if ([self.delegate conformsToProtocol:@protocol(RequestDelegate)])
        {
            if ([self.delegate respondsToSelector:@selector(getError:)])
            {
                [self.delegate getError:error];
            }
        }
    }
    showAlertScreen(@"Error", @"Request Time Out !!");
    [[AppDelegate sharedAppDelegate] removeLoadingView];
	[conn release];
    conn=nil;
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *parseError = nil;
    
    
    NSDictionary *xmlDictionary = [XMLReader dictionaryForXMLData:webData error:&parseError];
    
    
    [conn release];
    conn=nil;
    
    if (xmlDictionary!=nil)
    {
        if ([self.delegate conformsToProtocol:@protocol(RequestDelegate)])
        {
            if ([self.delegate respondsToSelector:@selector(getResult:)])
            {
                [self.delegate getResult:xmlDictionary];
            }
        }
    }
    else
    {
        showAlertScreen(@"Error", @"Unable to process");
        [[AppDelegate sharedAppDelegate] removeLoadingView];
    }
}


-(void)dealloc
{
    self.delegate=nil;
    [super dealloc];
}
@end
