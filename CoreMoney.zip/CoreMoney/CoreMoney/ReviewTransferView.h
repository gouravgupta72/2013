//
//  ReviewTransferView.h
//  CoreMoney
//

#import <UIKit/UIKit.h>

@interface ReviewTransferView : UITableViewCell

{
    UILabel * bankName,* lblCardNumber,*indate,*lblBal,*lblCompdate,*lblstatus;
    UIButton *btnChangeStatus;
    
}
//- (id)initWithFrame:(CGRect)frame reviewData:(ReviewData *) reviewObj;
@property (nonatomic,retain) UILabel * bankName,* lblCardNumber,*indate,*lblBal,*lblCompdate,*lblstatus;

@property (nonatomic,retain) UIButton *btnChangeStatus;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del;
@end
