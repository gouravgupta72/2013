//
//  AlertDetailViewCell.m
//  CoreMoney
//
// class use for create cell for alert detail view 

#import "AlertDetailViewCell.h"

@implementation AlertDetailViewCell
@synthesize lblLeftFirst,lblLeftSecond,lblLeftFourth,lblLeftThird,lblRightFirst,lblRightFourth,lblRightSecond,lblRightThird,btnChangeStatus,imgArrow, imgBackGround, btnRead, btnDelete, viewCellBottom, btnOpenBottomView, delegate, imgViewBottmViewIndicator;

//Designing subcategories of Alert Detail  View for Red ,Amber and green

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {

        
        lblLeftFirst = [[UILabel alloc] init];
        lblLeftFirst.font = FONT_ARIAL_18;
        lblLeftFirst.textColor = Name_color_Code;
        lblLeftFirst.textAlignment = UITextAlignmentLeft;
        lblLeftFirst.backgroundColor = [UIColor clearColor];
        [self addSubview:lblLeftFirst];
        
        [lblLeftFirst release];
        
        lblRightFirst = [[UILabel alloc] init];
        lblRightFirst.font = FONT_ARIAL_18;
        lblRightFirst.textAlignment = UITextAlignmentRight;
        lblRightFirst.backgroundColor = [UIColor clearColor];
        [self addSubview:lblRightFirst];
        [lblRightFirst release];
        
        lblLeftSecond = [[UILabel alloc] init];
        lblLeftSecond.font = FONT_ARIAL_16;
        lblLeftSecond.textAlignment = UITextAlignmentLeft;
        lblLeftSecond.backgroundColor = [UIColor clearColor];
        [self addSubview:lblLeftSecond];
        [lblLeftSecond release];
        
        lblRightSecond = [[UILabel alloc] init];
        lblRightSecond.font = FONT_ARIAL_16;
        lblRightSecond.textColor = [UIColor grayColor];
        lblRightSecond.textAlignment = UITextAlignmentRight;
        lblRightSecond.backgroundColor = [UIColor clearColor];
        [self addSubview:lblRightSecond];
        [lblRightSecond release];
        
        lblLeftThird = [[UILabel alloc] init];
        lblLeftThird.font = FONT_ARIAL_16;
        lblLeftThird.textAlignment = UITextAlignmentLeft;
        lblLeftThird.backgroundColor = [UIColor clearColor];
        [self addSubview:lblLeftThird];
        [lblLeftThird release];
        
        lblRightThird = [[UILabel alloc] init];
        lblRightThird.font = FONT_ARIAL_16;
        lblRightThird.textAlignment = UITextAlignmentRight;
        lblRightThird.backgroundColor = [UIColor clearColor];
        [self addSubview:lblRightThird];
        [lblRightThird release];
        
        lblLeftFourth = [[UILabel alloc] init];
        lblLeftFourth.textColor = [UIColor grayColor];
        lblLeftFourth.textAlignment = UITextAlignmentLeft;
        lblLeftFourth.backgroundColor = [UIColor clearColor];
        [self addSubview:lblLeftFourth];
        [lblLeftFourth release];
        
        lblRightFourth = [[UILabel alloc] init];
        lblRightFourth.font = FONT_ARIAL_16;
        lblRightFourth.textAlignment= UITextAlignmentRight;
        lblRightFourth.backgroundColor = [UIColor clearColor];
        [self addSubview:lblRightFourth];
        [lblRightFourth release];
        
        
        imgArrow =[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"imgStatusInactive.png"]];
        [self addSubview:imgArrow];
        imgArrow.hidden = YES;
        [imgArrow release];
        
        btnChangeStatus = [[UIButton alloc] init];
        [btnChangeStatus addTarget:self action:@selector(openStatus) forControlEvents:UIControlEventTouchUpInside];
        btnChangeStatus.backgroundColor = [UIColor clearColor];
        btnChangeStatus.hidden = YES;
        [self addSubview:btnChangeStatus];
        [btnChangeStatus release];
        
        
    }
    return self;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier imageHeight:(CGFloat)imageHeight delegate:(id)del
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        isBottomViewOpen = NO;
        self.delegate = del;
        self.imgBackGround = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.contentView.frame.size.width, imageHeight)];
        [self addSubview:self.imgBackGround];
        [self.imgBackGround release];
        
        
        
        self.viewCellBottom = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.imgBackGround.frame), self.contentView.frame.size.width, 36)];
//        self.viewCellBottom.backgroundColor = [UIColor grayColor];
        self.viewCellBottom.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Container.png"]];
        [self addSubview:self.viewCellBottom];
//        self.viewCellBottom.hidden = YES;
        [self.viewCellBottom release];
        
        self.btnRead = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetMaxX(self.viewCellBottom.frame) - 240, 5, 97, 25)];
        self.btnRead.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ButtonInActive.png"]];
        [self.btnRead setTitle:@"Read" forState:UIControlStateNormal];
        self.btnRead.enabled = NO;
        [self.btnRead addTarget:del action:@selector(tappedRead:) forControlEvents:UIControlEventTouchUpInside];
        [self.viewCellBottom addSubview:self.btnRead];
        [self.btnRead release];
        
        self.btnDelete = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetMaxX(self.viewCellBottom.frame) - 110, 5, 97, 25)];
        self.btnDelete.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ButtonActive.png"]];
        [self.btnDelete addTarget:del action:@selector(tappedDelete:) forControlEvents:UIControlEventTouchUpInside];
        [self.btnDelete setTitle:@"Delete" forState:UIControlStateNormal];
        [self.viewCellBottom addSubview:self.btnDelete];
        [self.btnDelete release];
        
        lblLeftFirst = [[UILabel alloc] init];
        lblLeftFirst.font = FONT_ARIAL_18;
        lblLeftFirst.textColor = Name_color_Code;
        lblLeftFirst.textAlignment = UITextAlignmentLeft;
        lblLeftFirst.backgroundColor = [UIColor clearColor];
        [self.imgBackGround addSubview:lblLeftFirst];
        
        [lblLeftFirst release];
        
        lblRightFirst = [[UILabel alloc] init];
        lblRightFirst.font = FONT_ARIAL_18;
        lblRightFirst.textAlignment = UITextAlignmentRight;
        lblRightFirst.backgroundColor = [UIColor clearColor];
        [self.imgBackGround addSubview:lblRightFirst];
        [lblRightFirst release];
        
        lblLeftSecond = [[UILabel alloc] init];
        lblLeftSecond.font = FONT_ARIAL_16;
        lblLeftSecond.textAlignment = UITextAlignmentLeft;
        lblLeftSecond.backgroundColor = [UIColor clearColor];
        [self.imgBackGround addSubview:lblLeftSecond];
        [lblLeftSecond release];
        
        lblRightSecond = [[UILabel alloc] init];
        lblRightSecond.font = FONT_ARIAL_16;
        lblRightSecond.textColor = [UIColor grayColor];
        lblRightSecond.textAlignment = UITextAlignmentRight;
        lblRightSecond.backgroundColor = [UIColor clearColor];
        [self.imgBackGround addSubview:lblRightSecond];
        [lblRightSecond release];
        
        lblLeftThird = [[UILabel alloc] init];
        lblLeftThird.font = FONT_ARIAL_16;
        lblLeftThird.textAlignment = UITextAlignmentLeft;
        lblLeftThird.backgroundColor = [UIColor clearColor];
        [self.imgBackGround addSubview:lblLeftThird];
        [lblLeftThird release];
        
        lblRightThird = [[UILabel alloc] init];
        lblRightThird.font = FONT_ARIAL_16;
        lblRightThird.textAlignment = UITextAlignmentRight;
        lblRightThird.backgroundColor = [UIColor clearColor];
        [self.imgBackGround addSubview:lblRightThird];
        [lblRightThird release];
        
        lblLeftFourth = [[UILabel alloc] init];
        lblLeftFourth.textColor = [UIColor grayColor];
        lblLeftFourth.textAlignment = UITextAlignmentLeft;
        lblLeftFourth.backgroundColor = [UIColor clearColor];
        [self.imgBackGround addSubview:lblLeftFourth];
        [lblLeftFourth release];
        
        lblRightFourth = [[UILabel alloc] init];
        lblRightFourth.font = FONT_ARIAL_16;
        lblRightFourth.textAlignment= UITextAlignmentRight;
        lblRightFourth.backgroundColor = [UIColor clearColor];
        [self.imgBackGround addSubview:lblRightFourth];
        [lblRightFourth release];
        
        
        imgArrow =[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"imgStatusInactive.png"]];
        [self.imgBackGround addSubview:imgArrow];
        imgArrow.hidden = YES;
        [imgArrow release];
        
        btnChangeStatus = [[UIButton alloc] init];
       [btnChangeStatus addTarget:self action:@selector(openStatus) forControlEvents:UIControlEventTouchUpInside];
        btnChangeStatus.backgroundColor = [UIColor clearColor];
        btnChangeStatus.hidden = YES;
        [self.imgBackGround addSubview:btnChangeStatus];
        [btnChangeStatus release];
        
        
        self.imgViewBottmViewIndicator = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Down Arrow.png"]];
        [self.imgBackGround addSubview:self.imgViewBottmViewIndicator];
        [self.imgViewBottmViewIndicator setFrame:CGRectMake(CGRectGetMaxX(self.imgBackGround.frame)-30, CGRectGetMaxY(self.imgBackGround.frame)-30, 30, 30)];
        [self.imgViewBottmViewIndicator release];
        
        //createButton(CGRectMake(0, CGRectGetMaxY(lblCardNumber.frame)-5, 145, 20), @"", @"", self, @selector(openStatus:));
        btnOpenBottomView = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetMaxX(self.imgBackGround.frame)-40, CGRectGetMaxY(self.imgBackGround.frame)-40, 40, 40)];
        
//        btnOpenBottomView = createButton(CGRectMake(200, 40, 30, 30), @"", @"", self, @selector(methodBtnOpenBottomView));
        [btnOpenBottomView addTarget:del action:@selector(methodBtnOpenBottomView:) forControlEvents:UIControlEventTouchUpInside];
        btnOpenBottomView.backgroundColor = [UIColor clearColor];
//        [btnOpenBottomView setTitle:@"Off" forState:UIControlStateNormal];
        
        [imgBackGround addSubview:btnOpenBottomView];
        [btnOpenBottomView release];
    }
    return self;
}

-(void) methodBtnOpenBottomView
{
    NSLog(@"khan");
    if (isBottomViewOpen)
    {
        self.viewCellBottom.hidden = YES;
        isBottomViewOpen = NO;
    }
    else
    {
        self.viewCellBottom.hidden = NO;
        isBottomViewOpen = YES;
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
