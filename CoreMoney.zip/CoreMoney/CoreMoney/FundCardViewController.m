//
//  FundCardViewController.m
//  CoreMoney
// Class used for create Fund View
#import "FundCardViewController.h"

@interface FundCardViewController ()
//- (IBAction)removeAmount:(id)sender;
- (IBAction)submitAmount:(id)sender;
- (IBAction)addAmount:(id)sender;
- (IBAction)clickedRemoveBtn:(id)sender;
- (IBAction)clickedAddBalBtn:(id)sender;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil CardData:(CardDetailClass *) carddata;
-(void)openSlide;
-(void) createMoveAnimation:(CGPoint)pos;
-(void) reInitializedBalfeild;
-(void) fillData;
-(void) isHiddenBtn;
-(void) createBorderAtView:(UIView *)viewObj;
-(void) openBack;
-(void) setOfset;
@end

@implementation FundCardViewController
@synthesize cardDataObj;

//- (IBAction)removeAmount:(id)sender {
    
    //    if (totalBal>0) {
    //        totalBal = 0;
    //
    //        [[AppDelegate sharedAppDelegate] addloadingView];
    //        [self performSelector:@selector(reInitializedBalfeild) withObject:nil afterDelay:1.0];
    //        self.txtAddBal.text = @"";
    //
    //    }
//}

// method use for submit amount
- (IBAction)submitAmount:(id)sender
{
    
    
    if(self.txtAddBal.text.length>0)
    {
        if (isAddViewShow) {
            showAlertWithOtherButtons(@"", @"Do you want to submit?", 1, self);
        }else
        {
            showAlertWithOtherButtons(@"", @"Do you want to submit?", 2, self);
        }
        
    }
    else
    {
        showAlertScreen(languageSelectedStringForKey(@"") ,languageSelectedStringForKey(@"Please enter correct amount") );
    }
}

/// method use for open slide menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

// method use for add amount 
- (IBAction)addAmount:(id)sender
{
    if(totalBal>0){
        [[AppDelegate sharedAppDelegate] addloadingView];
        [self performSelector:@selector(reInitializedBalfeild) withObject:nil afterDelay:1.0];
    }
    else{
        showAlertScreen(languageSelectedStringForKey(@"Alert") ,languageSelectedStringForKey(@"Please enter correct amount") );
    }
}

-(void) reInitializedBtn
{
    
    if (self.removeBtnView.center.y>(self.addBtnView.center.y+self.addBtnView.frame.size.height/2+16))
    {
        [self createMoveAnimation:CGPointMake(self.removeBtnView.center.x, self.addBtnView.center.y+self.addBtnView.frame.size.height/2+15+self.removeBtnView.frame.size.height/2)];
       
    }
    
    [self.addFundView removeFromSuperview];
    [self.lblTopMsgView removeFromSuperview];
    self.btnOutSideTouch.enabled = NO;
}

// method use for remove balance
- (IBAction)clickedRemoveBtn:(id)sender
{
    self.txtAddBal.text = @"";
    
    totalBal = self.cardDataObj.AVAILABLEBALANCE;
    self.btnOutSideTouch.enabled = YES;
    self.lblTotalBalatAddView.text =[NSString stringWithFormat:@"%@",displayCurrency( ChangeTocurrency(self.cardDataObj.AVAILABLEBALANCE))] ;
    isAddViewShow = NO;
    
    if (self.removeBtnView.center.y>(self.addBtnView.center.y+self.addBtnView.frame.size.height/2+16))
    {
        self.removeBtnView.center = CGPointMake(self.removeBtnView.center.x, self.addBtnView.center.y+self.addBtnView.frame.size.height/2+15+self.removeBtnView.frame.size.height/2);
    }
    
    self.addFundView.frame = CGRectMake(self.removeBtnView.frame.origin.x,self.removeBtnView.frame.origin.y, self.addFundView.frame.size.width, self.addFundView.frame.size.height);
    
    self.lblTopMsgView.frame = CGRectMake(self.addFundView.frame.origin.x+25, self.addFundView.frame.origin.y-11, self.lblTopMsgView.frame.size.width, self.lblTopMsgView.frame.size.height);
    
    self.lblTopMsgView.text = languageSelectedStringForKey(@"Remove Fund"); 
    self.btnOutSideTouch.frame = self.lblTopMsgView.frame;
    self.btnOutSideTouch.center = self.lblTopMsgView.center;
    [self.pageScroll addSubview:self.addFundView];
    [self.pageScroll addSubview:self.lblTopMsgView];
}

- (IBAction)clickedAddBalBtn:(id)sender
{
    
    totalBal = self.cardDataObj.AVAILABLEBALANCE;
    
    self.lblTotalBalatAddView.text =[NSString stringWithFormat:@"%@", displayCurrency(ChangeTocurrency(self.cardDataObj.AVAILABLEBALANCE))] ;
    
    isAddViewShow = YES;
    self.btnOutSideTouch.enabled = YES;
    self.lblTopMsgView.text = languageSelectedStringForKey(@"Add Fund");
    
    self.txtAddBal.text = @"";
    
    self.addFundView.frame = CGRectMake(self.addBtnView.frame.origin.x,self.addBtnView.frame.origin.y, self.addFundView.frame.size.width, self.addFundView.frame.size.height);
    
    self.lblTopMsgView.frame = CGRectMake(self.addFundView.frame.origin.x+25, self.addFundView.frame.origin.y-11, self.lblTopMsgView.frame.size.width, self.lblTopMsgView.frame.size.height);
    
    [self createMoveAnimation:CGPointMake(self.removeBtnView.center.x, self.removeBtnView.frame.size.height/2+(self.addFundView.center.y+self.addFundView.frame.size.height/2)+15)];
   // self.removeBtnView.center = CGPointMake(self.removeBtnView.center.x, self.removeBtnView.frame.size.height/2+(self.addFundView.center.y+self.addFundView.frame.size.height/2)+15);
    self.btnOutSideTouch.frame = self.lblTopMsgView.frame;
    self.btnOutSideTouch.center = self.lblTopMsgView.center;
    [self.pageScroll addSubview:self.addFundView];
    [self.pageScroll addSubview:self.lblTopMsgView];
    // [self.view bringSubviewToFront:self.addFundView];
}

// create move animation
-(void) createMoveAnimation:(CGPoint)pos
{
    [UIView animateWithDuration:0.2f
                          delay:0.0f
                        options: UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         self.removeBtnView.center = CGPointMake(pos.x, pos.y);
                     }
                     completion:nil];
    
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil CardData:(CardDetailClass *) carddata
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
        addNavigationBar(FUND_CARD_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);

        
    }
    return self;
}

// method use for reinitialeze the balance field
-(void) reInitializedBalfeild
{
    if (isAddViewShow)
    {
        self.cardDataObj.AVAILABLEBALANCE=self.cardDataObj.AVAILABLEBALANCE+Ammount;
        self.cardDataObj.CURRENTBALANCE=self.cardDataObj.CURRENTBALANCE+Ammount;
    }else
    {
        self.cardDataObj.AVAILABLEBALANCE=self.cardDataObj.AVAILABLEBALANCE-Ammount;
        self.cardDataObj.CURRENTBALANCE=self.cardDataObj.CURRENTBALANCE-Ammount;
    }
    
//    [[AppDelegate sharedAppDelegate].arrCardDetailArray replaceObjectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex withObject:cardDataObj];
    
    [self setOfset];
    
    [self.lblTopMsgView removeFromSuperview];
    
    [self.addFundView removeFromSuperview];
    
    //self.lblTopMsgView = nil;
    ///self.
    if(isAddViewShow == YES)
    {
        self.removeBtnView.center = CGPointMake(self.removeBtnView.center.x, self.removeBtnView.frame.size.height/2+(self.addBtnView.center.y+self.addBtnView.frame.size.height/2)+15);
    }
    
    self.cardDataObj.AVAILABLEBALANCE = totalBal;
    
    //[self isHiddenBtn];
    self.txtAddBal.text = @"";
    
    self.lblBalance.text = [NSString stringWithFormat:@"%@", displayCurrency(ChangeTocurrency(totalBal))];
    
    self.lblTotalBalatAddView.text = [NSString stringWithFormat:@"%@", displayCurrency(ChangeTocurrency(totalBal))];
    
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    
}
//method use for initialize field
-(void) fillData{
    
        
    self.lblUserName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings(self.cardDataObj.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@ ",self.cardDataObj.FIRSTNAME],checkISNullStrings(self.cardDataObj.LASTNAME)?@"":[NSString stringWithFormat:@"%@",self.cardDataObj.LASTNAME]];

    self.lblCardNumber.text = ChangeCardNumber(self.cardDataObj.CARDNUMBER);
    
    totalBal = self.cardDataObj.AVAILABLEBALANCE;
    
    self.lblTotalBalatAddView.text =[NSString stringWithFormat:@"%@", displayCurrency(ChangeTocurrency(self.cardDataObj.AVAILABLEBALANCE))] ;
    
    self.lblBalance.text = [NSString stringWithFormat:@"%@", displayCurrency(ChangeTocurrency(self.cardDataObj.AVAILABLEBALANCE))] ;
    
    
    self.lblAddBal.text = languageSelectedStringForKey(@"Add Fund");
    self.lblRemoveBal.text = languageSelectedStringForKey(@"Remove Fund");
    self.lblAmountMsg.text = languageSelectedStringForKey(@"Amount");
    self.lblNewBalMsg.text = languageSelectedStringForKey(@"New Balance");
    
    self.lblStatus.text=CardStatusValue(self.cardDataObj.STATUS_CARDACCOUNT);

    
    
}
// method use for hide buttons
-(void) isHiddenBtn{
    if (totalBal<=0)
    {
        self.btnAddAmt.hidden = NO;
        self.btnRemoveamount.hidden = YES;
      //  self.btnSubmit.hidden  = YES;
    }
    else
    {
        self.btnAddAmt.hidden = YES;
        self.btnRemoveamount.hidden = NO;
      //  self.btnSubmit.hidden  = NO;
    }
    
}

// method use for create border at view
-(void) createBorderAtView:(UIView *)viewObj{
    
    viewObj.layer.borderWidth = 1;
    viewObj.layer.cornerRadius = 8;
    viewObj.layer.borderColor = [UIColor grayColor].CGColor;
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self setOfset];
}
- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{

}
- (void)viewDidLoad
{
    self.pageScroll.maindelegate = self;
    self.cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];

    self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, 320, 480);
    self.pageScroll.frame = CGRectMake(self.pageScroll.frame.origin.x,(IS_IOS7?(IS_IPAD?120:60):120), self.pageScroll.frame.size.width, self.pageScroll.frame.size.height);
    [self fillData];
    
    [self createBorderAtView:self.addBtnView];
    [self createBorderAtView:self.removeBtnView];
    [self createBorderAtView:self.addFundView];
        
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
}

-(void) viewWillAppear:(BOOL)animated
{
    [AppDelegate sharedAppDelegate].classType=CARDS_FUND_CARD_PAGE;
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    //[self isHiddenBtn];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Pop to previous View
-(void)openBack
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    [self updateCardDetail];
    
}

-(void)updateCardDetail
{
    request_Id = 2;
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    NSLog(@"%@",self.cardDataObj.ACCOUNTNUMBER);
    [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=&deBsAccountNumber=%@&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=&deBusinessName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,self.cardDataObj.ACCOUNTNUMBER,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBACardHolderList];
    
    [DataReq release];
}
-(void) delyedOpen
{
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)dealloc {
    [_lblUserName release];
    [_lblCardNumber release];
    [_lblStatus release];
    [_lblBalance release];
    [_txtAddBal release];
    [_lblTxtAvailBal release];
    [_btnRemoveamount release];
    [_btnAddAmt release];
    [_pageScroll release];
    [_addBtnView release];
    [_removeBtnView release];
    [_lblAddBal release];
    [_lblRemoveBal release];
    [_addFundView release];
    [_lblTopMsgView release];
    [_lblAmountMsg release];
    [_lblNewBalMsg release];
    [_lblTotalBalatAddView release];
    [_btnOutSideTouch release];
    [_bgView release];
    [super dealloc];
}

- (void)viewDidUnload {
    [self setLblUserName:nil];
    [self setLblCardNumber:nil];
    [self setLblStatus:nil];
    [self setLblBalance:nil];
    [self setTxtAddBal:nil];
    [self setLblTxtAvailBal:nil];
    [self setBtnRemoveamount:nil];
    [self setBtnAddAmt:nil];
    [self setPageScroll:nil];
    [self setAddBtnView:nil];
    [self setRemoveBtnView:nil];
    [self setLblAddBal:nil];
    [self setLblRemoveBal:nil];
    [self setAddFundView:nil];
    [self setLblTopMsgView:nil];
    [self setLblAmountMsg:nil];
    [self setLblNewBalMsg:nil];
    [self setLblTotalBalatAddView:nil];
    [self setCardDataObj:nil];
    [self setBtnOutSideTouch:nil];
    [self setBgView:nil];
    [super viewDidUnload];
}

// set page in previouse position
-(void) setOfset
{
    [self.pageScroll setContentSize:CGSizeMake(320,340)];
    
    self.pageScroll.contentOffset=CGPointMake(0, 0);
    
    [self.txtAddBal resignFirstResponder];
    
    
}


#pragma mark - Request Work
-(void)AddFundCardRequest
{
    request_Id = 1;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Fund_Card_Add_Request;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deCIAUserID=%@&deLoadSrvcReqCardNumber=%@&deBCCSClientID=%@&deBulkLoadSrvcReqAmount=%@&deCIAStoreID=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,self.cardDataObj.CARDNUMBER,self.cardDataObj.CLIENTID,checkISNullStrings(self.txtAddBal.text)?@"":self.txtAddBal.text,[SystemConfiguration sharedSystemConfig].deIVRSource];
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcStartSingleLoad];
     
    [Datareq release];
    
}

-(void)RemoveFundCardRequest
{
    request_Id = 1;
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Fund_Card_Delete_Request;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deCIAUserID=%@&dbbSystemExtLogin=%@&deLoadSrvcReqCardNumber=%@&deBCCSClientID=%@&deBulkLoadSrvcReqAmount=%@&deCIAStoreID=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,self.cardDataObj.CARDNUMBER,self.cardDataObj.CLIENTID,checkISNullStrings(self.txtAddBal.text)?@"":self.txtAddBal.text,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcStartSingleUnload];
    
    [Datareq release];
    
}
#pragma mark - Response Methods
// Delegate methods of request class to get response data

-(void)getResponce:(id)jsonData
{
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    if (request_Id == 1) {
        if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
        {
            LoginResponceDataClass *obj=(LoginResponceDataClass *)jsonData;
            
            if (obj.Error_Code==1)
            {
                [self performSelector:@selector(reInitializedBalfeild) withObject:nil afterDelay:0.0];
            }
            showAlertScreen(nil, obj.ErrorMsg);
        }

    }else
    {
        if ([jsonData isKindOfClass:[NSArray class]])
        {
            if ([jsonData count]>0)
            {
                CardDetailClass *dataObj=[jsonData objectAtIndex:0];
                [[AppDelegate sharedAppDelegate].arrCardDetailArray replaceObjectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex withObject:dataObj];
            }
        }
        [[AppDelegate sharedAppDelegate] removeLoadingView];
        [self performSelector:@selector(delyedOpen) withObject:nil afterDelay:0.5];
    }
}


#pragma -mark UITextField Method

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    //[date stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
    NSString *strAmount = @"0";
    if (self.lblBalance.text.length > 0)
    {
        strAmount = [[self.lblBalance.text substringFromIndex:1] stringByReplacingOccurrencesOfString:@"," withString:@""];
    }
    
    
    totalBal = [strAmount  floatValue];
//    if(self.txtAddBal.text.length>0 && [self.txtAddBal.text floatValue] > 0)
//    {
        if(isAddViewShow == YES)
        {
            float val = [self.txtAddBal.text floatValue];
            totalBal = val + totalBal;
            self.lblTotalBalatAddView.text =[NSString stringWithFormat:@"%@",displayCurrency( ChangeTocurrency(totalBal))]  ;//[NSString stringWithFormat:@"%f",totalBal];
            /// self.txtAddBal.text = @"";
            // [self setOfset];
        }
        else
        {
            if(totalBal > [self.txtAddBal.text floatValue])
            {
                float val = [self.txtAddBal.text floatValue];
                totalBal = ( totalBal -val);
                self.lblTotalBalatAddView.text =[NSString stringWithFormat:@"%@",displayCurrency( ChangeTocurrency(totalBal))] ;//[NSString stringWithFormat:@"%f",totalBal];
                // self.txtAddBal.text = @"";
                
            }
            else{
                showAlertScreen(languageSelectedStringForKey(@"Incorrect value") ,languageSelectedStringForKey(@"Please enter amount less then current amount") );
            }
            
        }
        //[textField resignFirstResponder];
        
//    }
    [self setOfset];
    // [self setOfset];
    //[textField resignFirstResponder];
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return digitValidationOnNumKeyboard(textField,range,string);
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    textField.text=[NSString stringWithFormat:@"%0.2f",changeTextToAmount(textField.text)];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    
    if(isAddViewShow == YES)
        [self.pageScroll setContentOffset:CGPointMake(0, 30) animated:YES];
    else
        [self.pageScroll setContentOffset:CGPointMake(0, 80) animated:YES];
    
    [self.pageScroll setContentSize:CGSizeMake(320,450)];
    
    return YES;
}

#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 1)
    {
        if (buttonIndex == 0)
        {
            [[AppDelegate sharedAppDelegate] addloadingView];
            Ammount=[self.txtAddBal.text intValue];
            [self AddFundCardRequest];
        }
    }else if (alertView.tag == 2)
    {
        if (buttonIndex == 0)
        {
            [[AppDelegate sharedAppDelegate] addloadingView];
             Ammount=[self.txtAddBal.text intValue];
            [self RemoveFundCardRequest];
        }
    }
}
- (IBAction)clickedBtnOutsideTouch:(id)sender {
    
    [self reInitializedBtn];
}
@end
