//
//  AlertDetailViewCell.h
//  CoreMoney
//
// class use for create cell for alert detail view 
//

#import <UIKit/UIKit.h>

@interface AlertDetailViewCell : UITableViewCell
{
    UILabel *lblLeftFirst,*lblLeftSecond,*lblLeftThird,*lblLeftFourth;
    UILabel *lblRightFirst,*lblRightSecond,*lblRightThird,*lblRightFourth;
    UIButton *btnChangeStatus;
    UIImageView *imgArrow;
    UIView *imgBackGround;
    
    UIButton *btnRead;
    UIButton *btnDelete;
    UIView *viewCellBottom;
    UIButton *btnOpenBottomView;
    BOOL isBottomViewOpen;
    id delegate;
    UIImageView *imgViewBottmViewIndicator;
}
@property (nonatomic, retain)UIView *viewCellBottom;
@property (nonatomic, retain)UIImageView *imgViewBottmViewIndicator;
@property(nonatomic, assign)id delegate;
@property (nonatomic, retain) UIButton *btnOpenBottomView;
@property (nonatomic, retain) UILabel *lblLeftFirst,*lblLeftSecond,*lblLeftThird,*lblLeftFourth;
@property (nonatomic,retain)  UILabel *lblRightFirst,*lblRightSecond,*lblRightThird,*lblRightFourth;
@property (nonatomic,retain) UIButton *btnChangeStatus;
@property (nonatomic,retain) UIButton *btnRead;
@property (nonatomic,retain) UIButton *btnDelete;
@property (nonatomic,retain) UIImageView *imgArrow;
@property (nonatomic,retain) UIView *imgBackGround;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier imageHeight:(CGFloat)imageHeight delegate:(id)del;

@end
