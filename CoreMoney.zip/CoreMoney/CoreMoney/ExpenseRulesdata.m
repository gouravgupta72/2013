//
//  ExpenseRulesdata.m
//  CoreMoney
// Class is object class of expense rules class

#import "ExpenseRulesdata.h"

@implementation ExpenseRulesdata

@synthesize UseDailySpendLimit,UseMonthlySpendLimit,Daily_Spend_Limit,Monthly_Spend_Limit,International_Use_Allowed,UseMerchantCategory,ByPass_Card_Monetary_Limit,SingleTransaction_Spend_Limit,ByPassBusiness_BudgetLimit,Period,EXPENSE_CAT_ONE,EXPENSE_CAT_TWO,EXPENSE_CAT_THREE,Daily_Spend_Limit_business,Monthly_Spend_Limit_business,CATEGORY_DEF,murchantCatData,ShowSpendRuleOnSS,BypassBusinessBugdetLimitPeriod;

-(id) init
{
    self = [super init];
    if (self)
    {
        murchantCatData = [[NSMutableArray alloc] init];
    }
    return self;
}
-(void) dealloc
{
    UseMerchantCategory =nil;
    EXPENSE_CAT_ONE = nil;
    EXPENSE_CAT_TWO =nil;
    EXPENSE_CAT_THREE = nil;
    CATEGORY_DEF =nil;
    murchantCatData = nil;
    ShowSpendRuleOnSS=nil;
    BypassBusinessBugdetLimitPeriod=nil;
    [super dealloc];
    
}
@end
