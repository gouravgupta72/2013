//
//  HelpMenuDataClass.m



// Class For hold data of Help Menu Design.

#import "HelpMenuDataClass.h"

@implementation HelpMenuDataClass
@synthesize strimgName,strTitle,tag;

// Initialize data.
-(id)initwithHelpData :(NSString *)imgName :(NSString *)title :(int)tags
{
    if (self)
    {
        [super init];
        self.strTitle=title;
        self.strimgName=imgName;
        self.tag=tags;
    }
    return self;
}

-(void)dealloc
{
    self.strimgName=nil;
    self.strTitle=nil;
    [super dealloc];
}
@end
