//
//  AlertsDetailViewController.h
//  CoreMoney
//
// class used for alert detail view  

#import <UIKit/UIKit.h>
#import "DataParsingClass.h"
#import "CardListViewController.h"
#import "AlertDetailViewCell.h"
#import "ComboViewController.h"
@interface AlertsDetailViewController : SwipeViewController<DataParsingDelegate>
{
    Alert_Type alertType;
    NSMutableArray *dataArray;
    UIView *statusSelectView;
    int selectedIndex,newCardStatus,requestID;
    alertColorGroup alertColorIdentifier; //enum used to identify alert card color
    cellHeight cellHeightForRow;
    NSString *strAccountNumber;
    NSString *strBussAccountID;
    CardDetailClass *objCardDetailClass;
    int selectedAlert;
    int requestType;
    int alertNumber;
    int alertBottomViewNumber;
    ComboViewController *comboView;
    UIView *popView;
    
    NSMutableArray *alertSearchArray;
}

@property (retain, nonatomic) IBOutlet UIView *backView;
@property (retain, nonatomic) IBOutlet UITableView *listTableView;
@property (nonatomic, retain) NSString *strAccountNumber;
@property (nonatomic, retain) NSString *strBussAccountID;
//added new parameter alertcolor in following method for identifing the card type is red ,amber or green
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil alertType:(Alert_Type )alerttype array:(NSMutableArray *) array alertGroup:(int)alertcolor;
-(void)markAll;

@end
