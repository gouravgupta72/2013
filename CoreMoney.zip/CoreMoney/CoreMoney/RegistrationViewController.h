//
//  RegistrationViewController.h

//

// Class for creating Registration View.

#import <UIKit/UIKit.h>
#import "Common.h"
#import "HelpMenu.h"
@interface RegistrationViewController : UIViewController<UITextFieldDelegate,UIScrollViewDelegate>
{
    BOOL firstNameValid,lastNameValid,emailValid,verifyEmailValid,passwordValid;
    NSString * emailID;
}
@property (retain, nonatomic) IBOutlet UIScrollView *pagescroll;
@property (retain, nonatomic) IBOutlet UITextField *txtFirstName;
@property (retain, nonatomic) IBOutlet UITextField *txtLastName;
@property (retain, nonatomic) IBOutlet UITextField *txtEmail;
@property (retain, nonatomic) IBOutlet UITextField *txtVarifyEmail;
@property (retain, nonatomic) IBOutlet UITextField *txtPassword;
@property (retain, nonatomic) IBOutlet UITextField *txtConfirmPassword;
@property (retain, nonatomic) IBOutlet UILabel *lblPassword;
@property (retain, nonatomic) IBOutlet UILabel *lblEmail;
@property (retain, nonatomic) IBOutlet UILabel *lblName;
@property(nonatomic,retain)NSString * emailID;
@property (retain, nonatomic) IBOutlet UIView *myRegistrationView;
@end
