//
//  employeeDataClass.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface employeeDataClass : NSObject
{
    NSString *ACCTID, *EmployeeId, *Name;
}
@property (nonatomic,retain) NSString *ACCTID, *EmployeeId, *Name;
@end
