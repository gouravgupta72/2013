//
//  CalanderSingleView.m
//  CoreMoney

//class use for calender Single view

#import "CalanderSingleView.h"

@implementation CalanderSingleView

- (id)initWithFrame:(CGRect)frame Delegate:(id) del
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        delgate = del;
        int widthPedding=1;
        int heightPedding=1;
        
        //self.backgroundColor = [UIColor blueColor];
        UIView *tempVw = [[UIView alloc] initWithFrame:CGRectMake(13, 60, 293, 220)];
        tempVw.backgroundColor = [UIColor blackColor];
        
        [self addSubview:tempVw];
        UIImageView *bgImg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 20, 320, 300)];
        bgImg.image = [UIImage imageNamed:@"img_boxcalender.png"];
        [self addSubview:bgImg];        
        
        UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 20,  320, 40)];
        lblTitle.textColor = [UIColor whiteColor];
        lblTitle.backgroundColor = [UIColor clearColor];
        lblTitle.textAlignment = NSTextAlignmentCenter;
        lblTitle.text =languageSelectedStringForKey(@"Select Month Date");
        [self addSubview:lblTitle];
        [lblTitle release];
        
        UIButton *btnCancel = createButton(CGRectMake(170-45, 315-33,60, 26), @"", imgNAV_CancelBtn, self, @selector(tapOnGrid:));
        [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        btnCancel.tag = 0;
        btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [self addSubview:btnCancel];
        [btnCancel release];

        
        
        
        int j=1,oX, oY;
        int tag = 30;
        for (int i = 1; i<=5; i++) {
            
                oY = (heightPedding +43)*(i-1);
            
            
            for (int k=1; k<=7; k++) {
            
                
                    oX = (widthPedding+41)*(k-1);
                               
                UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(oX, oY, 41, 43)];
                [btn setTitle:[NSString stringWithFormat:@"%d",tag] forState:UIControlStateNormal];
                
                if (j >2 && j<=33){
                    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                btn.tag =tag;
                btn.backgroundColor = [UIColor whiteColor];
                }
                else{
                    [btn setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
                    btn.backgroundColor = [UIColor lightGrayColor];
                    btn.enabled = NO;
                }
                [btn addTarget:self action:@selector(tapOnGrid:) forControlEvents:UIControlEventTouchUpInside];
                [tempVw addSubview:btn];
                tag++;
                if(j==2 || j==33)
                    tag = 1;
                j++;
            }
            
        }
        
    }
    return self;
}

-(void) tapOnGrid:(id) sender{
    UIButton *btn = (UIButton *)sender;
    
    [delgate getDateforFrequency:btn.tag];
}

-(void) getDateforFrequency:(int) dat
{
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
