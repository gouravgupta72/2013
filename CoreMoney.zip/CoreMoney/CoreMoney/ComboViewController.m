//
//  ComboViewController.m
//  CoreMoney
//

#import "ComboViewController.h"

@interface ComboViewController ()

@end

@implementation ComboViewController

@synthesize data,lblDefault,delegate,comboType;
-(void)openTable
{
    tblCombo.hidden=!tblCombo.hidden;
}
-(id)initWithFrame:(CGRect)frame records:(NSMutableArray *)recordsArray callingClassType:(int)classType
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.data=[[NSMutableArray alloc] initWithArray:recordsArray];
        
        comboBoxDesignClass=classType;
        
        self.layer.borderWidth = 1;
        self.layer.borderColor = [UIColor lightGrayColor].CGColor;
        self.layer.masksToBounds = YES;
        
        
        tblCombo=[[UITableView alloc] initWithFrame:CGRectMake(0,0,self.frame.size.width, self.frame.size.height)];
        tblCombo.delegate=self;
        tblCombo.dataSource=self;
        tblCombo.bounces  = NO;

        tblCombo.backgroundColor=[UIColor whiteColor];
        tblCombo.separatorColor=[UIColor lightGrayColor];
        [self addSubview:tblCombo];
        //[view release];
        tblCombo.layer.masksToBounds = YES;
        //tblCombo.layer.cornerRadius=3;
        tblCombo.scrollEnabled=YES;
        [tblCombo release];
        
        if ([self.data count]*44<tblCombo.frame.size.height)
        {
            tblCombo.frame=CGRectMake(tblCombo.frame.origin.x, tblCombo.frame.origin.y, frame.size.width, [self.data count]*44);
            self.frame=CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, CGRectGetMaxY(tblCombo.frame));
            tblCombo.scrollEnabled=NO;
        }
        
    }
    return self;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.data count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (comboBoxDesignClass)
    {

            case yearList:
        {
            return 25;
        }
            break;
            default:
        {
            return 44;
        }
            break;
    }
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    cell.textLabel.font=FONT_ARIAL_14;
    cell.textLabel.numberOfLines = 2;
    
    
    switch (comboBoxDesignClass)
    {
        case State:
        {
            secretQustionDataClass *obj=[data objectAtIndex:indexPath.row];
            cell.textLabel.text=obj.indexNo;
        }
            break;
        case selectQuestion:
        {
            secretQustionDataClass *obj=[data objectAtIndex:indexPath.row];
            cell.textLabel.text=obj.secretQuestion;
        }
            break;
            case other:
        {
            switch (self.comboType)
            {
                case BankName_Combo:
                {
                    ExternalBankDataClass *obj=[data objectAtIndex:indexPath.row];
                    cell.textLabel.text=obj.Bank_Name;
                }
                    break;
                case BankNumber_Combo:
                {
                    ExternalBankDataClass *obj=[data objectAtIndex:indexPath.row];
                    cell.textLabel.text=obj.BankAccountNumber;
                }
                    break;
                
                default:
                    cell.textLabel.text=[data objectAtIndex:indexPath.row];
                    break;
            }
        }
            break;
            case emp_List:
        {
            employeeDataClass *obj=[data objectAtIndex:indexPath.row];
            cell.textLabel.text=obj.Name;

        }
            break;
        case Category_List:
        {
            ExpenseCategoryData *obj=[data objectAtIndex:indexPath.row];
            cell.textLabel.text=obj.CATEGORY_LABEL;
        }
            break;
        case subCategory_List:
        {
            SubCategoryDataClass *obj=[data objectAtIndex:indexPath.row];
            cell.textLabel.text=obj.EXPCAT_VALUE;
        }
            break;
            case business_List:
        {
            businessListDataClass *obj=[data objectAtIndex:indexPath.row];
            cell.textLabel.text=obj.LUTDESCRIPTION;
        }
            break;
        case yearList:
        {
            cell.textLabel.font=FONT_ARIAL_11;
            cell.textLabel.text=[data objectAtIndex:indexPath.row];
        }

            break;
        case summarizedBy:
            cell.textLabel.text=[data objectAtIndex:indexPath.row];
            break;
        default:
            break;
    }
       return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [delegate selectQuetion:[data objectAtIndex:indexPath.row]];
}
-(void)dealloc
{
    if (self.data!=nil)
    {
        [self.data removeAllObjects];
        [data release];
        data=nil;
    }
   /// self.lblDefault=nil;
    [super dealloc];
}
// Method put here to remove compilation error. These are the delegate methods
-(void) selectQuetion:(id) que
{
    
}
@end
