//
//  AlertCountSearchClass.m
//  CoreMoney
//

#import "AlertCountSearchClass.h"

@implementation AlertCountSearchClass
@synthesize isDataNull,strCount,alertTypeNo,colorNo,strAlertName;
-(void) dealloc
{
    strCount = nil;
    [super dealloc];
}
@end
