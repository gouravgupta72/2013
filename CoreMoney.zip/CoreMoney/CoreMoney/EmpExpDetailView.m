//
//  EmpExpDetailView.m
//  CoreMoney
// class use for create a view for top view of employee expense view

#import "EmpExpDetailView.h"

@implementation EmpExpDetailView
@synthesize lblBusExpAmt,lblBusinessName,lblperiod,lblPeriodValue;
@synthesize lblCategory, lblCategoryAmount, lblEmpName, lblEmpId, lblEmpExpense, lblSummraizedAmount, lblSummraizedText, lblSummrazidBy;

- (id)initWithFrame:(CGRect)frame :(int)expenseType
{
    self = [super initWithFrame:frame];
    if (self) {
        
        lblBusinessName =createLabel(@"Business Name", CGRectMake(10, 8, 300, 26));
//        lblBusinessName.backgroundColor = [UIColor greenColor];
        lblBusinessName.textColor = Name_color_Code;
        lblBusinessName.font = FONT_ARIAL_16;
        
        [self addSubview:lblBusinessName];
        
        lblperiod = createLabel(@"Period :", CGRectMake(10, CGRectGetMaxY(lblBusinessName.frame), 55, 20));
//        lblperiod.backgroundColor = [UIColor lightGrayColor];
        lblperiod.textColor = [UIColor blackColor];
        lblperiod.font = FONT_ARIAL_14;
        [self addSubview:lblperiod];
        
        lblPeriodValue = createLabel(@"This Month", CGRectMake(CGRectGetMaxX(lblperiod.frame), CGRectGetMaxY(lblBusinessName.frame), 150, 20));
//        lblPeriodValue.backgroundColor = [UIColor yellowColor];
        lblPeriodValue.textColor = Card_no_colore_code;
        lblPeriodValue.font = FONT_ARIAL_14;
        [self addSubview:lblPeriodValue];
        
        lblBusExpAmt = createLabel(@"$5000.00", CGRectMake(CGRectGetMaxX(lblPeriodValue.frame), CGRectGetMaxY(lblBusinessName.frame), 100, 20));
//        lblBusExpAmt.backgroundColor = [UIColor greenColor];
        lblBusExpAmt.textColor = [UIColor blackColor];
        lblBusExpAmt.font=FONT_ARIAL_14;
        lblBusExpAmt.textAlignment = UITextAlignmentRight;
        [self addSubview:lblBusExpAmt];
        
        
        lblCategory = createLabel(@"Travel", CGRectMake(10, CGRectGetMaxY(lblperiod.frame), 200, 20));
//        lblCategory.backgroundColor = [UIColor greenColor];
        lblCategory.textColor = Status_Color_Code;
        lblCategory.font=FONT_ARIAL_14;
        lblCategory.textAlignment = UITextAlignmentLeft;
        [self addSubview:lblCategory];
        
        lblCategoryAmount = createLabel(@"", CGRectMake(180, CGRectGetMaxY(lblperiod.frame), 130, 20));
//        lblCategoryAmount.backgroundColor = [UIColor redColor];
        lblCategoryAmount.textColor = [UIColor blackColor];
        lblCategoryAmount.font=FONT_ARIAL_14;
        lblCategoryAmount.textAlignment = UITextAlignmentRight;
        [self addSubview:lblCategoryAmount];
        
        lblEmpName = createLabel(@"Christopher", CGRectMake(10, CGRectGetMaxY(lblCategory.frame), 100, 20));
//        lblEmpName.backgroundColor = [UIColor greenColor];
        lblEmpName.textColor = Name_color_Code;
        lblEmpName.font=FONT_ARIAL_14;
        lblEmpName.textAlignment = UITextAlignmentLeft;
        [self addSubview:lblEmpName];
        
        lblEmpId = createLabel(@"12451215", CGRectMake(CGRectGetMaxX(lblEmpName.frame), CGRectGetMaxY(lblCategory.frame), 100, 20));
//        lblEmpId.backgroundColor = [UIColor redColor];
        lblEmpId.textColor = Card_no_colore_code;
        lblEmpId.font=FONT_ARIAL_14;
        lblEmpId.textAlignment = UITextAlignmentLeft;
        [self addSubview:lblEmpId];

        lblEmpExpense = createLabel(@"$0.00", CGRectMake(180, CGRectGetMaxY(lblCategory.frame), 130, 20));
//        lblEmpExpense.backgroundColor = [UIColor grayColor];
//        lblEmpExpense.backgroundColor = [UIColor greenColor];
        lblEmpExpense.textColor = [UIColor blackColor];
        lblEmpExpense.font=FONT_ARIAL_14;
        lblEmpExpense.textAlignment = UITextAlignmentRight;
        [self addSubview:lblEmpExpense];

        lblSummraizedText = createLabel(@"Summarized By :", CGRectMake(10, CGRectGetMaxY(lblperiod.frame), 115, 20));
        lblSummraizedText.textColor = [UIColor blackColor];
        lblSummraizedText.font=FONT_ARIAL_14;
        lblSummraizedText.textAlignment = UITextAlignmentLeft;
        [self addSubview:lblSummraizedText];
        
        lblSummrazidBy = createLabel(@"Quarter", CGRectMake(CGRectGetMaxX(lblSummraizedText.frame), CGRectGetMaxY(lblperiod.frame), 100, 20));
        lblSummrazidBy.textColor = Card_no_colore_code;
        lblSummrazidBy.font=FONT_ARIAL_14;
        lblSummrazidBy.textAlignment = UITextAlignmentLeft;
        [self addSubview:lblSummrazidBy];
        
        lblSummraizedAmount = createLabel(@"$0.00", CGRectMake(180, CGRectGetMaxY(lblperiod.frame), 130, 20));
//        lblSummraizedAmount.backgroundColor = [UIColor blueColor];
        lblSummraizedAmount.textColor = [UIColor blackColor];
        lblSummraizedAmount.font=FONT_ARIAL_14;
        lblSummraizedAmount.textAlignment = UITextAlignmentRight;
        [self addSubview:lblSummraizedAmount];

        
        [lblBusExpAmt release];
        [lblBusinessName release];
        [lblperiod release];
        [lblPeriodValue release];
        [lblCategory release];
        [lblEmpName release];
        [lblEmpId release];
        [lblEmpExpense release];
        [lblSummraizedText release];
        [lblSummraizedAmount release];
        [lblSummrazidBy release];

        
        switch (expenseType)
        {
            case Employee_analysis:
            {
                lblCategory.hidden=YES;
                lblCategoryAmount.hidden=YES;
                lblEmpName.hidden=YES;
                lblEmpId.hidden=YES;
                lblEmpExpense.hidden=YES;
                lblSummraizedText.hidden=YES;
                lblSummraizedAmount.hidden=YES;
                lblSummrazidBy.hidden=YES;
            }
                break;
            case Employee_Expense_Category:
            {
                lblEmpName.hidden=YES;
                lblEmpId.hidden=YES;
                lblEmpExpense.hidden=YES;
                lblSummraizedText.hidden=YES;
                lblSummraizedAmount.hidden=YES;
                lblSummrazidBy.hidden=YES;
            }
                break;

            case Employee_Business_Expense:
            {
                lblCategory.hidden=YES;
                lblCategoryAmount.hidden=YES;
                lblEmpName.hidden=YES;
                lblEmpId.hidden=YES;
                lblEmpExpense.hidden=YES;
                lblSummraizedAmount.hidden=YES;
            }
                break;
                
            case Employee_by_Expense_analysis:
            {
//                lblCategory.hidden=YES;
//                lblCategoryAmount.hidden=YES;
                lblSummraizedText.hidden=YES;
                lblSummraizedAmount.hidden=YES;
                lblSummrazidBy.hidden=YES;
                lblCategoryAmount.hidden = YES;
            }
                break;

            default:
                break;
        }
        
    }
    
    UILabel *lblLine=createLabel(@"", CGRectMake(0, CGRectGetMaxY(self.frame)-2, 320, 2));
    lblLine.backgroundColor=Name_color_Code;
    [self addSubview:lblLine];
    [lblLine release];
    
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
