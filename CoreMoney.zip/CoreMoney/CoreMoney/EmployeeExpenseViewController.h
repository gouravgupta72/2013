//
//  EmployeeExpenseViewController.h
//  CoreMoney
// Class use for create employee expense list 

#import <UIKit/UIKit.h>
#import "expenseRecordView.h"
#import "CalanderView.h"
#import "ComboViewController.h"
#import "EmpExpDetailView.h"

@interface EmployeeExpenseViewController : SwipeViewController <DataParsingDelegate>
{
    NSMutableArray *empArray, *recordArray, *businessListArray, *categoryArray;
    NSMutableArray *periodArr;
    UIView *popView;
    empPeriodType periodType;
    int AnalysisType;
    CalanderView *calendrObj;
    expenseRecordView *ExpenseRecordObj;
    int ComboType;
    ComboViewController *comboView;
    BOOL isFirstDate;
    EmpExpDetailView *empExpView;
    int localPageAnalysis,tableAnalysisType;
    
    NSString *strFromDate, *strToDate,*strEmpName, *strCategory, *strSubCategory, *strPeriod;
    
    employeeExpenseDataClass *empExpData;
    employeeDataClass *empObj;
    NSString *selectedEmpId, *SelectedBusinessName, *selectedBusinessId, *OwningPartnerTag;
    int requestId,CategoryId,subCategoryId;
    
    BOOL searchByEmployee;
    BOOL searchByCategory;
    
    NSString *strTextSub;
    NSString *strTextEmployee;
    NSString *strTextThisMonth;
    NSString *strSelectedSummarizedBy;
    
    NSString *strPeriodText;
    NSString *strDateFrom, *strDateTo;
}
@property (nonatomic, copy) NSString *strPeriodText;
@property (nonatomic, copy) NSString *strDateFrom;
@property (nonatomic, copy) NSString *strDateTo;

@property (nonatomic,retain) employeeExpenseDataClass *empExpData;

@property (retain, nonatomic) IBOutlet UIImageView *imgFilterBackground;
@property (retain, nonatomic) IBOutlet UIView *filterView;
@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (retain, nonatomic) IBOutlet UIScrollView *topScrollview;
@property (retain, nonatomic) IBOutlet UILabel *lblfilterTitle;
@property (retain, nonatomic) IBOutlet UILabel *lblPeriod;
@property (retain, nonatomic) IBOutlet UILabel *lblSelectPeriod;
@property (retain, nonatomic) IBOutlet UILabel *lblSelectdateFrom;
@property (retain, nonatomic) IBOutlet UILabel *lblSelectDateTo;
@property (retain, nonatomic) IBOutlet UIButton *btnCancle;
@property (retain, nonatomic) IBOutlet UILabel *lblSelectedCategory;
@property (retain, nonatomic) IBOutlet UILabel *lblSubCategory;
@property (retain, nonatomic) IBOutlet UIButton *btnSubmit;
- (IBAction)submitFilterRequest:(id)sender;
- (IBAction)openBusinessList:(id)sender;
@property (retain, nonatomic) IBOutlet UIView *employeeView;

@property (retain, nonatomic) IBOutlet UILabel *lblSelectEmployee;

- (IBAction)openEmpComboView:(id)sender;
- (IBAction)openPeriodComboView:(id)sender;
- (IBAction)canclePopView:(id)sender;
- (IBAction)tapCalanderFrom:(id)sender;
- (IBAction)tapCalanderTo:(id)sender;
- (IBAction)cancleEmpSelection:(id)sender;
- (IBAction)openCategoryCombo:(id)sender;
- (IBAction)openSubCategory:(id)sender;
- (IBAction)cancleCategorySelection:(id)sender;
@property (retain, nonatomic) IBOutlet UIView *secondComboView;
@property (retain, nonatomic) IBOutlet UIView *businessFilterView;
@property (retain, nonatomic) IBOutlet UIButton *btnEmpClear;
@property (retain, nonatomic) IBOutlet UIButton *btnCategoryClear;
@property (retain, nonatomic) IBOutlet UILabel *lblBusinessNameFilter;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil empDataArray:(NSMutableArray *)EmpDataArray analysisType:(int)pageType businessListArray:(NSMutableArray *)arrayBusiness categoryArray:(NSMutableArray *)catArray;
@end
