//
//  CardDetailView.h

// Class to design card Detail View.

#import <UIKit/UIKit.h>

@interface CardDetailView : UIView
{
    UILabel *lblName,*lblCardNo,*lblAmount,*lblCurrentBalance,*lblLastTxnAmount,*lblTime,*lblStatus, *lblEmployeeId;
}
- (id)initWithDetailViewFrame:(CGRect)frame;
@property(nonatomic,retain)UILabel *lblName,*lblCardNo,*lblAmount,*lblCurrentBalance,*lblLastTxnAmount,*lblTime,*lblStatus, *lblEmployeeId;
@end
