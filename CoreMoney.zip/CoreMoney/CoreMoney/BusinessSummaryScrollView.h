//
//  BusinessSummaryScrollView.h



#import <UIKit/UIKit.h>

@interface BusinessSummaryScrollView : UIView
{
    UILabel *lblBusinessName,*lblClientName;
}
@property (nonatomic,retain) UILabel *lblBusinessName,*lblClientName;
- (id)initWithUserDetailFrame:(CGRect)frame;
@end
