//
//  UserProfileDataClass.m


#import "UserProfileDataClass.h"


// Class used for hold UserProfileData.

@implementation UserProfileDataClass
@synthesize ADDRESS1, BUSINESSNAME, CITY, COUNTRY_CODE, CardStatus, DATEISSUED, DOB, ERRMSG, FIRSTNAME, FaxNumber, ID_NUMBER, LASTNAME, MOBILE, NAMEONCARD, PHONE, PHONEEXTENSION,CARDHOLDER_IDENTIFIED, ERROR_FOUND, POSTALCODE, STATE, CURRENTBALANCE, CURRENT_CARD_BALANCE,CUSTOMSPENDRULES, CardNumberLast4Digit, ERR_NUMBER, ID_CODE, EMAIL,ADDRESS2,countryName,StateCode;

-(void)dealloc
{
    
    self.ADDRESS1=nil;
    self.BUSINESSNAME=nil;
    self.CITY=nil;
    self.COUNTRY_CODE=nil;
    self.CardStatus=nil;
    self.DATEISSUED=nil;
    self.DOB=nil;
    self.ERRMSG=nil;
    self.FIRSTNAME=nil;
    self.LASTNAME=nil;
    self.FaxNumber=nil;
    self.ID_NUMBER=nil;
    self.MOBILE=nil;
    self.NAMEONCARD=nil,
    self.PHONE=nil;
    self.PHONEEXTENSION=nil;
    self.POSTALCODE=nil;
    self.STATE=nil;
    self.EMAIL=nil;
    self.StateCode=nil;
    self.countryName=nil;
       [super dealloc];
}
@end


