//
//  updateNewUserViewController.h
//  CoreMoney


#import <UIKit/UIKit.h>

@interface updateNewUserViewController : UIViewController<DataParsingDelegate>
@property (retain, nonatomic) IBOutlet UILabel *lblUserId;
@property (retain, nonatomic) IBOutlet UITextField *txtNewPassword;
@property (retain, nonatomic) IBOutlet UITextField *txtConfirmPassword;
- (IBAction)btnSubmitAction:(id)sender;
@property (retain, nonatomic) IBOutlet UIScrollView *pageScroll;

@end
