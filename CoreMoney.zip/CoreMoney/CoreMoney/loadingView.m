//
//  loadingView.m
// class used for create loading view

#import "loadingView.h"


@implementation loadingView
@synthesize activityIndicator,btnCancel,lblMsg;
-(void)clickMe
{
	[self.activityIndicator stopAnimating];
  	[self removeFromSuperview];
}
- (id) initWithMyFrame:(CGRect )f
{
	self=[super initWithFrame:f];
	[self setBackgroundColor:[UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.7]];
	CGPoint p=[self center];
	self.activityIndicator=[[UIActivityIndicatorView alloc] initWithFrame: CGRectMake(p.x-37/2, p.y-32/2, 37, 37)];
	[self.activityIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleWhite];
	[self addSubview:self.activityIndicator];
    
	lblMsg=[[UILabel alloc] initWithFrame:CGRectMake(p.x-50/2,CGRectGetMaxY(self.activityIndicator.frame), 200, 30)];
    lblMsg.text=@"Logging...";
    lblMsg.backgroundColor=[UIColor clearColor];
    lblMsg.textColor=[UIColor lightGrayColor];
    [self addSubview:lblMsg];
	return self;
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView {
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }
 */

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */



- (void)dealloc {
	[lblMsg release];
	[btnCancel release];
	[activityIndicator release];
    [super dealloc];
}


@end
