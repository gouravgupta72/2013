//
//  employeeExpenseDataClass.m
//  CoreMoney

#import "employeeExpenseDataClass.h"

@implementation employeeExpenseDataClass
@synthesize employeeExpenseArray,CardSpendTotal;
@end
