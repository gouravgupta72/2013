//
//  RecommendViewController.h
//  CoreMoney
// Class use for create recommend page 
//

#import <UIKit/UIKit.h>
#import "MessageUI/MFMailComposeViewController.h"

@interface RecommendViewController : UIViewController<MFMailComposeViewControllerDelegate>
@property (retain, nonatomic) IBOutlet UIScrollView *pageScroll;
@property (retain, nonatomic) IBOutlet UITextView *txtvMessag;
@property (retain, nonatomic) IBOutlet UITextField *txtEnterEmailid;
- (IBAction)sendRecommendMail:(id)sender;
@property (retain, nonatomic) IBOutlet UIView *bgView;

@end
