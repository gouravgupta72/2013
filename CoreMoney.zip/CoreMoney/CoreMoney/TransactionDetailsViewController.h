//
//  TransactionDetailsViewController.h
//  CoreMoney
//class is used for display Transaction Detail
#import <UIKit/UIKit.h>
#import "DataParsingClass.h"
#import "CardDetailClass.h"
#import "ExpenseCategoryData.h"
#import "CustomScrollView.h"

@interface TransactionDetailsViewController : SwipeViewController<DataParsingDelegate,UITextViewDelegate,ScrollDelegate>
{
    double balance;
    int cardStatus;
    UIView *popupView;
    
    expenseCategoryTyped expCatAddtype;
    
    CardDetailClass *cardDataObj;
    
    ExpenseCategoryData *expenseData;
    
    int indexExpCat;
    UIToolbar *toolbar;
    BOOL keyboardToolbarShouldHide;
    BOOL isDisappear;
    
    int SelectedRecordNumber,expenseCategoryCount;
    
    MemoDataClass *MemoObj;
    int RequestID;
    BOOL isSatteled;
    
    setteldTransaction *trnOBJ;
    
    NSMutableArray *expenseCategoryArray, *memoArray;
    
    int cat1,cat2;
    BOOL isMemoSet;
    
    int desvcExpenseCategoryType,desvcExpenseCategoryValueID;
    long uniqueid1, uniqueid2, uniqueid3, MemoUniqueId;
    int SucessCount;
}
@property (nonatomic,retain)  NSMutableArray *expenseCategoryArray, *memoArray;
@property (retain, nonatomic) IBOutlet UILabel *lblLastTrasactionTime;
@property (retain, nonatomic) IBOutlet UIView *bottumView;
@property (retain, nonatomic) IBOutlet UIView *topView;
@property (retain, nonatomic) IBOutlet UIView *mySubView;
@property (assign , nonatomic) double balance;
@property int cardStatus,SelectedRecordNumber;
@property (retain, nonatomic) IBOutlet UILabel *lblUserName;
@property (retain, nonatomic) IBOutlet UIView *holdSpendView;
@property (retain, nonatomic) IBOutlet UILabel *lblCardNumber;
@property (retain, nonatomic) IBOutlet UILabel *lblStatus;
@property (retain, nonatomic) IBOutlet UILabel *lblBalance;
@property (retain, nonatomic) IBOutlet CustomScrollView *pageScrollVw;
@property (retain, nonatomic) IBOutlet UILabel *lblTrasactionDateTime;
@property (retain, nonatomic) IBOutlet UILabel *lblPostedDateTime;
@property (retain, nonatomic) IBOutlet UILabel *lblTrasactionType;
@property (retain, nonatomic) IBOutlet UILabel *lblBalAtTrasaction;
@property (retain, nonatomic) IBOutlet UILabel *lblHoldAmount;
@property (retain, nonatomic) IBOutlet UILabel *lblExpCatAddSecond;
@property (retain, nonatomic) IBOutlet UIImageView *imgExpCatArrowSecond;
@property (retain, nonatomic) IBOutlet UIImageView *imgExpCatArrowThird;
@property (retain, nonatomic) IBOutlet UILabel *lblExpCatAddThird;
@property (retain, nonatomic) IBOutlet UIImageView *imgArrowExpCatFirst;
@property (retain, nonatomic) IBOutlet UILabel *lblCityName;
@property (retain, nonatomic) IBOutlet UITextView *txtMemo;
@property (retain, nonatomic) IBOutlet UITextView *txtMemoContent;
@property (retain, nonatomic) IBOutlet UILabel *lblExpCatAddFirst;
@property (retain, nonatomic) IBOutlet UIButton *btnUpdate;
@property (retain, nonatomic) IBOutlet UIButton *btnAddMemo;
@property (retain, nonatomic) IBOutlet UILabel *lblTransactionDescription;
@property (retain, nonatomic) IBOutlet UIView *viewPopUpAddMemo;
@property (retain, nonatomic) IBOutlet UIButton *btnAddMemoPopUpCancel;
@property (retain, nonatomic) IBOutlet UIButton *btnAddMemoPopUpOk;

- (IBAction)touchedBtnAddMemoPopUpOk:(id)sender;

- (IBAction)touchedBtnAddMemoPopUpCancel:(id)sender;

- (IBAction)touchedBtnAddMemo:(id)sender;

- (IBAction)clickedBtnUpdate:(id)sender;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil trasactiondata:(setteldTransaction *) trasctinD;

@property (retain, nonatomic) IBOutlet UILabel *lblMemoText;
@property (retain, nonatomic) IBOutlet UILabel *lblExpenseCategoryText;
@property (retain, nonatomic) IBOutlet UILabel *lblTransactionDate;
@property (retain, nonatomic) IBOutlet UILabel *lblPostedTime;
@property (retain, nonatomic) IBOutlet UILabel *lblCityText;
@property (retain, nonatomic) IBOutlet UILabel *lblBalanceAtText;
@property (retain, nonatomic) IBOutlet UILabel *lblHoldAmountText;


@end
