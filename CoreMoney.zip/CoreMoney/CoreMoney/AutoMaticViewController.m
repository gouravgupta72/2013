//
//  AutoMaticViewController.m
//  CoreMoney
//class use for Automatic funding page
#import "AutoMaticViewController.h"
#import "PopUpView.h"
#import "ComboViewController.h"
#import "CalanderView.h"
@interface AutoMaticViewController ()
-(void)openSlide;
-(void)updateViewLanguage;
-(void)openBack;
-(void) delyedOpen;
-(void)designProfileView;
-(void) fillData;
-(void) createBorderofview:(UIView *) view;
-(void)getLowBalanceData;
-(void)getSchedulingFundData;
-(void)updateLowBalanceFunding;
-(void)updateSchedulefunding;
-(void)MakeRequest;
 -(void)getResponce:(id)jsonData;
-(void) setOfset;
-(void)removeChangeStatusView;
-(void) removecomboView;
-(void) selectQuetion:(id) que;
-(void)setSelectedDate :(int)date;
-(void) selectQuetionview:(NSString *)dayName  SelectedIndex:(int)index;
-(void) openPopupofSelectDay;
-(void) openCalander;
-(void) getDateforFrequency:(int) dat;
-(void) createMoveAnimation:(CGPoint)pos;
@end

@implementation AutoMaticViewController
@synthesize cardDataObj,schedulingObj,lowBalancingObj;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil CardData:(CardDetailClass *) carddata
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
        addNavigationBar(AUTOMATIC_FUNDING, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        
    }
    return self;
}

-(void) didChangeMonths
{
    
}

-(void) calendarView:(KLCalendarView *)calendarView tappedTile:(KLTile *)aTile
{
    
}

-(KLTile *) calendarView:(KLCalendarView *)calendarView createTileForDate:(KLDate *)date
{
    KLTile *kl = [[[KLTile alloc] init] autorelease];
    return kl;
}

#pragma -mark UITextField Method
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if([textField isEqual:self.txtCardBalance])
    {
        [self.txtCardBalance resignFirstResponder];
        [self setOfset];
    }else if([textField isEqual:self.txtLoadAmount])
    {
        [self.txtThresholdBalance becomeFirstResponder];
    }else  if([textField isEqual:self.txtThresholdBalance])
    {
        [self.txtThresholdBalance resignFirstResponder];
        [self setOfset];
    }

    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [self.TabScroll setContentSize:CGSizeMake(320,500)];
    
    //textField.text=@"";
    if([textField isEqual:self.txtCardBalance]){
        //        self.TabScroll.contentOffset=CGPointMake(0, self.TabScroll.frame.origin.y+50);
        self.TabScroll.contentOffset=CGPointMake(0, 30);
    }
    if([textField isEqual:self.txtLoadAmount]){
        self.TabScroll.contentOffset=CGPointMake(0, 80);
    }
    
    if([textField isEqual:self.txtThresholdBalance]){
        self.TabScroll.contentOffset=CGPointMake(0, 160);
    }
    
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return digitValidationOnNumKeyboard(textField,range,string);
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    textField.text=[NSString stringWithFormat:@"%0.2f",changeTextToAmount(textField.text)];
}


// Open Slider Menu
-(void)openSlide
{
    IsFirstTime=YES;
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}
//method use for update language
-(void)updateViewLanguage
{
    _lblLoadFrequency.text=languageSelectedStringForKey(@"Load Frequency");
    _txtCardBalance.placeholder=languageSelectedStringForKey(@"Card Balance");
    _txtLoadAmount.placeholder=languageSelectedStringForKey(@"Load Amount");
    _txtThresholdBalance.placeholder=languageSelectedStringForKey(@"Threshold Balance");
    _lblLowBalanceTitle.text=languageSelectedStringForKey(@"Scheduled  ");
    _lblThreshholdTitle.text=languageSelectedStringForKey(@"Low Balance ");
    
    _lblLoadAmountText.text=languageSelectedStringForKey(@"Load Amount");
    _lblCardBalanceText.text=languageSelectedStringForKey(@"Card Balance");
    _lblThresholdText.text=languageSelectedStringForKey(@"Threshold Card Balance");
    
    
    if ([AppDelegate sharedAppDelegate].isSpanish)
    {
        
    }
}

// Pop to previous View
-(void)openBack
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    [self performSelector:@selector(delyedOpen) withObject:nil afterDelay:0.5];
}

-(void) delyedOpen{
    
    [self.navigationController popViewControllerAnimated:YES];
}
//method to design profile view
-(void)designProfileView
{
    
    // Threshold View Designing.
    self.thresholdview.layer.cornerRadius = 10;
    self.thresholdview.layer.masksToBounds = YES;
    self.thresholdview.layer.borderColor = Color132.CGColor;
    self.thresholdview.layer.borderWidth = 1.5f;
    
    // Low Balance View Designing.
    self.lowbalanceView.layer.cornerRadius = 10;
    self.lowbalanceView.layer.masksToBounds = YES;
    self.lowbalanceView.layer.borderColor = Color132.CGColor;
    self.lowbalanceView.layer.borderWidth = 1.5f;
    
}

// method initialized field
-(void) fillData{
        
    [frequencyArr addObject:@"Daily"];
//    [frequencyArr addObject:@"1st Day of month"];
    [frequencyArr addObject:@"Weekly"];
    [frequencyArr addObject:@"Monthly"];
    
    
    self.lblUserName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings(cardDataObj.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@ ",cardDataObj.FIRSTNAME],checkISNullStrings(cardDataObj.LASTNAME)?@"":[NSString stringWithFormat:@"%@",cardDataObj.LASTNAME]];

    
    self.lblCardNumber.text =ChangeCardNumber(cardDataObj.CARDNUMBER) ;
    self.lblBalance.text = [NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(cardDataObj.AVAILABLEBALANCE)) ] ;
    
    self.lblStatus.text=CardStatusValue(cardDataObj.STATUS_CARDACCOUNT);
    self.lblSchedulBtnView.text = languageSelectedStringForKey(@"Scheduled Funding");
    self.lblLowBalnceView.text = languageSelectedStringForKey(@"Low Balance Funding");
    
}

// method make border at view
-(void) createBorderofview:(UIView *) view{
    view.layer.borderWidth = 1;
    view.layer.borderColor = [UIColor grayColor].CGColor;
    view.layer.cornerRadius = 8;
}

- (void)viewDidLoad
{
    self.TabScroll.maindelegate = self;
    cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
    

    self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0 , 320, 480);
    
    [super viewDidLoad];
    frequencyArr = [[NSMutableArray alloc] init];
    
    
    [self fillData];
    [self createBorderofview:self.scheduleFundBtnView];
    [self createBorderofview:self.lowbalnceBtnView];
    [self createBorderofview:self.LowBalanceFundView];
    [self createBorderofview:self.ScheduleFundView];
    self.LowBalanceFundView.frame = CGRectMake( self.lowbalnceBtnView.frame.origin.x,self.lowbalnceBtnView.frame.origin.y , self.LowBalanceFundView.frame.size.width, self.LowBalanceFundView.frame.size.height);
    self.ScheduleFundView.frame = CGRectMake( self.scheduleFundBtnView.frame.origin.x,self.scheduleFundBtnView.frame.origin.y , self.ScheduleFundView.frame.size.width, self.ScheduleFundView.frame.size.height);
}
// method to get Low Balance
-(void)getLowBalanceData
{
    RequestID=LowBalanceSearch;
    [self MakeRequest];
}
// method to get Schedule Fund Data
-(void)getSchedulingFundData
{
    RequestID=SchedulingSearch;
    [self MakeRequest];
}
// method to update Low Balance Fund
-(void)updateLowBalanceFunding
{
    RequestID=Add_Lowbalance;
    [self MakeRequest];
}
// method to update Schedule fund
-(void)updateSchedulefunding
{
    RequestID=Add_scheduling;
    [self MakeRequest];
}
// method to send request 
-(void)MakeRequest
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    switch (RequestID) {
        case Add_scheduling:
        {
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            [SystemConfiguration sharedSystemConfig].dbbServiceName=AddScheduling_Fund_Req;
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deBAAccountAcctId=%@&deBABussinessAccAcctId=%@&deBAScheduleAmount=%@&deBAFrequency=%d&deProductid=%@&deBAScheduleTransferSelectDay=%@&deFlagScheduleInsertDelete=0&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.BSAcctID,BusinessPageObject.ACCTID,checkISNullStrings(self.txtCardBalance.text)?@"0.00":self.txtCardBalance.text,self.lblSetFrequency.tag,BusinessPageObject.BusinessName,(self.lblSetFrequency.tag==Monthly_f)?[NSString stringWithFormat:@"%d",dateFrequency]:@"",[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBAScheduleFunding];
        }
            
            break;
            
        case Add_Lowbalance:
        {
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            [SystemConfiguration sharedSystemConfig].dbbServiceName=AddLOW_BALANCE_FUNDING_Req;
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deBAAccountAcctId=%@&deBABussinessAccAcctId=%@&deBAScheduleAmount=%@&deBAThresholdAmount=%@&deProductid=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.BSAcctID,BusinessPageObject.ACCTID,checkISNullStrings(self.txtLoadAmount.text)?@"0.00":self.txtLoadAmount.text ,checkISNullStrings(self.txtThresholdBalance.text)?@"0.00":self.txtThresholdBalance.text,BusinessPageObject.BusinessName,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBALowBalanceFunding];
            
        }
            break;
            
        default:
            break;
    }
        
    [DataReq release];
    
}

-(void)getResponce:(id)jsonData
{
    switch (RequestID) {
        case LowBalanceSearch:
        {
            if ([jsonData isKindOfClass:[lowBalanceSearchDataClass class]])
            {
                lowBalanceSearchDataClass *err=(lowBalanceSearchDataClass *)jsonData;
                
                self.txtLoadAmount.text=ChangeTocurrency(err.AMOUNT);
                
                self.txtThresholdBalance.text=ChangeTocurrency(err.ThresholdAmount);
                
            }
            [self getSchedulingFundData];
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
        }
            break;
        case SchedulingSearch:
        {
            if ([jsonData isKindOfClass:[ScheduleFundingSearchDataClass class]])
            {
            schedulingObj=(ScheduleFundingSearchDataClass *)jsonData;
                
                if (!schedulingObj.ResCode)
                {
                    self.txtCardBalance.text=ChangeTocurrency(schedulingObj.AMOUNT);
                    [self selectQuetion:ChangeFrequencyData(schedulingObj.FREQUENCY)];
                }
                
            }
            
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case Add_scheduling:
        {
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                LoginResponceDataClass *obj=(LoginResponceDataClass *)jsonData;
                
                showAlertScreen(nil, obj.ErrorMsg);
            }
            
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        case Add_Lowbalance:
        {
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                LoginResponceDataClass *obj=(LoginResponceDataClass *)jsonData;
                
                showAlertScreen(nil, obj.ErrorMsg);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
            
        default:
            break;
    }
}


//-(void)addTabViews
//{
//    btnScheduleFunding=[[FundingButtonView alloc]initWithFundingButtonFrame:CGRectMake(0, 10, 320, 58) title:languageSelectedStringForKey( @"Scheduled Funding") delegate:self icon:@"" tag:2];
//    btnScheduleFunding.tag=2;
//    [_TabScroll addSubview:btnScheduleFunding];
//    [btnScheduleFunding release];
//    
//    btnLowBalance=[[FundingButtonView alloc]initWithFundingButtonFrame:CGRectMake(0, CGRectGetMaxY(btnScheduleFunding.frame), 320, 58) title:languageSelectedStringForKey( @"Low Balance Funding") delegate:self icon:@"" tag:3];
//    btnLowBalance.tag=3;
//    [_TabScroll addSubview:btnLowBalance];
//    [btnLowBalance release];
//    [self addScheduleFundingView];
//    [self addLowBalancefundingView];
//   
//}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//-(void)addScheduleFundingView
//{
//    _ScheduleFundView.frame=CGRectMake(0, 0, 320, 340);
//    _ScheduleFundView.backgroundColor=[UIColor clearColor];
//    [_TabScroll addSubview:_ScheduleFundView];
//    _ScheduleFundView.hidden=YES;
//}
//
//
//
//-(void)addLowBalancefundingView
//{
//    _LowBalanceFundView.frame=CGRectMake(0, CGRectGetMaxY(btnScheduleFunding.frame)+10, 320, 340);
//    _LowBalanceFundView.backgroundColor=[UIColor redColor];
//    [_TabScroll addSubview:_LowBalanceFundView];
//    [_TabScroll setContentSize:CGSizeMake( 0 , CGRectGetMaxY(_LowBalanceFundView.frame)+58)];
//    _LowBalanceFundView.hidden=YES;
//}

- (void)dealloc
{
    cardDataObj = nil;
    [_TabScroll release];
    [_ScheduleFundView release];
    [_LowBalanceFundView release];
    [_txtCardBalance release];
    [_lblLoadFrequency release];
    [_txtLoadAmount release];
    [_txtThresholdBalance release];
    [_thresholdview release];
    [_lowbalanceView release];
    [_lblThreshholdTitle release];
    [_lblLowBalanceTitle release];
    [_userdetailScrollView release];
    [_lblUserName release];
    [_lblCardNumber release];
    [_lblStatus release];
    [_lblBalance release];
    [_scheduleFundBtnView release];
    [_lblSchedulBtnView release];
    [_lowbalnceBtnView release];
    [_lblLowBalnceView release];
    [_lblSetFrequency release];
    
    [_viewSetFrequence release];
    [_btnOutSideTouch release];
    [_lblLoadAmountText release];
    [_lblThresholdText release];
    [_lblCardBalanceText release];
    [_bgView release];
    [super dealloc];
}
- (void)viewDidUnload
{
    [self setTabScroll:nil];
    [self setScheduleFundView:nil];
    [self setLowBalanceFundView:nil];
    [self setTxtCardBalance:nil];
    [self setLblLoadFrequency:nil];
    [self setTxtLoadAmount:nil];
    [self setTxtThresholdBalance:nil];
    [self setThresholdview:nil];
    [self setLowbalanceView:nil];
    [self setLblThreshholdTitle:nil];
    [self setLblLowBalanceTitle:nil];
    [self setUserdetailScrollView:nil];
    [self setLblUserName:nil];
    [self setLblCardNumber:nil];
    [self setLblStatus:nil];
    [self setLblBalance:nil];
    [self setScheduleFundBtnView:nil];
    [self setLblSchedulBtnView:nil];
    [self setLowbalnceBtnView:nil];
    [self setLblLowBalnceView:nil];
    [self setLblSetFrequency:nil];
    
    [self setViewSetFrequence:nil];
    [self setBtnOutSideTouch:nil];
    [self setLblLoadAmountText:nil];
    [self setLblThresholdText:nil];
    [self setLblCardBalanceText:nil];
    [self setBgView:nil];
    [super viewDidUnload];
}

// set page in previouse position
-(void) setOfset{
     [self.TabScroll setContentSize:CGSizeMake(320,360)];
    self.TabScroll.contentOffset=CGPointMake(0, 0);
    
    [self.txtCardBalance resignFirstResponder];
    
    [self.txtLoadAmount resignFirstResponder];
    [self.txtThresholdBalance resignFirstResponder];
}

-(void)viewWillAppear:(BOOL)animated
{
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    //[self updateViewLanguage];
    [AppDelegate sharedAppDelegate].classType=CARDS_AUTOMATIC_FUNDING_PAGE;
    daySelectNumber = 1;
   // _userdetailScrollView.frame=CGRectMake(0, IS_IPAD?0:IS_IPHONE_5?0: 0, 320, 120);
   // _userdetailScrollView.backgroundColor=[UIColor redColor];
    
    
    BusinessPageObject=[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    self.txtLoadAmount.text=ChangeTocurrency(lowBalancingObj.AMOUNT);
    
    self.txtThresholdBalance.text=ChangeTocurrency(lowBalancingObj.ThresholdAmount);
    self.txtCardBalance.text=ChangeTocurrency(schedulingObj.AMOUNT);
    if (!schedulingObj.ResCode)
    {
        [self selectQuetion:ChangeFrequencyData(schedulingObj.FREQUENCY)];
    }
    
    //[self getLowBalanceData];
    [super viewWillAppear:animated];
}



// method use for remove question select view
-(void)removeChangeStatusView
{
    [self removecomboView];
    
}

// remove combo view
-(void) removecomboView{
    if (comboView) {
        [self setOfset];
        [comboView removeFromSuperview];
        comboView = nil;
    }
}
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
//    UITouch *touch = [touches anyObject];
//    CGPoint touchPoint = [touch locationInView:self.view];
//    NSLog(@" current point is %f , %f",touchPoint.x,touchPoint.y);
    
        [self setOfset];
    
//    if ([touch isEqual:self.txtCardBalance]) {
//        NSLog(@"touch text field");
//    }
//    if ([touch isEqual:self.txtLoadAmount]) {
//        NSLog(@"touch text txtLoadAmount");
//    }
    
    if(comboView)
    [self removecomboView];
}
// method to select question
-(void) selectQuetion:(id) que
{
    [self setOfset];
    [comboView removeFromSuperview];
    comboView = nil;
    NSString *str = (NSString *)que;
    
    
    if ([str isEqualToString:[frequencyArr objectAtIndex:0]]) {
        frequencyType = DAILY;
    }
//    else if([str isEqualToString:[frequencyArr objectAtIndex:1]]){
//        frequencyType = FIRSTDAY_MONTH;
//    }
    else if([str isEqualToString:[frequencyArr objectAtIndex:1]]){
        frequencyType = WEEKLY;
    }
    else if([str isEqualToString:[frequencyArr objectAtIndex:2]]){
        frequencyType = MONTHLY;
    }
    
    switch (frequencyType) {
        case DAILY:{ 
            self.viewSetFrequence.hidden = YES;
            self.lblSetFrequency.text = que;
            self.lblLoadFrequency.text = languageSelectedStringForKey(que);
            self.lblSetFrequency.tag=Daily_f;
            _lblLoadFrequency.textColor=[UIColor blackColor];
            IsFirstTime=YES;
        }
            break;
        case FIRSTDAY_MONTH:{
            self.viewSetFrequence.hidden = YES;
            self.lblSetFrequency.text = que;
            self.lblLoadFrequency.text = languageSelectedStringForKey(que);
            _lblLoadFrequency.textColor=[UIColor blackColor];
            self.lblSetFrequency.tag=Monthly_f;
            dateFrequency=1;
            IsFirstTime=YES;
        }
            break;
        case WEEKLY:
        {
            strFrequency = que;
            if (!IsFirstTime)
            {
                [self selectQuetionview:setFrequencyCombo(schedulingObj.FREQUENCY) SelectedIndex:schedulingObj.FREQUENCY];
                IsFirstTime=YES;
            }else
            {
                [self openPopupofSelectDay];

            }
        }
            break;
        case MONTHLY:
        {
            //self.viewSetFrequence.hidden = NO;
            strFrequency = que;
            self.lblSetFrequency.tag=Monthly_f;
            self.lblLoadFrequency.text = languageSelectedStringForKey(que);
            if (!IsFirstTime)
            {
                [self setSelectedDate:schedulingObj.SelectDay];
                IsFirstTime=YES;
            }else
            {
                [self openCalander];
            }

        }
            break;
            
        default:
            break;
    }
}
//method to set selected date
-(void)setSelectedDate :(int)date
{
    self.lblSetFrequency.text = [NSString stringWithFormat:@"Day %d of the every month",date];
    _lblLoadFrequency.textColor=[UIColor blackColor];
    self.viewSetFrequence.hidden = NO;
//    if (date==1)
//    {
//        self.viewSetFrequence.hidden = YES;
//        self.lblSetFrequency.text = @"1st Day of month";
//        self.lblLoadFrequency.text = languageSelectedStringForKey(@"1st Day of month");
//        _lblLoadFrequency.textColor=[UIColor blackColor];
//        self.lblSetFrequency.tag=Monthly_f;
//        dateFrequency=1;
//        IsFirstTime=YES;
//    }
    dateFrequency=date;
}

-(void) selectQuetionview:(NSString *)dayName  SelectedIndex:(int)index
{
    self.lblLoadFrequency.text = languageSelectedStringForKey(strFrequency);
    _lblLoadFrequency.textColor=[UIColor blackColor];
    self.viewSetFrequence.hidden = NO;
    self.lblSetFrequency.text = dayName;
    self.lblSetFrequency.tag=index;
    daySelectNumber = index;
    [self removecomboView];
}
// method to open Popup of SelectDay
-(void) openPopupofSelectDay{
    
    comboView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.bgView.frame.size.width, self.bgView.frame.size.height)];
    
    
    comboView.backgroundColor = [UIColor clearColor];
    [self.bgView addSubview:comboView];
    
    PopUpView *csv = [[PopUpView alloc] initWithLoadFrequency:CGRectMake(0, 0, self.bgView.frame.size.width, self.bgView.frame.size.height) Delegate:self SelectedQue:daySelectNumber];
    [comboView addSubview:csv];
    [csv release];
}
// method to open Calander
-(void) openCalander{
    
    comboView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    comboView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:comboView];
    
    CalanderSingleView *cslv = [[CalanderSingleView alloc] initWithFrame:CGRectMake(0, 40, 300, 400) Delegate:self];
    [comboView addSubview:cslv];
    [cslv release];
    
}
// method to get Date for Frequency
-(void) getDateforFrequency:(int) dat
{
    
    if(dat>0){
        self.lblLoadFrequency.text = languageSelectedStringForKey(strFrequency);
        _lblLoadFrequency.textColor=[UIColor blackColor];
        self.viewSetFrequence.hidden = NO;
    self.lblSetFrequency.text = [NSString stringWithFormat:@"Day %d of the every month",dat];
    frequencyType = MONTHLY;
    dateFrequency=dat;
        
    }
    [self removecomboView];
    
}
- (IBAction)btnLoadFrequency:(id)sender
{
    IsFirstTime=YES;
    [self setOfset];
    [self.TabScroll setContentOffset:CGPointMake(0, 40) animated:NO];
    comboView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.bgView.frame.size.width, self.bgView.frame.size.height)];
    
    
    comboView.backgroundColor = [UIColor clearColor];
    [self.bgView addSubview:comboView];
    
    
    
    ComboViewController *comView = [[ComboViewController alloc] initWithFrame:CGRectMake(30, 238, 260, 170) records:frequencyArr callingClassType:other];
    comView.layer.cornerRadius = 8;
    comView.delegate = self;
    [comboView addSubview:comView];

}
//method called when touch is outside of button
- (IBAction)clickedBtnOutSideTouch:(id)sender {
     [self setOfset];
    self.btnOutSideTouch.enabled = NO;
    [self.lblThreshholdTitle removeFromSuperview];
    if(isLowBalanceViewOpen == YES){
        [self.LowBalanceFundView removeFromSuperview];
        
        isLowBalanceViewOpen = NO;
    }
    if(isScheduledViewOpen == YES){
        [self.ScheduleFundView removeFromSuperview];
        isScheduledViewOpen = NO;
        [self createMoveAnimation:CGPointMake(self.lowbalnceBtnView.center.x, self.scheduleFundBtnView.frame.origin.y+self.scheduleFundBtnView.frame.size.height+15+self.lowbalnceBtnView.frame.size.height/2)];
    }
    
}
//method called when low balance view clicked
- (IBAction)clickedSchedulFundView:(id)sender {
    [self setOfset];
    if(isLowBalanceViewOpen == YES){
        [self.LowBalanceFundView removeFromSuperview];
        [self.lblThreshholdTitle removeFromSuperview];
        isLowBalanceViewOpen = NO;
    }
    isScheduledViewOpen = YES;
    self.btnOutSideTouch.enabled = YES;
    self.lblThreshholdTitle.text = languageSelectedStringForKey(@"Scheduled Funding");
    
    self.lblThreshholdTitle.center = CGPointMake(self.ScheduleFundView.frame.origin.x+self.lblThreshholdTitle.frame.size.width/2+25, self.ScheduleFundView.frame.origin.y);
    
    

    [self.TabScroll addSubview:self.ScheduleFundView];
    [self.TabScroll addSubview:self.lblThreshholdTitle];
    self.btnOutSideTouch.center = self.lblThreshholdTitle.center;
    //self.lowbalnceBtnView.center = CGPointMake(self.lowbalnceBtnView.center.x, 282);
    [self createMoveAnimation:CGPointMake(self.lowbalnceBtnView.center.x, 282)];
}
// create move animation
-(void) createMoveAnimation:(CGPoint)pos
{
    [UIView animateWithDuration:0.2f
                          delay:0.0f
                        options: UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         self.lowbalnceBtnView.center = CGPointMake(pos.x, pos.y);
                     }
                     completion:nil];

}
//method called when low balance view clicked
- (IBAction)clickedLowBalView:(id)sender {
    
    [self setOfset];
    if(isScheduledViewOpen == YES){
        [self.ScheduleFundView removeFromSuperview];
        [self.lblThreshholdTitle removeFromSuperview];
        isScheduledViewOpen = NO;
    }
    
    [self createMoveAnimation:CGPointMake(self.lowbalnceBtnView.center.x, self.scheduleFundBtnView.frame.origin.y+self.scheduleFundBtnView.frame.size.height+15+self.lowbalnceBtnView.frame.size.height/2)];
    
    //self.lowbalnceBtnView.center = CGPointMake(self.lowbalnceBtnView.center.x, self.scheduleFundBtnView.frame.origin.y+self.scheduleFundBtnView.frame.size.height+15+self.lowbalnceBtnView.frame.size.height/2);
    
    isLowBalanceViewOpen = YES;
    self.btnOutSideTouch.enabled = YES;
    
    self.lblThreshholdTitle.text = languageSelectedStringForKey(@"Low Balance Funding");
    
    self.lblThreshholdTitle.center = CGPointMake(self.LowBalanceFundView.frame.origin.x+self.lblThreshholdTitle.frame.size.width/2+25, self.LowBalanceFundView.frame.origin.y);
    
    
    [self.TabScroll addSubview:self.LowBalanceFundView];
    [self.TabScroll addSubview:self.lblThreshholdTitle];

    self.btnOutSideTouch.center = self.lblThreshholdTitle.center;
}
//method to set Load Frequency
- (IBAction)setLoadFrequency:(id)sender {
    
    if (frequencyType == WEEKLY) {
        [self openPopupofSelectDay];
    }
    else if(frequencyType == MONTHLY)
    {
        [self openCalander];
    }
}
//method to save changes of  low balance funding
- (IBAction)ClickLowBalanceFunding:(id)sender {
    
    [self updateLowBalanceFunding];
}
//method to save changes of  Schedule Funding
- (IBAction)clickScheduleFunding:(id)sender {
    [self updateSchedulefunding];
}
@end

