//
//  SlideMenuView.m

#import "SlideMenuView.h"
#import "SlideMenuClass.h"
#import "SlideMenuCell.h"
#import "HomeViewController.h"
#import "BusinessSummaryViewController.h"
#import "CardListViewController.h"
#import "TransactionViewController.h"
#import "FundCardViewController.h"
#import "TransferViewController.h"
#import "AutoMaticViewController.h"
#import "UserProfileViewController.h"
#import "ExpenseRulesViewController.h"
#import "UserProfileViewController.h"
#import "AdminListViewController.h"
#import "EmployeeExpenseViewController.h"
#import "alertGroupViewController.h"
@implementation SlideMenuView

@synthesize arrSlideMenuData,pageName;

// Static items used in slide menu.
static SlideMenuView *_sharedMenuView; // common class referrence.
static int viewDisplayPosition = 40; // set the position of the view from left side.
static int viewDisplayPositionIPAD = 90; // set the position of the view from left side for iPad.
static int navHeight = 44; // navigation height.
//static bool animationStyle=NO; // Set the animation style of the view.

// Shared variable of the Slide Menu class
+ (SlideMenuView*)sharedManager
{
    navHeight = [AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame.size.height;
	@synchronized(self)
    {
        if (_sharedMenuView == nil)
        {
			_sharedMenuView = [[SlideMenuView alloc] init];
            [_sharedMenuView createMenuView];
        }
    }
    
    return _sharedMenuView;
}
// Method to manage the page type. Show the menu items.
-(void)manageAccounts
{
    switch (self.pageName) {
        case HOME_PAGE:
        {
            for (int i = 0; i<[arrSlideMenuData count]; i++) {
                SlideMenuClass *menu = [arrSlideMenuData objectAtIndex:i];
                if ([menu.strMenuTitle isEqualToString:languageSelectedStringForKey(@"Home")]) {
                    menu.isShow=YES;
                    break;
                }
            }
        }
            break;
        case BUSINESS_SUMMARY_PAGE:
        {
            for (int i = 0; i<[arrSlideMenuData count]; i++) {
                SlideMenuClass *menu = [arrSlideMenuData objectAtIndex:i];
                if ([menu.strMenuTitle isEqualToString:languageSelectedStringForKey(@"Business Summary")]) {
                    menu.isShow=YES;
                    break;
                }
            }
        }
            break;
        case TRANSFER_PAGE:
        {
            for (int i = 0; i<[arrSlideMenuData count]; i++) {
                SlideMenuClass *menu = [arrSlideMenuData objectAtIndex:i];
                if ([menu.strMenuTitle isEqualToString:languageSelectedStringForKey(@"Transfers")]) {
                    menu.isShow=YES;
                    break;
                }
            }
        }
            break;
        case EXPENCE_ANALYSIS_PAGE:
        {
            for (int i = 0; i<[arrSlideMenuData count]; i++) {
                SlideMenuClass *menu = [arrSlideMenuData objectAtIndex:i];
                if ([menu.strMenuTitle isEqualToString:languageSelectedStringForKey(@"Expense Analysis")]) {
                    menu.isShow=YES;
                    break;
                }
            }
        }
            break;
            
        default:
            break;
    }
}
// Method to arrange the slide menu data items.
-(void)arrangeSlideMenuData
{
    int height =( getHeight(44)*[arrSlideMenuData count]);

    tblMenu.scrollEnabled=NO;
    int value = [AppDelegate sharedAppDelegate].isIphone5?440:[AppDelegate sharedAppDelegate].screenHeight<568?480-80:[AppDelegate sharedAppDelegate].screenHeight-180;//360//160//80
    //int value = [AppDelegate sharedAppDelegate].screenHeight-0;
    if (height>value) {
        height=value;
        tblMenu.scrollEnabled=YES;
    }
    if (isFirstTime==YES) {
        [self manageAccounts];
    }
    
   

    
    //[tblMenu reloadData];
    tblMenu.frame=CGRectMake(0, tblMenu.frame.origin.y, menuView.frame.size.width, height);
    
    [tblMenu reloadData];
    if(tblMenu.scrollEnabled==YES)
    [self performSelector:@selector(setContentOfset) withObject:nil afterDelay:0.1];
    }

-(void) setContentOfset{
    int i =0;
    for(SlideMenuClass *menu in arrSlideMenuData){
        
        
        if (menu.isShow == YES) {
            [tblMenu setContentOffset:CGPointMake(0, getHeight(44)*i)];
        }
        i++;
    }

}
//create arrays for all three section of table. Initialize the array with the objects.
-(void)fillMenuWithIndex :(slideMenuContent)index
{
    arrSlideMenuData= [[NSMutableArray alloc] init];
    
    switch (index) {
        case SLIDE_DEFAULT_CONTENT:
        {
            // Default Case
            SlideMenuClass *menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideHome" title:languageSelectedStringForKey(@"Home") selectedMenu:HOME_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdminBusiness" title:languageSelectedStringForKey(@"Business Summary") selectedMenu:BUSINESS_SUMMARY_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCardHome" title:languageSelectedStringForKey(@"Cards") selectedMenu:self.pageName Type:HEADERS Show:NO Enabled:YES ListSize:7];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            if ([AdminAccessInfo AdminAcess].initiateTransferValue == INITIATETRANSFER || [AdminAccessInfo AdminAcess].viewTransferValue == VIEWTRANSFER)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideTransfer" title:languageSelectedStringForKey(@"Transfers") selectedMenu:TRANSFER_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
//            if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS)
//            {
//                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:5];
//            }
//            else
//            {
//                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:NO ListSize:5];
//                
//            }
//            [arrSlideMenuData addObject:menu];
//            [menu release];
            
            if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:5];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            
            if ([AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideExpenseAnalysis" title:languageSelectedStringForKey(@"Expense Analysis") selectedMenu:EXPENCE_ANALYSIS_PAGE Type:HEADERS Show:NO Enabled:[AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS?YES:NO ListSize:0];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideLogout" title:languageSelectedStringForKey(@"Logout") selectedMenu:LOGOUT_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
        }
            break;
        case SLIDE_CARDS:
        {
            // Earn Cashback Case
            SlideMenuClass *menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideHome" title:languageSelectedStringForKey(@"Home") selectedMenu:HOME_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdminBusiness" title:languageSelectedStringForKey(@"Business Summary") selectedMenu:BUSINESS_SUMMARY_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCardHome" title:languageSelectedStringForKey(@"Cards") selectedMenu:self.pageName Type:HEADERS Show:YES Enabled:YES ListSize:7];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCardList" title:languageSelectedStringForKey(@"Card list") selectedMenu:CARD_LIST_PAGE Type:SUBHEADERS Show:NO Enabled:(self.pageName==CARDS_TRANSACTION_PAGE || self.pageName==CARDS_FUND_CARD_PAGE || self.pageName==CARDS_AUTOMATIC_FUNDING_PAGE || self.pageName==CARDS_EXPENSE_RULE_PAGE || self.pageName==UPDATE_PROFILE_PAGE || self.pageName==CARDS_PROFILE_PAGE)?YES:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
//            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCardCreateNew" title:languageSelectedStringForKey(@"Create New") selectedMenu:CARD_CREATE_NEW_PAGE Type:SUBHEADERS Show:NO Enabled:(self.pageName==CARDS_TRANSACTION_PAGE || self.pageName==CARDS_FUND_CARD_PAGE || self.pageName==CARDS_AUTOMATIC_FUNDING_PAGE || self.pageName==CARDS_EXPENSE_RULE_PAGE|| self.pageName==UPDATE_PROFILE_PAGE || self.pageName==CARDS_PROFILE_PAGE)?NO:YES ListSize:0];
//            [arrSlideMenuData addObject:menu];
//            [menu release];
            
            if ([AdminAccessInfo AdminAcess].transactionHistoryValue == TRANSACTIONHISTORY)
            {
                
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCardTransaction" title:languageSelectedStringForKey(@"Transactions") selectedMenu:CARDS_TRANSACTION_PAGE Type:SUBHEADERS Show:NO Enabled:(self.pageName==CARD_LIST_DETAIL_PAGE || self.pageName==CARDS_TRANSACTION_PAGE || self.pageName==CARDS_PROFILE_PAGE || self.pageName==UPDATE_PROFILE_PAGE || self.pageName==CARDS_FUND_CARD_PAGE || self.pageName==CARDS_AUTOMATIC_FUNDING_PAGE || self.pageName==CARDS_EXPENSE_RULE_PAGE )?[AdminAccessInfo AdminAcess].transactionHistoryValue == TRANSACTIONHISTORY:NO ListSize:0];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            //if ([AdminAccessInfo AdminAcess].loadCard == LOADCARD)
            //cell.lblTitle.textColor = menu.isEnable==NO?[UIColor grayColor]:menu.isShow ?[UIColor orangeColor]:UI_COLOR_TEXT_LIGHT;
            if ([AdminAccessInfo AdminAcess].loadCard == LOADCARD)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideFundCard" title:languageSelectedStringForKey(@"Fund Card") selectedMenu:CARDS_FUND_CARD_PAGE Type:SUBHEADERS Show:NO Enabled:(self.pageName==CARD_LIST_DETAIL_PAGE || self.pageName==CARDS_TRANSACTION_PAGE || self.pageName==CARDS_PROFILE_PAGE || self.pageName==UPDATE_PROFILE_PAGE || self.pageName==CARDS_FUND_CARD_PAGE || self.pageName==CARDS_AUTOMATIC_FUNDING_PAGE || self.pageName==CARDS_EXPENSE_RULE_PAGE )?[AdminAccessInfo AdminAcess].loadCard==LOADCARD:NO ListSize:0];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            if ([AdminAccessInfo AdminAcess].scheduleCard == SCHEDULECARD)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCardAutomaticFunding" title:languageSelectedStringForKey(@"Automatic funding") selectedMenu:CARDS_AUTOMATIC_FUNDING_PAGE Type:SUBHEADERS Show:NO Enabled:(self.pageName==CARD_LIST_DETAIL_PAGE || self.pageName==CARDS_TRANSACTION_PAGE || self.pageName==CARDS_PROFILE_PAGE || self.pageName==UPDATE_PROFILE_PAGE || self.pageName==CARDS_FUND_CARD_PAGE || self.pageName==CARDS_AUTOMATIC_FUNDING_PAGE || self.pageName==CARDS_EXPENSE_RULE_PAGE )?[AdminAccessInfo AdminAcess].scheduleCard == SCHEDULECARD:NO ListSize:0];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            if ([AdminAccessInfo AdminAcess].expenseRules == EXPENSERULES)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideExpenseRules" title:languageSelectedStringForKey(@"Expense Rules") selectedMenu:CARDS_EXPENSE_RULE_PAGE Type:SUBHEADERS Show:NO Enabled:(self.pageName==CARD_LIST_DETAIL_PAGE || self.pageName==CARDS_TRANSACTION_PAGE || self.pageName==CARDS_PROFILE_PAGE || self.pageName==UPDATE_PROFILE_PAGE || self.pageName==CARDS_FUND_CARD_PAGE || self.pageName==CARDS_AUTOMATIC_FUNDING_PAGE || self.pageName==CARDS_EXPENSE_RULE_PAGE )?[AdminAccessInfo AdminAcess].expenseRules == EXPENSERULES:NO ListSize:0];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCardProfile" title:languageSelectedStringForKey(@"Profile") selectedMenu:CARDS_PROFILE_PAGE Type:SUBHEADERS Show:NO Enabled:(self.pageName==CARD_LIST_DETAIL_PAGE || self.pageName==CARDS_TRANSACTION_PAGE || self.pageName==CARDS_PROFILE_PAGE || self.pageName==UPDATE_PROFILE_PAGE || self.pageName==CARDS_FUND_CARD_PAGE || self.pageName==CARDS_AUTOMATIC_FUNDING_PAGE || self.pageName==CARDS_EXPENSE_RULE_PAGE )?YES:NO ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            if ([AdminAccessInfo AdminAcess].initiateTransferValue == INITIATETRANSFER || [AdminAccessInfo AdminAcess].viewTransferValue == VIEWTRANSFER)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideTransfer" title:languageSelectedStringForKey(@"Transfers") selectedMenu:TRANSFER_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
//            if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS)
//            {
//                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:5];
//            }
//            else
//            {
//                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:NO ListSize:5];
//                
//            }
//            [arrSlideMenuData addObject:menu];
//            [menu release];
            
            if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:5];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            
            if ([AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideExpenseAnalysis" title:languageSelectedStringForKey(@"Expense Analysis") selectedMenu:EXPENCE_ANALYSIS_PAGE Type:HEADERS Show:NO Enabled:[AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS?YES:NO ListSize:4];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideLogout" title:languageSelectedStringForKey(@"Logout") selectedMenu:LOGOUT_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
        }
            break;
        case SLIDE_ADMINISTRATION:
        {
            // Profile Settings Case
            SlideMenuClass *menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideHome" title:languageSelectedStringForKey(@"Home") selectedMenu:HOME_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdminBusiness" title:languageSelectedStringForKey(@"Business Summary") selectedMenu:BUSINESS_SUMMARY_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCardHome" title:languageSelectedStringForKey(@"Cards") selectedMenu:self.pageName Type:HEADERS Show:NO Enabled:YES ListSize:7];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            if ([AdminAccessInfo AdminAcess].initiateTransferValue == INITIATETRANSFER || [AdminAccessInfo AdminAcess].viewTransferValue == VIEWTRANSFER)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideTransfer" title:languageSelectedStringForKey(@"Transfers") selectedMenu:TRANSFER_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
//            if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS)
//            {
//                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:5];
//            }
//            else
//            {
//                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:NO ListSize:5];
//                
//            }
//            [arrSlideMenuData addObject:menu];
//            [menu release];
            if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:YES Enabled:YES ListSize:5];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdminProfile" title:languageSelectedStringForKey(@"Profile") selectedMenu:ADMIN_PROFILE_PAGE Type:SUBHEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmins" title:languageSelectedStringForKey(@"Admins") selectedMenu:ADMINS_PAGE Type:SUBHEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
//            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCreateNewAdmin" title:languageSelectedStringForKey(@"Create New") selectedMenu:ADMIN_CREATE_NEW_PAGE Type:SUBHEADERS Show:NO Enabled:YES ListSize:0];
//            [arrSlideMenuData addObject:menu];
//            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdminAlerts" title:languageSelectedStringForKey(@"Alerts") selectedMenu:ADMIN_ALERTS_PAGE Type:SUBHEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
//            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCategoryManagement" title:languageSelectedStringForKey(@"Category Management") selectedMenu:ADMINT_CATEGORY_MANAGEMENT_PAGE Type:SUBHEADERS Show:NO Enabled:YES ListSize:0];
//            [arrSlideMenuData addObject:menu];
//            [menu release];
            
            if ([AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideExpenseAnalysis" title:languageSelectedStringForKey(@"Expense Analysis") selectedMenu:EXPENCE_ANALYSIS_PAGE Type:HEADERS Show:NO Enabled:[AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS?YES:NO ListSize:4];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideLogout" title:languageSelectedStringForKey(@"Logout") selectedMenu:LOGOUT_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
        }
            break;
        case SLIDE_EXPENSE_ANALYSIS:
        {
            // Profile Settings Case
            SlideMenuClass *menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideHome" title:languageSelectedStringForKey(@"Home") selectedMenu:HOME_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdminBusiness" title:languageSelectedStringForKey(@"Business Summary") selectedMenu:BUSINESS_SUMMARY_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideCardHome" title:languageSelectedStringForKey(@"Cards") selectedMenu:self.pageName Type:HEADERS Show:NO Enabled:YES ListSize:7];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            if ([AdminAccessInfo AdminAcess].initiateTransferValue == INITIATETRANSFER || [AdminAccessInfo AdminAcess].viewTransferValue == VIEWTRANSFER)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideTransfer" title:languageSelectedStringForKey(@"Transfers") selectedMenu:TRANSFER_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
//            if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS)
//            {
//                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:5];
//            }
//            else
//            {
//                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:NO ListSize:5];
//                
//            }
//            [arrSlideMenuData addObject:menu];
//            [menu release];
            if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideAdmin" title:languageSelectedStringForKey(@"Administration") selectedMenu:ADMINISTRATION_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:5];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            if ([AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS)
            {
                menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideExpenseAnalysis" title:languageSelectedStringForKey(@"Expense Analysis") selectedMenu:self.pageName Type:HEADERS Show:YES Enabled:[AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS?YES:NO ListSize:4];
                [arrSlideMenuData addObject:menu];
                [menu release];
            }
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideEmployee-icon" title:languageSelectedStringForKey(@"Employee") selectedMenu:EXP_EMPLOYEE_PAGE Type:SUBHEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideEmployee-by-Expense-Categories-icon" title:languageSelectedStringForKey(@"Employee By Expense") selectedMenu:EXP_EMP_BY_EXPENSE_PAGE Type:SUBHEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideExpense-categories-icon" title:languageSelectedStringForKey(@"Expense Categories") selectedMenu:EXP_EXPENSE_CAT_PAGE Type:SUBHEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideBusiness-Expense-icon" title:languageSelectedStringForKey(@"Business Expense") selectedMenu:EXP_BUSINESS_EXP_PAGE Type:SUBHEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
                       
            
            menu=[[SlideMenuClass alloc] initWithTitle:@"imgSlideLogout" title:languageSelectedStringForKey(@"Logout") selectedMenu:LOGOUT_PAGE Type:HEADERS Show:NO Enabled:YES ListSize:0];
            [arrSlideMenuData addObject:menu];
            [menu release];
        }

            break;
        default:
            break;
    }
    [self arrangeSlideMenuData];
}
//animate slide view and main view to left
-(void)animateLeft
{
    int menuX = (IS_IPAD?viewDisplayPositionIPAD:viewDisplayPosition) + (2*SIZE_PADDING_SMALL);
    
    // Show menu
    [menuView setHidden:NO];
    
    // Setup animations
    [UIView beginAnimations: nil context: NULL];
    [UIView setAnimationDelegate: self];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelay:0.0];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    
    // Set frames
//    [AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame = CGRectMake(-menuView.frame.size.width, 20,[AppDelegate sharedAppDelegate].screenWidth,IS_IPAD?44:44);
    
    [AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame = CGRectMake(-menuView.frame.size.width,IS_IPAD?IS_IOS7?20:20:20,[AppDelegate sharedAppDelegate].screenWidth, IS_IPAD?IS_IOS7?44:92:44);
    
    [AppDelegate sharedAppDelegate].naviGationController.visibleViewController.view.frame = CGRectMake(-menuView.frame.size.width, IS_IPAD?IS_IOS7?65:20:0,[AppDelegate sharedAppDelegate].screenWidth,[AppDelegate sharedAppDelegate].screenHeight);
    dummyView.frame=CGRectMake(0, menuView.frame.origin.y+navHeight, menuX, menuView.frame.size.height-navHeight);
    menuView.frame = CGRectMake(menuX, menuView.frame.origin.y, menuView.frame.size.width, menuView.frame.size.height);
    // Commit animations
    [UIView commitAnimations];
}

//animate slide view and  main view to right
-(void)animateRight
{  
    // Setup animations
    [UIView beginAnimations: nil context: NULL];
    [UIView setAnimationDelegate: self];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelay:0.0];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    
    // Set locations
    
//    [AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame = CGRectMake(0, 20,[AppDelegate sharedAppDelegate].screenWidth,IS_IPAD?44:44);
    
    [AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:20,[AppDelegate sharedAppDelegate].screenWidth, IS_IPAD?IS_IOS7?44:92:44);

    [AppDelegate sharedAppDelegate].naviGationController.visibleViewController.view.frame = CGRectMake(0,IS_IPAD?IS_IOS7?65:20:0,[AppDelegate sharedAppDelegate].screenWidth,[AppDelegate sharedAppDelegate].screenHeight);
    
    menuView.frame = CGRectMake([AppDelegate sharedAppDelegate].screenWidth, menuView.frame.origin.y, menuView.frame.size.width, menuView.frame.size.height);
    dummyView.frame=CGRectMake([AppDelegate sharedAppDelegate].screenWidth, menuView.frame.origin.y+navHeight, 0, menuView.frame.size.height-navHeight);
    // Commit animations
    [UIView commitAnimations];
    
    // Hide menu
    [menuView setHidden:YES];
}

//open slide view
-(void)openMenu
{
    [tblMenu setContentOffset:CGPointMake(0, 0)];
    if (!isAnimate) {
        isAnimate=YES;
        //[tblMenu reloadData];
        [self animateLeft];
    }
    else
    {
        isAnimate=NO;
        [self animateRight];
    }
}
// Method to disoplay the slide menu & setting the view title.
-(void)displaySlideMenu
{
    switch (self.pageName)
    {
        case DEFAULT_PAGE:
        {
            lblSlideTitle.text=languageSelectedStringForKey(@"Default");
            [self fillMenuWithIndex:SLIDE_DEFAULT_CONTENT];
        }
            break;
        case HOME_PAGE:
        {
            lblSlideTitle.text=languageSelectedStringForKey(@"Home");
            [self fillMenuWithIndex:SLIDE_DEFAULT_CONTENT];
        }
            break;
        case BUSINESS_SUMMARY_PAGE:
        {
            lblSlideTitle.text=languageSelectedStringForKey(@"Business Summary");
            [self fillMenuWithIndex:SLIDE_DEFAULT_CONTENT];
        }
            break;
        case CARD_LIST_PAGE: case CARD_CREATE_NEW_PAGE: case CARDS_FUND_CARD_PAGE: case CARDS_AUTOMATIC_FUNDING_PAGE: case CARDS_EXPENSE_RULE_PAGE:
        {
            lblSlideTitle.text=languageSelectedStringForKey(@"Card List");
            [self fillMenuWithIndex:SLIDE_CARDS];
        }
            break;
        case TRANSFER_PAGE:
        {
            lblSlideTitle.text=languageSelectedStringForKey(@"Transfers");
            [self fillMenuWithIndex:SLIDE_DEFAULT_CONTENT];
        }
            break;
        case ADMINISTRATION_PAGE: case ADMIN_PROFILE_PAGE: case ADMINS_PAGE: case ADMIN_CREATE_NEW_PAGE: case ADMIN_ALERTS_PAGE: case ADMINT_CATEGORY_MANAGEMENT_PAGE:
        {
            lblSlideTitle.text=languageSelectedStringForKey(@"Adminstration Page");
            [self fillMenuWithIndex:SLIDE_ADMINISTRATION];
        }
            break;
        case EXPENCE_ANALYSIS_PAGE: case EXP_EMPLOYEE_PAGE: case EXP_EMP_BY_EXPENSE_PAGE: case EXP_EXPENSE_CAT_PAGE: case EXP_BUSINESS_EXP_PAGE:
        {
            lblSlideTitle.text=languageSelectedStringForKey(@"Expence Analysis");
            [self fillMenuWithIndex:SLIDE_EXPENSE_ANALYSIS];
        }
            break;
            case CARD_LIST_DETAIL_PAGE:
        {
            lblSlideTitle.text=languageSelectedStringForKey(CARD_LIST_DETAIL_TITLE);
            [self fillMenuWithIndex:SLIDE_CARDS];
        }
            break;
        case CARDS_TRANSACTION_PAGE:
        {
            lblSlideTitle.text=languageSelectedStringForKey(@"Transactions");
            [self fillMenuWithIndex:SLIDE_CARDS];
        }
            break;
        case CARDS_PROFILE_PAGE:
        {
            lblSlideTitle.text=languageSelectedStringForKey(@"User Profile");
            [self fillMenuWithIndex:SLIDE_CARDS];
        }
            break;
        case UPDATE_PROFILE_PAGE:
        {
            lblSlideTitle.text=[NSString stringWithFormat:@"%@ %@ %@",languageSelectedStringForKey(@"Update"),languageSelectedStringForKey(@"Card"),languageSelectedStringForKey(@"Profile")];
            [self fillMenuWithIndex:SLIDE_CARDS];
        }
            break;
        case PAGE_TRANSACTIONS_DETAILS:
        {
            lblSlideTitle.text=languageSelectedStringForKey(@"Transactions Details");
            [self fillMenuWithIndex:SLIDE_CARDS];
        }
            break;
            
        default:
            break;
    }
}
// Method to show slide menu view.
-(void)showMenuWithPageType :(pageType)page
{
    self.pageName=page;
    
    if ([AppDelegate sharedAppDelegate].classType==HOME_PAGE || [AppDelegate sharedAppDelegate].classType==BUSINESS_SUMMARY_PAGE || [AppDelegate sharedAppDelegate].classType==TRANSFER_PAGE) {
        isFirstTime=YES;
    }
    else{
        isFirstTime=NO;
    }
    
    
    [self displaySlideMenu];
        
    [self AddMenuView];
    [menuView setHidden:NO];
    [self openMenu];
    //[self displaySlideMenu];
}
// Method to hide slide view
-(void)hideMenu
{
    [menuView setHidden:YES];
    [menuView removeFromSuperview];
    [self openMenu];
}
// Method to add slide menu view to the window.
-(void)AddMenuView
{
    if ([menuView isDescendantOfView:[AppDelegate sharedAppDelegate].window]) {
        [menuView removeFromSuperview];
        [dummyView removeFromSuperview];
    }
    [[AppDelegate sharedAppDelegate].window addSubview:menuView];
    [[AppDelegate sharedAppDelegate].window addSubview:dummyView];
    [[AppDelegate sharedAppDelegate].window makeKeyAndVisible];
    [menuView setHidden:YES];
    
    
}
// Method to swipe right.
-(IBAction)rightSwipe:(id)sender
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==YES) {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [self hideMenu];
    }
}

//create sliding menu view
-(void)createMenuView
{
    //[self fillMenuWithIndex:DEFAULT];
   
    int menuX = (IS_IPAD?viewDisplayPositionIPAD:viewDisplayPosition) + (2*SIZE_PADDING_SMALL);
    int menuY = STATUSBAR_HEIGHT;
    int menuWidth = [AppDelegate sharedAppDelegate].screenWidth - menuX;
    
    dummyView=[[UIView alloc] initWithFrame:CGRectMake([AppDelegate sharedAppDelegate].screenWidth, menuY+navHeight, menuX, getAppHeight()-navHeight)];
    [dummyView setBackgroundColor:UIColorFromARGB(0x22000000)];
    
    UISwipeGestureRecognizer *rightSwipe  =  [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(rightSwipe:)];
    [rightSwipe setDirection:(UISwipeGestureRecognizerDirectionRight)];
    rightSwipe.delegate   =   self;
    [dummyView addGestureRecognizer:rightSwipe];
    [rightSwipe release];

    menuView=[[UIView alloc] initWithFrame:CGRectMake([AppDelegate sharedAppDelegate].screenWidth,IS_IOS7?0:menuY, menuWidth,IS_IOS7?getAppHeight()+20:getAppHeight())];
    menuView.backgroundColor=UIColorFromARGB(0xFF404040);
    
    UIView *topView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, menuView.frame.size.width, navHeight+2+(IS_IOS7?IS_IPAD?60:20:0))];
    topView.backgroundColor=UIColorFromARGB(0xFF222222);
    [menuView addSubview:topView];
    menuView.userInteractionEnabled=YES;
    
    lblSlideTitle = createLabel(@"", CGRectMake(0,IS_IOS7?20:0, menuView.frame.size.width, navHeight+2));
    lblSlideTitle.textAlignment=UITextAlignmentCenter;
    lblSlideTitle.font=IS_IPAD?[UIFont boldSystemFontOfSize:22]:[UIFont boldSystemFontOfSize:16];
    lblSlideTitle.textColor=[UIColor whiteColor];
    lblSlideTitle.backgroundColor=[UIColor clearColor];
    [topView addSubview:lblSlideTitle];
    [lblSlideTitle release];
    
   
    tblMenu= createTableView(CGRectMake(0, CGRectGetMaxY(topView.frame), menuView.frame.size.width, [AppDelegate sharedAppDelegate].screenHeight- getHeight(120)),self);//120
    tblMenu.separatorColor=UIColorFromARGB(0x88000000);
    tblMenu.scrollEnabled=YES;
    tblMenu.delegate=self;
    tblMenu.dataSource=self;
    [menuView addSubview:tblMenu];
    
    UILabel *lblMessage1 = createLabel(@"Version 1.0.0 | Privacy & Terms", CGRectMake(0, [AppDelegate sharedAppDelegate].screenHeight-getHeight(40), menuView.frame.size.width, getHeight(20)));
    lblMessage1.font=IS_IPAD?[UIFont systemFontOfSize:25]:[UIFont systemFontOfSize:14];
    lblMessage1.textColor=UI_COLOR_TEXT_LIGHT;
    lblMessage1.textAlignment=UITextAlignmentCenter;
    [menuView addSubview:lblMessage1];
    lblMessage1.hidden=YES;
    [lblMessage1 release];
    
    lblMessage1=createLabel(@"©2013 Discover Bank, Member DFDNC", CGRectMake(0, CGRectGetMaxY(lblMessage1.frame), menuView.frame.size.width, 20));
    lblMessage1.font=[UIFont systemFontOfSize:14];
    lblMessage1.textColor=UI_COLOR_TEXT_LIGHT;
    lblMessage1.textAlignment=UITextAlignmentCenter;
    [menuView addSubview:lblMessage1];
    lblMessage1.hidden=YES;
    [lblMessage1 release];
    
}
#pragma mark - Data Parsing Delegate method


// delegate method of Dataresponce class
-(void)getResponce:(id)jsonData
{
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    
    switch (selectedPageType) {
        case HOME_PAGE:
        {
            if (![AppDelegate sharedAppDelegate].arrBusinessData)
            {
                [AppDelegate sharedAppDelegate].arrBusinessData=[[NSMutableArray alloc] init];
            }
            else
            {
                [[AppDelegate sharedAppDelegate].arrBusinessData removeAllObjects];
            }
            [AppDelegate sharedAppDelegate].arrBusinessData=jsonData;
            HomeViewController *homeView = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
            
            [[AppDelegate sharedAppDelegate].naviGationController pushViewController:homeView animated:YES];
            [homeView release];
            [self hideSlideMenu];
        }
            break;
        case BUSINESS_SUMMARY_PAGE:
        {
            if (![AppDelegate sharedAppDelegate].arrBusinessData)
            {
                [AppDelegate sharedAppDelegate].arrBusinessData=[[NSMutableArray alloc] init];
            }
            else
            {
                [[AppDelegate sharedAppDelegate].arrBusinessData removeAllObjects];
            }
            [AppDelegate sharedAppDelegate].arrBusinessData=jsonData;
            BusinessSummaryViewController *bsvc=[[BusinessSummaryViewController alloc]init];
            [[AppDelegate sharedAppDelegate].naviGationController pushViewController:bsvc animated:YES];
            [bsvc release];
            [self hideSlideMenu];
            
        }
            break;
        case CARD_LIST_PAGE:
        {
            
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    if (![AppDelegate sharedAppDelegate].arrCardDetailArray)
                    {
                        [AppDelegate sharedAppDelegate].arrCardDetailArray = [[NSMutableArray alloc] init];
                        
                    }else
                    {
                        [[AppDelegate sharedAppDelegate].arrCardDetailArray removeAllObjects];
                        
                    }
                    
                    [AppDelegate sharedAppDelegate].arrCardDetailArray=jsonData;
                    
                    CardListViewController *clvc = [[CardListViewController alloc] init];
                    [[AppDelegate sharedAppDelegate].naviGationController pushViewController:clvc animated:YES];
                    [clvc release];
                    [self hideSlideMenu];
                }else
                {
                    showAlertScreen(@"No Records", @"There is no card Available for the Account.");
                }
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            
        }
            break;
        case CARDS_TRANSACTION_PAGE:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    TransactionViewController *obj=[[TransactionViewController alloc] initWithNibName:@"TransactionViewController" bundle:nil trasactionData:jsonData isAlertRequest:NO];
                    
                    [[AppDelegate sharedAppDelegate].naviGationController pushViewController:obj animated:YES];
                    [obj release];
                }else
                {
                    showAlertScreen(@"No Records", @"There is no record found.");
                }
                
                
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
            [self hideSlideMenu];
    
          
        }
            break;
        
        case CARDS_AUTOMATIC_FUNDING_PAGE:
        {
            
            
            switch (autoMaticfundReqType) {
                    
                case LowBalanceSearch:
                {
                    lowBalanceSearchObj = (lowBalanceSearchDataClass *) jsonData;
                    autoMaticfundReqType = SchedulingSearch;
                    [[AppDelegate sharedAppDelegate] addloadingView];
                    [self getRequestforScheduling];
                }
                    break;
                    
                case SchedulingSearch:
                {
                    
                    ScheduleFundingSearchDataClass *obj = (ScheduleFundingSearchDataClass *) jsonData;
                    AutoMaticViewController *fcvc = [[AutoMaticViewController alloc] initWithNibName:@"AutoMaticViewController" bundle:nil CardData:nil];
                    fcvc.lowBalancingObj = lowBalanceSearchObj;
                    fcvc.schedulingObj = obj;
                    [[AppDelegate sharedAppDelegate].naviGationController pushViewController:fcvc animated:YES];
                    
                    [fcvc release];
                    [self hideSlideMenu];
                    
                }
                    break;
                    
                default:
                    break;
            }
            
            
            
            
        }
            break;
        case CARDS_EXPENSE_RULE_PAGE:
        {
            [self openExpenseRulesPage];
        }
            break;
        case CARDS_PROFILE_PAGE:
        {
            UserProfileDataClass * obj  = (UserProfileDataClass *)jsonData;
            
            if(obj != nil){
                
                UserProfileViewController *upvc = [[UserProfileViewController alloc] initWithNibName:@"UserProfileViewController" bundle:nil userProfileData:obj];
                
                [[AppDelegate sharedAppDelegate].naviGationController pushViewController:upvc animated:YES];
                [upvc release];
                [self hideSlideMenu];
                
            }
            else{
                
            }

            
           
        }
            break;
        case TRANSFER_PAGE:
        {
            switch (transfer_request)
            {
                    
                case transfer_list:
                {
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        if ([jsonData count]==0)
                        {
//                            showAlertScreen(nil, @"No record Found");
                        }else
                        {
                            if (![AppDelegate sharedAppDelegate].Arraytransfer) {
                                [AppDelegate sharedAppDelegate].Arraytransfer=[[NSMutableArray alloc]init];
                            }else
                            {
                                [[AppDelegate sharedAppDelegate].Arraytransfer removeAllObjects];
                            }
                            
                            [AppDelegate sharedAppDelegate].Arraytransfer=jsonData;
                            
                    }
                       
                    }
                    TransferViewController *tvc = [[TransferViewController alloc] initWithNibName:@"TransferViewController" bundle:nil];
                    [[AppDelegate sharedAppDelegate].naviGationController pushViewController:tvc animated:YES];
                    [tvc release];
                    [self hideSlideMenu];

                    [[AppDelegate sharedAppDelegate] removeLoadingView];
                }
                    break;
                    
                case Bank_list:
                {
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        if ([jsonData count]==0)
                        {
                            //                    showAlertScreen(nil, @"No record Found");
                        }else
                        {
                            if (![AppDelegate sharedAppDelegate].ArraybankList) {
                                [AppDelegate sharedAppDelegate].ArraybankList=[[NSMutableArray alloc]init];
                            }else
                            {
                                [[AppDelegate sharedAppDelegate].ArraybankList removeAllObjects];
                            }
                            
                            [AppDelegate sharedAppDelegate].ArraybankList=jsonData;
                            
                        }
                    }else
                    {
//                        showAlertScreen(nil, jsonData);
                    }
                    
//                    [[AppDelegate sharedAppDelegate] removeLoadingView];
                    
                    transfer_request=transfer_list;
                    
                    [self transferPageRequest];
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
        case ADMIN_PROFILE_PAGE:
        {
            switch (selfprofile) {
                case get_load_LImit:
                {
                    if ([jsonData isKindOfClass:[adminLoadLimitDataClass class]])
                    {
                        adminLoadObj=(adminLoadLimitDataClass *)jsonData;
                        [self getAdminsProfile];
                    }else
                    {
                        showAlertScreen(nil, jsonData);
                        [[AppDelegate sharedAppDelegate] removeLoadingView];
                        [self hideSlideMenu];
                    }
                }
                    break;
                case Self_Profile:
                {
                    if ([jsonData isKindOfClass:[adminProfileData class]])
                    {
                        
                        adminProfileData *profile=(adminProfileData *)jsonData;
                        
                        AdminProfileViewController *adPVC=[[AdminProfileViewController alloc] initWithNibName:@"AdminProfileViewController" bundle:nil admin:YES];
                        
                        adPVC.adminProfileObj=profile;
                        adPVC.adminLoadDataObj=adminLoadObj;
                        [[AppDelegate sharedAppDelegate].naviGationController pushViewController:adPVC animated:YES];
                        [adPVC release];
                        
                        [[AppDelegate sharedAppDelegate] removeLoadingView];
                        
                    }else
                    {
                        showAlertScreen(nil, jsonData);
                    }
                    [[AppDelegate sharedAppDelegate] removeLoadingView];
                    [self hideSlideMenu];
                }
                    break;
                default:
                    break;
            }
        }
            break;
        case ADMINS_PAGE:
        {
                if ([jsonData isKindOfClass:[NSArray class]])
                {
                    if ([jsonData count]>0)
                    {
                        if (![AppDelegate sharedAppDelegate].ArrayAdmin)
                        {
                            [AppDelegate sharedAppDelegate].ArrayAdmin=[[NSMutableArray alloc]init];
                        }else
                        {
                            [[AppDelegate sharedAppDelegate].ArrayAdmin removeAllObjects];
                        }
                        
                        [AppDelegate sharedAppDelegate].ArrayAdmin=jsonData;
                        
                        AdminListViewController *apvc = [[AdminListViewController alloc] initWithNibName:@"AdminListViewController" bundle:nil];
                        
                        [[AppDelegate sharedAppDelegate].naviGationController pushViewController:apvc animated:YES];
                        [apvc release];
                        
                    }else
                    {
                        showAlertScreen(nil, @"No record Found");
                    }
                    
                }else
                {
                    showAlertScreen(nil, jsonData);
                }
             [self hideSlideMenu];
                [[AppDelegate sharedAppDelegate] removeLoadingView];
                
        }
            break;
        case ADMIN_CREATE_NEW_PAGE:
        {
            [self openCreateNewAdminPage];
        }
            break;
        case ADMIN_ALERTS_PAGE:
        {
            
            NSMutableArray *dataArray=nil;
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                dataArray=jsonData;
                
            }
            alertGroupViewController *avc = [[alertGroupViewController alloc] initWithNibName:@"alertGroupViewController" bundle:nil Array:dataArray];
            [[AppDelegate sharedAppDelegate].naviGationController pushViewController:avc animated:YES];
            [avc release];
            [self hideSlideMenu];
        }
            break;
        case ADMINT_CATEGORY_MANAGEMENT_PAGE:
        {
            [self openAdminCategoryManagementPage];
        }
            break;
        case EXPENCE_ANALYSIS_PAGE:
        {
            [self openExpenseAnalysisPage];
        }
            break;
        case EXP_EMPLOYEE_PAGE:
        {
            switch (analysisRequest)
            {
                case exp_Business_List:
                {
                    if (!arrBusinessList) {
                        arrBusinessList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrBusinessList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrBusinessList=jsonData;
                    }
                    
                    [self getEmployeeListRequest];
                }
                    break;
                case Exp_Cate_List:
                {
                    if (!arrCategoryList) {
                        arrCategoryList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrCategoryList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrCategoryList=jsonData;
                    }
                    [self getEmployeeExpenseRequest];

                }
                    break;
                case EmployeeList_Request:
                {
                    if (!arrEmployeeList) {
                        arrEmployeeList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrEmployeeList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrEmployeeList=jsonData;
                    }
                    [self GetExpenseCategory];
                }
                    break;
                    case Employee:
                {
                    employeeExpenseDataClass *expObj;
                    if (![jsonData isKindOfClass:[employeeExpenseDataClass class]])
                    {
                        expObj = [[employeeExpenseDataClass alloc] init];
                        showAlertScreen(nil, jsonData);
                    }
                    else
                    {
                        expObj=(employeeExpenseDataClass *)jsonData;
                        if ([expObj.employeeExpenseArray count]==0)
                        {
                            showAlertScreen(nil, @"No record Found..");
                        }
                    }
                       
                            EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:arrEmployeeList analysisType:Employee_analysis businessListArray:arrBusinessList categoryArray:arrCategoryList];
                             adPVC.empExpData=expObj;
                            [[AppDelegate sharedAppDelegate].naviGationController pushViewController:adPVC animated:YES];
                            [adPVC release];
                            
                            [self hideSlideMenu];;
                    
                    
                    [[AppDelegate sharedAppDelegate]removeLoadingView];
                }
                default:
                    break;
            }
            
        }
            break;
        case EXP_EMP_BY_EXPENSE_PAGE:
        {
            switch (analysisRequest)
            {
                case exp_Business_List:
                {
                    if (!arrBusinessList) {
                        arrBusinessList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrBusinessList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrBusinessList=jsonData;
                    }
                    
                    [self getEmployeeListRequest];
                }
                    break;
                case Exp_Cate_List:
                {
                    if (!arrCategoryList) {
                        arrCategoryList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrCategoryList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrCategoryList=jsonData;
                    }
                    [self getEmployeeByExpenseAnalysisRequest];
                    
                }
                    break;
                case EmployeeList_Request:
                {
                    if (!arrEmployeeList) {
                        arrEmployeeList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrEmployeeList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrEmployeeList=jsonData;
                    }
                    [self GetExpenseCategory];
                }
                    break;
                case EmployeeByExpense:
                {
                    employeeExpenseDataClass *expObj;
                    if (![jsonData isKindOfClass:[employeeExpenseDataClass class]])
                    {
                        expObj = [[employeeExpenseDataClass alloc] init];
                        showAlertScreen(nil, jsonData);
                    }
                    else
                    {
                        expObj=(employeeExpenseDataClass *)jsonData;
                        if ([expObj.employeeExpenseArray count]==0)
                        {
                            showAlertScreen(nil, @"No record Found..");
                        }
                    }
                                                 EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:arrEmployeeList analysisType:Employee_by_Expense_analysis businessListArray:arrBusinessList categoryArray:arrCategoryList];
                             adPVC.empExpData=expObj;
                            [[AppDelegate sharedAppDelegate].naviGationController pushViewController:adPVC animated:YES];
                            [adPVC release];
                            
                            [self hideSlideMenu];
                    
                    [[AppDelegate sharedAppDelegate]removeLoadingView];
                }
                default:
                    break;
            }

            
        }
            break;
        case EXP_EXPENSE_CAT_PAGE:
        {
            switch (analysisRequest)
            {
                case exp_Business_List:
                {
                    if (!arrBusinessList) {
                        arrBusinessList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrBusinessList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrBusinessList=jsonData;
                    }
                    
                    [self getEmployeeListRequest];
                }
                    break;
                case Exp_Cate_List:
                {
                    if (!arrCategoryList) {
                        arrCategoryList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrCategoryList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrCategoryList=jsonData;
                    }
                    [self getExpenseCategoryRequest];
                    
                }
                    break;
                case EmployeeList_Request:
                {
                    if (!arrEmployeeList) {
                        arrEmployeeList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrEmployeeList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrEmployeeList=jsonData;
                    }
                    [self GetExpenseCategory];
                }
                    break;
                case EmployeeExpenseCategor:
                {
                    
                    employeeExpenseDataClass *expObj;
                    if (![jsonData isKindOfClass:[employeeExpenseDataClass class]])
                    {
                        expObj = [[employeeExpenseDataClass alloc] init];
                        showAlertScreen(nil, jsonData);
                    }
                    else
                    {
                        expObj=(employeeExpenseDataClass *)jsonData;
                        if ([expObj.employeeExpenseArray count]==0)
                        {
                            showAlertScreen(nil, @"No record Found..");
                        }
                    }
                    
                    
                        EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:arrEmployeeList analysisType:Employee_Expense_Category businessListArray:arrBusinessList categoryArray:arrCategoryList];
                             adPVC.empExpData=expObj;
                            [[AppDelegate sharedAppDelegate].naviGationController pushViewController:adPVC animated:YES];
                            [adPVC release];
                            
                            
                            [self hideSlideMenu];                    
                    
                    [[AppDelegate sharedAppDelegate]removeLoadingView];
                }
                default:
                    break;
            }

            
        }
            break;
        case EXP_BUSINESS_EXP_PAGE:
        {
            switch (analysisRequest)
            {
                case exp_Business_List:
                {
                    if (!arrBusinessList) {
                        arrBusinessList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrBusinessList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrBusinessList=jsonData;
                    }
                    
                    [self getEmployeeListRequest];
                }
                    break;
                case Exp_Cate_List:
                {
                    if (!arrCategoryList) {
                        arrCategoryList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrCategoryList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrCategoryList=jsonData;
                    }
                    [self getBussinessRequest];
                    
                }
                    break;
                case EmployeeList_Request:
                {
                    if (!arrEmployeeList) {
                        arrEmployeeList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [arrEmployeeList removeAllObjects];
                    }
                    if ([jsonData isKindOfClass:[NSArray class]])
                    {
                        arrEmployeeList=jsonData;
                    }
                    [self GetExpenseCategory];
                }
                    break;
                case EmployeeBusinessExpense:
                {
                    employeeExpenseDataClass *expObj;
                    if (![jsonData isKindOfClass:[employeeExpenseDataClass class]])
                    {
                        expObj = [[employeeExpenseDataClass alloc] init];
                        showAlertScreen(nil, jsonData);
                    }
                    else
                    {
                        expObj=(employeeExpenseDataClass *)jsonData;
                        if ([expObj.employeeExpenseArray count]==0)
                        {
                            showAlertScreen(nil, @"No record Found..");
                        }
                    }
                            EmployeeExpenseViewController *adPVC=[[EmployeeExpenseViewController alloc] initWithNibName:@"EmployeeExpenseViewController" bundle:nil empDataArray:arrEmployeeList analysisType:Employee_Business_Expense businessListArray:arrBusinessList categoryArray:arrCategoryList];
                             adPVC.empExpData=expObj;
                            [[AppDelegate sharedAppDelegate].naviGationController pushViewController:adPVC animated:YES];
                            [adPVC release];
                            
                            [self hideSlideMenu];                    

                    
                    [[AppDelegate sharedAppDelegate]removeLoadingView];
                }
                default:
                    break;
            }
        }
            break;
        case CARD_LIST_DETAIL_PAGE:
        {
            [self openCardListDetailsPage];
        }
            break;
        case LOGOUT_PAGE:
        {
            [self openLogout];
        }
            break;
            
            
        default:
            break;
    }
    
    
}


#pragma mark - Methods to open Pages.
// Method to hide menu.
-(void)hideSlideMenu
{
    [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
    [self hideMenu];
}
// Method to open Home Page.
-(void)openHomePage
{
    
    if ([AppDelegate sharedAppDelegate].classType==HOME_PAGE) {
        [self hideSlideMenu];
    }
    else{
        [[AppDelegate sharedAppDelegate] addloadingView];
        
        selectedPageType = HOME_PAGE;
        DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
        dataParsing.Datadelegate=self;
        [SystemConfiguration sharedSystemConfig].dbbServiceName=Business_Search_Request;
        [SystemConfiguration sharedSystemConfig].deFlagShowDetails=@"1";
        [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPProductParent=&deBusinessName=&deCIASDDANumber=&deAADAccountNumber=&dePPCardStatus=&deCIASFirstName=&deCIASLastName=&deCIAAddressLine1=&deCIAAddressLine2=&deCIASCity=&deCIASState=&deCIASCountry=&deCIASZipCode=&deBSAcctId=&deFlagShowDetails=%@&deRequestBatchSize=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].deFlagShowDetails] ServiceName:svcBusinessAccountSearch];

        [dataParsing release];
//        HomeViewController *hvc = [[HomeViewController alloc] init];
//        [[AppDelegate sharedAppDelegate].naviGationController pushViewController:hvc animated:YES];
//        [hvc release];
//        [self hideSlideMenu];
    }
}
// Method to open Business Summary Page.
-(void)openBusinessSummaryPage
{
    if ([AppDelegate sharedAppDelegate].classType==BUSINESS_SUMMARY_PAGE) {
        [self hideSlideMenu];
    }
    else{
        
        [[AppDelegate sharedAppDelegate] addloadingView];
        
        selectedPageType = BUSINESS_SUMMARY_PAGE;
        DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
        dataParsing.Datadelegate=self;
        [SystemConfiguration sharedSystemConfig].dbbServiceName=Business_Search_Request;
        [SystemConfiguration sharedSystemConfig].deFlagShowDetails=@"1";
        [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPProductParent=&deBusinessName=&deCIASDDANumber=&deAADAccountNumber=&dePPCardStatus=&deCIASFirstName=&deCIASLastName=&deCIAAddressLine1=&deCIAAddressLine2=&deCIASCity=&deCIASState=&deCIASCountry=&deCIASZipCode=&deBSAcctId=&deFlagShowDetails=%@&deRequestBatchSize=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].deFlagShowDetails] ServiceName:svcBusinessAccountSearch];
        
        [dataParsing release];

        
       
    }
}
// Method to open Card List Page.
-(void)openCardlistPage
{
    if ([AppDelegate sharedAppDelegate].classType==CARD_LIST_PAGE) {
        [self hideSlideMenu];
    }
    else{
        // Code to open Card List Page.
        [[AppDelegate sharedAppDelegate] addloadingView];
        selectedPageType = CARD_LIST_PAGE;
        
        BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
        
        DataParsingClass *DataReq=[[DataParsingClass alloc] init];
        DataReq.Datadelegate=self;
        
        [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
        [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
        
        
        
        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=%@&deBsAccountNumber=&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=&deBusinessName=%@",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.BusinessName,BusinessPageObject.Business_ID_Desc] ServiceName:svcBACardHolderList];
        
        [DataReq release];
        
        
    }
}
// Method to open Create Card Page.
-(void)openCreateCardPage
{
    if ([AppDelegate sharedAppDelegate].classType==CARD_CREATE_NEW_PAGE) {
        [self hideSlideMenu];
    }
    else{
        // Code to open Create Card Page.
        [self hideSlideMenu];
    }
}
// Method to open Transaction Page.
-(void)openTransactionsPage
{
    if ([AppDelegate sharedAppDelegate].classType==CARDS_TRANSACTION_PAGE) {
        [self hideSlideMenu];
    }
    else{
        
        [[AppDelegate sharedAppDelegate] addloadingView];
        selectedPageType = CARDS_TRANSACTION_PAGE;
        
        int BatchSize=50;
        CardDetailClass * cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
        [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
        [SystemConfiguration sharedSystemConfig].dbbServiceName=TransactionHistory_Request;
        [SystemConfiguration sharedSystemConfig].deCIASTxnFilter=@"0";
        DataParsingClass *DataReq=[[DataParsingClass alloc] init];
        DataReq.Datadelegate=self;
        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deCIAClientID=%@&deCIAAccountNumber=%@&deANAProductID=%@&deCIASFromDate=&deCIASToDate=&deCIASTxnFilter=%@&deCIASTxnBatchSize=%@&deCIASTxnPageIndex=0&de_TranId_TH=&deCIASTxnHistoryType=0&deCIAMaximumTxnAmount=&deCIAminimumTxnAmount=&deCIAMerchantSearch=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,cardDataObj.CLIENTID,cardDataObj.ACCOUNTNUMBER,cardDataObj.PRODUCTID,[SystemConfiguration sharedSystemConfig].deCIASTxnFilter,[NSString stringWithFormat:@"%d",BatchSize],[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCHTransactionHistory];
        // Code to open transactions Page.
        [DataReq release];
    }
}
// Method to open Fund Card Page.
-(void)openFundCardPage
{
    if ([AppDelegate sharedAppDelegate].classType==CARDS_FUND_CARD_PAGE)
    {
        [self hideSlideMenu];
    }
    else{
        // Code to open Fund Card Page.
        FundCardViewController *fcv = [[FundCardViewController alloc] initWithNibName:@"FundCardViewController" bundle:nil CardData:nil];
        [[AppDelegate sharedAppDelegate].naviGationController pushViewController:fcv animated:YES];
        [fcv release];
        [self hideSlideMenu];
    }
}
// make request for scheduling at automatic funding page
-(void) getRequestforScheduling{
    autoMaticfundReqType = SchedulingSearch;
    [[AppDelegate sharedAppDelegate] addloadingView];
    selectedPageType = CARDS_AUTOMATIC_FUNDING_PAGE;
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Search_Schedule_funding_Request;
    CardDetailClass *cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deBAAccountAcctId=%@&deBTSFlag=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.BSAcctID] ServiceName:svcBAScheduleFundingSearch];
    [DataReq release];
}
// Method to open Automatic Funding Page.
-(void)openAutomaticFundingPage
{
    if ([AppDelegate sharedAppDelegate].classType==CARDS_AUTOMATIC_FUNDING_PAGE) {
        [self hideSlideMenu];
    }
    else{
        selectedPageType = CARDS_AUTOMATIC_FUNDING_PAGE;
        autoMaticfundReqType = LowBalanceSearch;
        [[AppDelegate sharedAppDelegate] addloadingView];
        selectedPageType = CARDS_AUTOMATIC_FUNDING_PAGE;
        DataParsingClass *DataReq=[[DataParsingClass alloc] init];
        DataReq.Datadelegate=self;
        
                [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
                [SystemConfiguration sharedSystemConfig].dbbServiceName=Search_LowBalance_REquest;
                CardDetailClass *cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
                [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deBAAccountAcctId=%@&deBTSFlag=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.BSAcctID] ServiceName:svcBALowBalanceFundingSearch];
                
            
        [DataReq release];
        
        
    }
}
// Method to open Expense Rules Page.
-(void)openExpenseRulesPage
{
    if ([AppDelegate sharedAppDelegate].classType==CARDS_EXPENSE_RULE_PAGE) {
        [self hideSlideMenu];
    }
    else{
        // Code to open Expense Rules Page.
        ExpenseRulesViewController *ervc = [[ExpenseRulesViewController alloc] initWithNibName:@"ExpenseRulesViewController" bundle:nil CardData:nil];
        [[AppDelegate sharedAppDelegate].naviGationController pushViewController:ervc animated:YES];
        [ervc release];
        [self hideSlideMenu];
        
    }
}
// Method to open Card Profile Page.
-(void)openProfilePage
{
    if ([AppDelegate sharedAppDelegate].classType==CARDS_PROFILE_PAGE) {
        [self hideSlideMenu];
    }
    else{
        
        [[AppDelegate sharedAppDelegate] addloadingView];
        selectedPageType = CARDS_PROFILE_PAGE;
        
        [SystemConfiguration sharedSystemConfig].dbbServiceName=Card_holder_Detail_Request;
        [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
        
        
        CardDetailClass *CardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
        
        DataParsingClass *DataReq=[[DataParsingClass alloc] init];
        DataReq.Datadelegate=self;
        
        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deTCIVRPrimaryAccountNumber=%@&deTCIVRAccountNumber=%@&deTCIVRANI=&deTCIVRDNS=&deBSAcctid_New=%@&deIVRSource=%@",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, CardDataObj.CARDNUMBER,CardDataObj.ACCOUNTNUMBER,CardDataObj.BSAcctID,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCardholderDetail];
        
        [DataReq release];
        // Code to open Cards Profile Page.
       
    }
}
// Method to open Transfers Page.
-(void)openTransfersPage
{
    if ([AppDelegate sharedAppDelegate].classType==TRANSFER_PAGE)
    {
        
        [self hideSlideMenu];
    }
    else
    {
        
              transfer_request=Bank_list;
        
        selectedPageType= TRANSFER_PAGE;
        [self transferPageRequest];
//        TransferViewController *tvc =[[TransferViewController alloc] initWithNibName:@"TransferViewController" bundle:nil];
//        [[AppDelegate sharedAppDelegate].naviGationController pushViewController:tvc animated:YES];
//        [tvc release];
//        [self hideSlideMenu];
    }
    
}
// Method to open Admin Profile Page.
-(void)openAdminProfilePage
{
    if ([AppDelegate sharedAppDelegate].classType==ADMIN_PROFILE_PAGE) {
        [self hideSlideMenu];
    }
    else{
        selectedPageType=ADMIN_PROFILE_PAGE;
        [self getAdminLoadLimit];
    }
}

-(void)transferPageRequest
{
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    switch (transfer_request)
    {
        case transfer_list:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=ViewTransferDetail_Request;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deBABussinessAccAcctId=&deProductid=%@&deTCIVRNOOFTRANSACTIONS=&deTCIVRLASTTRANSACTION=&deBAOriginSource=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,checkISNullStrings(BusinessPageObject.BusinessName)?@"":BusinessPageObject.BusinessName] ServiceName:svcBAViewTransferDetail];
        }
            break;
        case Bank_list:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=GetExternal_Bank_list;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deBABusinessAccAcctId=%@&deBABussinessAccountNum=%@",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,checkISNullStrings(BusinessPageObject.ACCTID)?@"":BusinessPageObject.ACCTID,checkISNullStrings(BusinessPageObject.BusinessName)?@"":BusinessPageObject.BusinessName] ServiceName:svcBAExternalBankList];
        }

            break;
            
        default:
            break;
    }
    
    [DataReq release];
}

-(void)requestForAdminList
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    

    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    [SystemConfiguration sharedSystemConfig].dbbServiceName=GEt_Admin_List_Request;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
   [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deANAClientID=%@&deANAuserStatus=&deANAInternalId=6&deANAuserid=&deANASearchInternalId=&deANAUserName=&deANAUserSurName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.OwningPartner,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcSearchUser];
    
    [DataReq release];

}


-(void)getBussinessRequest
{

    [[AppDelegate sharedAppDelegate] addloadingView];
    analysisRequest = EmployeeBusinessExpense;
    
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName = getBusiness_Expense;
    
    NSString *url = [NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deBusinessExpBusinessId=%@&deBusinessExpBusinessName=&deBusinessExpReportFrom=%@&deBusinessExpReportUpto=%@&deBusinessExpSummarizedByPeriod=D&deBusinessExpCustomDuration=&deBusinessExpCustomPeriod=&deBusinessExpOrderBy=&deBusinessExpGroupBy=&deIVRSource=MobileCoreMoney&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.BusinessName,dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_First))),dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_Lats)))];
    
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcBusinessExpense];
    [Datareq release];
}


-(void)getEmployeeExpenseRequest
{
    analysisRequest=Employee;
    [[AppDelegate sharedAppDelegate] addloadingView];
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    selectedPageType=EXP_EMPLOYEE_PAGE;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getEmployee_Expense;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deFromDate_EC=%@&deToDate_EC=%@&deBSProductId_EC=%@&deFlag_EC=SC&deChannelID_EC=&DE_EmployeeID_MS=&deMerchantCategory_EC=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_First))),dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_Lats))),BusinessPageObject.BusinessName,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcCardSpendReportAPI];
    [Datareq release];
}


-(void)getExpenseCategoryRequest
{

    [[AppDelegate sharedAppDelegate] addloadingView];
    analysisRequest=EmployeeExpenseCategor;
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getExpenseCategory_Expense;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    
    ExpenseCategoryData *objExpenseCategoryData = [arrCategoryList objectAtIndex:0];
    //01/01/2013
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deFromDate_EC=%@&deToDate_EC=%@&deBSProductId_EC=%@&deChannelID_EC=&deExpCatID1_EC=%d&deExpSubCatID1_EC=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_First))),dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_Lats))),BusinessPageObject.BusinessName,objExpenseCategoryData.CATEGORY_TYPE,[SystemConfiguration sharedSystemConfig].deIVRSource];
    

    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcGenerateReport_ExpenseCategoryAPI];
    [Datareq release];
}

-(void)getEmployeeByExpenseAnalysisRequest
{

    [[AppDelegate sharedAppDelegate] addloadingView];
    analysisRequest=EmployeeByExpense;
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    ExpenseCategoryData *objExpenseCategoryData = [arrCategoryList objectAtIndex:0];
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getEmployeeByExpenceAnalysisReport;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
   NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deEmpByExpense_FromDate=%@&deEmpByExpense_ToDate=%@&deEmpByExpense_ProductID=%@&deEmpByExpense_ChannelID=&deEmpByExpense_ExpenseCategory=%d&deEmpByExpense_ExpenseType=&deEmpByExpense_EmployeeId=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_First))),dateForAnalysis(getStringFromDate(returnDate([NSDate date],CurrentMonth_Lats))),BusinessPageObject.BusinessName,objExpenseCategoryData.CATEGORY_TYPE,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcEmployeeByExpenseCategoryAPI];
    [Datareq release];
}


-(void)getEmployeeListRequest
{
     analysisRequest=EmployeeList_Request;
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getEmployeeList;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deUserid=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=&deProductID=%@&deClientid=%@",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource,BusinessPageObject.BusinessName,BusinessPageObject.OwningPartner];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcGetEmployees];
    [Datareq release];
    
}


-(void)GetExpenseCategory
{
     analysisRequest=Exp_Cate_List;
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=GetEXpenseCategory;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&desvcBusinessAccountID=%@&desvcExpenseCategoryType=%@&deSetFlagValue_BankAct=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.BusinessName,@"",[SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcViewExpenseCategory];
    
    [DataReq release];
    
}

-(void)getBusinessList
{
    analysisRequest=exp_Business_List;
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getBusiness_List;
    
    // We have to change this value deSpendProductFlag=5
    
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deSpendProductFlag=5&dePPProductParent=%@&dePPClientList=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcGetSpendProducts];
    
    [DataReq release];
}

-(void)getAlertCount
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;

    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=ALERT_COUNT_REQUEST;
    
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPAdminPortalClientID=&deAlertUserID=%@&deAlertDirection=2&deAlertType=&deAlertDate=&deAlertActionDate=&deAlertStatus=NEW&deRFCount=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:SvcALViewAlertMsgCountAction];

    [DataReq release];

}

-(void)getAdminsProfile
{
    selfprofile=Self_Profile;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getAdminProfile_Request;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dePPAdminPortalFilterID=1&dePPAdminPortalUserID=%@&dePPAdminPortalIPAddress=&dePPAdminPortalClientID=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcGetIPAddrMatchIPAddrAndCheckDay];
    [Datareq release];
    
}

-(void)getAdminLoadLimit
{
    selfprofile=get_load_LImit;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getAdmin_load_par_req;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deLoadParameter_Acctid=%@&deLoadParameter_Type=User&deValueOFDay=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcviewloadparameter];
    [Datareq release];
    
}

// Method to open Admins Page.
-(void)openAdminsPage
{
    if ([AppDelegate sharedAppDelegate].classType==ADMINS_PAGE)
    {
        
        [self hideSlideMenu];
    }
    else{
        // Code to open Admins Page.
        if ([AppDelegate sharedAppDelegate].ArrayAdmin !=nil) {
            [[AppDelegate sharedAppDelegate].ArrayAdmin removeAllObjects];
            [[AppDelegate sharedAppDelegate].ArrayAdmin release];
            [AppDelegate sharedAppDelegate].ArrayAdmin=nil;
        }
        selectedPageType= ADMINS_PAGE;
        [self requestForAdminList];
    }
}
// Method to open Create New Admin Page.
-(void)openCreateNewAdminPage
{
    if ([AppDelegate sharedAppDelegate].classType==ADMIN_CREATE_NEW_PAGE) {
        [self hideSlideMenu];
    }
    else{
        // Code to open Create New Admin Page.
        [self hideSlideMenu];
    }
}
// Method to open Admin Alerts Page.
-(void)openAdminAlertsPage
{
    if ([AppDelegate sharedAppDelegate].classType==ADMIN_ALERTS_PAGE) {
        [self hideSlideMenu];
    }
    else{
        // Code to open Admin Alerts Page.
        
        selectedPageType = ADMIN_ALERTS_PAGE;
        [self getAlertCount];
    }
    
}
// Method to open Admin Category Management Page.
-(void)openAdminCategoryManagementPage
{
    if ([AppDelegate sharedAppDelegate].classType==ADMINT_CATEGORY_MANAGEMENT_PAGE) {
        [self hideSlideMenu];
    }
    else{
        // Code to open Admin Category Management Page.
        [self hideSlideMenu];
    }
}
// Method to open Expense Analysis Page.
-(void)openExpenseAnalysisPage
{
    if ([AppDelegate sharedAppDelegate].classType==EXPENCE_ANALYSIS_PAGE)
    {
        [self hideSlideMenu];
    }
    else{
       
        ExpenseAnalysisViewController *alvc = [[ExpenseAnalysisViewController alloc] initWithNibName:@"ExpenseAnalysisViewController" bundle:nil];
        
        [[AppDelegate sharedAppDelegate].naviGationController pushViewController:alvc animated:YES];
        [alvc release];

        [self hideSlideMenu];
    }
}
// Method to open Expense Employee Page.
-(void)openExpenseEmployeePage
{
    if ([AppDelegate sharedAppDelegate].classType==EXP_EMPLOYEE_PAGE) {
        [self hideSlideMenu];
    }
    else{
       [self getBusinessList];
    }
}
// Method to open Employee by expense Page.
-(void)openEmployeeByExpensePage
{
    if ([AppDelegate sharedAppDelegate].classType==EXP_EMP_BY_EXPENSE_PAGE) {
        [self hideSlideMenu];
    }
    else{
        
        [self getBusinessList];
    }
}
// Method to open business expense Page.
-(void)openBusinessExpensePage
{
    if ([AppDelegate sharedAppDelegate].classType==EXP_BUSINESS_EXP_PAGE) {
        [self hideSlideMenu];
    }
    else{
        
        [self getBusinessList];
    }
}
// Method to open expense categroies Page.
-(void)openExpenseCategroiesPage
{
    if ([AppDelegate sharedAppDelegate].classType==EXP_EXPENSE_CAT_PAGE) {
        [self hideSlideMenu];
    }
    else{
        
      [self getBusinessList];
    }
}

// Method to open Card List Details Page.
-(void)openCardListDetailsPage
{
    if ([AppDelegate sharedAppDelegate].classType==CARD_LIST_DETAIL_PAGE) {
        [self hideSlideMenu];
    }
    else{
        // Code for open Expense AnalysisPage.
        [self hideSlideMenu];
    }
}
// Method to open Logout Application.
-(void)openLogout
{
    [AppDelegate sharedAppDelegate].isUserLogin = NO;
    [self hideSlideMenu];
    [[AppDelegate sharedAppDelegate] addLoginPage];
}
// Method to open Pages.
-(void)openPages:(int)index
{
    switch (index) {
        case HOME_PAGE:
        {
            [self openHomePage];
        }
            break;
        case BUSINESS_SUMMARY_PAGE:
        {
            [self openBusinessSummaryPage];
        }
            break;
        case CARD_CREATE_NEW_PAGE:
        {
            [self openCreateCardPage];
        }
            break;
        case CARD_LIST_PAGE:
        {
            [self openCardlistPage];
        }
            break;
        case CARDS_TRANSACTION_PAGE:
        {
            [self openTransactionsPage];
        }
            break;
        case CARDS_FUND_CARD_PAGE:
        {
            [self openFundCardPage];
        }
            break;
        case CARDS_AUTOMATIC_FUNDING_PAGE:
        {
            [self openAutomaticFundingPage];
        }
            break;
        case CARDS_EXPENSE_RULE_PAGE:
        {
            [self openExpenseRulesPage];
        }
            break;
        case CARDS_PROFILE_PAGE:
        {
            [self openProfilePage];
        }
            break;
        case TRANSFER_PAGE:
        {
            [self openTransfersPage];
        }
            break;
        case ADMIN_PROFILE_PAGE:
        {
            [self openAdminProfilePage];
        }
            break;
        case ADMINS_PAGE:
        {
            [self openAdminsPage];
        }
            break;
        case ADMIN_CREATE_NEW_PAGE:
        {
            [self openCreateNewAdminPage];
        }
            break;
        case ADMIN_ALERTS_PAGE:
        {
            [self openAdminAlertsPage];
        }
            break;
        case ADMINT_CATEGORY_MANAGEMENT_PAGE:
        {
            [self openAdminCategoryManagementPage];
        }
            break;
        case EXPENCE_ANALYSIS_PAGE:
        {
            [self openExpenseAnalysisPage];
        }
            break;
        case EXP_EMPLOYEE_PAGE:
        {
            selectedPageType=EXP_EMPLOYEE_PAGE;
            [self openExpenseEmployeePage];
        }
            break;
        case EXP_EMP_BY_EXPENSE_PAGE:
        {
            selectedPageType=EXP_EMP_BY_EXPENSE_PAGE;
            [self openEmployeeByExpensePage];
        }
            break;
        case EXP_EXPENSE_CAT_PAGE:
        {
            selectedPageType=EXP_EXPENSE_CAT_PAGE;
            [self openExpenseCategroiesPage];
        }
            break;
        case EXP_BUSINESS_EXP_PAGE:
        {   selectedPageType=EXP_BUSINESS_EXP_PAGE;
            [self openBusinessExpensePage];
        }
            break;
        case CARD_LIST_DETAIL_PAGE:
        {
            [self openCardListDetailsPage];
        }
            break;
          case LOGOUT_PAGE:
        {
            [self openLogout];
        }
            break;
        default:
            break;
    }
}
#pragma -mark UITableView Methods
// Method return number of sections in table.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
// Method return cell height in table.
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return getHeight(44);
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrSlideMenuData count];
}
// Method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"Cell";
	
    SlideMenuCell *cell = (SlideMenuCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        cell = [[[SlideMenuCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    cell.imgColorView.hidden=YES;
    cell.lblValue.hidden=YES;
    
    SlideMenuClass *menu;
    menu =( SlideMenuClass *)[arrSlideMenuData objectAtIndex:indexPath.row];
    
    if ([menu.strMenuTitle isEqualToString:@"Administration"])
    {
    }
    
    cell.imgMenu.image=[UIImage imageNamed:GetImageName(menu.strImage)];
    
    if (menu.indexType == HEADERS)
    {
        if (menu.pageName == LOGOUT_PAGE) {
            cell.lblTitle.font=IS_IPAD?[UIFont boldSystemFontOfSize:24]:[UIFont boldSystemFontOfSize:16];
        }
        else{
            cell.lblTitle.font=IS_IPAD?[UIFont systemFontOfSize:24]:[UIFont systemFontOfSize:18];
        }
        cell.lblTitle.textColor = menu.isEnable==NO?[UIColor grayColor]:menu.isShow ?[UIColor orangeColor]:UI_COLOR_TEXT_LIGHT;
        cell.imgMenu.frame=CGRectMake(SIZE_PADDING_DEFAULT, 7, getWidth(30), getHeight(30));
        cell.lblTitle.frame=CGRectMake(CGRectGetMaxX(cell.imgMenu.frame)+10, 7, getWidth(170), getHeight(30));
        
//        if (menu.isShow) {
//           [tblMenu scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop  animated:animationStyle];
//        }
    }
    else{
        cell.lblTitle.font=IS_IPAD?[UIFont systemFontOfSize:24]:[UIFont systemFontOfSize:18];
        cell.lblTitle.textColor = menu.isEnable==NO ? [UIColor grayColor] : UI_COLOR_TEXT_LIGHT;
        
        cell.imgMenu.frame=CGRectMake(SIZE_PADDING_DEFAULT+30, 7, getWidth(30), getHeight(30));
        
        cell.lblTitle.frame=CGRectMake(CGRectGetMaxX(cell.imgMenu.frame)+10, 7, getWidth(200), getHeight(30));
    }
    
    // hide colors for now
    cell.imgColorView.hidden=YES;
    // hide colors for now

//    cell.imgMenu.backgroundColor=[UIColor whiteColor];
    cell.lblTitle.text=menu.strMenuTitle;

    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    cell.backgroundColor=[UIColor clearColor];
    return cell;
}
// Method called when the table cell is selected.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    SlideMenuClass *menu;
    
    menu =(SlideMenuClass *)[arrSlideMenuData objectAtIndex:indexPath.row];
    NSString *strname = @"";
    
    if (menu.isEnable==NO) {
        return;
    }
    
    for (int i=0; i <[arrSlideMenuData count]; i++)
    {
        SlideMenuClass * obj = [arrSlideMenuData objectAtIndex:i];
        if (obj.isShow==YES) {
            strname = obj.strMenuTitle;
        }
    }
    if (![menu.strMenuTitle isEqualToString:strname]) {
        strname = @" ";
    }
    if ([menu.strMenuTitle isEqualToString:languageSelectedStringForKey(@"Cards")])
    {
        if (menu.isShow==YES)
        {
            isFirstTime=YES;
            menu.isShow=YES;
            [self fillMenuWithIndex:SLIDE_DEFAULT_CONTENT];
        }
        else
        {
            isFirstTime=NO;
            [self fillMenuWithIndex:SLIDE_CARDS];
        }
    }
    else if ([menu.strMenuTitle isEqualToString:languageSelectedStringForKey(@"Administration")])
    {
        // If index value is 129 based on Manage Admins Access then user can able to click on
        // Administration cell
        
        if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS)
        {
            if (menu.isShow==YES)
            {
                isFirstTime=YES;
                menu.isShow=YES;
                [self fillMenuWithIndex:SLIDE_DEFAULT_CONTENT];
                
            }
            else
            {
                isFirstTime=NO;
                [self fillMenuWithIndex:SLIDE_ADMINISTRATION];
            }
        }
    }else if ([menu.strMenuTitle isEqualToString:languageSelectedStringForKey(@"Expense Analysis")])
    {
        // If Index value, based on Report Access is 105, then user can click on
        // expense analysis cell else it will not be clickable
        
        if ([AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS)
        {
            if (menu.isShow==YES)
            {
                isFirstTime=YES;
                menu.isShow=YES;
                [self fillMenuWithIndex:SLIDE_DEFAULT_CONTENT];
                
            }
            else
            {
                isFirstTime=NO;
                [self fillMenuWithIndex:SLIDE_EXPENSE_ANALYSIS];
            }
        }
      
    }else if ([menu.strMenuTitle isEqualToString:languageSelectedStringForKey(@"Transfers")])
    {
        [self openPages:TRANSFER_PAGE];
    }
    else{
        isFirstTime=YES;
        menu.isShow=NO;
        [self openPages:menu.pageName];
    }    
}

-(void)dealloc
{
    if ([arrSlideMenuData count]>0) {
        [arrSlideMenuData removeAllObjects];
        [arrSlideMenuData release];
        arrSlideMenuData=nil;
    }
    if (menuView!=nil) {
        [menuView release];
        menuView=nil;
    }
    if (tblMenu!=nil) {
        [tblMenu release];
        tblMenu=nil;
    }
    [super dealloc];
}
@end
