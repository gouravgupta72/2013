//
//  MerchantCategoryClass.m
//  CoreMoney

#import "MerchantCategoryClass.h"

@implementation MerchantCategoryClass
@synthesize strTitle,strsubTitle,isEnabled,dailyLimit,monthlyLimit,tagValue;
@synthesize MerchantCategoryCodePlan,Default_Selection,SKey,MCCDescription,DefaultDescription,SpendLimit_Auto,SpendLimit_Auto_Month,  MCCPlanDescription;

-(void)dealloc
{
    self.MerchantCategoryCodePlan=nil;
    self.Default_Selection=nil;
    self.SKey=nil;
    self.MCCDescription=nil;
    self.DefaultDescription=nil;
    self.SpendLimit_Auto=nil;
    self.SpendLimit_Auto_Month=nil;
    self.MCCPlanDescription=nil;
    [super dealloc];
}
@end
