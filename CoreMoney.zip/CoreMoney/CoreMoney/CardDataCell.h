//
//  CardDataCell.h


// Class to design Card Data Cell.

#import <UIKit/UIKit.h>

@interface CardDataCell : UITableViewCell
{
    UILabel *lblTitleName,*lblCardNumber,*lblStatus,*lblAmount, *lblEmployeeId;
    UIButton *btnState,*btnView;
    UIImageView *imgArrow;
    UIImageView *imgBackGround;
    id delegate;
    CGFloat fltImageHeight;
}
@property(nonatomic, assign)id delegate;
@property CGFloat fltImageHeight;

@property(nonatomic, retain) UILabel *lblTitleName,*lblCardNumber,*lblStatus,*lblAmount, *lblEmployeeId;
@property(nonatomic, retain) UIButton *btnState,*btnView;
@property (nonatomic,retain) UIImageView *imgArrow;
@property (nonatomic,retain) UIImageView *imgBackGround;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del imageHeight:(CGFloat)imageHeight;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier Delegate:(id)del;
-(void)openStatusView:(int)index;
@end
