//
//  ExpenseCategory.m
//  CoreMoney
//


#import "ExpenseCategory.h"

@implementation ExpenseCategory
@synthesize expCatDesc,expense;

-(void) dealloc
{
    self.expCatDesc = nil;
    [super dealloc];
}

@end
