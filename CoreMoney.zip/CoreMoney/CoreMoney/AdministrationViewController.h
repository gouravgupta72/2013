//
//  AdministrationViewController.h
//  CoreMoney


#import <UIKit/UIKit.h>
#import "DataParsingClass.h"
#import "adminLoadLimitDataClass.h"

@interface AdministrationViewController : SwipeViewController<DataParsingDelegate>
{
    NSMutableArray *cellArray;
    int requestID;
adminLoadLimitDataClass *adminLoadObj;
}
@property (retain, nonatomic) IBOutlet UIView *bgView;

@end
