//
//  TransferDetailDataClass.m
//  CoreMoney


#import "TransferDetailDataClass.h"

@implementation TransferDetailDataClass
@synthesize  AddedOnDate, BA_ACCT_ID, BankAccountNumber, Bank_Name, CreditDebitIndicator, DDHTranId ,FundAvailableDate, RequestId, Source, Status_Desc, UserName, Status, TransactionAmount;

-(void)dealloc
{
    self.AddedOnDate=nil;
    self.BA_ACCT_ID=nil;
    self.BankAccountNumber=nil;
    self.Bank_Name=nil;
    self.CreditDebitIndicator=nil;
    self.DDHTranId =nil;
    self.FundAvailableDate=nil;
    self.RequestId=nil;
    self.Source=nil;
    self.Status_Desc=nil;
    self.UserName=nil;
    [super dealloc];
}
@end
