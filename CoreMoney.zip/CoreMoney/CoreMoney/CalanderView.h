//
//  CalanderView.h



#import <UIKit/UIKit.h>
#import "KLCalendarView.h"
#import "CheckmarkTile.h"
#import <QuartzCore/QuartzCore.h>

@interface CalanderView : UIView <KLCalendarViewDelegate>
{
    KLCalendarView *calendarView;
    KLTile *currentTile;
    KLTile *tile;
    id delegate;
    UIView *viewBG;
}
- (id)initWithCalanderFrame:(CGRect)frame Delegate:(id)del backGroundColor:(UIColor *)bgColor;
-(void) calanderCancelDelegate;
-(void)PickDate: (id)sender;
- (id)initWithCalanderFrame:(CGRect)frame Delegate:(id)del selectDate:(NSDate *) date;
- (id)initWithCalanderFrame:(CGRect)frame Delegate:(id)del backGroundColor:(UIColor *)bgColor date:(NSString *) selectDate;
@end
