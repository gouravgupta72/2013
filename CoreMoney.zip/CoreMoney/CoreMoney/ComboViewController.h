//
//  ComboViewController.h
//  CoreMoney
//

#import <UIKit/UIKit.h>
#import "secretQustionDataClass.h"
#import "ExternalBankDataClass.h"
#import "employeeDataClass.h"
@interface ComboViewController : UIView <UITableViewDelegate,UITableViewDataSource>
{
    UITableView *tblCombo;
    NSMutableArray *data;
    UILabel *lblDefault;
    id delegate;
    BOOL isSelectQuetion,isState;
    
    int comboType, comboBoxDesignClass;
}
@property(nonatomic,retain) NSMutableArray *data;
@property(nonatomic,retain) UILabel *lblDefault;
@property (nonatomic,retain) id delegate;
@property int comboType;
-(id)initWithFrame:(CGRect)frame records:(NSMutableArray *)recordsArray callingClassType:(int)classType ;
-(void) selectQuetion:(id) que ;
@end
