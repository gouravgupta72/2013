//
//  businessListDataClass.h
//  CoreMoney


#import <Foundation/Foundation.h>

@interface businessListDataClass : NSObject
{
    NSString *LUTCODE, *LUTDESCRIPTION, *PRODUCT_PARENT;
}
@property (nonatomic,retain)NSString *LUTCODE, *LUTDESCRIPTION, *PRODUCT_PARENT;
@end
