//
//  ForgetUserIDViewController.m

// Class used for create forgot user id view

#import "ForgetUserIDViewController.h"
#import "PopUpView.h"
#import "ComboViewController.h"

@interface ForgetUserIDViewController ()
- (IBAction)clickeDobBtn:(id)sender;
- (IBAction)clickedSecreteBtn:(id)sender;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil ForgotPage:(forgotPage) page;
-(void) changeTextIntoselectLang;
-(void)getRequest;
-(void)getResponce:(id)jsonData;
-(void) openBack;
-(void)openDone;
-(void)removeChangeStatusView;
-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index;
-(void)PickDate: (id)sender;
-(void) selectQuetion:(id) que;
-(void) calanderCancelDelegate;
-(void) removeCalanderView;
-(void) removeComboView;
-(BOOL)checkEmptyTextField;
-(void) setOfset;
- (IBAction)cleckedForgotUserBtn:(id)sender;
- (IBAction)SubmitButtonClicked:(id)sender;
//-(void) setNavigationScaling:(NSNotification *)info;
@end

@implementation ForgetUserIDViewController
@synthesize ValidUserId,SecretQuestionArr;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil ForgotPage:(forgotPage) page
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        forgotPageType = page;
        switch (page) {
            case FORGOT_PWD_PAGE:
            {
                addNavigationBar(languageSelectedStringForKey(FORGOT_PASSWORD) , NAV_LEFT_BACK, NAV_RIGHT_NONE, self);
                self.viewCover.hidden=YES;
                self.viewCoverAbove.hidden=YES;
            }
                break;
                
            case FORGOT_USER_PAGE:
            {
                addNavigationBar(languageSelectedStringForKey(FORGOT_USER_ID), NAV_LEFT_BACK, NAV_RIGHT_NONE, self);
                self.viewCover.hidden=YES;
                self.viewCoverAbove.hidden=YES;
            }
                break;
                
            case REGISTER_DEVICE_PAGE:
            {
                addNavigationBar(languageSelectedStringForKey(REGISTER_DEVICE), NAV_LEFT_BACK, NAV_RIGHT_NONE, self);
                self.viewCover.hidden=NO;
                self.viewCoverAbove.hidden=NO;
            }
                break;
            default:
                break;
        }
        
    }
    return self;
}

// change word in to select language
-(void) changeTextIntoselectLang
{
    self.lblBankAc.text = languageSelectedStringForKey(@"Bank A/C");
    self.lblSecretQue.text = languageSelectedStringForKey(@"Secret Question");
    self.lblSecretAnsw.text = languageSelectedStringForKey(@"Secret Answer");
    self.lblDob.text = languageSelectedStringForKey(@"Date of Birth");
    self.lblEmail.text  = languageSelectedStringForKey(@"Email");
    self.txtBankAc.placeholder = languageSelectedStringForKey(@"Bank Account Number");
    self.txtSecretAnsw.placeholder = languageSelectedStringForKey(@"Secret Answer");
    self.txtEmail.placeholder = languageSelectedStringForKey(@"Email");
    self.lblTxtSecretQue.text = languageSelectedStringForKey(@"Secret Question");
    self.lblTxtDOB.text = languageSelectedStringForKey(@"Date of Birth");
    [self.btnSubmit setTitle:languageSelectedStringForKey(@"Submit") forState:UIControlStateNormal];
    
    if ([AppDelegate sharedAppDelegate].isSpanish)
    {
        CGRect Frame;
        Frame=self.lblRetrieveMsg.frame;
        self.lblRetrieveMsg.frame=CGRectMake(Frame.origin.x, Frame.origin.y, 197, Frame.size.height);
    }
}

- (void)viewDidLoad
{
    //self.view.backgroundColor = [UIColor blackColor];
    [self changeTextIntoselectLang];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void) viewWillAppear:(BOOL)animated{
//    NavigationBarStyle();
    [self.navigationController setNavigationBarHidden:NO];
    
        
    if(forgotPageType == FORGOT_USER_PAGE)
    {
    self.lblRetrieveMsg.text =languageSelectedStringForKey(@"Retrieve User id");
    self.viewCover.hidden=YES;
    self.viewCoverAbove.hidden=YES;
    ReqId=GetSEcurity_Question;
   // [self getRequest];
    }
    else if(forgotPageType == FORGOT_PWD_PAGE)
    {
        self.lblRetrieveMsg.text = languageSelectedStringForKey(@"Retrieve Password");
        self.viewCover.hidden=YES;
        self.viewCoverAbove.hidden=YES;
        ReqId=GetSEcurity_Question;
      //  [self getRequest];
    }else
    {
        self.lblRetrieveMsg.text = languageSelectedStringForKey(@"Register Device");
        ReqId=GetSEcurity_Question;
        self.viewCover.hidden=NO;
        self.viewCoverAbove.hidden=NO;
        
        self.btnSubmit.frame=CGRectMake(217,IS_IPAD?IS_IOS7?215:220:IS_IOS7?215:200, 90, 35);
    
      //  [self getRequest];
    }
    
    
     self.bgView.frame=CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, self.bgView.frame.size.width,IS_IPAD?IS_IOS7?self.bgView.frame.size.height+20:self.bgView.frame.size.height+20:IS_IOS7?self.bgView.frame.size.height+60:self.bgView.frame.size.height);
    
    self.pageScroll.frame=CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?-40:0, self.pageScroll.frame.size.width,IS_IPAD?IS_IOS7?self.pageScroll.frame.size.height+20:self.pageScroll.frame.size.height+20:IS_IOS7?self.pageScroll.frame.size.height+60:self.pageScroll.frame.size.height);
//    self.viewCover.frame=CGRectMake(0, IS_IOS7?170:170, self.viewCover.frame.size.width,self.viewCover.frame.size.height);
    
}

//-(void) setNavigationScaling:(NSNotification *)info
//{
//    self.navigationController.navigationBar.transform = CGAffineTransformMakeScale([UIScreen mainScreen].applicationFrame.size.width / 320.0f, [UIScreen mainScreen].applicationFrame.size.height / 480.0f);
//    self.navigationController.navigationBar.frame = CGRectMake(0, 20, [AppDelegate sharedAppDelegate].screenWidth, IS_IPAD?92:44);
//}
-(void)getRequest
{
    
    DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
    dataParsing.Datadelegate=self;
    
    switch (ReqId) {
        case GetSEcurity_Question:
        {
            [[AppDelegate sharedAppDelegate] addloadingView];
            [SystemConfiguration sharedSystemConfig].dbbServiceName=CardLookUp_Request;
            
            [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=1&dbbServiceName=%@&deCIALutID=CMSecQuestion",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName] ServiceName:svcCCardLookUp];

        }
            break;
            case Forget_user_ID_req:
        {
            if (![self checkEmptyTextField])
            {
                [[AppDelegate sharedAppDelegate] addloadingView];
                [SystemConfiguration sharedSystemConfig].dbbServiceName=Check_Security_Que;
                [SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct=@"1";
                [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=%@&dbbServiceName=%@&deANAuserid=%@&deANASecQuestion=%@&deANASecAnswer=%@&deSetFlagValue_BankAct=%@&deTCIVRValidateInfoDOB=%@&deBAEmailID=%@&deIVRSource=%@&deIVRIpAddress=%@&deIVRCallerId=%@&deIVRCalledId=%@&deIVRRequestTime=%@&deIVRSessionID=%@&deDBBServiceApiLevel=%@&deDBBServiceAppID=%@",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbSystemSingleSignon,[SystemConfiguration sharedSystemConfig].dbbServiceName, @"",[NSString stringWithFormat:@"%d",SelectedQuestionIndex] ,self.txtSecretAnsw.text,[SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct,[self.lblTxtDOB.text stringByReplacingOccurrencesOfString:@"-" withString:@""],self.txtEmail.text,[SystemConfiguration sharedSystemConfig].deIVRSource,[SystemConfiguration sharedSystemConfig].deIVRIpAddress,[SystemConfiguration sharedSystemConfig].deIVRCallerId,[SystemConfiguration sharedSystemConfig].deIVRCalledId,[SystemConfiguration sharedSystemConfig].deIVRRequestTime,[SystemConfiguration sharedSystemConfig].deIVRSessionID,[SystemConfiguration sharedSystemConfig].deDBBServiceApiLevel,[SystemConfiguration sharedSystemConfig].deDBBServiceAppID ]ServiceName:svcCheckSecretQuestion];
            };
            
        }
            break;
        case Forget_pwd_req:
        {
            if (![self checkEmptyTextField])
            {
            [[AppDelegate sharedAppDelegate] addloadingView];
            [SystemConfiguration sharedSystemConfig].dbbServiceName=Check_Security_Que;
            [SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct=@"0";
            [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=%@&dbbServiceName=%@&deANAuserid=%@&deANASecQuestion=%@&deANASecAnswer=%@&deSetFlagValue_BankAct=%@&deTCIVRValidateInfoDOB=%@&deBAEmailID=%@&deIVRSource=%@&deIVRIpAddress=%@&deIVRCallerId=%@&deIVRCalledId=%@&deIVRRequestTime=%@&deIVRSessionID=%@&deDBBServiceApiLevel=%@&deDBBServiceAppID=%@",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbSystemSingleSignon,[SystemConfiguration sharedSystemConfig].dbbServiceName, self.ValidUserId ,[NSString stringWithFormat:@"%d",SelectedQuestionIndex] ,self.txtSecretAnsw.text,[SystemConfiguration sharedSystemConfig].deSetFlagValue_BankAct,[self.lblTxtDOB.text stringByReplacingOccurrencesOfString:@"-" withString:@""],self.txtEmail.text,[SystemConfiguration sharedSystemConfig].deIVRSource,[SystemConfiguration sharedSystemConfig].deIVRIpAddress,[SystemConfiguration sharedSystemConfig].deIVRCallerId,[SystemConfiguration sharedSystemConfig].deIVRCalledId,[SystemConfiguration sharedSystemConfig].deIVRRequestTime,[SystemConfiguration sharedSystemConfig].deIVRSessionID,[SystemConfiguration sharedSystemConfig].deDBBServiceApiLevel,[SystemConfiguration sharedSystemConfig].deDBBServiceAppID ]ServiceName:svcCheckSecretQuestion];
            }
        }
            break;
        case Reg_Device_Req:
        {
                [[AppDelegate sharedAppDelegate] addLoginLoadingView];
                [SystemConfiguration sharedSystemConfig].dbbServiceName=RegisterDevice;
                [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            [SystemConfiguration sharedSystemConfig].dbbSystemSingleSignon=@"1";
            
            [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=%@&dbbServiceName=%@&deANAUserID=%@&deANASecQuestion=%@&deANASecAnswer=%@&deDeviceId=%@&deDeviceType=%@&deBADescription=&deBAAdminPortalVerficationCode=&deBAAdminPortalPreferredLanguage=&deIVRSource=%@&deIVRIpAddress=&deIVRCallerId=&deIVRCalledId=&deIVRRequestTime=&deIVRSessionID=&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbSystemSingleSignon,[SystemConfiguration sharedSystemConfig].dbbServiceName,[UserDetailClass sharedUser].strUserId,[NSString stringWithFormat:@"%d",SelectedQuestionIndex] ,self.txtSecretAnsw.text,[SystemConfiguration sharedSystemConfig].deDeviceId,@"iPhone",[SystemConfiguration sharedSystemConfig].deIVRSource
 ]ServiceName:svcDeviceRegisteration];
        }

            break;
        case HOME_PAGE_Req:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=Business_Search_Request;
            [SystemConfiguration sharedSystemConfig].deFlagShowDetails=@"1";
            [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPProductParent=&deBusinessName=&deCIASDDANumber=&deAADAccountNumber=&dePPCardStatus=&deCIASFirstName=&deCIASLastName=&deCIAAddressLine1=&deCIAAddressLine2=&deCIASCity=&deCIASState=&deCIASCountry=&deCIASZipCode=&deBSAcctId=&deFlagShowDetails=%@&deRequestBatchSize=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].deFlagShowDetails,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBusinessAccountSearch];

        }
            
            break;
            
        default:
            break;
    }
    
    [dataParsing release];
}
#pragma mark - Response Methods
// Delegate methods of request class to get response data
-(void)getResponce:(id)jsonData
{
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    switch (ReqId)
    {
        case GetSEcurity_Question:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    SecretQuestionArr=jsonData;
                }
            }
            
        }
            break;
            
            case Forget_pwd_req:
        {
                LoginResponceDataClass *loginDataobj=(LoginResponceDataClass *)jsonData;
                
                if (loginDataobj.Error_Code==0)
                {
                    showAlertWithOkButton(nil, loginDataobj.ErrorMsg, Forget_pwd_req, self);
                }else
                {
                     showAlertScreen(nil, loginDataobj.ErrorMsg);
                }
           
        
        }
            break;
        case Forget_user_ID_req:
        {
            LoginResponceDataClass *loginDataobj=(LoginResponceDataClass *)jsonData;
            
            if (loginDataobj.Error_Code==0)
            {
                showAlertWithOkButton(nil, loginDataobj.ErrorMsg, Forget_user_ID_req, self);
            }else
            {
                showAlertScreen(nil, loginDataobj.ErrorMsg);
            }

        }
            break;
            
            case Reg_Device_Req:
        {
            LoginResponceDataClass *loginDataobj=(LoginResponceDataClass *)jsonData;
            
            
            if (loginDataobj.Error_Code==1)
            {
                 showAlertWithOkButton(nil, loginDataobj.ErrorMsg, Reg_Device_Req, self);
                
            }else
            {
                showAlertScreen(nil, loginDataobj.ErrorMsg);
            }
        }
            break;
//        case HOME_PAGE_Req:
//        {
//                            
//            if (jsonData == 0) {
//                
//            }
//            else{
//                if (![AppDelegate sharedAppDelegate].arrBusinessData)
//                {
//                    [AppDelegate sharedAppDelegate].arrBusinessData=[[NSMutableArray alloc] init];
//                }
//                
//                [AppDelegate sharedAppDelegate].arrBusinessData=jsonData;
//                HomeViewController *homeView = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
//                
//                [self.navigationController pushViewController:homeView animated:YES];
//                [homeView release];
//            }
//
//                
//            
//        }
//            break;
        default:
            break;
    }
    
}

#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (forgotPageType==FORGOT_PWD_PAGE)
    {
        updateNewUserViewController *forgotUserid = [[updateNewUserViewController alloc] initWithNibName:@"updateNewUserViewController" bundle:nil];
        
        [self.navigationController pushViewController:forgotUserid animated:YES];
        [forgotUserid release];
        
    }else
    {
       [self.navigationController popViewControllerAnimated:YES];  
    }
       
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_lblBankAc release];
    [_lblSecretQue release];
    [_lblSecretAnsw release];
    [_lblDob release];
    [_lblEmail release];
    [_txtBankAc release];
    [_txtSecretAnsw release];
    [_txtEmail release];
    [_lblTxtSecretQue release];
    [_lblTxtDOB release];
    [_btnSecretQue release];
    [_btnDob release];
    [_pageScroll release];
    [_lblRetrieveMsg release];
    [_viewCover release];
//    [_viewCover release];
    [_btnSubmit release];
    [_viewCoverAbove release];
    [_bgView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setLblBankAc:nil];
    [self setLblSecretQue:nil];
    [self setLblSecretAnsw:nil];
    [self setLblDob:nil];
    [self setLblEmail:nil];
    [self setTxtBankAc:nil];
    [self setTxtSecretAnsw:nil];
    [self setTxtEmail:nil];
    [self setLblTxtSecretQue:nil];
    [self setLblTxtDOB:nil];
    [self setBtnSecretQue:nil];
    [self setBtnDob:nil];
    [self setPageScroll:nil];
    [self setLblRetrieveMsg:nil];
    [self setViewCover:nil];
//    [self setViewCover:nil];
    [self setBtnSubmit:nil];
    [self setViewCoverAbove:nil];
    SecretQuestionArr = nil;
//    if ([SecretQuestionArr count]!=0)
//    {
//        [SecretQuestionArr removeAllObjects];
//        SecretQuestionArr=nil;
//    }

    [self setBgView:nil];
    [super viewDidUnload];
}

// when tap on cancel bar button then call this method. that send to controll on previuos view
-(void) openBack
{
    [self performSelector:@selector(sendToPreviusView) withObject:nil afterDelay:0.1];
}

-(void) sendToPreviusView
{
    [self.navigationController popViewControllerAnimated:YES];
}
// check entered email and password length
-(void)openDone
{
    [self checkEmptyTextField];
   /* if (![self.txtFirstName.text length]>0)
    {
        showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(BLANK_FIELD));
        return;
    }
    
    if (![self.txtLastName.text length]>0){
        showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(BLANK_FIELD));
        return;
    }
    if (![self.txtEmail.text length]>0){
        if (![self.txtVarifyEmail.text length]>0){
            showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(BLANK_FIELD));
            return;
        }
    }
    if (![self.txtEmail.text isEqualToString:self.txtVarifyEmail.text ]){
        showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(VERIFY_EMAIL_ALERT));
        return;
    }
    if (![self.txtPassword.text isEqualToString:self.txtConfirmPassword.text ] || [self.txtConfirmPassword.text length]<5 ||[self.txtPassword.text length]<5 ){
        showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(@"INV_PWD_MESSAGE"));
        return;
    }
    
    BOOL checkMail=validateEmailString(self.txtEmail.text);
    [self.txtConfirmPassword resignFirstResponder];
    [self.txtEmail resignFirstResponder];
    [self.txtFirstName resignFirstResponder];
    [self.txtLastName resignFirstResponder];
    [self.txtPassword resignFirstResponder];
    [self.txtVarifyEmail resignFirstResponder];
    
    if (checkMail)
    {
        return;
    }else
    {
        showAlertScreen(languageSelectedStringForKey(EMAIL_TEXT),languageSelectedStringForKey(@"Valid_email_message"));
        emailValid = NO;
        
    }*/
    
    //    [self sendCreateAccountRequest];
}
// method use for remove question select view
-(void)removeChangeStatusView
{
    for (UIView *view in [[AppDelegate sharedAppDelegate].window subviews]) {
        if ([view isKindOfClass:[PopUpView class]]) {
            [view removeFromSuperview];
        }
        
    }
    
}

// delegate metohds for selecting question 
-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index
{
    self.lblTxtSecretQue.textColor = [UIColor blackColor];
    self.lblTxtSecretQue.text = languageSelectedStringForKey(question);
    [[NSUserDefaults standardUserDefaults] setInteger:index forKey:@"SelectedQuetionIndex"];
    for (UIView *view in [[AppDelegate sharedAppDelegate].window subviews]) {
        if ([view isKindOfClass:[PopUpView class]]) {
            [view removeFromSuperview];
        }
        
    }
    
}

// delegate method for pick date from calander view
-(void)PickDate: (id)sender
{
    NSString *dateStr = [NSString stringWithFormat:@"%@",sender];
    
   // [AppDelegate sharedAppDelegate].selectedDate = uploadDate;
    
    self.lblTxtDOB.text = dateStr;
    self.lblTxtDOB.textColor = [UIColor blackColor];
    if ([calanderView isDescendantOfView:self.view]) {
        [calanderView removeFromSuperview];
        calanderView = nil;
    }
    
}
-(void) selectQuetion:(id) que
{
    secretQustionDataClass *obj=(secretQustionDataClass *)que;
    SelectedQuestionIndex=[obj.indexNo intValue];
    self.lblTxtSecretQue.textColor = [UIColor blackColor];
    self.lblTxtSecretQue.text = obj.secretQuestion;
    [self removeComboView];
}
// Open secrete question view
- (IBAction)clickedSecreteBtn:(id)sender {
    
    [self setOfset];
    
    int selectedQue=[[NSUserDefaults standardUserDefaults]  integerForKey:@"SelectedQuetionIndex"];
    if (selectedQue < 0) {
        selectedQue = 0;
    }
//    PopUpView *csv = [[PopUpView alloc] initWithQuestionViewFram:CGRectMake(0, 0, [AppDelegate sharedAppDelegate].screenWidth, [AppDelegate sharedAppDelegate].screenHeight) Delegate:self SelectedQue:selectedQue];
//    [[AppDelegate sharedAppDelegate].window addSubview:csv];
   
    if (comboView == nil) {
        comboView = [[UIView alloc] initWithFrame:self.view.frame];
        comboView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:comboView];
        
        ComboViewController *comView = [[ComboViewController alloc] initWithFrame:CGRectMake(24,IS_IPAD?IS_IOS7?85:105:IS_IOS7?145:105, 270, 300) records:SecretQuestionArr callingClassType:selectQuestion];
        comView.delegate = self;
        [comboView addSubview:comView];
        
    }
    
}
-(void) calanderCancelDelegate
{
    [self removeCalanderView];
    
}
// Remove calander view
-(void) removeCalanderView{
    if (calanderView) {
        [calanderView removeFromSuperview];
        calanderView = nil;
    }
}
-(void) removeComboView{
    if (comboView ) {
        [comboView removeFromSuperview];
        comboView = nil;
    }
}
// touch methods
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    if(calanderView){
    [self removeCalanderView];
    }
    else if(comboView){
        [self removeComboView];
    }
    
}

// Open Calaneder for select date of birth
- (IBAction)clickeDobBtn:(id)sender {
    [self setOfset];
    
    if(calanderView == nil){
        calanderView = [[UIView alloc] initWithFrame:self.view.frame];
        calanderView.backgroundColor= [UIColor clearColor];
        [self.view addSubview:calanderView];
        
        CalanderView *calnderObj=[[CalanderView alloc]initWithCalanderFrame:CGRectMake(52, 85, 216, 315) Delegate:self backGroundColor:[UIColor whiteColor] date:self.lblTxtDOB.text];
        
        [calanderView addSubview:calnderObj];
        [calnderObj release];
           
        }
    else{
        [calanderView removeFromSuperview];
        calanderView = nil;
    }
}
// check text field
-(BOOL)checkEmptyTextField
{
   if ([self.lblTxtSecretQue.text isEqualToString:@"Secret question"]){
         showAlertScreen(@"Question", @"Please Select Question");
        return YES;
    }
    else if ([self.txtSecretAnsw.text length]==0) {
        [self.txtSecretAnsw becomeFirstResponder];
         showAlertScreen(@"Answer", @"Please Give answer");
        return YES;
    }
    else if ([self.lblTxtDOB.text isEqualToString:@"Date of Birth"]){
         showAlertScreen(@"Date", @"Please Choose date");
        return YES;
    }
    else if (isFutureDateWithFormat(self.lblTxtDOB.text, @"MM-dd-yyyy"))
    {
        showAlertScreen(@"Date", @"You cannot Choose future date");
        return YES;
    }
    else if ([self.txtEmail.text length]==0) {
        [self.txtEmail becomeFirstResponder];
         showAlertScreen(@"Email", @"Please enter email id");
        return YES;
    }
    else 
    {
        BOOL isMailValid = validateEmailField(self.txtEmail);
        if (isMailValid) {
            return NO;
        }
        else{
            showAlertScreen(@"Email", @"Please enter correct email id");
            return YES;
        }
    }
    
        
    return NO;
}

// set page in previouse position
-(void) setOfset{
   // [self.pageScroll setContentSize:CGSizeMake(320,480)];
//    self.pageScroll.contentOffset=CGPointMake(0, 0);
    
    [self.txtBankAc resignFirstResponder];
    
    [self.txtEmail resignFirstResponder];
    [self.txtSecretAnsw resignFirstResponder];
}

#pragma -mark UITextField Method

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isEqual:self.txtEmail] )
	{
		[self setOfset];
        //  [self logIn];
        
	}
	else if ([textField isEqual:self.txtBankAc])
	{
		[self.txtBankAc resignFirstResponder];
        
        
	}
       else
        {
            [self setOfset];
        }
    [self.pageScroll setContentSize:CGSizeMake(240,350)];
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if ([textField isEqual:self.txtBankAc]) {
        
      //  [self.pageScroll setContentOffset:CGPointMake(0, self.txtUserName.frame.origin.y-4) animated:YES];
    }
    if ([textField isEqual:self.txtEmail]) {
        
            self.pageScroll.contentOffset=CGPointMake(0, self.pageScroll.frame.origin.y+180);
        
    }
    [self.pageScroll setContentSize:CGSizeMake(320,600)];
    
    return YES;
}
- (IBAction)cleckedForgotUserBtn:(id)sender {
    
    ForgetUserIDViewController *forgotUserid = [[ForgetUserIDViewController alloc] initWithNibName:@"ForgetUserIDViewController" bundle:nil];
    [self.navigationController pushViewController:forgotUserid animated:YES];
}
- (IBAction)SubmitButtonClicked:(id)sender
{
    if (forgotPageType==FORGOT_USER_PAGE)
    {
         ReqId=Forget_user_ID_req;
    }else if(forgotPageType==FORGOT_PWD_PAGE)
    {
        ReqId=Forget_pwd_req;
    }else if (forgotPageType==REGISTER_DEVICE_PAGE)
    {
         ReqId=Reg_Device_Req;
    }
   
    [self getRequest];
}
@end
