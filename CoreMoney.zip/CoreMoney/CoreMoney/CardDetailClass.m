//
//  CardDetailClass.m
//  CoreMoney

// Class used for hold card detail data.

#import "CardDetailClass.h"

@implementation CardDetailClass
@synthesize  FLAG,isActiveButtonShow;

@synthesize CURRENTBALANCE, OFACScore, AVAILABLEBALANCE;

@synthesize AccountGeneratedStatus, AccountManualStatus, CARDSTATUS, ChangeAccessCodeCounter, DecisionFlag, ErrorCounter, GeneratedStatus, LOSTSTOLENALLOWEDCM, ManualCardStatus, NOOFPINATTEMPTS, StudentChoice, dePPAccountType;

@synthesize ACCOUNTNUMBER, ACQUISITIONSOURCE, ADDRESS1, ADDRESSLINE2, ADMIN_NUMBER, AGENTID, AlertEmailAddress, BSAcctID, BSAgentId, CARDEXPIRATIONDATE, CARDNUMBER, CITY ,CLIENTID, COUNTRY, CradType, CustomAccountID, CustomAccountIDLabel, DATEOFBIRTH, DDANumber, DispatchDate, EMAILID, EMAIL_ADDRESS2, FIRSTNAME, GOVERNMENTID, HOMEPHONENUMBER, HOME_FAX_NO, HPhoneCountryCode, HPhoneExtension, IDEXPIRATIONDATE, IDISSUECOUNTRY, IDISSUEDATE, IDISSUESTATE, IDNUMBER, LANGUAGE_INDICATOR, LASTNAME, LastBulkOFACCheckDate, LastLoginDateTime, LastPlasticIssued, LastPlasticShipped, MAIDEN_NAME, MIDDLENAME, MOBILE_PHONE_NO, NAME_ON_CARD, OFACInquiryDate, OFACSDNEntry1, OFACSDNEntry2, OFACSDNEntry3, OFACSDNEntry4, OFACSDNEntry5, OFFICE_PHONE, OtherIDDescription, POSTALCODE, PRODUCTID, PasswordPolicy, SECOND_LAST_NAME, SECURITY_ANSWER, SECURITY_QUESTION, SSN, STATE, STATUS_CARDACCOUNT, STOREID, SavingAccountNumber, StudentIDCardNumber, TERMSANDCONDITIONS, TITLE_NAME, USERFIELD1, USERFIELD2, USERFIELD3, USERFIELD4, USERFIELD5, UserId, UserStatus, WORK_FAX_NO, WPhoneCountryCode, WPhoneExtension, LastTransactionDate, LastTransfer;


-(void)dealloc
{
    self.ACCOUNTNUMBER=nil;
    self.ACQUISITIONSOURCE=nil;
    self.ADDRESS1=nil;
    self.ADDRESSLINE2=nil;
    self.ADMIN_NUMBER=nil;
    self.AGENTID=nil;
    self.AlertEmailAddress=nil;
    self.BSAcctID=nil;
    self.BSAgentId=nil;
    self.CARDEXPIRATIONDATE=nil;
    self.CARDNUMBER=nil;
    self.CITY=nil;
    self.CLIENTID=nil;
    self.COUNTRY=nil;
    self.CradType=nil;
    self.CustomAccountID=nil;
    self.CustomAccountIDLabel=nil;
    self.DATEOFBIRTH=nil;
    self.DDANumber=nil;
    self.DispatchDate=nil;
    self.EMAILID=nil;
    self.EMAIL_ADDRESS2=nil;
    self.FIRSTNAME=nil;
    self.GOVERNMENTID=nil;
    self.HOMEPHONENUMBER=nil;
    self.HOME_FAX_NO=nil;
    self.HPhoneCountryCode=nil;
    self.HPhoneExtension=nil;
    self.IDEXPIRATIONDATE=nil;
    self.IDISSUECOUNTRY=nil;
    self.IDISSUEDATE=nil;
    self.IDISSUESTATE=nil;
    self.IDNUMBER=nil;
    self.LANGUAGE_INDICATOR=nil;
    self.LASTNAME=nil;
    self.LastBulkOFACCheckDate=nil;
    self.LastLoginDateTime=nil;
    self.LastPlasticIssued=nil;
    self.LastPlasticShipped=nil;
    self.MAIDEN_NAME=nil;
    self.MIDDLENAME=nil;
    self.MOBILE_PHONE_NO=nil;
    self.NAME_ON_CARD=nil;
    self.OFACInquiryDate=nil;
    self.OFACSDNEntry1=nil;
    self.OFACSDNEntry2=nil;
    self.OFACSDNEntry3=nil;
    self.OFACSDNEntry4=nil;
    self.OFACSDNEntry5=nil;
    self.OFFICE_PHONE=nil;
    self.OtherIDDescription=nil;
    self.POSTALCODE=nil;
    self.PRODUCTID=nil;
    self.PasswordPolicy=nil;
    self.SECOND_LAST_NAME=nil;
    self.SECURITY_ANSWER=nil;
    self.SECURITY_QUESTION=nil;
    self.SSN=nil;
    self.STATE=nil;
   // self.STATUS_CARDACCOUNT=nil;
    self.STOREID=nil;
    self.SavingAccountNumber=nil;
    self.StudentIDCardNumber=nil;
    self.TERMSANDCONDITIONS=nil;
    self.TITLE_NAME=nil;
    self.USERFIELD1=nil;
    self.USERFIELD2=nil;
    self.USERFIELD3=nil;
    self.USERFIELD4=nil;
    self.USERFIELD5=nil;
    self.UserId=nil;
    self.UserStatus=nil;
    self.WORK_FAX_NO=nil;
    self.WPhoneCountryCode=nil;
    self.WPhoneExtension=nil;
    
    [super dealloc];
}
@end
