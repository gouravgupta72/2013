//
//  BusinessSummaryScrollView.m


#import "BusinessSummaryScrollView.h"

@implementation BusinessSummaryScrollView
@synthesize lblBusinessName,lblClientName;

- (id)initWithUserDetailFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor=[UIColor clearColor];
        
        lblBusinessName=createLabel(@"Business Name", CGRectMake(13, 10, 280, 40));
//        lblBusinessName.font=FONT_ARIAL_23;
        lblBusinessName.font = [UIFont boldSystemFontOfSize:23];
        lblBusinessName.textColor=Name_color_Code;
        lblBusinessName.textAlignment=NSTextAlignmentLeft;
        lblBusinessName.numberOfLines = 2;
        [self addSubview:lblBusinessName];
        [lblBusinessName release];
        
//        lblClientName=createLabel(@"Client Name", CGRectMake(34, 55, 280, 36));
//        lblClientName.font=FONT_ARIAL_16;
//        lblClientName.textColor=Name_color_Code;
//        lblClientName.textAlignment=NSTextAlignmentRight;
//        lblClientName.numberOfLines = 2;
//        [self addSubview:lblClientName];
//        [lblClientName release];
    }
    return self;
}

@end
