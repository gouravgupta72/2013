//
//  HomeCell.m


#import "HomeCell.h"

@implementation HomeCell
@synthesize lblName,cellImage,cellArrowImage,cellBgImage;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        int adjustment = 7;
        
        cellBgImage = [[UIImageView alloc] initWithFrame:CGRectMake(5, 7, 310,45)];
        cellBgImage.image=[UIImage imageNamed:GetImageName(@"img_btnTabBg_home")];
        [self addSubview:cellBgImage];
        [cellBgImage release];
        
        lblName=createLabel(@"", CGRectMake(50, adjustment, 200, self.frame.size.height));
        lblName.backgroundColor=[UIColor clearColor];
        lblName.font=[UIFont systemFontOfSize:18.f];
        lblName.textColor=[UIColor blackColor];
        // lblName.font=FONT_ARIAL_14;
        [self addSubview:lblName];
        
        [lblName release];
        
        cellImage=[[UIImageView alloc] initWithFrame:CGRectMake(10, 14, 25,30)];
        cellImage.image=[UIImage imageNamed:GetImageName(@"")];
        [self addSubview:cellImage];
        [cellImage release];
        
        cellArrowImage=[[UIImageView alloc] initWithFrame:CGRectMake(290, 21, 10, 15)];
        cellArrowImage.image=[UIImage imageNamed:GetImageName(@"img_arrow_home")];
        [self addSubview:cellArrowImage];
        [cellArrowImage release];

    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
