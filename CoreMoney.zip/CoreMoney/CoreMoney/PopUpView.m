//
//  ChangeStatusView.m

// Class to Design pop up view for - Select Language, Change Status, Security Questions

#import "PopUpView.h"
#import "PopUpClass.h"
#import "HomeCell.h"
#import "CalanderView.h"

@implementation PopUpView

// Static variables to used in designing the popup view.
static int popupCellHeight = 40; // Height of the cells default.
static int popCellWidth = 190; // Width of the cells.
static int popQueCellWidth = 240; // Height of the popup view questionary page.

// Method to fill questionary data.
-(void) fillquetiondata:(int)selectIndex
{
    arrStatusData = [[NSMutableArray alloc] init];
    PopUpClass *statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Que1");
    statusObj.isSelected=NO;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Que2");
    statusObj.isSelected=NO;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Que3");
    statusObj.isSelected=NO;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Que4");
    statusObj.isSelected=NO;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Que5");
    statusObj.isSelected=NO;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Que6");
    statusObj.isSelected=NO;
    [arrStatusData addObject:statusObj];
    [statusObj release];

    statusObj = [arrStatusData objectAtIndex:selectIndex];
    statusObj.isSelected=YES;
}
// Method to fill Card Status Data.
-(void)fillStatusData :(cardStatus)status
{
    arrStatusData = [[NSMutableArray alloc] init];
    switch (status)
    {
        case ACTIVE_CARD:
        {
            PopUpClass *statusObj = [[PopUpClass alloc] init];
                        
            statusObj.strTitle=languageSelectedStringForKey(@"Blocked");
            statusObj.StatusNo=BLOCKED_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Inactive");
            statusObj.StatusNo=Inactive_Card;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Lost");
            statusObj.StatusNo=Lost_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Stolen");
            statusObj.StatusNo=Stolen_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Closed");
            statusObj.StatusNo=Closed_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            

        }
            break;
            case BLOCKED_CARD:
        {
            PopUpClass *statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Active");
            statusObj.StatusNo=ACTIVE_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
                    
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Inactive");
            statusObj.StatusNo=Inactive_Card;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Lost");
            statusObj.StatusNo=Lost_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Stolen");
            statusObj.StatusNo=Stolen_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Closed");
            statusObj.StatusNo=Closed_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            

        }
            break;
        case Inactive_Card:
        {
            PopUpClass *statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Active");
            statusObj.StatusNo=ACTIVE_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Blocked");
            statusObj.StatusNo=BLOCKED_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
                      
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Lost");
            statusObj.StatusNo=Lost_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Stolen");
            statusObj.StatusNo=Stolen_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Closed");
            statusObj.StatusNo=Closed_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            

        }
            break;
        case Pending_CARD:
        {
            PopUpClass *statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Active");
            statusObj.StatusNo=ACTIVE_CARD;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
        }
            break;

        default:
            break;
    }
    
}

// Method to fill Card Status Data.
-(void)fillAdminStatusData :(int )status
{
    if (!arrStatusData) {
        arrStatusData = [[NSMutableArray alloc] init];
    }else
    {
        [arrStatusData removeAllObjects];
    }
    
    switch (status)
    {
        case ACtive_Admin:
        {
            PopUpClass *statusObj;
            
                     
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Locked");
            statusObj.StatusNo=Blocked_Admin;
            [arrStatusData addObject:statusObj];
            [statusObj release];
                       
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Close");
            statusObj.StatusNo=Closed_Admin;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            
        }
            break;
        case Blocked_Admin:
        {
            PopUpClass *statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Active");
            statusObj.StatusNo=ACtive_Admin;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Close");
            statusObj.StatusNo=Closed_Admin;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            
        }
            break;
        case Closed_Admin:
        {
            PopUpClass *statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Active");
            statusObj.StatusNo=ACtive_Admin;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            statusObj = [[PopUpClass alloc] init];
            statusObj.strTitle=languageSelectedStringForKey(@"Locked");
            statusObj.StatusNo=Blocked_Admin;
            [arrStatusData addObject:statusObj];
            [statusObj release];
            
            
        }
            break;
            
        default:
            break;
    }
    
}
// Method to fill Language Data.
-(void)fillLanguageData
{
    arrStatusData = [[NSMutableArray alloc] init];
    PopUpClass *statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"English");
    statusObj.isSelected=NO;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Spanish");
    statusObj.isSelected=NO;
    [arrStatusData addObject:statusObj];
    [statusObj release];

    int languageValue = [[NSUserDefaults standardUserDefaults] integerForKey:@"applicationLanguage"];
    if (languageValue == 1)
    {
        statusObj = [arrStatusData objectAtIndex:0];
        statusObj.isSelected=YES;
    }
    else
    {
        statusObj = [arrStatusData objectAtIndex:1];
        statusObj.isSelected=YES;
    }
    
}
-(void)fillExpCatData:(NSMutableArray *)selectIndex
{
    arrStatusData = [[NSMutableArray alloc]init];
    
    for (int i=0; i<[selectIndex count]; i++)
    {
        SubCategoryDataClass *expData=[selectIndex objectAtIndex:i];
        
        PopUpClass *statusObj = [[PopUpClass alloc] init];
        statusObj.strTitle=expData.EXPCAT_VALUE;
        statusObj.StatusNo=expData.EXPCAT_VALUE_ID;
        [arrStatusData addObject:statusObj];
        [statusObj release];
    }
}



-(void)fillFrequencyData:(int)selectIndex
{
    arrStatusData = [[NSMutableArray alloc] init];
    PopUpClass *statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Monday");
    statusObj.isSelected=NO;
    statusObj.StatusNo=Monday_f;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Tuesday");
    statusObj.isSelected=NO;
    statusObj.StatusNo=Tuesday_f;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Wednesday");
    statusObj.isSelected=NO;
    statusObj.StatusNo=Wednesday_f;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Thursday");
    statusObj.isSelected=NO;
    statusObj.StatusNo=Thursday_f;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Friday");
    statusObj.isSelected=NO;
    statusObj.StatusNo=Friday_f;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Saturday");
    statusObj.isSelected=NO;
    statusObj.StatusNo=Saturday_f;
    [arrStatusData addObject:statusObj];
    [statusObj release];
    
    statusObj = [[PopUpClass alloc] init];
    statusObj.strTitle=languageSelectedStringForKey(@"Sunday");
    statusObj.isSelected=NO;
    statusObj.StatusNo=Sunday_f;
    [arrStatusData addObject:statusObj];
    [statusObj release];

    
    statusObj = [arrStatusData objectAtIndex:selectIndex-1];
    statusObj.isSelected=YES;
}

-(void)fillBypassFlagData :(NSMutableArray *)dataArray
{
    arrStatusData = [[NSMutableArray alloc]init];
    
    for (int i=0; i<[dataArray count]; i++)
    {
        secretQustionDataClass *expData=[dataArray objectAtIndex:i];
        
        PopUpClass *statusObj = [[PopUpClass alloc] init];
        statusObj.strTitle=expData.secretQuestion;
        statusObj.StatusNo=[expData.indexNo intValue];
        [arrStatusData addObject:statusObj];
        [statusObj release];
    }
}

// Method for cancel button pressed.
-(void)openCancel
{
    [DELEGATE removeChangeStatusView];
}
// Method to design the Questionary view.
-(id) initWithQuestionViewFram:(CGRect)frame Delegate:(id)delegate SelectedQue:(int)selectIndex
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor=[UIColor clearColor];
        isQuetion = YES;
        isLanguage=NO;
        isChangeStatus=NO;
        ischangeAdminStatus=NO;
        isExpense=NO;
        isfrequency=NO;
        [self fillquetiondata:selectIndex];
        
        DELEGATE=delegate;
        
        int viewHeight = [arrStatusData count]*popupCellHeight;
        
        UIView *statusView = [[UIView alloc] initWithFrame:CGRectMake((320-popQueCellWidth)/2, ([AppDelegate sharedAppDelegate].screenHeight-350), popQueCellWidth, viewHeight+70)];
        statusView.backgroundColor=[UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7];
        statusView.backgroundColor=[UIColor greenColor];
        [self addSubview:statusView];
        [statusView release];
        
        statusView.layer.cornerRadius = 5;
        statusView.layer.masksToBounds = YES;
        statusView.layer.borderColor = [UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7].CGColor;
        statusView.layer.borderWidth = 1.5f;
        
        
        UIView *topTitleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, popQueCellWidth, 35)];
        topTitleView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:topTitleView];
        [topTitleView release];
        
        UILabel *lblTitle = createLabel(languageSelectedStringForKey(@"Select Question"), CGRectMake(5, 0, popQueCellWidth-10, 35));
        lblTitle.backgroundColor=[UIColor clearColor];
        lblTitle.textAlignment= NSTextAlignmentCenter;
        lblTitle.textColor=[UIColor whiteColor];
        lblTitle.font=[UIFont systemFontOfSize:18];
        [topTitleView addSubview:lblTitle];
        [lblTitle release];
        
        
        tblStatus = createTableView(CGRectMake(0, CGRectGetMaxY(lblTitle.frame), popQueCellWidth, viewHeight), self);
        tblStatus.separatorColor=[UIColor blackColor];
        tblStatus.backgroundColor=[UIColor whiteColor];
        tblStatus.scrollEnabled=NO;
        [statusView addSubview:tblStatus];
        [tblStatus release];
        
        UIView * bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(tblStatus.frame), popQueCellWidth, 35)];
        bottomView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:bottomView];
        
        
        UIButton *btnCancel = createButton(CGRectMake(90, 5, 62, 25), @"", imgNAV_CancelBtn, self, @selector(openCancel));
        [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [bottomView addSubview:btnCancel];
        
        [btnCancel release];
    }
    return self;
}
// Method to design the select language view
- (id)initWithLanguageViewFrame:(CGRect)frame Delegate:(id)delegate
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor=[UIColor clearColor];
        
        
//        self.backgroundColor=[UIColor colorWithRed:242/255 green:175/255 blue:50/255 alpha:0.9];
        isLanguage=YES;
        isQuetion = NO;
        isChangeStatus=NO;
        ischangeAdminStatus=NO;
        isExpense=NO;
        isfrequency=NO;
        [self fillLanguageData];
        DELEGATE=delegate;
        
        int viewHeight = [arrStatusData count]*popupCellHeight+70;
        
        UIView *statusView = [[UIView alloc] initWithFrame:CGRectMake((320-popCellWidth)/2, ([AppDelegate sharedAppDelegate].screenHeight-118)/2, popCellWidth, viewHeight)];
        
//        UIView *statusView = [[UIView alloc] initWithFrame:CGRectMake(([AppDelegate sharedAppDelegate].screenWidth-172)/2, ([AppDelegate sharedAppDelegate].screenHeight-118)/2, 172, viewHeight)];
        statusView.backgroundColor=[UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7];
        [self addSubview:statusView];
        [statusView release];
        
        statusView.layer.cornerRadius = 5;
        statusView.layer.masksToBounds = YES;
        statusView.layer.borderColor = [UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7].CGColor;
        statusView.layer.borderWidth = 1.5f;
        
        
        UIView *topTitleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, popCellWidth, 35)];
        topTitleView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:topTitleView];
        [topTitleView release];
        
        UILabel *lblTitle = createLabel(languageSelectedStringForKey(@"Select Language"), CGRectMake(14, 0, 162, 35));
        lblTitle.backgroundColor=[UIColor clearColor];
        lblTitle.textAlignment= NSTextAlignmentCenter;
        lblTitle.textColor=[UIColor whiteColor];
        lblTitle.font=[UIFont systemFontOfSize:18];
        [topTitleView addSubview:lblTitle];
        [lblTitle release];
        
        tblStatus = createTableView(CGRectMake(0, CGRectGetMaxY(lblTitle.frame), popCellWidth, popupCellHeight*2), self);
        tblStatus.separatorColor=[UIColor blackColor];
        tblStatus.backgroundColor=[UIColor whiteColor];
        tblStatus.scrollEnabled=NO;
        [statusView addSubview:tblStatus];
        [tblStatus release];
        
        UIView * bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(tblStatus.frame), popCellWidth, 35)];
        bottomView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:bottomView];
        

        UIButton *btnCancel = createButton(CGRectMake(55, 5, 62, 25), @"", imgNAV_CancelBtn, self, @selector(openCancel));
        [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [bottomView addSubview:btnCancel];

        [btnCancel release];
        
    }
    self.transform = CGAffineTransformMakeScale([UIScreen mainScreen].applicationFrame.size.width / 320.0f, [UIScreen mainScreen].applicationFrame.size.height / 479.0f);
    return self;
}
// Method to design the Card change status view.
- (id)initWithPopViewFrame:(CGRect)frame CardData:(CardDetailClass *)cardDataObj Delegate:(id)delegate
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor=[UIColor clearColor];
        isLanguage=NO;
        isQuetion = NO;
        isChangeStatus=YES;
        ischangeAdminStatus=NO;
        isExpense=NO;
        isfrequency=NO;
        [self fillStatusData :cardDataObj.STATUS_CARDACCOUNT];
        
        DELEGATE=delegate;
        
        int viewHeight = [arrStatusData count]*popupCellHeight;
        
        UIView *statusView = [[UIView alloc] initWithFrame:CGRectMake((320-popCellWidth)/2, (480-(viewHeight+60))/2, popCellWidth, viewHeight+70)];
        statusView.backgroundColor=[UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7];
        statusView.backgroundColor=[UIColor greenColor];
        [self addSubview:statusView];
        [statusView release];
        
        statusView.layer.cornerRadius = 5;
        statusView.layer.masksToBounds = YES;
        statusView.layer.borderColor = [UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7].CGColor;
        statusView.layer.borderWidth = 1.5f;
        
        
        UIView *topTitleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, popCellWidth, 35)];
        topTitleView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:topTitleView];
        [topTitleView release];
        
        UILabel *lblTitle = createLabel(languageSelectedStringForKey(@"Change Status"), CGRectMake(5, 0, popCellWidth-10, 35));
        lblTitle.textAlignment= NSTextAlignmentCenter;
        lblTitle.backgroundColor=[UIColor clearColor];
        lblTitle.textColor=[UIColor whiteColor];
        lblTitle.font=[UIFont systemFontOfSize:18];
        [topTitleView addSubview:lblTitle];
        [lblTitle release];
        
        
        tblStatus = createTableView(CGRectMake(0, CGRectGetMaxY(lblTitle.frame), popCellWidth, viewHeight), self);
        tblStatus.separatorColor=[UIColor blackColor];
        tblStatus.backgroundColor=[UIColor whiteColor];
        tblStatus.scrollEnabled=NO;
        [statusView addSubview:tblStatus];
        [tblStatus release];
        
        UIView * bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(tblStatus.frame), popCellWidth, 35)];
        bottomView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:bottomView];
        
        
        UIButton *btnCancel = createButton(CGRectMake(64, 5, 62, 25), @"", imgNAV_CancelBtn, self, @selector(openCancel));
        [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [bottomView addSubview:btnCancel];
        
        [btnCancel release];
    }
    return self;
}


- (id)initWithAdminStatusViewFrame:(CGRect)frame CardData:(int)cardDataObj Delegate:(id)delegate
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor=[UIColor clearColor];
        isLanguage=NO;
        isQuetion = NO;
        isChangeStatus=NO;
        ischangeAdminStatus=YES;
        isExpense=NO;
        isfrequency=NO;
        [self fillAdminStatusData :cardDataObj];
        
        DELEGATE=delegate;
        
        int viewHeight = [arrStatusData count]*popupCellHeight;
        
        UIView *statusView = [[UIView alloc] initWithFrame:CGRectMake((320-popCellWidth)/2, (480-(viewHeight+60))/2, popCellWidth, viewHeight+70)];
        statusView.backgroundColor=[UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7];
        statusView.backgroundColor=[UIColor greenColor];
        [self addSubview:statusView];
        [statusView release];
        
        statusView.layer.cornerRadius = 5;
        statusView.layer.masksToBounds = YES;
        statusView.layer.borderColor = [UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7].CGColor;
        statusView.layer.borderWidth = 1.5f;
        
        
        UIView *topTitleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, popCellWidth, 35)];
        topTitleView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:topTitleView];
        [topTitleView release];
        
        UILabel *lblTitle = createLabel(languageSelectedStringForKey(@"Change Status"), CGRectMake(5, 0, popCellWidth-10, 35));
        lblTitle.textAlignment= NSTextAlignmentCenter;
        lblTitle.backgroundColor=[UIColor clearColor];
        lblTitle.textColor=[UIColor whiteColor];
        lblTitle.font=[UIFont systemFontOfSize:18];
        [topTitleView addSubview:lblTitle];
        [lblTitle release];
        
        
        tblStatus = createTableView(CGRectMake(0, CGRectGetMaxY(lblTitle.frame), popCellWidth, viewHeight), self);
        tblStatus.separatorColor=[UIColor blackColor];
        tblStatus.backgroundColor=[UIColor whiteColor];
        tblStatus.scrollEnabled=NO;
        [statusView addSubview:tblStatus];
        [tblStatus release];
        
        UIView * bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(tblStatus.frame), popCellWidth, 35)];
        bottomView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:bottomView];
        
        
        UIButton *btnCancel = createButton(CGRectMake(64, 5, 62, 25), @"", imgNAV_CancelBtn, self, @selector(openCancel));
        [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [bottomView addSubview:btnCancel];
        
        [btnCancel release];
    }
    return self;
}

-(id) initWithLoadFrequency:(CGRect)frame Delegate:(id)delegate SelectedQue:(int)selectIndex
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor=[UIColor clearColor];
        isQuetion = NO;
        isLanguage=NO;
        isChangeStatus=NO;
        ischangeAdminStatus=NO;
        isExpense=NO;
        isfrequency=YES;
        [self fillFrequencyData :selectIndex];
        
        DELEGATE=delegate;
        
        int viewHeight = [arrStatusData count]*popupCellHeight;
        
        UIView *statusView = [[UIView alloc] initWithFrame:CGRectMake((320-popQueCellWidth)/2, 50, popQueCellWidth, viewHeight+70)];
        statusView.backgroundColor=[UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7];
        statusView.backgroundColor=[UIColor greenColor];
        [self addSubview:statusView];
        [statusView release];
        
        statusView.layer.cornerRadius = 5;
        statusView.layer.masksToBounds = YES;
        statusView.layer.borderColor = [UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7].CGColor;
        statusView.layer.borderWidth = 1.5f;
        
        
        UIView *topTitleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, popQueCellWidth, 35)];
        topTitleView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:topTitleView];
        [topTitleView release];
        
        UILabel *lblTitle = createLabel(languageSelectedStringForKey(@"Select Day"), CGRectMake(5, 0, popQueCellWidth-10, 35));
        lblTitle.backgroundColor=[UIColor clearColor];
        lblTitle.textAlignment= NSTextAlignmentCenter;
        lblTitle.textColor=[UIColor whiteColor];
        lblTitle.font=[UIFont systemFontOfSize:18];
        [topTitleView addSubview:lblTitle];
        [lblTitle release];
        
        
        tblStatus = createTableView(CGRectMake(0, CGRectGetMaxY(lblTitle.frame), popQueCellWidth, viewHeight), self);
        tblStatus.separatorColor=[UIColor blackColor];
        tblStatus.backgroundColor=[UIColor whiteColor];
        tblStatus.scrollEnabled=NO;
        [statusView addSubview:tblStatus];
        [tblStatus release];
        
        UIView * bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(tblStatus.frame), popQueCellWidth, 35)];
        bottomView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:bottomView];
        
        
        UIButton *btnCancel = createButton(CGRectMake(bottomView.frame.size.width/2-31, 5, 62, 25), @"", imgNAV_CancelBtn, self, @selector(openCancel));
        [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [bottomView addSubview:btnCancel];
        
        [btnCancel release];
    }
    return self;
}

-(id)initWithBypassLoad:(CGRect)frame Delegate:(id)delegate limitArray:(NSMutableArray*)arr
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor=[UIColor clearColor];
        isQuetion = NO;
        isLanguage=NO;
        isChangeStatus=NO;
        ischangeAdminStatus=NO;
        isExpense=NO;
        isfrequency=YES;
        [self fillBypassFlagData:arr];
        
        DELEGATE=delegate;
        
        int viewHeight = [arrStatusData count]*popupCellHeight;
        
        UIView *statusView = [[UIView alloc] initWithFrame:CGRectMake((320-popQueCellWidth)/2, 50, popQueCellWidth, viewHeight+70)];
        statusView.backgroundColor=[UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7];
        statusView.backgroundColor=[UIColor greenColor];
        [self addSubview:statusView];
        [statusView release];
        
        statusView.layer.cornerRadius = 5;
        statusView.layer.masksToBounds = YES;
        statusView.layer.borderColor = [UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7].CGColor;
        statusView.layer.borderWidth = 1.5f;
        
        
        UIView *topTitleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, popQueCellWidth, 35)];
        topTitleView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:topTitleView];
        [topTitleView release];
        
        UILabel *lblTitle = createLabel(languageSelectedStringForKey(@"Select Period"), CGRectMake(5, 0, popQueCellWidth-10, 35));
        lblTitle.backgroundColor=[UIColor clearColor];
        lblTitle.textAlignment= NSTextAlignmentCenter;
        lblTitle.textColor=[UIColor whiteColor];
        lblTitle.font=[UIFont systemFontOfSize:18];
        [topTitleView addSubview:lblTitle];
        [lblTitle release];
        
        
        tblStatus = createTableView(CGRectMake(0, CGRectGetMaxY(lblTitle.frame), popQueCellWidth, viewHeight), self);
        tblStatus.separatorColor=[UIColor blackColor];
        tblStatus.backgroundColor=[UIColor whiteColor];
        tblStatus.scrollEnabled=NO;
        [statusView addSubview:tblStatus];
        [tblStatus release];
        
        UIView * bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(tblStatus.frame), popQueCellWidth, 35)];
        bottomView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:bottomView];
        
        
        UIButton *btnCancel = createButton(CGRectMake(bottomView.frame.size.width/2-31, 5, 62, 25), @"", imgNAV_CancelBtn, self, @selector(openCancel));
        [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [bottomView addSubview:btnCancel];
        
        [btnCancel release];
    }
    return self;
}


// Add Expence categoey view
-(id) initWithExpenceCategory:(CGRect)frame Delegate:(id)delegate SelectedQue:(NSString *)selectIndex Array:(NSMutableArray *)dataArray
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor=[UIColor clearColor]; 
        isChangeStatus=NO;
        ischangeAdminStatus=NO;
        isQuetion = NO;
        isLanguage=NO;
        isExpense=YES;
        isfrequency=NO;
        [self fillExpCatData:dataArray];
        
        DELEGATE=delegate;
        
        int viewHeight = [arrStatusData count]*popupCellHeight;
        
        if ([arrStatusData count]>3)
        {
            viewHeight = 3*popupCellHeight;
        }
        
        popQueCellWidth=300;
        
        UIView *statusView = [[UIView alloc] initWithFrame:CGRectMake((320-popQueCellWidth)/2, 120, popQueCellWidth, viewHeight+70)];
      
        
        statusView.backgroundColor=[UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7];
        statusView.backgroundColor=[UIColor greenColor];
        [self addSubview:statusView];
        [statusView release];
        
        statusView.layer.cornerRadius = 5;
        statusView.layer.masksToBounds = YES;
        statusView.layer.borderColor = [UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7].CGColor;
        statusView.layer.borderWidth = 1.5f;
        
        
        UIView *topTitleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, popQueCellWidth, 35)];
        topTitleView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:topTitleView];
        [topTitleView release];
        
        UILabel *lblTitle = createLabel(selectIndex, CGRectMake(0, 0, popQueCellWidth, 35));
        lblTitle.backgroundColor=[UIColor clearColor];
        lblTitle.textAlignment= NSTextAlignmentCenter;
        lblTitle.textColor=[UIColor whiteColor];
        lblTitle.font=[UIFont systemFontOfSize:18];
        [topTitleView addSubview:lblTitle];
        [lblTitle release];
        
        
        tblStatus = createTableView(CGRectMake(0, CGRectGetMaxY(lblTitle.frame), popQueCellWidth, viewHeight), self);
        tblStatus.separatorColor=[UIColor blackColor];
        tblStatus.backgroundColor=[UIColor whiteColor];
        tblStatus.scrollEnabled=YES;
        [statusView addSubview:tblStatus];
        [tblStatus release];
        
        UIView * bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(tblStatus.frame), popQueCellWidth, 35)];
        bottomView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:imgNAV_BG]];
        [statusView addSubview:bottomView];
        
        
        UIButton *btnCancel = createButton(CGRectMake(bottomView.frame.size.width/2-31, 5, 62, 25), @"", imgNAV_CancelBtn, self, @selector(openCancel));
        [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
        btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
        
        [bottomView addSubview:btnCancel];
        
        [btnCancel release];
    }
    return self;
}


// Add calander in view
-(id) loadCalander:(CGRect) fram Delegate:(id)delegate{
    
    self.frame = fram;
    self.backgroundColor= [UIColor clearColor];
    
    DELEGATE = delegate;
    
    UIImageView *topView = [[UIImageView alloc] initWithFrame:CGRectMake(60, 80, 200, 40)];
    topView.image = [UIImage imageNamed:imgNAV_BG];
    [self addSubview:topView];
    [topView release];
    
    UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(60, 80, 200, 40)];
    lblTitle.textColor = [UIColor whiteColor];
    lblTitle.textAlignment = NSTextAlignmentCenter;
    lblTitle.text = @"Select date";
    [self addSubview:lblTitle];
    [lblTitle release];
    
    
    
    UIImageView *bottomview = [[UIImageView alloc] initWithFrame:CGRectMake(60, 355, 200, 40)];
    bottomview.image = [UIImage imageNamed:imgNAV_BG];
    [self addSubview:bottomview];
    [bottomview release];
    
    
    
    UIButton *btnCancel = createButton(CGRectMake(130, 5,60, 30), @"", imgNAV_CancelBtn, self, @selector(openCancel));
    [btnCancel setTitle:languageSelectedStringForKey(@"Cancel") forState:UIControlStateNormal];
    btnCancel.titleLabel.font=[UIFont systemFontOfSize:12];
    
    [self addSubview:btnCancel];
    
    [btnCancel release];
    
    return self;
}
#pragma mark - UITableView Delegate Methods
// Delegate Method returns number of sections is table.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
// Delegate Method to set the height of the cell.
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return popupCellHeight;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrStatusData count];
}
// Delegate Method to design the cell of the table.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"Cell";
    
    HomeCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell==nil) {
        cell = [[[HomeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    PopUpClass * statusObj = [arrStatusData objectAtIndex:indexPath.row];
    
    UIImage *imgNotSelected = [UIImage imageNamed:@"imgStatusNotSelected"];
    UIImage *imgSelected = [UIImage imageNamed:@"imgStatusSelected"];
    
    cell.cellBgImage.image=(statusObj.isSelected)?imgSelected:imgNotSelected;
    
    cell.cellBgImage.frame=CGRectMake(5, (popupCellHeight-imgSelected.size.height)/2, imgSelected.size.width, imgSelected.size.height);
    
    cell.lblName.text=statusObj.strTitle;
    
    cell.lblName.frame=CGRectMake(CGRectGetMaxX(cell.cellBgImage.frame)+6, 0, popQueCellWidth-cell.cellBgImage.frame.size.width-10, 40);

    cell.cellArrowImage.hidden=YES;
    cell.lblName.numberOfLines = 2;
    cell.lblName.font=[UIFont systemFontOfSize:15];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}
// Delegate Method for selecting on the row.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    index=indexPath.row;
    if (isLanguage==YES && isQuetion == NO && isChangeStatus==NO && ischangeAdminStatus==NO && isExpense==NO  && isfrequency==NO) {
        [[NSUserDefaults standardUserDefaults] setInteger:index+1 forKey:@"applicationLanguage"];
        [self openCancel];
    }
    else if(isLanguage == NO && isQuetion==NO && isChangeStatus==NO && ischangeAdminStatus==NO && isExpense==NO  && isfrequency==NO)
    {
       [self showAlert];
        
    }else if(isLanguage == NO && isQuetion==NO && isChangeStatus==YES && ischangeAdminStatus==NO &&isExpense==NO  && isfrequency==NO)
    {
        PopUpClass * statusObj = [arrStatusData objectAtIndex:index];
    
        if ([DELEGATE respondsToSelector:@selector(selectQuetionview:SelectedIndex:)])
        {
            [DELEGATE selectQuetionview:statusObj.strTitle SelectedIndex:statusObj.StatusNo];
        }
    }else if(isLanguage == NO && isQuetion==NO && isChangeStatus==NO && ischangeAdminStatus==YES &&isExpense==NO  && isfrequency==NO)
    {
        PopUpClass * statusObj = [arrStatusData objectAtIndex:index];
        
    if ([DELEGATE respondsToSelector:@selector(selectQuetionview:SelectedIndex:)])
        {
            [DELEGATE selectQuetionview:statusObj.strTitle SelectedIndex:statusObj.StatusNo];
        }
    }else if(isLanguage == NO && isQuetion==NO && isChangeStatus==NO && ischangeAdminStatus==NO &&isExpense==YES  && isfrequency==NO)
    {
        PopUpClass * statusObj = [arrStatusData objectAtIndex:index];
        
        if ([DELEGATE respondsToSelector:@selector(selectQuetionview:SelectedIndex:)])
        {
            [DELEGATE selectQuetionview:statusObj.strTitle SelectedIndex:statusObj.StatusNo];
        }
    }else if(isLanguage == NO && isQuetion==NO && isChangeStatus==NO && ischangeAdminStatus==NO &&isExpense==NO && isfrequency==YES)
    {
        PopUpClass * statusObj = [arrStatusData objectAtIndex:index];
        //-(void) selectQuetionview:(NSString *)dayName SelectedIndex:(int)index SelectedItem:(NSString *)itemName
        if ([DELEGATE respondsToSelector:@selector(selectQuetionview:SelectedIndex:)])
        {
            [DELEGATE selectQuetionview:statusObj.strTitle SelectedIndex:statusObj.StatusNo];
        }
    }
    else{
        PopUpClass * statusObj = [arrStatusData objectAtIndex:index];
        if ([DELEGATE respondsToSelector:@selector(selectQuetionview:SelectedIndex:)]) {
            [DELEGATE selectQuetionview:statusObj.strTitle SelectedIndex:index];
        }
    }
}
// Method to pass the selected object to the delegate class.
-(void)handlePopupViewWork
{
    PopUpClass * statusObj = [arrStatusData objectAtIndex:index];
    if ([DELEGATE respondsToSelector:@selector(handleStatus:SelectedIndex:)]) {
        [DELEGATE handleStatus:statusObj.strTitle SelectedIndex:index];
    }
}

// Method to show the alert for change status view.
-(void)showAlert
{
    self.hidden=YES;
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Change Status" message:@"\n\n\n" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"YES",nil];
    UILabel *lblMessage = [[UILabel alloc] initWithFrame:CGRectMake(12.0, 25.0, 260.0, 90.0)];
    [lblMessage setFont:[UIFont fontWithName:@"Helvetica" size:(15.0)]];
    lblMessage.textAlignment=UITextAlignmentCenter;
    lblMessage.textColor = [UIColor whiteColor];
    lblMessage.text = @"Do you want to change status ?";
    lblMessage.backgroundColor = [UIColor clearColor];
    [alertView addSubview:lblMessage];
    [alertView show];
    [alertView release];
    [lblMessage release];
}
#pragma mark - UIAlertView Delegate Method
// Delegate Method called on select of the ok/cancel button on alert.
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex;
{
    if (buttonIndex==0) {
        [self openCancel];
    }
    else if (buttonIndex==1)
    {
        [self handlePopupViewWork];
    }
}
-(void)dealloc
{
    if ([arrStatusData count]>0) {
        [arrStatusData removeAllObjects];
        [arrStatusData release];
        arrStatusData=nil;
    }
    if (DELEGATE!=nil) {
        DELEGATE=nil;
    }
    
    for (UIView *view in [self subviews])
    {
        if ([view isKindOfClass:[UIView class]]) {
            [view removeFromSuperview];
        }
    }
    [super dealloc];
}
// Method called when the protocol or delegate method is not implemented in the class.
-(void)handleStatus:(NSString *)strStatus SelectedIndex:(cardStatus)index
{
    [self openCancel];
}

// Below method placed here to remove compilation errors
// Method to remove the status view.
-(void)removeChangeStatusView
{
}
// Method to pass the selected question.
-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index
{

    
}
@end
