//
//  expenseRecordView.m
//  CoreMoney


#import "expenseRecordView.h"

@implementation expenseRecordView

//- (id)initwithExpenseRecordFrame:(CGRect)frame analysisType:(int)analysis analysisSubType:(int)analysisSubCat dataArray:(NSMutableArray*)analysisArray period:(int)period

- (id)initwithExpenseRecordFrame:(CGRect)frame analysisType:(int)analysis dataArray:(NSMutableArray*)analysisArray period:(int)period searchForEmployee:(int) searchByEmp searchForCategory:(int)searchByCat{
    
    self = [super initWithFrame:frame];
    if (self)
    {
        searchByCategory = searchByCat;
        searchByEmployee = searchByEmp;
        selectedPeriod=period;
        analysisType=analysis;
        
        dataArray=analysisArray;
        
        tblRecord=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, frame.size.height) style:UITableViewStylePlain];
        tblRecord.dataSource=self;
        tblRecord.delegate=self;
        tblRecord.separatorColor=[UIColor clearColor];
        [self addSubview:tblRecord];
        
        [tblRecord release];
    }
    return self;
}


#pragma mark- Table View Delegates
// Delegate method to set the number of sections in table.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
// Delegate method to set the height of the cell.
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    float rowHeight = (analysisType==Employee_analysis)?54:(analysisType==Employee_Business_Expense)?54:(analysisType==Employee_by_Expense_analysis)?54:(analysisType==Employee_Expense_Category)?100:0;
    return rowHeight;
//    return 
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{    
    return [dataArray count];
}

// Delegate method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	static NSString *CellIdentifier = @"Cell";
    
	expenseAnalyisCell *cell = (expenseAnalyisCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[expenseAnalyisCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier analysisType:analysisType]autorelease];
    }
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    
    if (searchByEmployee < 1 && searchByCategory < 1)
    {
        employeeExpData *dataObj=[dataArray objectAtIndex:indexPath.row];
        
        cell.lblEmployeeName.text=dataObj.EmployeeName;
        cell.lblEmployeeName.frame=CGRectMake(cell.lblEmployeeName.frame.origin.x, cell.lblEmployeeName.frame.origin.y, getTextWidth(dataObj.EmployeeName, cell.lblEmployeeName.font), cell.lblEmployeeName.frame.size.height);
        
    cell.lblEmployeeId.text=checkISNullStrings(dataObj.CardNumber)?@"":dataObj.CardNumber;
//        cell.lblEmployeeId.text = @"";
        cell.lblEmployeeId.frame=CGRectMake(CGRectGetMaxX(cell.lblEmployeeName.frame)+2, cell.lblEmployeeId.frame.origin.y + 2,getTextWidth(cell.lblEmployeeId.text, cell.lblEmployeeId.font), cell.lblEmployeeId.frame.size.height);
//        cell.lblEmployeeId.frame = CGRectMake(CGRectGetMaxX(cell.lblEmployeeId.frame), 9, cell.lblEmployeeId.frame.size.width, 20);
        
        cell.lblExpenseAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dataObj.TotalExpenses))];
        
          
        
        if (analysisType == Employee_analysis ||analysisType == Employee_Business_Expense)
        {
            if (selectedPeriod==EMP_TODAYS || selectedPeriod== EMP_THIS_MONTHS)
            {
                cell.lblEmployeeName.frame=CGRectMake(CGRectGetMinX(cell.lblEmployeeName.frame), 7, cell.lblEmployeeName.frame.size.width, 20);
                
                cell.lblEmployeeId.frame=CGRectMake(CGRectGetMinX(cell.lblEmployeeId.frame), 9, cell.lblEmployeeId.frame.size.width, 20);
                
                cell.imgBudget.hidden=NO;
                cell.lblBudgetAmout.hidden=NO;
                
                cell.lblExpenseAmount.frame=CGRectMake(CGRectGetMinX(cell.lblEmployeeName.frame), CGRectGetMaxY(cell.lblEmployeeName.frame), 100, 20);
                cell.lblExpenseAmount.textAlignment=UITextAlignmentLeft;
                
                
                cell.lblBudgetAmout.frame=CGRectMake(CGRectGetMaxX(cell.bgView.frame)-105, CGRectGetMaxY(cell.lblEmployeeName.frame), 100, 20);
                cell.lblBudgetAmout.textAlignment=UITextAlignmentRight;
                
                
                
                int color=compareBudgetFaire([dataObj.ExpenseLimit doubleValue],dataObj.TotalExpenses);
                
                switch (color)
                {
                    case green:
                        cell.imgBudget.image=[UIImage imageNamed:@"green-box.png"];
                        break;
                    case yellow:
                        cell.imgBudget.image=[UIImage imageNamed:@"yallow-box.png"];
                        break;
                    case red:
                        cell.imgBudget.image=[UIImage imageNamed:@"red-box.png"];
                        break;
                    default:
                        break;
                }
                
                if (checkISNullStrings(dataObj.ExpenseLimit))
                {
                    cell.lblBudgetAmout.hidden=YES;
                    cell.imgBudget.hidden=YES;
                }else
                {
                    cell.lblBudgetAmout.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency([dataObj.ExpenseLimit doubleValue]-dataObj.TotalExpenses))];
                    cell.lblBudgetAmout.hidden=NO;
                    cell.imgBudget.hidden=NO;
                }
            }else
            {
                cell.lblEmployeeId.hidden=NO;
                cell.lblBudgetAmout.hidden=YES;
                
                cell.lblEmployeeName.frame=CGRectMake(CGRectGetMinX(cell.lblEmployeeName.frame), 7, cell.lblEmployeeName.frame.size.width, 20);
                
                cell.lblEmployeeId.frame=CGRectMake(CGRectGetMinX(cell.lblEmployeeId.frame), 9, cell.lblEmployeeId.frame.size.width, 20);
               

                cell.lblExpenseAmount.frame=CGRectMake(CGRectGetMaxX(cell.bgView.frame)-105, CGRectGetMaxY(cell.lblEmployeeName.frame), 100, 20);;
                cell.lblExpenseAmount.textAlignment=UITextAlignmentRight;
            }
        }
        if ([dataObj.arrEmployeCatDescExpense count] > 0)
        {
            // Only 1 Category and Amount will be displayed other labels will be hidden from the cell
            
            ExpenseCategory *objExpenseCat1 = [dataObj.arrEmployeCatDescExpense objectAtIndex:0];
            cell.lblCategory1.text=checkISNullStrings(objExpenseCat1.expCatDesc)?@"":objExpenseCat1.expCatDesc;
            cell.lblCategoryAmount1.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(objExpenseCat1.expense))];
            
            cell.lblCategory2.hidden = YES;
            cell.lblCategoryAmount2.hidden = YES;
            
            cell.lblCategory3.hidden = YES;
            cell.lblCategoryAmonut3.hidden = YES;
        }
        
        if ([dataObj.arrEmployeCatDescExpense count] > 1)
        {
            // 2 Labels for Category and Amount will be displayed other label will be hidden from the cell
            
            cell.lblCategory2.hidden = NO;
            cell.lblCategoryAmount2.hidden = NO;
            
            ExpenseCategory *objExpenseCat2 = [dataObj.arrEmployeCatDescExpense objectAtIndex:1];
            cell.lblCategory2.text=checkISNullStrings(objExpenseCat2.expCatDesc)?@"":objExpenseCat2.expCatDesc;
            cell.lblCategoryAmount2.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(objExpenseCat2.expense))];

            cell.lblCategory3.hidden = YES;
            cell.lblCategoryAmonut3.hidden = YES;
        }
        if ([dataObj.arrEmployeCatDescExpense count] > 2)
        {
            // All 3 labels will be displayed in Cell
            
            cell.lblCategory3.hidden = NO;
            cell.lblCategoryAmonut3.hidden = NO;
            
            ExpenseCategory *objExpenseCat3 = [dataObj.arrEmployeCatDescExpense objectAtIndex:2];
            cell.lblCategory3.text=checkISNullStrings(objExpenseCat3.expCatDesc)?@"":objExpenseCat3.expCatDesc;
            cell.lblCategoryAmonut3.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(objExpenseCat3.expense))];
        }
        
      
        
        
        
        cell.lblCategory.text=checkISNullStrings(dataObj.expCateGory)?@"Travel":dataObj.expCateGory;
        cell.lblCategory.frame=CGRectMake(cell.lblCategory.frame.origin.x, cell.lblCategory.frame.origin.y, getTextWidth(dataObj.expCateGory, cell.lblCategory.font), cell.lblCategory.frame.size.height);
        cell.lblCategoryAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dataObj.expCateAmount))];
        
        
        
        
        cell.lblSummarizedPeriod.text=checkISNullStrings(dataObj.EmployeeName)?@"01 sep 2013":dataObj.EmployeeName;
        cell.lblSummrizedAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dataObj.TotalExpenses))];
    }
    else
    {
        if ((searchByEmployee > 0 && searchByCategory < 1) || (searchByEmployee > 0 && searchByCategory > 0))
        {
            ExpenseCategory *objExpenseCat1 = [dataArray objectAtIndex:indexPath.row];
            cell.lblCategory.text=checkISNullStrings(objExpenseCat1.expCatDesc)?@"":objExpenseCat1.expCatDesc;
            cell.lblCategoryAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(objExpenseCat1.expense))];            
            [cell.lblCategory setFrame:CGRectMake(15, 16, 120, 20)];
        }
        else if(searchByEmployee < 1 && searchByCategory > 0)
        {        
            employeeExpData *dataObj=[dataArray objectAtIndex:indexPath.row];            
            cell.lblEmployeeName.text=dataObj.EmployeeName;
            cell.lblExpenseAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(dataObj.TotalExpenses))];
        }
        cell.lblEmployeeId.hidden = YES;
    }
    
    return cell;
}

-(void) dealloc
{
    [super dealloc];
}


@end
