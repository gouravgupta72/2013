//
//  HomeViewController.h
//
// Class used to design the Home Page.

#import <UIKit/UIKit.h>
#import "HomeView.h"
#import "DataParsingClass.h"
@interface HomeViewController : SwipeViewController<DataParsingDelegate>
{
    NSMutableArray *cellArray;
    NSString *strBalance;
    UIView *topView;
    
    int RequestID;
    
}
@property (retain, nonatomic) IBOutlet UITableView *tblView;
@property (retain, nonatomic) IBOutlet UIView *myHomeView;
@property (retain, nonatomic) IBOutlet UIScrollView *myTopScrollView;
@property (retain, nonatomic) IBOutlet UIView *leftView;
@property (retain, nonatomic) IBOutlet UIView *rightView;

@end
