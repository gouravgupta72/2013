//
//  ExpenseRulesdata.h
//  CoreMoney
//
// Class is object class of expense rules class

#import <Foundation/Foundation.h>

@interface ExpenseRulesdata : NSObject
{
    NSString *UseMerchantCategory,*EXPENSE_CAT_ONE,*EXPENSE_CAT_TWO,*EXPENSE_CAT_THREE,*CATEGORY_DEF,*ShowSpendRuleOnSS;
    
    NSString *UseDailySpendLimit,*UseMonthlySpendLimit,*Daily_Spend_Limit,*Monthly_Spend_Limit,*SingleTransaction_Spend_Limit,*Period,*Daily_Spend_Limit_business,*Monthly_Spend_Limit_business, *BypassBusinessBugdetLimitPeriod;
    
    BOOL International_Use_Allowed,ByPass_Card_Monetary_Limit,ByPassBusiness_BudgetLimit;
    
    NSMutableArray *murchantCatData;
    
}


@property BOOL International_Use_Allowed,ByPass_Card_Monetary_Limit,ByPassBusiness_BudgetLimit;

@property (nonatomic , retain)  NSMutableArray *murchantCatData;

@property (nonatomic , retain)NSString *UseDailySpendLimit, *UseMonthlySpendLimit,*Daily_Spend_Limit,*Monthly_Spend_Limit,*SingleTransaction_Spend_Limit,*Period,*Daily_Spend_Limit_business,*Monthly_Spend_Limit_business, *BypassBusinessBugdetLimitPeriod;


@property (nonatomic,retain) NSString *UseMerchantCategory,*EXPENSE_CAT_ONE,*EXPENSE_CAT_TWO,*EXPENSE_CAT_THREE,*CATEGORY_DEF,*ShowSpendRuleOnSS;


@end
