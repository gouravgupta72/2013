//
//  HelpMenuItem.m


// Class for design Help Menu Content.
#import "HelpMenuItem.h"


@implementation HelpMenuItem
@synthesize lblTitle;
// Return Help Menu Content.
- (id)initWithHelpMenuFrame:(CGRect)frame delegate:(id)del image:(NSString *)imgName Title:(NSString *)title tag:(int)index
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.tag=index;
        
        self.backgroundColor=[UIColor clearColor];
        lblTitle=[[UILabel alloc]initWithFrame:CGRectMake(4, 3, frame.size.width-2, 12)];
        lblTitle.textAlignment=NSTextAlignmentCenter;
        lblTitle.textColor=[UIColor whiteColor];
        lblTitle.font=[UIFont fontWithName:@"Arial" size:12.0f];
        lblTitle.adjustsFontSizeToFitWidth=YES;
        lblTitle.backgroundColor=[UIColor clearColor];
        lblTitle.text=title;
        [self addSubview:lblTitle];
        [imglogo release];
        
        imglogo=[[UIImageView alloc]initWithFrame:CGRectMake((frame.size.width/2-10), CGRectGetMaxY(lblTitle.frame)+3, 25, 25)];
        imglogo.image=[UIImage imageNamed:imgName];
        [self addSubview:imglogo];
        [imglogo release];
        
        btnSelect=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        btnSelect.backgroundColor=[UIColor clearColor];
        [btnSelect addTarget:del action:@selector(HelpItemClick:) forControlEvents:UIControlEventTouchUpInside];
        
        btnSelect.tag=index;
        [self addSubview:btnSelect];
        [btnSelect release];
    }
    return self;
}


@end
