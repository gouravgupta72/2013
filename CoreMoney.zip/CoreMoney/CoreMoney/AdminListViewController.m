//
//  AdminListViewController.m
//  CoreMoney
// Class use for create admin list
#import "AdminListViewController.h"
#import "AdminListCell.h"

@interface AdminListViewController ()
-(void)openBack;
-(void)openSlide;
-(void)removeChangeStatusView;
-(void)openLogout;
-(void) removePopUpview;
-(void)getResponce:(id)jsonData;
-(void)changeAdminStatus :(int)statusValue;
-(void)getAdminsProfile;
-(void)getAdminLoadLimit;
-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index;
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex;
-(void)openStatusView:(int)index;
@end

@implementation AdminListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        addNavigationBar(ADMIN_LIST, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
    }
    return self;
}

- (void)viewDidLoad
{
    self.tableViewAdminList.frame = CGRectMake(0, (IS_IPAD?20:0), 320,IS_IPAD?IS_IOS7?440:420:IS_IOS7?495:435);
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void) viewWillAppear:(BOOL)animated{
    [AppDelegate sharedAppDelegate].classType = ADMINS_PAGE;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_tableViewAdminList release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setTableViewAdminList:nil];
    [super viewDidUnload];
}
//go to back view
-(void)openBack
{
    [self.navigationController popViewControllerAnimated:YES];
}
// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

//method used for remove changed status view
-(void)removeChangeStatusView
{
    [self removePopUpview];
    
}
-(void)openLogout
{
    
}
// method use for remove popup view
-(void) removePopUpview
{
    if (statusSelectView) {
        [statusSelectView removeFromSuperview];
        [statusSelectView release];
        statusSelectView = nil;
    }
    [self.tableViewAdminList reloadData];
}
//method use for response
-(void)getResponce:(id)jsonData
{
    switch (RequestId) {
        case changeAdminStatus:
        {
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                LoginResponceDataClass *dataObj=(LoginResponceDataClass *)jsonData;
                if (dataObj.Error_Code==1)
                {
                    AdminDataClass *adOb=[[AppDelegate sharedAppDelegate].ArrayAdmin objectAtIndex:selectedIndex];
                    adOb.UserStatus=newStatus;
                    
                    [[AppDelegate sharedAppDelegate].ArrayAdmin replaceObjectAtIndex:selectedIndex withObject:adOb];
                }
                showAlertScreen(nil, dataObj.ErrorMsg);
            }
            
            [self.tableViewAdminList reloadData];
            [self removePopUpview];
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            

        }
            break;
            case getAdminProfile:
        {
            if ([jsonData isKindOfClass:[adminProfileData class]])
            {
                AdminDataClass *adOb=[[AppDelegate sharedAppDelegate].ArrayAdmin objectAtIndex:selectedIndex];
                
                adminProfileData *profile=(adminProfileData *)jsonData;
                
                AdminProfileViewController *adPVC=[[AdminProfileViewController alloc] initWithNibName:@"AdminProfileViewController" bundle:nil admin:NO];
                
                adPVC.AdminDataObj=adOb;
                adPVC.adminProfileObj=profile;
                adPVC.adminLoadDataObj=adminLoadObj;
                
                [self.navigationController pushViewController:adPVC animated:YES];
                [adPVC release];

                
                 [[AppDelegate sharedAppDelegate] removeLoadingView];
                
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
            
            case getAdminLoad:
        {
            if ([jsonData isKindOfClass:[adminLoadLimitDataClass class]])
            {
                adminLoadObj=(adminLoadLimitDataClass *)jsonData;
                [self getAdminsProfile];
            }else
            {
                showAlertScreen(nil, jsonData);
                [[AppDelegate sharedAppDelegate] removeLoadingView];
            }
        }
            break;
            
        default:
            break;
    }
   }

//method used for change admin status 
-(void)changeAdminStatus :(int)statusValue
{
     RequestId=changeAdminStatus;
    AdminDataClass *adOb=[[AppDelegate sharedAppDelegate].ArrayAdmin objectAtIndex:selectedIndex];

    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Update_Existing_Admin_user;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
     NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deANAuserid=%@&deANAAdminUserid=%@&deANAClientID=%@&deANAFirstName=&deANASurNameSearchUser=&deANAInternalId=&deANAuserStatus=%d&deANAUsrPassword=&deANALoadFunding=&deANARoutingNumber=&deANAAccountNumber=&deANAUserSeeAcctBlnce=&deIVRSource=%@&deIVRIpAddress=&deIVRCallerId=&deIVRCalledId=&deIVRRequestTime=&deIVRSessionID=&deUserACH_ByPassMinReserveFund=&deBAEmailID=&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,adOb.UserId, [UserDetailClass sharedUser].strUserId, adOb.ClientID, statusValue, [SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcUpdateExistingUser];
    [Datareq release];

}
//method to get admin profile
-(void)getAdminsProfile
{
    RequestId=getAdminProfile;
    
    AdminDataClass *adOb=[[AppDelegate sharedAppDelegate].ArrayAdmin objectAtIndex:selectedIndex];
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getAdminProfile_Request;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dePPAdminPortalFilterID=1&dePPAdminPortalUserID=%@&dePPAdminPortalIPAddress=&dePPAdminPortalClientID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,adOb.UserId];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcGetIPAddrMatchIPAddrAndCheckDay];
    [Datareq release];

}
//method to get admin load limit
-(void)getAdminLoadLimit
{
    RequestId=getAdminLoad;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
     AdminDataClass *adOb=[[AppDelegate sharedAppDelegate].ArrayAdmin objectAtIndex:selectedIndex];
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=getAdmin_load_par_req;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    
    
    NSString *url = [NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deLoadParameter_Acctid=%@&deLoadParameter_Type=User&deValueOFDay=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,adOb.UserId,[SystemConfiguration sharedSystemConfig].deIVRSource];
    
    [Datareq SendRequest:API_DOMAIN Parameter:url ServiceName:svcviewloadparameter];
    [Datareq release];
    
}

-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index
{
    newStatus=index;
    
    showAlertWithOtherButtons(nil, @"Do you want to change status?", 0, self);
}

#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
        if (buttonIndex == 0)
        {
            [self changeAdminStatus:newStatus];
        }else
        {
            [self removePopUpview];
        }
    
}

// Method to open the status view.
-(void)openStatusView:(int)index
{
        selectedIndex=index;
    
        AdminDataClass *adOb=[[AppDelegate sharedAppDelegate].ArrayAdmin objectAtIndex:index];
    
    
        statusSelectView = [[UIView alloc] initWithFrame:self.view.frame];
        statusSelectView.backgroundColor = [UIColor clearColor];
        
        [self.view addSubview:statusSelectView];
        
        PopUpView *csv = [[PopUpView alloc] initWithAdminStatusViewFrame:CGRectMake(0, 0, 320, 480) CardData:adOb.UserStatus Delegate:self];
        
        [statusSelectView addSubview:csv];
        [csv release];
}

#pragma mark- Table View Delegate methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 50;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [[AppDelegate sharedAppDelegate].ArrayAdmin count];
}
//delegate method to design cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"Cell";
      AdminListCell *cell = (AdminListCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[AdminListCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier Delegate:self]autorelease];
   }
    cell.contentView.backgroundColor=(indexPath.row %2 == 0)? [UIColor colorWithPatternImage:[UIImage imageNamed:@"imgCellBackground"]] : [UIColor whiteColor];
    
    AdminDataClass *adObj;
    adObj =(AdminDataClass *)[[AppDelegate sharedAppDelegate].ArrayAdmin objectAtIndex:indexPath.row];
    
    cell.lblTitleName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings(adObj.FirstName)?@"":[NSString stringWithFormat:@"%@ ",adObj.FirstName],checkISNullStrings(adObj.LastName)?@"":[NSString stringWithFormat:@"%@",adObj.LastName]];
    
    cell.lblCardNumber.text=checkISNullStrings(adObj.UserId)?@"":adObj.UserId;
    
    
    cell.btnView.frame=CGRectMake(CGRectGetMaxX(cell.lblTitleName.frame)+10, 17, 7, 13);
    cell.btnView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"imgStatusInactive"]];
    cell.lblStatus.text=AdminStatusValue(adObj.UserStatus);
    
    
    cell.btnState.tag=indexPath.row;
    
    if ([AdminAccessInfo AdminAcess].mgmtPolicyAccessValue != MGMTPOLICYACCESS)
    {
        cell.btnState.enabled = NO;
        cell.btnView.hidden = YES;
    }
    else
    {
        cell.btnState.enabled = YES;
        cell.btnView.hidden = NO;
    }
    
    
    if (adObj.UserStatus== Closed_Admin)
    {
        cell.btnState.enabled = NO;
        cell.btnView.hidden = YES;
    }
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}
//delegate method called when we select the row of table
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    selectedIndex=indexPath.row;
    [self getAdminLoadLimit];
}


@end
