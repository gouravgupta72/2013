//
//  AdminDataClass.m
//  CoreMoney
// class used for admin data
#import "AdminDataClass.h"

@implementation AdminDataClass
@synthesize UserId, FirstName, LastName, ClientName, ClientID, UserTypeDescription, UserStatusDescription, UserType, UserStatus, RoleType, LAST_ACCESSED_AT;

-(void)dealloc
{
    self.UserId=nil;
    self.FirstName=nil;
    self.LastName=nil;
    self.ClientName=nil;
    self.ClientID=nil;
    self.UserTypeDescription=nil;
    self.UserStatusDescription=nil;
    self.LAST_ACCESSED_AT=nil;
    [super dealloc];
}
@end
