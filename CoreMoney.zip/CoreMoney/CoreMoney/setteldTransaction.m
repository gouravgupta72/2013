//
//  TransactiobDetailDataClass.m
//  CoreMoney

// Class used for holding data of transaction Detail.

#import "setteldTransaction.h"



@implementation setteldTransaction
@synthesize  SettledTxnTranId, SettledTxnTranTime, SettledTxnPostTime, Transaction_Description, Transaction_Source, CardAcceptorName_Location, postingRef, TypeOfTran, TransactionReason, COREAUTH_TRANID, SPEND_CATEGORY,MerchantCity,OverLimitFlag, CATEGORY_LABEL, COMMENT;

@synthesize Transaction_Amount, Current_Balance,MemoFlag, transactionType, HeldAmount, ReversibleFlag;


-(void)dealloc
{
    self.SettledTxnTranId=nil;
    self.SettledTxnTranTime=nil;
    self.SettledTxnPostTime=nil;
    self.Transaction_Description=nil;
    self.Transaction_Source=nil;
    self.CardAcceptorName_Location=nil;
    self.postingRef=nil;
    self.TypeOfTran=nil;
    self.TransactionReason=nil;
    self.COREAUTH_TRANID=nil;
    self.SPEND_CATEGORY=nil;
    self.CATEGORY_LABEL=nil;
    self.COMMENT=nil;
    [super dealloc];
}
@end
