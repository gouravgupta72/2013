//
//  HomeView.h
//  CoreMoney
// Class to design the home page top view.

#import <UIKit/UIKit.h>

@interface HomeView : UIView
{
    UILabel *lblBusinessName,*lblLastLogin,*lblUserName,*lblAmount;
}
@property (nonatomic, retain) UILabel *lblBusinessName,*lblLastLogin,*lblUserName,*lblAmount;
@end
