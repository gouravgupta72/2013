//
//  SlideMenuClass.h
// Object class for Slide menu objects.

#import <Foundation/Foundation.h>

@interface SlideMenuClass : NSObject
{
    NSString *strImage,*strMenuTitle;
    pageType pageName;
    slideIndexType indexType;
    BOOL isShow;
    BOOL isEnable;
    int count; // The variable is used for passing count for particular cell.
}
@property(nonatomic,assign) pageType pageName;
@property(nonatomic,assign) BOOL isShow,isEnable;
@property(nonatomic,assign) slideIndexType indexType;;
@property(nonatomic,retain) NSString *strImage,*strMenuTitle;
@property(nonatomic,assign) int count;

-(id)initWithTitle:(NSString *)titleImage title:(NSString *)titleName selectedMenu:(pageType)menu Type:(slideIndexType)type Show:(BOOL)show Enabled:(BOOL)enable ListSize:(int)size;
@end
