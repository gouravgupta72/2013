//
//  NSString+Value.m
//  CoreMoney

// Class for overWrite nsstring class.
#import "NSString+Value.h"

@implementation NSString (Value)
+(id)ValueForDictionary:(NSDictionary *)dic
{
    if (![dic isKindOfClass:[NSNull class]])
    {
        NSString *value=[dic valueForKey:@"text"];
         return value;
    }else
    {
         return nil;
    }
}
@end