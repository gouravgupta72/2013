//
//  AdminProfileViewController.m
//  CoreMoney

//class use for admin profile 
#import "AdminProfileViewController.h"
#import "ComboViewController.h"
#import "PopUpView.h"

@interface AdminProfileViewController ()
- (IBAction)userInfoClicked:(id)sender;
- (IBAction)loadLimitClicked:(id)sender;
- (IBAction)clickedStatusBtn:(id)sender;
- (IBAction)clickedChangePwd:(id)sender;
- (IBAction)clickedPwdSubmit:(id)sender;
- (IBAction)changeValueofSlider:(id)sender;
- (IBAction)openSecretQuestionCombo:(id)sender;
@property (retain, nonatomic) IBOutlet UISwitch *swtLoadLimit;
@property (retain, nonatomic) IBOutlet UIButton *btnUpdateLimit;
-(void)openBack;
-(void)openSlide;
-(void)SetLanguage;
-(void)setProfileData;
-(void) redesignAdminInfoUI;
-(void) createBorderofView:(UIView *) view;
-(void)DesignInitialView;
-(void) removeComboview;
-(void) selectQuetion:(id) que;
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex;
-(void)removeChangeStatusView;
- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
-(void) setOfset;
-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index;
-(void)getResponce:(id)jsonData;
-(void)changePwdRequest;
-(void)getSecurityQuestion;
-(void)setAdminLoadLimit;
-(void)checkSecuritiQuestion;
//-(void)chagePwdSucess;
-(BOOL)checkEmptyTextField;
- (IBAction)clickChangePwdRequest:(id)sender;
- (IBAction)changeAdminLoadLimit:(id)sender;
@end

@implementation AdminProfileViewController
@synthesize adminProfileObj,AdminDataObj,adminLoadDataObj;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil admin:(BOOL)isAdmin
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        isAdminProfile = isAdmin;
        if(isAdminProfile == NO){
        addNavigationBar(ADMIN_PROFILE_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        }
        else
        {
        addNavigationBar(ADMIN_USERPROFILE_TITLE, NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
        }

        
    }
    return self;
}

-(void)openBack
{
    [self.navigationController popViewControllerAnimated:YES];
}
// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
   
    self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, 320, 480);
    [self DesignInitialView];
    // Do any additional setup after loading the view from its nib.
}
//method use for set langauge
-(void)SetLanguage
{

    self.btnChangePwd.titleLabel.text=languageSelectedStringForKey(@"Change Password");
    self.lblDailyLoadLimit.text=languageSelectedStringForKey(@"Daily Load Limit");
    self.lblMonthlyLoadLimit.text=languageSelectedStringForKey(@"Monthly Load Limit");
    self.lblBypassLoadLimit.text=languageSelectedStringForKey(@"Bypass Load Limits");
    self.btnUpdate.titleLabel.text=languageSelectedStringForKey(@"Update");
    self.lblPersonalDetail.text= languageSelectedStringForKey(@"Personal Detail");
    self.lblAddress.text=languageSelectedStringForKey(@"Address");
    self.lblLoadLimit.text=languageSelectedStringForKey(@"Load Limit");
}
//method use for set profile data
-(void)setProfileData
{
    self.lblEmailId.text=[NSString stringWithFormat:@"%@",checkISNullStrings(self.adminProfileObj.EMAIL_ID)?@"":self.adminProfileObj.EMAIL_ID];
    
    self.lblAddressLine1.text=[NSString stringWithFormat:@"%@",checkISNullStrings(self.adminProfileObj.AddressLine1)?@"":self.adminProfileObj.AddressLine1];
    
    self.lblAddressLine2.text=[NSString stringWithFormat:@"%@",checkISNullStrings(self.adminProfileObj.AddressLine2)?@"":self.adminProfileObj.AddressLine2];
    
    self.lblAddressLine3.text=[NSString stringWithFormat:@"%@%@%@%@",checkISNullStrings(adminProfileObj.City)?@"":[NSString stringWithFormat:@"%@ ",adminProfileObj.City],checkISNullStrings(adminProfileObj.State)?@"":[NSString stringWithFormat:@"%@",adminProfileObj.State],checkISNullStrings(adminProfileObj.Country)?@"":[NSString stringWithFormat:@"%@ ",adminProfileObj.Country],checkISNullStrings(adminProfileObj.ZIPCODE)?@"":[NSString stringWithFormat:@",%@ ",adminProfileObj.ZIPCODE]];
    
    if (isAdminProfile)
    {
        self.lblBusinessName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings([UserDetailClass sharedUser].UserName)?@"":[NSString stringWithFormat:@"%@ ",[UserDetailClass sharedUser].UserName],checkISNullStrings([UserDetailClass sharedUser].LastName)?@"":[NSString stringWithFormat:@"%@",[UserDetailClass sharedUser].LastName]];
        
        self.btnView.hidden=YES;
        self.lblUser.text=@"";
        
        self.lblLastLogin.text=[NSString stringWithFormat:@"%@",checkISNullStrings([UserDetailClass sharedUser].LAST_ACCESSED_AT)?@"":[UserDetailClass sharedUser].LAST_ACCESSED_AT];
        
        self.lblUser.text=[UserDetailClass sharedUser].strUserId;
        
        self.txtDaily.enabled = NO;
        self.txtMonthly.enabled = NO;
        self.txtSingle.enabled = NO;
        self.btnUpdateLimit.hidden = YES;
        self.swtLoadLimit.enabled = NO;
        self.scrollLoadLimit.scrollEnabled = NO;


    }else
    {
        
        self.txtDaily.enabled = YES;
        self.txtMonthly.enabled = YES;
        self.txtSingle.enabled = YES;
        self.btnUpdateLimit.hidden = NO;
        self.swtLoadLimit.enabled = YES;
        self.scrollLoadLimit.scrollEnabled = YES;
        
        
         self.lblBusinessName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings(AdminDataObj.FirstName)?@"":[NSString stringWithFormat:@"%@ ",AdminDataObj.FirstName],checkISNullStrings(AdminDataObj.LastName)?@"":[NSString stringWithFormat:@"%@",AdminDataObj.LastName]];
        
        self.btnView.hidden=NO;
        self.lblUser.text=[NSString stringWithFormat:@"%@",checkISNullStrings(self.AdminDataObj.UserId)?@"":self.AdminDataObj.UserId];
        
        self.lblLoadClientId.text=[NSString stringWithFormat:@"%@",checkISNullStrings(self.AdminDataObj.UserId)?@"":self.AdminDataObj.UserId];
        
         self.lblLastLogin.text=[NSString stringWithFormat:@"%@",checkISNullStrings(self.AdminDataObj.LAST_ACCESSED_AT)?@"":self.AdminDataObj.LAST_ACCESSED_AT];
    }
    
         
    self.lblBtnStatus.text=AdminStatusValue(self.AdminDataObj.UserStatus);
    
    self.lblUserDate.text=[NSString stringWithFormat:@"%@",checkISNullStrings(self.adminProfileObj.DOB)?@"":ConvertDateFormatemmddyyyy(self.adminProfileObj.DOB)];
    
    self.lblLoadBusinessName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings([UserDetailClass sharedUser].UserName)?@"":[NSString stringWithFormat:@"%@ ",[UserDetailClass sharedUser].UserName],checkISNullStrings([UserDetailClass sharedUser].LastName)?@"":[NSString stringWithFormat:@"%@",[UserDetailClass sharedUser].LastName]];
    
    self.lblLoadUserName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings(AdminDataObj.FirstName)?@"":[NSString stringWithFormat:@"%@ ",AdminDataObj.FirstName],checkISNullStrings(AdminDataObj.LastName)?@"":[NSString stringWithFormat:@"%@",AdminDataObj.LastName]];
    
    self.lblLoadStatus.text=AdminStatusValue(self.AdminDataObj.UserStatus);

    self.txtDaily.text=checkISNullStrings(self.adminLoadDataObj.DailyLoad)?@"":displayCurrency(ChangeTocurrency([self.adminLoadDataObj.DailyLoad doubleValue]));
    self.txtMonthly.text= checkISNullStrings(self.adminLoadDataObj.MonthlyLoad)?@"":displayCurrency(ChangeTocurrency([self.adminLoadDataObj.MonthlyLoad doubleValue]));
    self.txtSingle.text= checkISNullStrings(self.adminLoadDataObj.SingleLoad)?@"":displayCurrency(ChangeTocurrency([self.adminLoadDataObj.SingleLoad doubleValue]));
    
    
    for (UISwitch *swch in self.viewLoadLimit.subviews)
    {
        if (swch.tag==1)
        {
            [swch setOn:self.adminLoadDataObj.BypassLoadLimitsFlag animated:NO];
            switchOnOffValues=self.adminLoadDataObj.BypassLoadLimitsFlag;
        }
    }

}

// If index value is 129 based on Policy Mgmt access & Manage Admins access
-(void) redesignAdminInfoUI
{
    self.imgTop.hidden = YES;
    self.lblLoadLimit.hidden = YES;
    self.lblUserInfo.hidden = YES;
    
    self.btnUserInfo.hidden = YES;
    self.btnLoadLimit.hidden = YES;
    
    self.btnChangePwd.hidden = YES;
    
    [self.AdminScrollView setFrame:CGRectMake(0, 0, self.AdminScrollView.frame.size.width, self.AdminScrollView.frame.size.height)];
    
    [self.userDetailView setFrame:CGRectMake(0, 0, self.userDetailView.frame.size.width, self.userDetailView.frame.size.height)];
}

-(void) viewWillAppear:(BOOL)animated
{
    if ([AdminAccessInfo AdminAcess].mgmtPolicyAccessValue != MGMTPOLICYACCESS) {
        [self redesignAdminInfoUI];
    }
    else
    {
    if (isAdminProfile)
    {
        self.btnView.hidden = YES;
        self.btnChangePwd.hidden = NO;
        self.lblUserInfo.text =languageSelectedStringForKey(@"Admin Info");
    }
    else{
        self.btnView.hidden = NO;
        self.btnChangePwd.hidden = YES;
        self.lblUserInfo.text = languageSelectedStringForKey(@"User Info");
    }
    }
    [self SetLanguage];
    [self setProfileData];
}

-(void) createBorderofView:(UIView *) view
{
    view.layer.cornerRadius = 10;
    view.layer.masksToBounds = YES;
    view.layer.borderColor = Color132.CGColor;
    view.layer.borderWidth = 1.5f;

}
-(void)DesignInitialView
{
    self.AdminScrollView.maindelegate=self;
    self.scrollLoadLimit.maindelegate=self;
    
    self.userDetailView.frame=CGRectMake(0, CGRectGetMaxY(self.imgTop.frame)-15, 320, 440);
    [self.AdminScrollView addSubview:self.userDetailView];
    self.changePwdParentView.frame = CGRectMake(0, CGRectGetMaxY(self.imgTop.frame)-15, 320, 440);
    [self.AdminScrollView addSubview:self.changePwdParentView];
    self.changePwdParentView.hidden = YES;
    self.changePwdScrollView.contentSize = CGSizeMake(self.changePwdScrollView.frame.size.width, self.changePwdScrollView.frame.size.height+100);
    
    [self createBorderofView:self.viewPersonalDetail];
    [self createBorderofView:self.viewAddress];
    [self createBorderofView:self.changePasswordView];
    
    
    self.loadLimitCompleteView.frame=CGRectMake(320, CGRectGetMaxY(self.imgTop.frame)-30, 320, 440);
    [self.AdminScrollView addSubview:self.loadLimitCompleteView];
    
    if (!isAdminProfile) {
        self.loadLimitView.hidden = NO;
        self.scrollLoadLimit.frame=CGRectMake(0, 60, 320, 480);
    }
    else{
        self.loadLimitView.hidden = YES;
        self.scrollLoadLimit.frame=CGRectMake(0, 0, 320, 480);
    }

    
    [self.loadLimitCompleteView addSubview:self.scrollLoadLimit];
    [self.scrollLoadLimit setContentSize:CGSizeMake(320,600)];
    
    [self createBorderofView:self.viewLoadLimit];
    
  
    self.imgTop.image = [UIImage imageNamed:@"leftTabAct.png"];
    
    [self.AdminScrollView setContentSize:CGSizeMake(640,416)];
    
    self.AdminScrollView.contentOffset=CGPointMake(0, 0);
  
}
- (IBAction)clickedPwdSubmit:(id)sender {
}

- (IBAction)changeValueofSlider:(id)sender {
    
    UISwitch *sld = (UISwitch *)sender;
        
    switchOnOffValues = sld.on;
        
    showAlertWithOtherButtons(@"",languageSelectedStringForKey(@"Do you want to change the value?") , sld.tag, self);

}

-(void) removeComboview{
    if (comboParentView) {
        [comboParentView removeFromSuperview];
        [comboParentView release];
        comboParentView = nil;
    }
}
-(void) selectQuetion:(id) que
{
    secretQustionDataClass *obj=(secretQustionDataClass *)que;
    SelectedQuestionIndex=[obj.indexNo intValue];
    self.lblSecretQuetionPwd.textColor = [UIColor blackColor];
    self.lblSecretQuetionPwd.text = obj.secretQuestion;
    [self removeComboview];
}

#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 1) {
        if (buttonIndex == 1) {
            
            for (UISwitch *swch in self.viewLoadLimit.subviews)
            {
                if (swch.tag==1)
                {
                    [swch setOn:!switchOnOffValues animated:YES];
                    switchOnOffValues=!switchOnOffValues;
                }
                
            }
        }
    }
}

#pragma -mark UITextField Method

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isEqual:self.txtDaily]) {
        [self.txtMonthly becomeFirstResponder];
    }else if ([textField isEqual:self.txtMonthly])
    {
        [self.txtSingle becomeFirstResponder];
    }else if ([textField isEqual:self.txtSingle])
    {
        [self.txtSingle resignFirstResponder];
        [self setOfset];
    } else if([textField isEqual:self.txtOldPwd]){
        [self.txtNewPwd becomeFirstResponder];
        
    }else if([textField isEqual:self.txtNewPwd]){
        [self.txtConfirmPwd becomeFirstResponder];
        
    }else if([textField isEqual:self.txtConfirmPwd]){
        [self.txtConfirmPwd resignFirstResponder];
         self.changePwdScrollView.contentOffset = CGPointMake(0, 0);
        
    }else if([textField isEqual:self.txtSecretAnswer]){
        [self.txtSecretAnswer resignFirstResponder];
         self.changePwdScrollView.contentOffset = CGPointMake(0, 0);
    }
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([textField isEqual:self.txtDaily])
    {
        self.scrollLoadLimit.contentOffset=CGPointMake(0, 60);
//        self.txtDaily.text=@"";
    }else if ([textField isEqual:self.txtMonthly])
    {
        self.scrollLoadLimit.contentOffset=CGPointMake(0, 120);
//         self.txtMonthly.text=@"";
    }else if ([textField isEqual:self.txtSingle])
    {
        self.scrollLoadLimit.contentOffset=CGPointMake(0, 180);
//         self.txtSingle.text=@"";
    }else if([textField isEqual:self.txtOldPwd]){
        self.changePwdScrollView.contentOffset = CGPointMake(0, 0);
        
    }else if([textField isEqual:self.txtNewPwd]){
        self.changePwdScrollView.contentOffset = CGPointMake(0, 20);
        
    }else if([textField isEqual:self.txtConfirmPwd]){
        self.changePwdScrollView.contentOffset = CGPointMake(0, 100);
        
    }else if([textField isEqual:self.txtSecretAnswer]){
        self.changePwdScrollView.contentOffset = CGPointMake(0, 220);
    }

    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if([textField isEqual:self.txtDaily] || [textField isEqual:self.txtMonthly] || [textField isEqual:self.txtSingle]){
    return digitValidationOnNumKeyboard(textField,range,string);
    }
    else if([textField isEqual:self.txtOldPwd] || [textField isEqual:self.txtNewPwd] || [textField isEqual:self.txtConfirmPwd] || [textField isEqual:self.txtSecretAnswer]){
        return YES;
    }
    else
        return NO;
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if([textField isEqual:self.txtDaily] || [textField isEqual:self.txtMonthly] || [textField isEqual:self.txtSingle]){
    textField.text=[NSString stringWithFormat:@"%0.2f",changeTextToAmount(textField.text)];
    }
}

-(void)removeChangeStatusView
{
    [self removeComboview];
    
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (comboParentView) {
        [self removeComboview];
    }
    [self setOfset];
}

- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
     //[self setOfset];
}

// set page in previouse position
-(void) setOfset
{
    
    
       
    if (self.changePwdParentView.hidden == YES) {
        self.changePwdScrollView.contentOffset = CGPointMake(0, 0);
        [self.txtOldPwd resignFirstResponder];
        [self.txtNewPwd resignFirstResponder];
        [self.txtConfirmPwd resignFirstResponder];
        [self.txtSecretAnswer resignFirstResponder];
    }
     else{
    self.scrollLoadLimit.contentOffset=CGPointMake(0, 0);
    
    [self.txtSingle resignFirstResponder];
    [self.txtDaily resignFirstResponder];
    [self.txtMonthly resignFirstResponder];

}
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_userDetailView release];
    [_AdminScrollView release];
    [_imgTop release];
    [_viewPersonalDetail release];
    [_viewAddress release];
    [_lblUserInfo release];
    [_btnLoadLimit release];
    [_btnUserInfo release];
    [_lblLoadLimit release];
    [_viewLoadLimit release];
    [_loadLimitCompleteView release];
    [_scrollLoadLimit release];
    [_txtDaily release];
    [_txtMonthly release];
    [_txtSingle release];
    [_btnView release];
    [_lblBtnStatus release];
    [_imgArrow release];
    [_btnChangePwd release];
    [_lblUserDate release];
    [_loadLimitView release];
    [_lblChangePassword release];
    [_changePasswordView release];
    [_btnPasswordSubmit release];
    [_changePwdParentView release];
    [_changePwdScrollView release];
    [_lblChangePwdHeader release];
    [_lblOldChangPwdHeader release];
    [_lblConfirmPwdHeader release];
    [_txtOldPwd release];
    [_txtNewPwd release];
    [_txtConfirmPwd release];
    [_txtSecretAnswer release];
    [_lblSecretQuetionPwd release];
    [_lblPersonalDetail release];
    [_lblAddress release];
    [_lblMonthlyLoadLimit release];
    [_lblDailyLoadLimit release];
    [_lblSingleloadLimit release];
    [_lblBypassLoadLimit release];
    [_lblAddress release];
    [_btnUpdate release];
    [_lblBusinessName release];
    [_lblUserName release];
    [_lblEmailId release];
    [_lblLastLogin release];
    [_lblUser release];
    [_lblAddressLine1 release];
    [_lblAddressLine2 release];
    [_lblAddressLine3 release];
    [_lblLoadBusinessName release];
    [_lblLoadUserName release];
    [_lblLoadClientId release];
    [_lblLoadStatus release];
    [_bgView release];
    [_swtLoadLimit release];
    [_btnUpdateLimit release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setUserDetailView:nil];
    [self setAdminScrollView:nil];
    [self setImgTop:nil];
    [self setViewPersonalDetail:nil];
    [self setViewAddress:nil];
    [self setLblUserInfo:nil];
    [self setBtnLoadLimit:nil];
    [self setBtnUserInfo:nil];
    [self setLblLoadLimit:nil];
    [self setViewLoadLimit:nil];
    [self setLoadLimitCompleteView:nil];
    [self setScrollLoadLimit:nil];
    [self setTxtDaily:nil];
    [self setTxtMonthly:nil];
    [self setTxtSingle:nil];
    [self setBtnView:nil];
    [self setLblBtnStatus:nil];
    [self setImgArrow:nil];
    [self setBtnChangePwd:nil];
    [self setLblUserDate:nil];
    [self setLoadLimitView:nil];
    [self setLblChangePassword:nil];
    [self setChangePasswordView:nil];
    [self setBtnPasswordSubmit:nil];
    [self setChangePwdParentView:nil];
    [self setChangePwdScrollView:nil];
    [self setLblChangePwdHeader:nil];
    [self setLblOldChangPwdHeader:nil];
    [self setLblConfirmPwdHeader:nil];
    [self setTxtOldPwd:nil];
    [self setTxtNewPwd:nil];
    [self setTxtConfirmPwd:nil];
    [self setTxtSecretAnswer:nil];
    [self setLblSecretQuetionPwd:nil];
    [self setLblPersonalDetail:nil];
    [self setLblAddress:nil];
    [self setLblMonthlyLoadLimit:nil];
    [self setLblDailyLoadLimit:nil];
    [self setLblSingleloadLimit:nil];
    [self setLblBypassLoadLimit:nil];
    [self setLblAddress:nil];
    [self setBtnUpdate:nil];
    [self setLblBusinessName:nil];
    [self setLblUserName:nil];
    [self setLblEmailId:nil];
    [self setLblLastLogin:nil];
    [self setLblUser:nil];
    [self setLblAddressLine1:nil];
    [self setLblAddressLine2:nil];
    [self setLblAddressLine3:nil];
    [self setLblLoadBusinessName:nil];
    [self setLblLoadUserName:nil];
    [self setLblLoadClientId:nil];
    [self setLblLoadStatus:nil];
    [self setBgView:nil];
    [self setSwtLoadLimit:nil];
    [self setBtnUpdateLimit:nil];
    [super viewDidUnload];
}
//method called when  User Info button clicked
- (IBAction)userInfoClicked:(id)sender
{
    [self setOfset];
    self.imgTop.image = [UIImage imageNamed:@"leftTabAct.png"];
    self.AdminScrollView.contentOffset=CGPointMake(0, 0);
    self.changePwdParentView.hidden = YES;
    self.userDetailView.hidden = NO;
}
//method called when  Load Limit button clicked
- (IBAction)loadLimitClicked:(id)sender
{
    [self setOfset];
    self.changePwdParentView.hidden = YES;
    self.imgTop.image = [UIImage imageNamed:@"rightTabAct.png"];
    self.AdminScrollView.contentOffset=CGPointMake(320, 0);

       
}
-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index
{
    self.lblBtnStatus.text = languageSelectedStringForKey(question);
    [self removeComboview];
}
- (IBAction)clickedStatusBtn:(id)sender {
    
    
    comboParentView  = [[UIView alloc] initWithFrame:self.bgView.frame];
    comboParentView.backgroundColor = [UIColor clearColor];    
    [self.bgView addSubview:comboParentView];
    
    PopUpView *csv = [[PopUpView alloc] initWithAdminStatusViewFrame:CGRectMake(0, 0, 320, 480) CardData:1 Delegate:self];
    
    [comboParentView addSubview:csv];
    [csv release];

    
}
-(void)getResponce:(id)jsonData
{
    switch (requestId)
    {
        case getSecurityQuestion:
        {
            if ([jsonData count]>0)
            {
                
                if (!SecretQuestionArr) {
                    SecretQuestionArr=[[NSMutableArray alloc]init];
                }else
                {
                    [SecretQuestionArr removeAllObjects];
                }
                
                SecretQuestionArr=jsonData;
            }

            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;

        case change_Pwd:
        {
            LoginResponceDataClass *loginDataobj=(LoginResponceDataClass *)jsonData;
            
            if (loginDataobj.Error_Code==1)
            {
                [self chagePwdSucess :self.txtConfirmPwd.text];
                showAlertScreen(nil, loginDataobj.ErrorMsg);
            }else
            {
                showAlertScreen(nil, loginDataobj.ErrorMsg);
            }

            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
            
            case Check_SecurityQue:
        {
            LoginResponceDataClass *loginDataobj=(LoginResponceDataClass *)jsonData;
            
            if (loginDataobj.Error_Code==0)
            {
                [self changePwdRequest];
            }else
            {
                showAlertScreen(nil, loginDataobj.ErrorMsg);
                [[AppDelegate sharedAppDelegate] removeLoadingView];
            }

        }
            break;
            
            case Change_Admin_load_limit:
        {
            showAlertScreen(nil, jsonData);
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
        default:
            break;
    }
}

//method use for change Password Request
-(void)changePwdRequest
{
    requestId=change_Pwd;
    DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
    dataParsing.Datadelegate=self;
    [[AppDelegate sharedAppDelegate] addloadingView];
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Update_User_Reqest;
    
    [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deANAuserid=%@&deANAUsrOldPassword=%@&deANAUsrPassword=%@&deIVRSource=%@&deIVRIpAddress=&deIVRCallerId=&deIVRCalledId=&deIVRRequestTime=&deIVRSessionID=&deANASecOldQuestion=&deANASecOldAnswer=&deANASecQuestion=&deANASecAnswer=&deTCIVRDOB=&deBAEmailID=&de_AddressLine1=&de_AddressLine2=&deANACity=&de_Country=&de_State=&de_ZipCode=&deANAUpdateUserFlag=1&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, [SystemConfiguration sharedSystemConfig].dbbSystemSingleSignon,[SystemConfiguration sharedSystemConfig].dbbServiceName, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin, [UserDetailClass sharedUser].strUserId, self.txtOldPwd.text, self.txtNewPwd.text,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcUpdateNewUser];
    
    [dataParsing release];

}
//method use for get Security Question
-(void)getSecurityQuestion
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    requestId=getSecurityQuestion;
    DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
    dataParsing.Datadelegate=self;
    [[AppDelegate sharedAppDelegate] addloadingView];
    [SystemConfiguration sharedSystemConfig].dbbServiceName=CardLookUp_Request;
    
    [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=1&dbbServiceName=%@&deCIALutID=CMSecQuestion",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName] ServiceName:svcCCardLookUp];
    [dataParsing release];
}
//method use for set AdminLoad Limit
-(void)setAdminLoadLimit
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    requestId=Change_Admin_load_limit;
    DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
    dataParsing.Datadelegate=self;
    [[AppDelegate sharedAppDelegate] addloadingView];
    [SystemConfiguration sharedSystemConfig].dbbServiceName=loadAdminParameter;
    
 
    
    [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deLoadParameter_Acctid=%@&deLoadParameter_Type=User&deLoadParameterDailyLimit=%d&deLoadParameterDailyLoad=%@&deLoadParameterDailyLimitForDayTime=0&deMondayStartDate=&deMondayEndDate=&deTuesdayStartDate=&deTuesdayEndDate=&deWednesdayStartDate=&deWednesdayEndDate=&deThrusdayStartDate=&deThrusdayEndDate=&deFridayStartDate=&deFridayEndDate=&deSaturdayStartDate=&deSaturdayEndDate=&deSundayStartDate=&deSundayEndDate=&deLoadParameterMonthlyLimit=%d&deLoadParameterMonthlyLoad=%@&deLoadParameterSingleLimit=%d&deLoadparameterSingleLoad=%@&deBypassLoadLimitsFlag=%d&deIVRSource=MobileCoreMoney&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,(isAdminProfile?[UserDetailClass sharedUser].strUserId:self.AdminDataObj.UserId),([self.txtDaily.text isEqualToString:@"0.00"]||[self.txtDaily.text isEqualToString:@"$0.00"]?0:1),[NSString stringWithFormat:@"%@",checkISNullStrings(self.txtDaily.text)?@"0.00":self.txtDaily.text],([self.txtMonthly.text isEqualToString:@"0.00"]||[self.txtMonthly.text isEqualToString:@"$0.00"]?0:1),[NSString stringWithFormat:@"%@",checkISNullStrings(self.txtMonthly.text)?@"0.00":self.txtMonthly.text],([self.txtSingle.text isEqualToString:@"0.00"]||[self.txtSingle.text isEqualToString:@"$0.00"]?0:1),[NSString stringWithFormat:@"%@",checkISNullStrings(self.txtSingle.text)?@"0.00":self.txtSingle.text],switchOnOffValues] ServiceName:svcLoadParameter];
    
    [dataParsing release];
}

//method use for check security Question
-(void)checkSecuritiQuestion
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    requestId=Check_SecurityQue;
    DataParsingClass *dataParsing=[[DataParsingClass alloc] init];
    dataParsing.Datadelegate=self;
    [[AppDelegate sharedAppDelegate] addloadingView];
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Check_Security_Que;
    
    [dataParsing SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&dbbSystemSingleSignon=1&dbbServiceName=%@&deANAuserid=%@&deANASecQuestion=%d&deANASecAnswer=%@&deSetFlagValue_BankAct=0&deTCIVRValidateInfoDOB=&deBAEmailID=&deIVRSource=%@&deIVRIpAddress=&deIVRCallerId=&deIVRCalledId=&deIVRRequestTime=&deIVRSessionID=&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[UserDetailClass sharedUser].strUserId,SelectedQuestionIndex,self.txtSecretAnswer.text,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCheckSecretQuestion];
    [dataParsing release];
}

- (IBAction)clickedChangePwd:(id)sender
{
    [self getSecurityQuestion];
    
    self.changePwdParentView.hidden = NO;
    self.userDetailView.hidden = YES;
        
}

-(void)chagePwdSucess :(NSString *)newPwd
{
    [UserDetailClass sharedUser].StrPassword=newPwd;
    self.changePwdParentView.hidden = YES;
    self.userDetailView.hidden = NO;

}
// Open secrete question view

- (IBAction)openSecretQuestionCombo:(id)sender
{
    comboParentView  = [[UIView alloc] initWithFrame:self.bgView.frame];
    
    comboParentView.backgroundColor = [UIColor clearColor];
    
    [self.bgView addSubview:comboParentView];
    self.changePwdScrollView.contentOffset = CGPointMake(0, 130) ;
    ComboViewController *comView = [[ComboViewController alloc] initWithFrame:CGRectMake(20, 233, 280, 150) records:SecretQuestionArr callingClassType:selectQuestion];
    comView.delegate = self;
    [comboParentView addSubview:comView];
}

// check text field
-(BOOL)checkEmptyTextField
{
     if ([self.txtOldPwd.text length]==0){
        showAlertScreen(@"Old Password", @"Please Enter Old Password");
        return YES;
    }
    else if ([self.txtNewPwd.text length]==0)
    {
        showAlertScreen(@"New Password", @"Please Enter New Password");
        return YES;
    }
    else if ([self.txtConfirmPwd.text length]==0)
    {
        showAlertScreen(@"Confirm Password", @"Please Enter Confirm Password");
        return YES;
    }
    else if (![self.txtNewPwd.text isEqualToString: self.txtConfirmPwd.text])
    {
        showAlertScreen(@"Password not match", @"Confirm password not matched");
        return YES;
    }else if ([self.lblSecretQuetionPwd.text isEqualToString:@"Secret question"]){
        showAlertScreen(@"Question", @"Please Select Question");
        return YES;
    }
    else if ([self.txtSecretAnswer.text length]==0) {
        [self.txtSecretAnswer becomeFirstResponder];
        showAlertScreen(@"Answer", @"Please Give answer");
        return YES;
    }
    
    return NO;
}
- (IBAction)clickChangePwdRequest:(id)sender
{
    if (![self checkEmptyTextField])
    {
        [self checkSecuritiQuestion];
    }
}
//method use for change AdminLoad Limit
- (IBAction)changeAdminLoadLimit:(id)sender
{
    
    [self setAdminLoadLimit];
}
@end
