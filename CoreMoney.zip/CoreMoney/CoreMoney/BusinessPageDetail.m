//
//  BusinessPageDetail.m
//  CoreMoney


// Class used for hold data of business summary.

#import "BusinessPageDetail.h"

@implementation BusinessPageDetail
@synthesize ACCTID, ADDRESS1, ADDRESSLINE2, AccountNumber, Account_Billing, ActiveAdmins, AvailableBalance, BToBTransfer, BlockedCards, BusinessCurrentBalance, BusinessDesignation, BusinessMTDCardSpend, BusinessName, BusinessTotalAvailableCardBalance, BusinessTotalAvailableFunds, BusinessTotalCurrentCardBalance, BusinessTotalPendingCreditTransactions, BusinessTotalPendingDebitTransactions, BusinessYTDCardSpend, Business_ID_Desc, CARDLINE4, CARD_STATUS, CITY, COUNTRY, CRAD_LIMIT, CURRENT_BALANCE, DATE_APPROVED, DDANumber, DateOfIncorporation, EMAIL_ADDRESS1, FIRST_NAME, HOME_PHONE, HomeFaxNumber, InactiveCards, IsEnrollmentFeePaid, LANGUAGE_INDICATOR, LAST_NAME, LastAdminLogin, LastCreditTransferDate, LastDebitTransferDate, LastTransfer, MAX_LOAD_AMT, NumberOfCards,  OD_AMT, OwningPartner, PHONEEXTENSION, PRODUCT_PARENT, Parent_Bussiness, PendingCardTxns, STATE, TaxId, URL, WAREHOUSED_AMOUNT, WaiveEnrollmentFee, ZIP_CODE, UnusedBudget;

-(void)dealloc
{
    self.ACCTID=nil;
    self.ADDRESS1=nil;
    self.ADDRESSLINE2=nil;
    self.AccountNumber=nil;
    self.Account_Billing=nil;
    self.BusinessDesignation=nil;
    self.BusinessName=nil;
    self.Business_ID_Desc=nil;
    self.CARDLINE4=nil;
    self.CITY=nil;
    self.COUNTRY=nil;
    self.DATE_APPROVED=nil;
    self.DDANumber=nil;
    self.DateOfIncorporation=nil;
    self.EMAIL_ADDRESS1=nil;
    self.FIRST_NAME=nil;
    self.HOME_PHONE=nil;
    self.HomeFaxNumber=nil;
    self.LANGUAGE_INDICATOR=nil;
    self.LAST_NAME=nil;
    self.LastAdminLogin=nil;
    self.LastCreditTransferDate=nil;
    self.LastDebitTransferDate=nil;
    self.OwningPartner=nil;
    self.PHONEEXTENSION=nil;
    self.PRODUCT_PARENT=nil;
    self.Parent_Bussiness=nil;
    self.STATE=nil;
    self.TaxId=nil;
    self.URL=nil;
    self.WAREHOUSED_AMOUNT=nil;
    self.WaiveEnrollmentFee=nil;
    self.ZIP_CODE=nil;

    
    [super dealloc];
}
@end
