//
//  SlideMenuCell.h
// Class to design Slide menu cell.

#import <UIKit/UIKit.h>

@interface SlideMenuCell : UITableViewCell
{
    UILabel *lblTitle,*lblValue;
    UIImageView *imgMenu,*imgColorView;
    
}
@property(nonatomic,retain) UIImageView *imgMenu,*imgColorView;
@property(nonatomic,retain) UILabel *lblTitle,*lblValue;
@end
