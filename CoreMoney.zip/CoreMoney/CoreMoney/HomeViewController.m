//
//  HomeViewController.m
//
// Class used to design the Home Page.

#import "HomeViewController.h"
#import "ChangePasswordViewController.h"
#import "HomeCell.h"
#import "CardListViewController.h"
#import "BusinessSummaryViewController.h"
#import "TransferViewController.h"
#import "AdminListViewController.h"
#import "AdministrationViewController.h"
#import "ExpenseAnalysisViewController.h"
#import "AlertsDetailViewController.h"

@interface HomeViewController ()
-(void)openSlide;
-(void) addObjectToArray:(NSString *) imgName Label:(NSString *)lblString;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(void)getResponce:(id)jsonData;
-(void)getRequest;
-(void)designHomeView;
-(void)OpenChangePassword;
@end

@implementation HomeViewController

// Method to open slide menu.
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO) {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else{
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}
// Method to initialise the cell array.
-(void) addObjectToArray:(NSString *) imgName Label:(NSString *)lblString
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:imgName forKey:@"imgName"];
    [dict setObject:languageSelectedStringForKey(lblString) forKey:@"lblString"];
    
    [cellArray addObject:dict];
    [dict release];
}
// Delegate method of scroll view called when scroll view scroller.
// Method used to get the index of the selected view.
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat pageWidth =self.myTopScrollView.frame.size.width;
    [AppDelegate sharedAppDelegate].HomePageIndexNo = floor((self.myTopScrollView.contentOffset.x - pageWidth / 3) / pageWidth) + 1;
    if ([AppDelegate sharedAppDelegate].HomePageIndexNo==0) {
        self.leftView.hidden=YES;
        self.rightView.hidden=NO;
    }
    else if ([AppDelegate sharedAppDelegate].HomePageIndexNo == [[AppDelegate sharedAppDelegate].arrBusinessData count]-1)
    {
        self.leftView.hidden=NO;
        self.rightView.hidden=YES;
    }
    else{
        self.leftView.hidden=NO;
        self.rightView.hidden=NO;
    }
        [self setScrollViewLeftRightIndicator];

}
#pragma mark - View Designing Methods.
// Method called to load xib.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        addNavigationBar(HOME_TITLE, NAV_LEFT_NONE, NAV_RIGHT_SLIDE, self);

        
        cellArray = [[NSMutableArray alloc] init];
        
        [self addObjectToArray:@"img_business_home" Label:@"Business Summary"];
        [self addObjectToArray:@"img_cards_home" Label:@"Cards"];
        if ([AdminAccessInfo AdminAcess].initiateTransferValue == INITIATETRANSFER || [AdminAccessInfo AdminAcess].viewTransferValue == VIEWTRANSFER)
        {
            [self addObjectToArray:@"img_transfer_home" Label:@"Transfers"];
        }
        if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS)
        {
            [self addObjectToArray:@"img_administration_home" Label:@"Administration"];
        }
        if ([AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS)
        {
            [self addObjectToArray:@"expenceanalysis" Label:@"Expense Analysis"];
        }
        //        if (IS_IPAD) {
//            float posX = [AppDelegate sharedAppDelegate].screenWidth;
//            float posY = [AppDelegate sharedAppDelegate].screenHeight;
//            self.myHomeView.center = CGPointMake(posX, posY+200);
//        }
        
        // Custom initialization
        
//        if ([AppDelegate sharedAppDelegate].isNotification == YES) {
//            [[AppDelegate sharedAppDelegate] addloadingView];
//            RequestID = Alert_Detail;
//            [self getRequest];
//        }
    }
    return self;
}

// Method for the view to load.
- (void)viewDidLoad
{

    self.navigationController.navigationBarHidden=NO;
    
    self.myHomeView.frame=CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, 320, 460);
    
//    if (IS_IOS7) {
//        self.myHomeView.frame = CGRectMake(0,60 , 320, 460);
//    }
//    else if(IS_IPAD)
//    {
//        self.myHomeView.frame = CGRectMake(0,20 , 320, 460);
//    }
//    else
//    {
//        self.myHomeView.frame = CGRectMake(0,0 , 320, 460);
//    }
    
    [self.view addSubview:self.myHomeView];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
// Method for the view to appear.
-(void) viewWillAppear:(BOOL)animated
{
    if ([AppDelegate sharedAppDelegate].HomePageIndexNo==0)
    {
        self.leftView.hidden=YES;
    }
    
   
    [AppDelegate sharedAppDelegate].classType=HOME_PAGE;
    [self.navigationController setNavigationBarHidden:NO];
//    NavigationBarStyle();
  
    //addNavigationBar(HOME_TITLE, NAV_LEFT_NONE, NAV_RIGHT_SLIDE, self);
//    if ([ [AppDelegate sharedAppDelegate].arrBusinessData count]==0)
//    {
//          [[AppDelegate sharedAppDelegate] addloadingView];
//        [self getRequest];
//    }else
//    {
        [self designHomeView];
//    }
    [self.myTopScrollView setContentOffset:CGPointMake(320*[AppDelegate sharedAppDelegate].HomePageIndexNo, 0)];
    [self setScrollViewLeftRightIndicator];
    [super viewWillAppear:animated];
}
-(void) setScrollViewLeftRightIndicator
{
    float fltContentOffsetX = self.myTopScrollView.contentOffset.x;
    float fltContentSizeWidth = self.myTopScrollView.contentSize.width;
    CGFloat pageWidth =self.myTopScrollView.frame.size.width;
    
    (fltContentSizeWidth - (fltContentOffsetX + pageWidth)  == 0) ? (self.rightView.hidden = YES):(self.rightView.hidden = NO);
    fltContentOffsetX > 0 ? (self.leftView.hidden = NO) : (self.leftView.hidden = YES);
    
}

#pragma mark - Response Methods
// Delegate methods of request class to get response data
-(void)getResponce:(id)jsonData
{
    
    switch (RequestID) {
        case cardList:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]>0)
                {
                    if (![AppDelegate sharedAppDelegate].arrCardDetailArray)
                    {
                        [AppDelegate sharedAppDelegate].arrCardDetailArray = [[NSMutableArray alloc] init];
                        
                    }else
                    {
                        [[AppDelegate sharedAppDelegate].arrCardDetailArray removeAllObjects];
                        
                    }
                    
                    [AppDelegate sharedAppDelegate].arrCardDetailArray=jsonData;
                    
                    CardListViewController *clvc = [[CardListViewController alloc] init];
                    
                    [self.navigationController pushViewController:clvc animated:YES];
                    [clvc release];
                }else
                {
                    showAlertScreen(@"No Records", @"There is no card Available for the Account.");
                }
            }else
            {
                showAlertScreen(nil, jsonData);
            }
            
            [[AppDelegate sharedAppDelegate] removeLoadingView];

        }
            break;
            
        case transfer_list:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]==0)
                {
//                    showAlertScreen(nil, @"No record Found");
                }else
                {
                    if (![AppDelegate sharedAppDelegate].Arraytransfer) {
                        [AppDelegate sharedAppDelegate].Arraytransfer=[[NSMutableArray alloc]init];
                    }else
                    {
                        [[AppDelegate sharedAppDelegate].Arraytransfer removeAllObjects];
                    }
                    
                    [AppDelegate sharedAppDelegate].Arraytransfer=jsonData;
                    
                   
                }
            }
            TransferViewController *tvc = [[TransferViewController alloc] initWithNibName:@"TransferViewController" bundle:nil];
            [self.navigationController pushViewController:tvc animated:YES];
            [tvc release];
            
            [[AppDelegate sharedAppDelegate] removeLoadingView];
        }
            break;
            
        case Bank_list:
        {

            if ([jsonData isKindOfClass:[NSArray class]])
            {
                if ([jsonData count]==0)
                {
//                    showAlertScreen(nil, @"No record Found");
                }else
                {
                    if (![AppDelegate sharedAppDelegate].ArraybankList) {
                        [AppDelegate sharedAppDelegate].ArraybankList=[[NSMutableArray alloc]init];
                    }else
                    {
                        [[AppDelegate sharedAppDelegate].ArraybankList removeAllObjects];
                    }
                    
                    [AppDelegate sharedAppDelegate].ArraybankList=jsonData;
                    
                }
            }else
            {
//                showAlertScreen(nil, jsonData);
            }
            
            [[AppDelegate sharedAppDelegate] removeLoadingView];
            
            RequestID=transfer_list;
            
            [self getRequest];
        }
            break;
        case Alert_Detail:
        {
            if ([jsonData isKindOfClass:[NSArray class]]) {
                
                
                if ([jsonData count]>0)
                {
                    AlertsDetailViewController *advc = [[AlertsDetailViewController alloc] initWithNibName:@"AlertsDetailViewController" bundle:nil alertType:[AppDelegate sharedAppDelegate].notificationTag array:jsonData alertGroup:RedAlert];
                    [self.navigationController pushViewController:advc animated:YES];
                    [advc release];
                    
                    [AppDelegate sharedAppDelegate].isNotification = NO;
                    [[AppDelegate sharedAppDelegate] removeLoadingView];
                }
                
            }
            else
            {
                showAlertScreen(@"", @"No records found");
            }

           
        }
            break;
            
        case back_HomePage:
        {
            if ([jsonData isKindOfClass:[NSArray class]]) {
                
                if (![AppDelegate sharedAppDelegate].arrBusinessData)
                {
                    [AppDelegate sharedAppDelegate].arrBusinessData=[[NSMutableArray alloc] init];
                }
                else
                {
                    [[AppDelegate sharedAppDelegate].arrBusinessData removeAllObjects];
                }
                [AppDelegate sharedAppDelegate].arrBusinessData=jsonData;
                    [self designHomeView];
            }
            else
            {
                showAlertScreen(@"", @"No records found");
            }
            
            
        }
            break;
        
        default:
            break;
    }
    
}

-(void)getRequest
{
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    BusinessPageDetail *BusinessPageObject =[[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:[AppDelegate sharedAppDelegate].HomePageIndexNo];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    switch (RequestID) {
        case cardList:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=%@&deBsAccountNumber=&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=&deBusinessName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,BusinessPageObject.BusinessName, [SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBACardHolderList];
        }
            break;            
        case transfer_list:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=ViewTransferDetail_Request;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&deBABussinessAccAcctId=&deProductid=%@&deTCIVRNOOFTRANSACTIONS=&deTCIVRLASTTRANSACTION=&deBAOriginSource=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,checkISNullStrings(BusinessPageObject.BusinessName)?@"":BusinessPageObject.BusinessName,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBAViewTransferDetail];
        }
            break;
        case Bank_list:
        {
            [SystemConfiguration sharedSystemConfig].dbbServiceName=GetExternal_Bank_list;
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deBABusinessAccAcctId=%@&deBABussinessAccountNum=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,checkISNullStrings(BusinessPageObject.ACCTID)?@"":BusinessPageObject.ACCTID ,checkISNullStrings(BusinessPageObject.BusinessName)?@"":BusinessPageObject.BusinessName,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBAExternalBankList];
        }
            break;
        case Alert_Detail:
        {
            if ([AppDelegate sharedAppDelegate].notificationTag == Card_Pending_Activation_Alert) {
                [SystemConfiguration sharedSystemConfig].dbbServiceName=CardHolderList_Request;
                [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
                
                [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=&deCIAPrimaryAccountNumber=&deCIAAccountNumber=&deCIAFirstName=&deCIAMiddleName=&deCIALastName=&deCIASSN=&deCIAFeild1=&deCIAFeild2=&deCIAFeild3=&deCIAFeild4=&deCIAFeild5=&deCIAEmbAcctid=&deCIASteps=&deCIACity=&deCIAState=&deCIACountryOfIssue=&deCIAAddressLine1=&deCIAAddressLine2=&deCIAApartmentNumber=&deCIAPostalCode=&deANAProductID=&deBsAccountNumber=&DE_Email1=&deCM_CustomAccountID=&dePAcctCrt_SecondLastName_CNB=&deVersion_CS=&deCIASTranID=&DE_MobilePhoneNumber=&DE_HomePhoneNumber=&DE_OfficePhoneNumber=&deAgentID=&deCIACardStatus=%d&deBusinessName=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,Pending_CARD,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBACardHolderList];
                
            }
            else{
                
                [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
                [SystemConfiguration sharedSystemConfig].dbbServiceName=ALERT_DISPLAY_REQUEST;
                
                [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deANAuserid=%@&deAlertType=%d&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[AppDelegate sharedAppDelegate].notificationTag,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcSpendCardBAAlertDisplay];
                
                
                
            }

        }
            break;
        case back_HomePage:
        {
            
            [SystemConfiguration sharedSystemConfig].dbbServiceName=Business_Search_Request;
            [SystemConfiguration sharedSystemConfig].deFlagShowDetails=@"1";
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"User=%@&Password=%@&dbbSystemExtLogin=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&dePPProductParent=&deBusinessName=&deCIASDDANumber=&deAADAccountNumber=&dePPCardStatus=&deCIASFirstName=&deCIASLastName=&deCIAAddressLine1=&deCIAAddressLine2=&deCIASCity=&deCIASState=&deCIASCountry=&deCIASZipCode=&deBSAcctId=&deFlagShowDetails=%@&deRequestBatchSize=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[SystemConfiguration sharedSystemConfig].deFlagShowDetails,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcBusinessAccountSearch];
            
        }
            break;

      
        default:
            break;
    }
    
        
    [DataReq release];
}

// Method to design home view.
-(void)designHomeView
{
        
    int viewHeight = 102,viewWidth = 320;
    int xPos = 0,yPos=0;
    HomeView *homeSlabView;
    for (int i = 0; i< [[AppDelegate sharedAppDelegate].arrBusinessData count]; i++)
    {
        BusinessPageDetail *homeObj = [[AppDelegate sharedAppDelegate].arrBusinessData objectAtIndex:i];
        
        homeSlabView = [[HomeView alloc] initWithFrame:CGRectMake(xPos, yPos, viewWidth, viewHeight)];
        
        homeSlabView.lblUserName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings([UserDetailClass sharedUser].UserName)?@"":[NSString stringWithFormat:@"%@ ",[UserDetailClass sharedUser].UserName],checkISNullStrings([UserDetailClass sharedUser].LastName)?@"":[NSString stringWithFormat:@"%@",[UserDetailClass sharedUser].LastName]];
        
        
        homeSlabView.lblBusinessName.text=[NSString stringWithFormat:@"%@",checkISNullStrings(homeObj.Business_ID_Desc)?@"":[NSString stringWithFormat:@"%@ ",homeObj.Business_ID_Desc]];
        
        homeSlabView.lblLastLogin.text=checkISNullStrings([UserDetailClass sharedUser].LAST_ACCESSED_AT)?[NSString stringWithFormat:@"01/01/2000 12:00:00"]:[UserDetailClass sharedUser].LAST_ACCESSED_AT;
        
        homeSlabView.lblAmount.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(homeObj.AvailableBalance))];
        
        [self.myTopScrollView addSubview:homeSlabView];
        xPos=CGRectGetMaxX(homeSlabView.frame);
        [homeSlabView release];
        
    }
    [self.myTopScrollView setContentSize:CGSizeMake(xPos, viewHeight)];
    //[self.myHomeView addSubview:self.myTopScrollView];
    //[self.myHomeView addSubview:self.leftView];
    //[self.myHomeView addSubview:self.rightView];
    [[AppDelegate sharedAppDelegate] removeLoadingView];
}
// methods use for create administration view
-(void) createAdministration
{
    AdministrationViewController *alvc = [[AdministrationViewController alloc] initWithNibName:@"AdministrationViewController" bundle:nil];
    
    [self.navigationController pushViewController:alvc animated:YES];
    [alvc release];
}

// Method to open change password view controller.
-(void)OpenChangePassword
{
    ChangePasswordViewController *cvc=[[ChangePasswordViewController alloc] initWithNibName:@"ChangePasswordViewController" bundle:nil];
    UINavigationController *navController=[[UINavigationController alloc] initWithRootViewController:cvc];
    [self presentModalViewController:navController animated:YES];
    [cvc release];
    [navController release];
}

#pragma mark- Table View Delegates
// Delegate method to set the number of sections in table.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
// Delegate method to set the height of the cell.
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 48;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [cellArray count];
}
// Delegate method to design the cell.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"Cell";
	HomeCell *cell = (HomeCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[HomeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    NSMutableDictionary *dict = [cellArray objectAtIndex:indexPath.row];
    
    
    cell.lblName.text=[dict objectForKey:@"lblString"];
    cell.cellImage.image=[UIImage imageNamed:[dict objectForKey:@"imgName"]];
    cell.lblName.textColor=[UIColor blackColor];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        return cell;
}

// Delegate method called when the row selects.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    int rowSelected = indexPath.row;
    if (rowSelected > 1 && ([AdminAccessInfo AdminAcess].initiateTransferValue != INITIATETRANSFER && [AdminAccessInfo AdminAcess].viewTransferValue != VIEWTRANSFER))
    {
        rowSelected++;
    }
    if (rowSelected > 2 && [AdminAccessInfo AdminAcess].adminPageAccessValue != ADMINPAGEACCESS) {
        rowSelected++;
    }
    if (rowSelected > 3 && [AdminAccessInfo AdminAcess].reportAccessValue != REPORTACCESS) {
        rowSelected++;
    }
    switch (rowSelected) {
        case BUSINESS_SUMMARY_BUTTON:
        {
            // Code to open Business summary page.
            BusinessSummaryViewController *businessObj=[[BusinessSummaryViewController alloc]init];
            
            [self.navigationController pushViewController:businessObj animated:YES];
            [businessObj release];
        }
            break;
        case CARDS_LIST_BUTTON:
        {
            // Code to open card list page.
            [[AppDelegate sharedAppDelegate] addloadingView];
            RequestID=cardList;
            [self getRequest];
        }
            break;
        case TRANSFERS_BUTTON:
        {
            // If Initiate Transfer Access Value is 170 or View Transfer Value is 171 than only
            // user can view transfer option page
            
            if ([AdminAccessInfo AdminAcess].initiateTransferValue == INITIATETRANSFER || [AdminAccessInfo AdminAcess].viewTransferValue == VIEWTRANSFER) {
                [[AppDelegate sharedAppDelegate] addloadingView];
                RequestID=Bank_list;
                [self getRequest];
            }
        }
            break;
        case ADMINISTRATION_BUTTON:
        {
            // If index value is 129 then user can view admin page. Else admin option will not be visible for that user.
            if ([AdminAccessInfo AdminAcess].adminPageAccessValue == ADMINPAGEACCESS) {
                [self createAdministration];
            }
        }
            break;
        case EXPENSE_ANALYSIS_BUTTON:
        {
            if ([AdminAccessInfo AdminAcess].reportAccessValue == REPORTACCESS)
            {
                ExpenseAnalysisViewController *alvc = [[ExpenseAnalysisViewController alloc] initWithNibName:@"ExpenseAnalysisViewController" bundle:nil];
                
                [self.navigationController pushViewController:alvc animated:YES];
                [alvc release];
            }
           
            
        }
            break;
        default:
            break;
    }
}
#pragma mark - View Related Methods
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
// Method to release the memory of the allocated objects.
- (void)dealloc {
    if ([cellArray count]>0) {
        [cellArray removeAllObjects];
        [cellArray release];
        cellArray=nil;
    }
    if ([[AppDelegate sharedAppDelegate].arrBusinessData count]>0) {
        [[AppDelegate sharedAppDelegate].arrBusinessData removeAllObjects];
        [[AppDelegate sharedAppDelegate].arrBusinessData release];
        [AppDelegate sharedAppDelegate].arrBusinessData=nil;
    }
    [_tblView release];
    [_myHomeView release];
    [_myTopScrollView release];
    [_leftView release];
    [_rightView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setTblView:nil];
    [self setMyHomeView:nil];
    [self setMyTopScrollView:nil];
    [self setLeftView:nil];
    [self setRightView:nil];
    [super viewDidUnload];
}

@end
