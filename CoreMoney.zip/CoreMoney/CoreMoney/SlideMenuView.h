//
//  SlideMenuView.h

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import "DataParsingClass.h"
#import "ExpenseAnalysisViewController.h"
#import "adminLoadLimitDataClass.h"
@interface SlideMenuView : NSObject<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UIGestureRecognizerDelegate,DataParsingDelegate>
{
    UIView *menuView,*dummyView;
    UITableView *tblMenu;
    BOOL isAnimate,isFirstTime;
    NSString *barCodeString;
    UIView *searchTopView;
    UITextField *txtSearchField;
    NSMutableArray *arrSlideMenuData;
    int pageName;
    UILabel *lblSlideTitle;
    pageType selectedPageType;
    AutoMaticFunding autoMaticfundReqType;
    
    lowBalanceSearchDataClass *lowBalanceSearchObj;
    
    int transfer_request, analysisRequest, selfprofile;
    NSMutableArray *arrBusinessList, *arrEmployeeList, *arrCategoryList;
    adminLoadLimitDataClass *adminLoadObj;
}
@property (nonatomic, retain) NSMutableArray *arrSlideMenuData;
@property (nonatomic, assign) int pageName;

-(void)createMenuView;
+ (SlideMenuView*)sharedManager;
-(void)showMenuWithPageType :(pageType)page;
-(void)hideMenu;
@end
