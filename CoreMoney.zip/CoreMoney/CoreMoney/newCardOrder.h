//
//  newCardOrder.h
//  CoreMoney

#import <Foundation/Foundation.h>

@interface newCardOrder : NSObject
{
    NSString *ResErrorMsg, *ORDER_ID;
    int ResCode;
}

@property (nonatomic,retain) NSString *ResErrorMsg, *ORDER_ID;
@property  int ResCode;
@end
