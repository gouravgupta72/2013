//
//  newCardOrder.m
//  CoreMoney


#import "newCardOrder.h"

@implementation newCardOrder

@synthesize  ResCode,ResErrorMsg,ORDER_ID;

@end
