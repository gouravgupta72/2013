//
//  RegistrationViewController.m

//


// Class for creating Registration View.

#import "RegistrationViewController.h"
#import "HelpMenu.h"
@interface RegistrationViewController ()

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(void) changeTextIntoselectLang;
-(void) changeLaguageAtRegister;
-(void)createAccountRequest;
-(void)sendCreateAccountRequest;

-(void)checkEmptyTextField;
-(void)openDone;
-(void) openBack;
-(void)varifyData;
- (BOOL)validateFirstName:(UITextField *)firstNameField;
- (BOOL)validateLastName:(UITextField *)lastNameField;
- (BOOL)validateEmailField:(UITextField *)emailAddressField;

- (BOOL)validateVerifyEmailField:(UITextField *)verifyEmailField;
- (BOOL)validateEmailAndPassword:(UITextField *)passwordField;
@end

@implementation RegistrationViewController
@synthesize emailID;

// Initialize Registration View.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
//        self.title = REGISTRATION_TITLE;
        
        addNavigationBar(REGISTRATION_TITLE, NAV_LEFT_BACK, NAV_RIGHT_DONE, self);
        self.navigationItem.leftBarButtonItem.title = languageSelectedStringForKey(@"Cancel");
        self.navigationItem.rightBarButtonItem.title =languageSelectedStringForKey(@"Done");
        // Custom initialization
        
//        UIButton *btnLeft = [[UIButton alloc] init];
//        [btnLeft setTitle:@"Cancel" forState:UIControlStateNormal];
//        [btnLeft setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//        [btnLeft setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        
    }
    return self;
}

- (void)viewDidLoad
{
    HelpMenu *obj=[[HelpMenu alloc]initWithFrame:CGRectMake(0, 385, 320, 51)];
    obj.delegateReg= self;
    [self.pagescroll addSubview:obj];
    [obj release];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    
    [_txtConfirmPassword release];
    [_txtEmail release];
    [_txtFirstName release];
    [_txtLastName release];
    [_txtPassword release];
    [_txtVarifyEmail release];
    [_pagescroll release];
    [_lblName release];
    [_lblEmail release];
    [_lblPassword release];
    [_myRegistrationView release];
    [super dealloc];
}


-(void) viewWillAppear:(BOOL)animated
{
    _myRegistrationView.frame=CGRectMake(0, IS_IPAD?5:-10, [AppDelegate sharedAppDelegate].screenWidth, [AppDelegate sharedAppDelegate].screenHeight-[AppDelegate sharedAppDelegate].naviGationController.navigationBar.frame.size.height+20);
    [AppDelegate sharedAppDelegate].classType = REGISTRATION_PAGE;
    [self.navigationController setNavigationBarHidden:NO];
//      NavigationBarStyle();
    [self changeTextIntoselectLang];
    
}
// change word ni to select language
-(void) changeTextIntoselectLang
{
    self.lblName.text = languageSelectedStringForKey(@"name");
    self.lblEmail.text = languageSelectedStringForKey(@"Email Address");
    self.lblPassword.text = languageSelectedStringForKey(@"password");
    self.txtFirstName.placeholder = languageSelectedStringForKey(@"first_name");
    self.txtLastName.placeholder = languageSelectedStringForKey(@"last_name");
    self.txtEmail.placeholder = languageSelectedStringForKey(@"email");
    self.txtVarifyEmail.placeholder = languageSelectedStringForKey(@"varify");
    self.txtPassword.placeholder = languageSelectedStringForKey(@"password");
    self.txtConfirmPassword.placeholder = languageSelectedStringForKey(@"confirm_password");
    
}

 //select language delegate method
-(void) changeLaguageAtRegister
{
    [self changeTextIntoselectLang];
}
 //send request to server for create account
-(void)createAccountRequest
{
//    Request *req=[[Request alloc] init];
//    req.delegate=self;
//    [req request:REGITER_ACTION Parameter:[NSString stringWithFormat:@"firstname=%@&lastname=%@&email=%@&password=%@",self.txtFirstName.text,self.txtLastName.text,self.txtEmail.text,self.txtPassword.text]];
//    [req release];
}

// create request for create account
-(void)sendCreateAccountRequest
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    [self performSelector:@selector(createAccountRequest) withObject:nil afterDelay:0.0f];
}

// check text field
-(void)checkEmptyTextField
{
    if ([self.txtFirstName.text length]==0) {
        [self.txtFirstName becomeFirstResponder];
        return;
    }
    else if ([self.txtLastName.text length]==0) {
        [self.txtLastName becomeFirstResponder];
        return;
    }
    else if ([self.txtEmail.text length]==0) {
        [self.txtEmail becomeFirstResponder];
        return;
    }
    else if ([self.txtVarifyEmail.text length]==0) {
        [self.txtVarifyEmail becomeFirstResponder];
        return;
    }
    else if ([self.txtPassword.text length]==0) {
        [self.txtPassword becomeFirstResponder];
        return;
    }
    else if ([self.txtConfirmPassword.text length]==0) {
        [self.txtConfirmPassword becomeFirstResponder];
        return;
    }
}

// check entered email and password length
-(void)openDone
{
    [self checkEmptyTextField];
    if (![self.txtFirstName.text length]>0)
    {
        showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(BLANK_FIELD));
        return;
    }
    
    if (![self.txtLastName.text length]>0){
        showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(BLANK_FIELD));
        return;
    }
    if (![self.txtEmail.text length]>0){
        if (![self.txtVarifyEmail.text length]>0){
            showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(BLANK_FIELD));
            return;
        }
    }
    if (![self.txtEmail.text isEqualToString:self.txtVarifyEmail.text ]){
        showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(VERIFY_EMAIL_ALERT));
        return;
    }
    if (![self.txtPassword.text isEqualToString:self.txtConfirmPassword.text ] || [self.txtConfirmPassword.text length]<5 ||[self.txtPassword.text length]<5 ){
        showAlertScreen(languageSelectedStringForKey(ERROR_MSG), languageSelectedStringForKey(@"INV_PWD_MESSAGE"));
        return;
    }
    
    BOOL checkMail=validateEmailString(self.txtEmail.text);
    [self.txtConfirmPassword resignFirstResponder];
    [self.txtEmail resignFirstResponder];
    [self.txtFirstName resignFirstResponder];
    [self.txtLastName resignFirstResponder];
    [self.txtPassword resignFirstResponder];
    [self.txtVarifyEmail resignFirstResponder];
    
    if (checkMail)
    {
        return;
    }else
    {
        showAlertScreen(languageSelectedStringForKey(EMAIL_TEXT),languageSelectedStringForKey(@"Valid_email_message"));
        emailValid = NO;
        
    }

//    [self sendCreateAccountRequest];
}

// when tap on cancel bar button then call this method. that send to controll on previuos view
-(void) openBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

// Varify for data before sending request.
-(void)varifyData
{
    if ([self validateFirstName:self.txtFirstName])
    {
    return;
    }
    else if ([self validateLastName:self.txtLastName])
    {
    return;
    }else if ([self validateEmailField:self.txtEmail])
    {
    return;
    }
    else if ([self validateVerifyEmailField:self.txtVarifyEmail])
    {
    return;
    }else if ([self validateEmailAndPassword:self.txtPassword])
    {
    return;
    }
}

// Check For valid first name.
- (BOOL)validateFirstName:(UITextField *)firstNameField
{
	NSString *firstName = firstNameField.text;
	firstNameValid = ([firstName length] > 0);
	if(firstNameValid)
	{
		if( !([firstName length] < 51) )
		{
            showAlertScreen(languageSelectedStringForKey(INFO_VERIFY),languageSelectedStringForKey(FIRSTNAME_MESSAGE));
			firstNameValid = NO;
            self.txtFirstName.text=@"";
		}
	}
	return firstNameValid;
}

// Check For valid last name.
- (BOOL)validateLastName:(UITextField *)lastNameField
{
	NSString * lastName = lastNameField.text;
	lastNameValid = ([lastName length] > 0);
	if(lastNameValid)
	{
		if(!([lastName length] < 51) )
		{
            showAlertScreen(languageSelectedStringForKey(INFO_VERIFY),languageSelectedStringForKey(LASTNAME_MESSAGE));
			lastNameValid = NO;
            self.txtLastName.text=@"";
		}
	}
	return lastNameValid;
}

// Check For valid Email.
- (BOOL)validateEmailField:(UITextField *)emailAddressField
{
    NSString *emailRegEx=EMAIL_CHECK_EXP;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
	self.emailID = emailAddressField.text;
	emailValid = [emailTest evaluateWithObject:self.emailID];
    emailValid = ([self.emailID length] > 0);
    if( !([self.emailID length] < 101) )
    {
        showAlertScreen(languageSelectedStringForKey(INFO_VERIFY),languageSelectedStringForKey(@"Valid_email_message"));
        emailValid = NO;
    }

    return emailValid;
}

// Check For valid varify name.
- (BOOL)validateVerifyEmailField:(UITextField *)verifyEmailField
{
	NSString * verifyEmail = verifyEmailField.text;
    verifyEmailValid=([verifyEmail length]>0);
    if( !([verifyEmail length] < 101) )
    {
        showAlertScreen(languageSelectedStringForKey(INFO_VERIFY),languageSelectedStringForKey(@"Valid_email_message"));
        verifyEmailValid = NO;
    }
	return verifyEmailValid;
}

// Check For valid password and Email.
- (BOOL)validateEmailAndPassword:(UITextField *)passwordField
{
    NSString *password = passwordField.text;
    passwordValid=[password length]<15;
    if ([password length] < 15)
    {
        return YES;
    }
    else
    {
        showAlertScreen(languageSelectedStringForKey(@"INV_PWD_LOGIN"),languageSelectedStringForKey(@"INV_PWD_MESSAGE"));
        return NO;
    }
}


#pragma -mark UITextField Method

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isEqual:self.txtFirstName])
    {
        [self.txtLastName becomeFirstResponder];
    }
    else if ([textField isEqual:self.txtLastName])
    {
        [self.txtEmail becomeFirstResponder];
    }
    else if ([textField isEqual:self.txtEmail])
    {
        [self.txtVarifyEmail becomeFirstResponder];
    }
    else if ([textField isEqual:self.txtVarifyEmail])
    {
        [self.txtPassword becomeFirstResponder];
    }
    else if ([textField isEqual:self.txtPassword])
    {
        [self.txtConfirmPassword becomeFirstResponder];
    }
    else if ([textField isEqual:self.txtConfirmPassword])
    {
        [self.txtConfirmPassword resignFirstResponder];
        [self.pagescroll setContentSize:CGSizeMake(320,410)];
    }
    return YES;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([textField isEqual:self.txtFirstName] && [self validateFirstName:self.txtFirstName])
    {
        return firstNameValid;
    }
    else if ([textField isEqual:self.txtLastName] && [self validateLastName:self.txtLastName])
    {
        return lastNameValid;
    }
    else if ([textField isEqual:self.txtEmail] && [self validateEmailField:self.txtEmail])
    {
        return emailValid;
    }
    else if ([textField isEqual:self.txtVarifyEmail] && [self validateVerifyEmailField:self.txtVarifyEmail])
    {
        return verifyEmailValid;
    }
    else if ([textField isEqual:self.txtPassword] && [self validateEmailAndPassword:self.txtPassword])
    {
        return passwordValid;
    }
    else if ([textField isEqual:self.txtConfirmPassword] && [self validateEmailAndPassword:self.txtConfirmPassword])
    {
        return passwordValid;
    }
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([textField isEqual:self.txtFirstName])
    {
        self.pagescroll.contentOffset=CGPointMake(0, self.pagescroll.frame.origin.y);
    }
    else if ([textField isEqual:self.txtLastName])
    {
        self.pagescroll.contentOffset=CGPointMake(0, self.pagescroll.frame.origin.y);
    }
    else if ([textField isEqual:self.txtEmail])
    {
        self.pagescroll.contentOffset=CGPointMake(0, self.pagescroll.frame.origin.y+100);
    }
    else if ([textField isEqual:self.txtVarifyEmail])
    {
        self.pagescroll.contentOffset=CGPointMake(0, self.pagescroll.frame.origin.y+100);
    }
    else if ([textField isEqual:self.txtPassword])
    {
        self.pagescroll.contentOffset=CGPointMake(0, self.pagescroll.frame.origin.y+180);
    }
    else if ([textField isEqual:self.txtConfirmPassword])
    {
        self.pagescroll.contentOffset=CGPointMake(0, self.pagescroll.frame.origin.y+180);
    }
    [self.pagescroll setContentSize:CGSizeMake(320,600)];
    return YES;
}
- (void)viewDidUnload {
    [self setLblName:nil];
    [self setLblEmail:nil];
    [self setLblPassword:nil];
    [self setMyRegistrationView:nil];
    
    self.emailID=nil;
    [super viewDidUnload];
}
@end
