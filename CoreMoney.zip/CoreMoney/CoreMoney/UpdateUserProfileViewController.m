//
//  UpdateUserProfileViewController.m
//  CoreMoney
//class is used for update profile of user
#import "UpdateUserProfileViewController.h"
#import "ComboViewController.h"
#define ALERTVIEW @"AlertView"

@interface UpdateUserProfileViewController ()

-(void)openBack;
-(void)openSlide;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(void)designProfileView;
-(void)setProfileData;
-(void)getUserProfileUpdate;
-(void)getResponce:(id)jsonData;
- (BOOL)validateEmailField:(UITextField *)emailAddressField;
-(void)checkTextFields;
- (IBAction)openUpdateUser:(id)sender;

@end

@implementation UpdateUserProfileViewController
@synthesize userProfileObj,strPhoneNumber,CardDetailData,emailID,stateArray,zipCode,strNavigatedFrom;
//go to prvious view
-(void)openBack
{
    [self.navigationController popViewControllerAnimated:YES];
}
//open slide menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        addNavigationBar([NSString stringWithFormat:@"%@ %@ %@",languageSelectedStringForKey(@"Update"),languageSelectedStringForKey(@"Card"),languageSelectedStringForKey(@"Profile")], NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
    }
    return self;
}
//method use for design profile view
-(void)designProfileView
{
    self.lblTopTitle.backgroundColor=[UIColor whiteColor];
    self.lblTopTitle.textColor=Color127;
    
    
    self.lblBottomTitle.backgroundColor=[UIColor whiteColor];
    self.lblBottomTitle.textColor=Color127;
    
    // Design Scroll View
    
    // Top View Designing.
    self.topVewScroll.layer.cornerRadius = 10;
    self.topVewScroll.layer.masksToBounds = YES;
    self.topVewScroll.layer.borderColor = Color132.CGColor;
    self.topVewScroll.layer.borderWidth = 1.5f;
    
    // Bottom View Designing.
    self.bottomViewScroll.layer.cornerRadius = 10;
    self.bottomViewScroll.layer.masksToBounds = YES;
    self.bottomViewScroll.layer.borderColor = Color132.CGColor;
    self.bottomViewScroll.layer.borderWidth = 1.5f;

    
    [self.bottomView addSubview:self.myScrollView];
    self.bottomView.backgroundColor=[UIColor whiteColor];
}
//method use for set profile data
-(void)setProfileData
{
    //dataobj replaced by CardDetailData for showing name in user profile view
    self.lblUserName.text=[NSString stringWithFormat:@"%@%@",checkISNullStrings(CardDetailData.FIRSTNAME)?@"":[NSString stringWithFormat:@"%@ ",CardDetailData.FIRSTNAME],checkISNullStrings(CardDetailData.LASTNAME)?@"":[NSString stringWithFormat:@"%@",CardDetailData.LASTNAME]];
        
    
    self.lblCardStatus.text=CardStatusValue(CardDetailData.STATUS_CARDACCOUNT) ;
    self.lblCardNumber.text=[NSString stringWithFormat:@"%@",ChangeCardNumber((CardDetailData.CARDNUMBER))];
    
    
    self.lblAvailableBalance.text=[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(CardDetailData.AVAILABLEBALANCE))];
    

    
    self.txtEmployeeID.text=checkISNullStrings(CardDetailData.CustomAccountID)?@"":[NSString stringWithFormat:@"%@",CardDetailData.CustomAccountID];
    
    if ([self.strNavigatedFrom isEqualToString:ALERTVIEW])
    {
        self.txtAddressLine1.text=[NSString stringWithFormat:@"%@",checkISNullStrings( CardDetailData.ADDRESS1)?@"":[NSString stringWithFormat:@"%@ ",CardDetailData.ADDRESS1]];
        
        self.txtAddressLine2.text=[NSString stringWithFormat:@"%@",checkISNullStrings(CardDetailData.ADDRESSLINE2)?@"":[NSString stringWithFormat:@"%@ ",CardDetailData.ADDRESSLINE2]];
        
        
        
        self.txtCity.text=[NSString stringWithFormat:@"%@",checkISNullStrings(CardDetailData.CITY)?@"":[NSString stringWithFormat:@"%@",CardDetailData.CITY]];
        
        
        self.txtZipcode.text=checkISNullStrings(CardDetailData.POSTALCODE)?@"":[NSString stringWithFormat:@"%@",CardDetailData.POSTALCODE];
        
        self.txtUserPhoneNumber.text=checkISNullStrings(CardDetailData.HOMEPHONENUMBER)?@"":changePhoneNumberToUS([NSString stringWithFormat:@"%@",CardDetailData.HOMEPHONENUMBER]);
        
        self.txtUserMobileNumber.text=checkISNullStrings(CardDetailData.MOBILE_PHONE_NO)?@"":[NSString stringWithFormat:@"%@",CardDetailData.MOBILE_PHONE_NO];
        
        self.txtUserEmail.text=checkISNullStrings(CardDetailData.EMAILID)?@"":[NSString stringWithFormat:@"%@",CardDetailData.EMAILID];
        
        self.lblSelectstate.text=checkISNullStrings(CardDetailData.STATE)?@"":[NSString stringWithFormat:@"%@",CardDetailData.STATE];
    }
    else
    {
        self.txtAddressLine1.text=[NSString stringWithFormat:@"%@",checkISNullStrings(userProfileObj.ADDRESS1)?@"":[NSString stringWithFormat:@"%@ ",userProfileObj.ADDRESS1]];
        
        self.txtAddressLine2.text=[NSString stringWithFormat:@"%@",checkISNullStrings(userProfileObj.ADDRESS2)?@"":[NSString stringWithFormat:@"%@ ",userProfileObj.ADDRESS2]];

        
        
        self.txtCity.text=[NSString stringWithFormat:@"%@",checkISNullStrings(userProfileObj.CITY)?@"":[NSString stringWithFormat:@"%@",userProfileObj.CITY]];
        
        
        self.txtZipcode.text=checkISNullStrings(userProfileObj.POSTALCODE)?@"":[NSString stringWithFormat:@"%@",userProfileObj.POSTALCODE];
        
        self.txtUserPhoneNumber.text=checkISNullStrings(userProfileObj.PHONE)?@"":changePhoneNumberToUS([NSString stringWithFormat:@"%@",userProfileObj.PHONE]);
        
        self.txtUserMobileNumber.text=checkISNullStrings(userProfileObj.MOBILE)?@"":[NSString stringWithFormat:@"%@",userProfileObj.MOBILE];
        
        self.txtUserEmail.text=checkISNullStrings(userProfileObj.EMAIL)?@"":[NSString stringWithFormat:@"%@",userProfileObj.EMAIL];
        
        self.lblSelectstate.text=checkISNullStrings(userProfileObj.STATE)?@"":[NSString stringWithFormat:@"%@",userProfileObj.STATE];
    }
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [AppDelegate sharedAppDelegate].classType = UPDATE_PROFILE_PAGE;
    strPhoneNumber=[[NSString alloc] init];
    self.bgView.frame = CGRectMake(0,IS_IPAD?IS_IOS7?1:1:IS_IOS7?40:0, 320,IS_IOS7?540:480);

    // Do any additional setup after loading the view from its nib.
    [self designProfileView];
}
//method use for change language
-(void)changeLanguage
{
    self.lblTopTitle.text=languageSelectedStringForKey(@"Personal Details");
    self.lblBottomTitle.text=languageSelectedStringForKey(@"Address");
    [self.btnUpdate setTitle:languageSelectedStringForKey(@"Update") forState:UIControlStateNormal];
}

-(void)viewWillAppear:(BOOL)animated
{
    if ([self.strNavigatedFrom isEqualToString:ALERTVIEW])
    {
        [AppDelegate sharedAppDelegate].classType = ADMIN_ALERTS_PAGE;
    }
    else
    {
        [AppDelegate sharedAppDelegate].classType = UPDATE_PROFILE_PAGE;
    }
    self.view.backgroundColor=[UIColor whiteColor];
//    NavigationBarStyle();
    self.myScrollView.frame=CGRectMake(0,0, 320, 370);
    [self setProfileData];
    self.myScrollView.contentSize=CGSizeMake(320,580);
    self.myScrollView.scrollEnabled=YES;
    [self changeLanguage];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - Request Work
//method use for get updated user profile 
-(void)getUserProfileUpdate
{
    NSString *strPhoneNumberValue = removeOtherSymbolsFromString(self.txtUserPhoneNumber.text);

    NSString *mobile=removeOtherSymbolsFromString(self.txtUserMobileNumber.text);
  
    
    DataParsingClass *Datareq=[[DataParsingClass alloc] init];
    Datareq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbServiceName=Card_update_profile_Request;
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
   
    if ([self validateZIPField:self.txtZipcode])
    {
          [[AppDelegate sharedAppDelegate] addloadingView];
        [Datareq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"user=%@&password=%@&Application=%@&dbbServiceName=%@&dbbSystemExtLogin=%@&deCIAClientID=%@&deCIAAccountNumber=%@&deBSAcctId=%@&deBAAdminNumber=%@&deCM_AccountManualStatus=&deCM_CustomAccountID=%@&deCIAEmailAddress=%@&deCIASOfficePhone=%@&deCNBMobilePhone=%@&deCIAAddressLine1=%@&deCIAAddressLine2=%@&deCIACity=%@&deCIAState=%@&deCIASCountry=%@&deCIAPostalCode=%@&deIVRSource=%@&deIVRIpAddress=&deIVRSessionID=&deIVRRequestTime=&deTCIVRANI=&deTCIVRDNS=&deDBBServiceApiLevel=&deDBBServiceAppID=",[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword,[SystemConfiguration sharedSystemConfig].Application,[SystemConfiguration sharedSystemConfig].dbbServiceName,[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,CardDetailData.CLIENTID,CardDetailData.ACCOUNTNUMBER,CardDetailData.BSAcctID,checkISNullStrings(CardDetailData.ADMIN_NUMBER)?@"":[NSString stringWithFormat:@"%@",CardDetailData.ADMIN_NUMBER],checkISNullStrings(self.txtEmployeeID.text)?@"":[NSString stringWithFormat:@"%@",self.txtEmployeeID.text],self.txtUserEmail.text,strPhoneNumberValue,checkISNullStrings(mobile)?@"":[NSString stringWithFormat:@"%@",mobile],self.txtAddressLine1.text,checkISNullStrings(self.txtAddressLine2.text)?@"":[NSString stringWithFormat:@"%@",self.txtAddressLine2.text],self.txtCity.text,checkISNullStrings(self.lblSelectstate.text)?@"":[NSString stringWithFormat:@"%@",self.lblSelectstate.text],CardDetailData.COUNTRY,self.txtZipcode.text,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCardUpdate3];
    }
    
    [Datareq release];

}
#pragma mark - Response Methods
// receive data from json
-(void)getResponce:(id)jsonData
{
    [[AppDelegate sharedAppDelegate] removeLoadingView];
    if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
    {
        LoginResponceDataClass *obj=(LoginResponceDataClass *)jsonData;
        showAlertScreen(nil, obj.ErrorMsg);
        
        CardDetailData.CustomAccountID=checkISNullStrings(self.txtEmployeeID.text)?@"":[NSString stringWithFormat:@"%@",self.txtEmployeeID.text];
        
        [[AppDelegate sharedAppDelegate].arrCardDetailArray replaceObjectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex withObject:CardDetailData];
    }
}



- (BOOL)validateEmailField:(UITextField *)emailAddressField
{
    NSString *emailRegEx=EMAIL_CHECK_EXP;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];	
	emailValid = [emailTest evaluateWithObject:emailAddressField.text];
    emailValid = ([emailAddressField.text length] > 0);
    if( !([emailAddressField.text length] < 101) )
    {
        showAlertScreen(languageSelectedStringForKey(INFO_VERIFY),languageSelectedStringForKey(@"Valid_email_message"));
        emailValid = NO;
    }
    
    return emailValid;
}

// Check For valid Email.
- (BOOL)validateZIPField:(UITextField *)zipAddressField
{
    
    NSString *strZipCode=self.txtZipcode.text;

    NSString *zipcodeExpression=ZIPCODE_CHECK_EXP;
	    
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:zipcodeExpression options:0 error:NULL];
    
    NSTextCheckingResult *match = [regex firstMatchInString:strZipCode options:0 range:NSMakeRange(0, [strZipCode length])];
    if (match)
    {
        return YES;
    }
    else
    {
  showAlertScreen(languageSelectedStringForKey(INFO_VERIFY),languageSelectedStringForKey(@"Valid_Zip_message"));
        return NO;
    }
}

#pragma mark - View Designing Methods
-(void)checkTextFields
{
    if (self.txtEmployeeID.text.length==0) {
        self.myScrollView.contentOffset=CGPointMake(0, 0);
        showAlertScreen(@"Error", @"Please Enter Employee Id");
        [self.txtEmployeeID becomeFirstResponder];
    }
    else if (self.txtUserEmail.text.length==0) {
        self.myScrollView.contentOffset=CGPointMake(0, 40);
        showAlertScreen(@"Error", @"Please Enter Email Id");
        [self.txtUserEmail becomeFirstResponder];
    }
    else if (self.txtAddressLine1.text.length==0) {
        self.myScrollView.contentOffset=CGPointMake(0, 190);
        showAlertScreen(@"Error", @"Please Enter Address");
        [self.txtAddressLine1 becomeFirstResponder];
    }

    else if (self.txtZipcode.text.length==0) {
        self.myScrollView.contentOffset=CGPointMake(0, 320);
        showAlertScreen(@"Error", @"Please Enter Zipcode");
        [self.txtZipcode becomeFirstResponder];
    }
    else if (!validateEmailString(self.txtUserEmail.text))
    {
        showAlertScreen(@"Error", @"Invalid Email ID");
        self.myScrollView.contentOffset=CGPointMake(0, 40);
        [self.txtUserEmail becomeFirstResponder];
    }
    else
    {
        self.myScrollView.contentOffset=CGPointMake(0, 0);
        [self getUserProfileUpdate];
    }
    self.myScrollView.contentOffset=CGPointMake(0, 0);
    [self.myScrollView setContentSize:CGSizeMake(320,580)];
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(comboView){
        [self removecomboView];
        return;
    }
    self.myScrollView.contentOffset=CGPointMake(0, 0);
    [self.myScrollView setContentSize:CGSizeMake(320,580)];
    [self.txtEmployeeID resignFirstResponder];
    [self.txtUserEmail resignFirstResponder];
    [self.txtUserPhoneNumber resignFirstResponder];
    [self.txtAddressLine1 resignFirstResponder];
    [self.txtAddressLine2 resignFirstResponder];
    [self.txtCity resignFirstResponder];
    [self.txtZipcode resignFirstResponder];
}
#pragma mark - UITextField Methods

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    if ([textField isEqual:self.txtUserPhoneNumber])
    {
        UITextRange *selectedRange = textField.selectedTextRange;
        int pos = [textField offsetFromPosition:textField.endOfDocument toPosition:selectedRange.start];
        NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        NSArray *components = [newString componentsSeparatedByCharactersInSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
        NSString *decimalString = [components componentsJoinedByString:@""];
        
        NSUInteger length = decimalString.length;
        
        if ( length > 10  )
        {
            return NO;
        }
        
        NSUInteger index = 0;
        NSMutableString *formattedString = [NSMutableString string];
        
        //it put dash after first 3 digit
        if (length - index > 3) {
            NSString *areaCode = [decimalString substringWithRange:NSMakeRange(index, 3)];
            [formattedString appendFormat:@"(%@)-",areaCode];
            index += 3;
        }
        // it put dash next 3 three digit
        if (length - index > 3) {
            NSString *prefix = [decimalString substringWithRange:NSMakeRange(index, 3)];
            [formattedString appendFormat:@"%@-",prefix];
            index += 3;
        }
        // for after 6 digit
        NSString *remainder = [decimalString substringFromIndex:index];
        [formattedString appendString:remainder];
        
        textField.text = formattedString;
        // For relocate the cursorpostion on exist position
        if (textField.text.length>3)
        {
            UITextPosition *newPos = [textField positionFromPosition:textField.endOfDocument offset:pos];
            
            // Reselect the range, to move the cursor to that position
            textField.selectedTextRange = [textField textRangeFromPosition:newPos toPosition:newPos];
            
            
        }
        return NO;
        
    }
    if ([textField isEqual:self.txtUserMobileNumber])
    {
        
        NSCharacterSet *nonNumberSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        
        if ([string rangeOfCharacterFromSet:nonNumberSet].location != NSNotFound)
        {
            return NO;
        }
        
        
        NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        
        NSUInteger length = newString.length;
        
        if ( length > 10  )
        {
            return NO;
        }
    }
    
    if ([textField isEqual:self.txtEmployeeID])
    {
             
        
        NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        
        NSUInteger length = newString.length;
        
        if ( length > 25  )
        {
            return NO;
        }
    }

       return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([textField isEqual:self.txtEmployeeID])
    {
        [self.myScrollView setContentOffset:CGPointMake(0, self.txtEmployeeID.frame.origin.y-6) animated:YES];
    }
    else if ([textField isEqual:self.txtUserEmail])
    {
        [self.myScrollView setContentOffset:CGPointMake(0, self.txtUserEmail.frame.origin.y-10) animated:YES];
    }
    else if ([textField isEqual:self.txtUserPhoneNumber])
    {
        [self.myScrollView setContentOffset:CGPointMake(0, self.txtUserPhoneNumber.frame.origin.y-10) animated:YES];
    }
    else if ([textField isEqual:self.txtUserMobileNumber])
    {
        [self.myScrollView setContentOffset:CGPointMake(0, self.txtUserMobileNumber.frame.origin.y-10) animated:YES];
    }
    else if ([textField isEqual:self.txtAddressLine1])
    {
        [self.myScrollView setContentOffset:CGPointMake(0, self.txtAddressLine1.frame.origin.y+190) animated:YES];
    }
    else if ([textField isEqual:self.txtAddressLine2])
    {
        [self.myScrollView setContentOffset:CGPointMake(0, self.txtAddressLine2.frame.origin.y+200) animated:YES];
    }
    else if ([textField isEqual:self.txtCity])
    {
        [self.myScrollView setContentOffset:CGPointMake(0, self.txtCity.frame.origin.y+200) animated:YES];
    }
    else if ([textField isEqual:self.txtZipcode])
    {
        [self.myScrollView setContentOffset:CGPointMake(0, self.txtZipcode.frame.origin.y+190) animated:YES];
    }
    // [self.myScrollView setContentSize:CGSizeMake(320,680)];
    
    return YES;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isEqual:self.txtEmployeeID]) {
        self.myScrollView.contentOffset=CGPointMake(0, 40);
        [self.txtUserEmail becomeFirstResponder];
        return YES;
    }
    else if ([textField isEqual:self.txtUserEmail]) {
        self.myScrollView.contentOffset=CGPointMake(0, 90);
        [self.txtUserPhoneNumber becomeFirstResponder];
        return YES;
    }
    else if ([textField isEqual:self.txtUserPhoneNumber]) {
        self.myScrollView.contentOffset=CGPointMake(0, 190);
        [self.txtUserMobileNumber becomeFirstResponder];
        return YES;
    }
    else if ([textField isEqual:self.txtUserMobileNumber]) {
        self.myScrollView.contentOffset=CGPointMake(0, 190);
        [self.txtUserMobileNumber resignFirstResponder];
        [self.txtAddressLine1 becomeFirstResponder];
        return YES;
    }
    else if ([textField isEqual:self.txtAddressLine1]) {
        self.myScrollView.contentOffset=CGPointMake(0, 240);
        [self.txtAddressLine2 becomeFirstResponder];
        return YES;
    }
    else if ([textField isEqual:self.txtAddressLine2]) {
        self.myScrollView.contentOffset=CGPointMake(0, 280);
        [self.txtCity becomeFirstResponder];
        return YES;
    }
    else if ([textField isEqual:self.txtCity]) {
        self.myScrollView.contentOffset=CGPointMake(0, 320);
        [self.txtZipcode becomeFirstResponder];
        return YES;
    }
    else if ([textField isEqual:self.txtZipcode]) {
        self.myScrollView.contentOffset=CGPointMake(0, 0);
        [self.myScrollView setContentSize:CGSizeMake(320,580)];
        [self.txtZipcode resignFirstResponder];
        return YES;
    }
    return YES;
}
- (void)dealloc {
    [_myScrollView release];
    [_topView release];
    [_bottomView release];
    [_lblUserName release];
    [_lblCardNumber release];
    [_lblCardStatus release];
    [_lblAvailableBalance release];
    [_lblTopTitle release];
    [_lblBottomTitle release];
    [_topVewScroll release];
    [_bottomViewScroll release];
    [_txtEmployeeID release];
    [_txtUserEmail release];
    [_txtUserPhoneNumber release];
    [_txtAddressLine1 release];
    [_txtAddressLine2 release];
    [_txtCity release];
    [_txtZipcode release];
    [_txtUserMobileNumber release];
    [_btnUpdate release];
    [_lblSelectstate release];
    [_bgView release];
    //memory release for stateArray
    [stateArray release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setMyScrollView:nil];
    [self setTopView:nil];
    [self setBottomView:nil];
    [self setLblUserName:nil];
    [self setLblCardNumber:nil];
    [self setLblCardStatus:nil];
    [self setLblAvailableBalance:nil];
    [self setLblTopTitle:nil];
    [self setLblBottomTitle:nil];
    [self setTopVewScroll:nil];
    [self setBottomViewScroll:nil];
    [self setTxtEmployeeID:nil];
    [self setTxtUserEmail:nil];
    [self setTxtUserPhoneNumber:nil];
    [self setTxtAddressLine1:nil];
    [self setTxtAddressLine2:nil];
    [self setTxtCity:nil];
    [self setTxtZipcode:nil];
    [self setTxtUserMobileNumber:nil];
    
    self.CardDetailData=nil;
    self.userProfileObj=nil;
    
    [self setBtnUpdate:nil];
    [self setLblSelectstate:nil];
    [self setBgView:nil];
    [super viewDidUnload];
}
//method called when update user
- (IBAction)openUpdateUser:(id)sender {
    [self checkTextFields];
}
//method called when state is tapped
- (IBAction)tapAtStateCombo:(id)sender {
    comboView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    
    
    comboView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:comboView];
    self.myScrollView.contentOffset=CGPointMake(0,370);
    ComboViewController *comView = [[ComboViewController alloc] initWithFrame:CGRectMake(215, 142, 78, 278) records:stateArray callingClassType:State];
    comView.delegate = self;
    [comboView addSubview:comView];
    
}
-(void) selectQuetion:(id) que
{
    secretQustionDataClass *stat=(secretQustionDataClass *)que;
    self.lblSelectstate.text = stat.indexNo;
    [self removecomboView];
}
// remove combo view
-(void) removecomboView{
    if (comboView) {
        self.myScrollView.contentOffset=CGPointMake(0, 175);
        [comboView removeFromSuperview];
        comboView = nil;
    }
}

@end
