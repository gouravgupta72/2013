//
//  employeeExpData.h
//  CoreMoney

#import <Foundation/Foundation.h>

@interface employeeExpData : NSObject
{
    NSString *EmployeeName, *CardNumber , *ExpenseLimit;
    double TotalExpenses, Diff_Limit_Expense;
    
    double expCatOneAmount,expCatTwoAmount,expCatThreeAmount;
    NSString *expCatOneText, *expCatTwoText, *expCatThreeText;
    
    NSString *expCateGory;
    double expCateAmount;
    NSMutableArray *arrEmployeCatDescExpense;
}
@property(nonatomic,retain) NSString *EmployeeName, *CardNumber, *ExpenseLimit;
@property double TotalExpenses, Diff_Limit_Expense;
@property (nonatomic,retain) NSString *expCatOneText, *expCatTwoText, *expCatThreeText;
@property (nonatomic,retain) NSString *expCateGory;
@property (nonatomic, retain) NSMutableArray *arrEmployeCatDescExpense;
@property  double expCatOneAmount,expCatTwoAmount,expCatThreeAmount;
@property  double expCateAmount;
@end
