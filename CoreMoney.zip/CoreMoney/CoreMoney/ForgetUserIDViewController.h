//
//  ForgetUserIDViewController.h

// Class used for create forgot user id view

#import <UIKit/UIKit.h>
#import "CalanderView.h"
#import "PopUpView.h"
#import "DataParsingClass.h"
#import "ComboViewController.h"
#import "HomeViewController.h"
#import "updateNewUserViewController.h"

@interface ForgetUserIDViewController : UIViewController<DataParsingDelegate>
{
   // CalanderView *calnderObj;
    UIView *calanderView;
    forgotPage forgotPageType;
    UIView *comboView;
    int ReqId;
    
    NSMutableArray *SecretQuestionArr;
    NSString *ValidUserId;
    int SelectedQuestionIndex;
}
@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (nonatomic, retain) NSMutableArray *SecretQuestionArr;
@property (retain, nonatomic) IBOutlet UIImageView *viewCover;

@property (retain, nonatomic) IBOutlet UIButton *btnSubmit;
@property (retain, nonatomic) IBOutlet UIView *viewCoverAbove;
@property(nonatomic,retain) NSString *ValidUserId;
@property (retain, nonatomic) IBOutlet UILabel *lblBankAc;
@property (retain, nonatomic) IBOutlet UILabel *lblSecretQue;
@property (retain, nonatomic) IBOutlet UILabel *lblSecretAnsw;
@property (retain, nonatomic) IBOutlet UILabel *lblDob;
@property (retain, nonatomic) IBOutlet UILabel *lblEmail;
@property (retain, nonatomic) IBOutlet UILabel *lblRetrieveMsg;
@property (retain, nonatomic) IBOutlet UITextField *txtBankAc;
@property (retain, nonatomic) IBOutlet UITextField *txtSecretAnsw;
@property (retain, nonatomic) IBOutlet UITextField *txtEmail;
@property (retain, nonatomic) IBOutlet UILabel *lblTxtSecretQue;
@property (retain, nonatomic) IBOutlet UIButton *btnSecretQue;

@property (retain, nonatomic) IBOutlet UILabel *lblTxtDOB;

@property (retain, nonatomic) IBOutlet UIButton *btnDob;
- (IBAction)SubmitButtonClicked:(id)sender;
@property (retain, nonatomic) IBOutlet UIScrollView *pageScroll;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil ForgotPage:(forgotPage) pagetype;
@end
