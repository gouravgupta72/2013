//
//  LoginViewController.h

// class user for login view
#import <UIKit/UIKit.h>
#import "responseParse.h"
#import "DataParsingClass.h"
#import "HelpMenu.h"

@interface LoginViewController : UIViewController<DataParsingDelegate>
{
    int ReqID;
    forgotPage forgotPageType;
}
@property (retain, nonatomic) IBOutlet UITextField *txtUserName;
@property (retain, nonatomic) IBOutlet UITextField *txtPassword;
@property (retain, nonatomic) IBOutlet UIButton *btnLogin;
@property (retain, nonatomic) IBOutlet UIButton *btnRegister;
@property (retain, nonatomic) IBOutlet UIButton *btnForgotUserClick;
@property (retain, nonatomic) IBOutlet UIScrollView *pageScroll;
@property (retain, nonatomic) IBOutlet UILabel *lblForgotPwd;
@property (retain, nonatomic) IBOutlet UILabel *lblForgotUserId;
@property (retain, nonatomic) IBOutlet UIImageView *imgVLineUserId;
@property (retain, nonatomic) IBOutlet UIImageView *imgVPwdLine;

@property (retain, nonatomic) IBOutlet UIButton *btnForgotPassword;
- (IBAction)touchedBtnForgotPassword:(id)sender;

@end
