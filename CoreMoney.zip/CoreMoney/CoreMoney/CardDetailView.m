//
//  CardDetailView.m

// Class to design card Detail View.

#import "CardDetailView.h"

@implementation CardDetailView
@synthesize lblStatus,lblAmount,lblCardNo,lblCurrentBalance,lblLastTxnAmount,lblName,lblTime,lblEmployeeId;

- (id)initWithDetailViewFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        lblName=createLable(CGRectMake(13, 10, 299, 21), FONT_ARIAL_20);
        lblName.textAlignment=NSTextAlignmentLeft;
        lblName.textColor=Name_color_Code;
        [self addSubview:lblName];
        [lblName release];
        
        lblEmployeeId=createLable(CGRectMake(13, 10, 299, 21), FONT_ARIAL_16);
        lblEmployeeId.textAlignment=NSTextAlignmentLeft;
        lblEmployeeId.textColor=Card_no_colore_code;
        [self addSubview:lblEmployeeId];
        [lblEmployeeId release];

        
        lblCardNo=createLable(CGRectMake(13, CGRectGetMaxY(lblName.frame)+5, 250, 15), FONT_ARIAL_14);
        lblCardNo.textAlignment=NSTextAlignmentLeft;
        lblCardNo.textColor=Card_no_colore_code;
        [self addSubview:lblCardNo];
        [lblCardNo release];
        
        lblStatus=createLable(CGRectMake(13, CGRectGetMaxY(lblCardNo.frame)+5, 210, 15), FONT_ARIAL_14);
        lblStatus.textAlignment=NSTextAlignmentLeft;
        lblStatus.textColor=Status_Color_Code;
        [self addSubview:lblStatus];
        [lblStatus release];
        
        
        UILabel *currentBalance=createLable(CGRectMake(13, CGRectGetMaxY(lblStatus.frame)+5, 126, 18), FONT_ARIAL_14);
        currentBalance.textAlignment=NSTextAlignmentLeft;
        currentBalance.textColor=Card_no_colore_code;
        currentBalance.text=languageSelectedStringForKey(@"Available Balance");
        [self addSubview:currentBalance];
        [currentBalance release];

        
        lblAmount=createLable(CGRectMake(CGRectGetMaxX(currentBalance.frame), CGRectGetMaxY(lblStatus.frame)+5, 168, 18), FONT_ARIAL_14);
        lblAmount.textAlignment=NSTextAlignmentRight;
        lblAmount.textColor=[UIColor blackColor];
        [self addSubview:lblAmount];
        [lblAmount release];
        
        currentBalance=createLable(CGRectMake(13, CGRectGetMaxY(lblAmount.frame)+5, 126, 18), FONT_ARIAL_14);
        currentBalance.textAlignment=NSTextAlignmentLeft;
        currentBalance.textColor=Card_no_colore_code;
        currentBalance.text=languageSelectedStringForKey(@"Current Balance");
        [self addSubview:currentBalance];
        [currentBalance release];
        
        lblCurrentBalance=createLable(CGRectMake(CGRectGetMaxX(currentBalance.frame), CGRectGetMaxY(lblAmount.frame)+5, 168, 18), FONT_ARIAL_14);
        lblCurrentBalance.textAlignment=NSTextAlignmentRight;
        lblCurrentBalance.adjustsFontSizeToFitWidth=YES;
        lblCurrentBalance.textColor=[UIColor blackColor];
        [self addSubview:lblCurrentBalance];
        [lblCurrentBalance release];
        
        currentBalance=createLable(CGRectMake(13, CGRectGetMaxY(lblCurrentBalance.frame)+5, 130, 18), FONT_ARIAL_13);
        currentBalance.textAlignment=NSTextAlignmentLeft;
        currentBalance.textColor=Card_no_colore_code;
        currentBalance.text=languageSelectedStringForKey(@"Last Txn Amt");
        [self addSubview:currentBalance];
        [currentBalance release];
        
        lblLastTxnAmount=createLable(CGRectMake(CGRectGetMaxX(currentBalance.frame), CGRectGetMaxY(lblCurrentBalance.frame)+5, 165, 18), FONT_ARIAL_13);
        lblLastTxnAmount.textAlignment=NSTextAlignmentRight;
        lblLastTxnAmount.textColor=Card_no_colore_code;
        lblLastTxnAmount.adjustsFontSizeToFitWidth=YES;
        [self addSubview:lblLastTxnAmount];
        [lblLastTxnAmount release];
        
        
        currentBalance=createLable(CGRectMake(13, CGRectGetMaxY(lblLastTxnAmount.frame)+5, 140, 18), FONT_ARIAL_13);
        currentBalance.textAlignment=NSTextAlignmentLeft;
        currentBalance.textColor=Card_no_colore_code;
        currentBalance.text=languageSelectedStringForKey(@"Last Txn Date");
        [self addSubview:currentBalance];
        [currentBalance release];
        
        lblTime=createLable(CGRectMake(CGRectGetMaxX(currentBalance.frame), CGRectGetMaxY(lblLastTxnAmount.frame)+5, 155, 18), FONT_ARIAL_13);
        lblTime.textAlignment=NSTextAlignmentRight;
        lblTime.adjustsFontSizeToFitWidth=YES;
        lblTime.textColor=Card_no_colore_code;
        [self addSubview:lblTime];
        [lblTime release];
    }
    return self;
}

-(void)dealloc
{
    for (UIView *view in [self subviews]) {
        if ([view isKindOfClass:[UILabel class]]) {
            [view removeFromSuperview];
        }
    }
    [super dealloc];
}


@end
