//
//  CardListDetailViewController.h

// Class for Card List Detail View.

#import <UIKit/UIKit.h>
#import "CardDetailView.h"
#import "DataParsingClass.h"

@interface CardListDetailViewController : SwipeViewController<DataParsingDelegate,UIScrollViewDelegate>
{
    CardDetailView *viewObj;
    
    NSMutableArray *cellArray, *stateArray;
    
    lowBalanceSearchDataClass *lowBalanceSearchObj;
    
    NSString *ProductId;
    
    CARD_DETAILS_BUTTONS cardDetailButtonType;
    
    AutoMaticFunding autoMaticfundReqType;
   
    BOOL isFirstTime;
}
@property(nonatomic,retain) NSString *ProductId;
@property (retain, nonatomic) IBOutlet UITableView *tblCardList;
@property (retain, nonatomic) IBOutlet UIView *hearedView;
@property (retain, nonatomic) IBOutlet UIScrollView *scrollUpperView;
@property (retain, nonatomic) IBOutlet UIImageView *myHeaderImage;
@property (retain, nonatomic) IBOutlet UIView *leftview;
@property (retain, nonatomic) IBOutlet UIView *rightview;
@property (retain, nonatomic) IBOutlet UIView *mySubView;

@end
