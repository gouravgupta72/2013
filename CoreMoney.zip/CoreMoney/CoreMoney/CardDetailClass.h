//
//  CardDetailClass.h
//  CoreMoney

// Class used for hold card detail data.

#import <Foundation/Foundation.h>

@interface CardDetailClass : NSObject
{
    NSString *ACCOUNTNUMBER, *ACQUISITIONSOURCE, *ADDRESS1, *ADDRESSLINE2, *ADMIN_NUMBER, *AGENTID, *AlertEmailAddress, *BSAcctID, *BSAgentId, *CARDEXPIRATIONDATE, *CARDNUMBER, *CITY ,*CLIENTID, *COUNTRY, *CradType, *CustomAccountID, *CustomAccountIDLabel, *DATEOFBIRTH, *DDANumber, *DispatchDate, *EMAILID, *EMAIL_ADDRESS2, *FIRSTNAME, *GOVERNMENTID, *HOMEPHONENUMBER, *HOME_FAX_NO, *HPhoneCountryCode, *HPhoneExtension, *IDEXPIRATIONDATE, *IDISSUECOUNTRY, *IDISSUEDATE, *IDISSUESTATE, *IDNUMBER, *LANGUAGE_INDICATOR, *LASTNAME, *LastBulkOFACCheckDate, *LastLoginDateTime, *LastPlasticIssued, *LastPlasticShipped, *MAIDEN_NAME, *MIDDLENAME, *MOBILE_PHONE_NO, *NAME_ON_CARD, *OFACInquiryDate, *OFACSDNEntry1, *OFACSDNEntry2, *OFACSDNEntry3, *OFACSDNEntry4, *OFACSDNEntry5, *OFFICE_PHONE, *OtherIDDescription, *POSTALCODE, *PRODUCTID, *PasswordPolicy, *SECOND_LAST_NAME, *SECURITY_ANSWER, *SECURITY_QUESTION, *SSN, *STATE,  *STOREID, *SavingAccountNumber, *StudentIDCardNumber, *TERMSANDCONDITIONS, *TITLE_NAME, *USERFIELD1, *USERFIELD2, *USERFIELD3, *USERFIELD4, *USERFIELD5, *UserId, *UserStatus, *WORK_FAX_NO, *WPhoneCountryCode, *WPhoneExtension, *LastTransactionDate;
    
    int AccountGeneratedStatus, AccountManualStatus, CARDSTATUS, ChangeAccessCodeCounter, DecisionFlag, ErrorCounter, GeneratedStatus, LOSTSTOLENALLOWEDCM, ManualCardStatus, NOOFPINATTEMPTS, StudentChoice, dePPAccountType ,STATUS_CARDACCOUNT;
    
    double CURRENTBALANCE, OFACScore, AVAILABLEBALANCE, LastTransfer;
    BOOL isActiveButtonShow;
    
    BOOL FLAG;
}


@property (nonatomic,retain) NSString *ACCOUNTNUMBER, *ACQUISITIONSOURCE, *ADDRESS1, *ADDRESSLINE2, *ADMIN_NUMBER, *AGENTID, *AlertEmailAddress, *BSAcctID, *BSAgentId, *CARDEXPIRATIONDATE, *CARDNUMBER, *CITY ,*CLIENTID, *COUNTRY, *CradType, *CustomAccountID, *CustomAccountIDLabel, *DATEOFBIRTH, *DDANumber, *DispatchDate, *EMAILID, *EMAIL_ADDRESS2, *FIRSTNAME, *GOVERNMENTID, *HOMEPHONENUMBER, *HOME_FAX_NO, *HPhoneCountryCode, *HPhoneExtension, *IDEXPIRATIONDATE, *IDISSUECOUNTRY, *IDISSUEDATE, *IDISSUESTATE, *IDNUMBER, *LANGUAGE_INDICATOR, *LASTNAME, *LastBulkOFACCheckDate, *LastLoginDateTime, *LastPlasticIssued, *LastPlasticShipped, *MAIDEN_NAME, *MIDDLENAME, *MOBILE_PHONE_NO, *NAME_ON_CARD, *OFACInquiryDate, *OFACSDNEntry1, *OFACSDNEntry2, *OFACSDNEntry3, *OFACSDNEntry4, *OFACSDNEntry5, *OFFICE_PHONE, *OtherIDDescription, *POSTALCODE, *PRODUCTID, *PasswordPolicy, *SECOND_LAST_NAME, *SECURITY_ANSWER, *SECURITY_QUESTION, *SSN, *STATE, *STOREID, *SavingAccountNumber, *StudentIDCardNumber, *TERMSANDCONDITIONS, *TITLE_NAME, *USERFIELD1, *USERFIELD2, *USERFIELD3, *USERFIELD4, *USERFIELD5, *UserId, *UserStatus, *WORK_FAX_NO, *WPhoneCountryCode, *WPhoneExtension, *LastTransactionDate;


@property int AccountGeneratedStatus, AccountManualStatus, CARDSTATUS, ChangeAccessCodeCounter, DecisionFlag, ErrorCounter, GeneratedStatus, LOSTSTOLENALLOWEDCM, ManualCardStatus, NOOFPINATTEMPTS, StudentChoice, dePPAccountType, STATUS_CARDACCOUNT;

@property double CURRENTBALANCE, OFACScore, AVAILABLEBALANCE, LastTransfer;
@property BOOL isActiveButtonShow;

@property BOOL FLAG;
@end
