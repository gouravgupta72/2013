//
//  AlertViewCell.m
//  CoreMoney
// class use for create cell for alert view

#import "AlertViewCell.h"

@implementation AlertViewCell
@synthesize lblAlertCount,lblAlertName,imgView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    //Desining of Red , Amber and green Alert cell
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
       
        imgView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 7, 300, 46)];
        imgView.image = [UIImage imageNamed:@"img_fundbtnbg.png"];
        [self addSubview:imgView];
        [imgView release];
        
        lblAlertName=createLabel(@"", CGRectMake(15, 7, 215, 46));
        lblAlertName.font = FONT_ARIAL_17;
        lblAlertName.textAlignment = UITextAlignmentLeft;
        lblAlertName.textColor =[UIColor blackColor];
        lblAlertName.numberOfLines = 2;
        [self addSubview:lblAlertName];
        [lblAlertName release];
        
        lblAlertCount=createLabel(@"", CGRectMake(CGRectGetMaxX(lblAlertName.frame), 7, 75, 46));
        lblAlertCount.font = FONT_ARIAL_17;
        lblAlertCount.textAlignment = UITextAlignmentRight;
        lblAlertCount.textColor =[UIColor blackColor];
        [self addSubview:lblAlertCount];
        [lblAlertCount release];
 
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
