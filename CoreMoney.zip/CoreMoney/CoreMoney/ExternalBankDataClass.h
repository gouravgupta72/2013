//
//  ExternalBankDataClass.h
//  CoreMoney

#import <Foundation/Foundation.h>

@interface ExternalBankDataClass : NSObject

{
    NSString *RecipientID ,*BA_ACCT_ID ,*RoutingNumber, *BankAccountNumber, *Bank_Name, *AddedOnDate, *Bank_Owner, *Status, *IsActive, *Val_Tries, * MicroDepostiRev, *Description, *ResErrorMsg;
    
    double MicroDeposit1, MicroDeposit2;
   
    int  ResErrorCode, ResCode;
}
@property (nonatomic,retain) NSString *RecipientID ,*BA_ACCT_ID ,*RoutingNumber, *BankAccountNumber, *Bank_Name, *AddedOnDate, *Bank_Owner, *Status, *IsActive, *Val_Tries, * MicroDepostiRev, *Description, *ResErrorMsg;

@property double MicroDeposit1, MicroDeposit2;

@property int  ResErrorCode, ResCode;

@end
