//
//  UpdateUserProfileViewController.h
//  CoreMoney
//class is used for update profile of user

#import <UIKit/UIKit.h>
#import "UserProfileDataClass.h"
#import "DataParsingClass.h"
#import "CardDetailClass.h"
#import "LoginResponceDataClass.h"
#import "CustomScrollView.h"
#import "secretQustionDataClass.h"
@interface UpdateUserProfileViewController : SwipeViewController<UITextFieldDelegate,DataParsingDelegate,ScrollDelegate>
{
    UserProfileDataClass *userProfileObj;
    
    CardDetailClass *CardDetailData;
    
    NSString * strPhoneNumber;
       
    NSString * emailID, *zipCode;
    UIView *comboView;
    NSMutableArray *stateArray;
    BOOL emailValid,zipValid;
    NSString *strNavigatedFrom;
}
@property (nonatomic,retain) NSMutableArray *stateArray;
@property (retain, nonatomic) IBOutlet UIView *bgView;
@property (nonatomic,retain) NSString * emailID, *zipCode, *strNavigatedFrom;
@property (nonatomic,retain) CardDetailClass *CardDetailData;
@property (nonatomic, assign) UserProfileDataClass *userProfileObj;
@property (retain, nonatomic) IBOutlet UIScrollView *myScrollView;
@property (retain, nonatomic) IBOutlet UIView *topView;
@property (retain, nonatomic) IBOutlet UIView *bottomView;
@property (retain, nonatomic) IBOutlet UILabel *lblUserName;
@property (retain, nonatomic) IBOutlet UILabel *lblCardNumber;
@property (retain, nonatomic) IBOutlet UILabel *lblCardStatus;
@property (retain, nonatomic) IBOutlet UILabel *lblAvailableBalance;
@property (retain, nonatomic) IBOutlet UILabel *lblTopTitle;
@property (retain, nonatomic) IBOutlet UILabel *lblBottomTitle;
@property (retain, nonatomic) IBOutlet UIView *topVewScroll;
@property (retain, nonatomic) IBOutlet UIView *bottomViewScroll;

@property (retain, nonatomic) IBOutlet UITextField *txtEmployeeID;

@property (retain, nonatomic) IBOutlet UITextField *txtUserEmail;

@property (retain, nonatomic) IBOutlet UITextField *txtUserMobileNumber;

@property (retain, nonatomic) IBOutlet UITextField *txtUserPhoneNumber;
@property (retain, nonatomic) IBOutlet UITextField *txtAddressLine1;
@property (retain, nonatomic) IBOutlet UITextField *txtAddressLine2;
@property (retain, nonatomic) IBOutlet UITextField *txtCity;
@property (retain, nonatomic) IBOutlet UITextField *txtZipcode;
@property (retain, nonatomic) IBOutlet UILabel *lblSelectstate;

@property (nonatomic, retain) NSString * strPhoneNumber;

- (IBAction)openUpdateUser:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *btnUpdate;
- (IBAction)tapAtStateCombo:(id)sender;

@end
