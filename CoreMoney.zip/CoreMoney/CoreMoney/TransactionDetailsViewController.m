//
//  TransactionDetailsViewController.m
//  CoreMoney
//class is used for display Transaction Detail
#define SuccessMessage @"Updated Succesfully.."
#define FailureMessage @"Update was Failed"
#define PartiallyMessage @"One or More Update was Failed"

#import "TransactionDetailsViewController.h"
#import "PopUpView.h"
#import "setteldTransaction.h"

@interface TransactionDetailsViewController ()

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil trasactiondata:(setteldTransaction *) trasctinD;
-(void)openBack;
-(void)openSlide;
- (IBAction)clickedBtnUpdate:(id)sender;
-(void) fillData;
-(void) setOfset;
-(void) removePopupview;
-(void)removeChangeStatusView;
-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index;
-(void) openPopupViewAtAddBtn :(NSMutableArray *)catArray :(NSString *)title;
-(int) checkExpCatIndex:(NSString *)str;
- (IBAction)clickedExpcatAddFirstBtn:(id)sender;
- (IBAction)clickedExpcatAddSecondBtn:(id)sender;
- (IBAction)clickedExpcatAddThirdBtn:(id)sender;
-(void)dismissKeyboard;
-(void)resizeFrame;
- (void)keyboardWillHide:(NSNotification *)notification;
- (void)keyboardWillShow:(NSNotification *)notification;
@end

@implementation TransactionDetailsViewController
@synthesize cardStatus;
@synthesize SelectedRecordNumber,balance;
@synthesize memoArray,expenseCategoryArray;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil trasactiondata:(setteldTransaction *) trasctinD
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        trnOBJ = trasctinD;
        
    }
    return self;
}
// Pop to previous View
-(void)openBack
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    [self.navigationController popViewControllerAnimated:YES];
}
// Open Slider Menu
-(void)openSlide
{
    if ([AppDelegate sharedAppDelegate].isSlideViewVisible==NO)
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=YES;
        [[SlideMenuView sharedManager] showMenuWithPageType:[AppDelegate sharedAppDelegate].classType];
    }
    else
    {
        [AppDelegate sharedAppDelegate].isSlideViewVisible=NO;
        [[SlideMenuView sharedManager] hideMenu];
    }
}

-(void) satteledView{
    
    if (isSatteled == YES) {
        self.topView.hidden = YES;
        self.bottumView.frame = CGRectMake(0, 0, self.bottumView.frame.size.width, self.bottumView.frame.size.height);
        self.pageScrollVw.contentSize = self.bottumView.frame.size;
    }
}
- (void)viewDidLoad
{
    
    cardDataObj=[[AppDelegate sharedAppDelegate].arrCardDetailArray objectAtIndex:[AppDelegate sharedAppDelegate].CardDetailPageIndex];
    self.mySubView.frame=CGRectMake(0,IS_IPAD?IS_IOS7?20:20:IS_IOS7?60:0, 320, 460);
    
    [self.view addSubview:self.mySubView];
    self.pageScrollVw.frame = CGRectMake(0, 78, self.pageScrollVw.frame.size.width, self.pageScrollVw.frame.size.height);
    [self.mySubView addSubview:self.pageScrollVw];
    self.pageScrollVw.contentSize = CGSizeMake(self.pageScrollVw.frame.size.width, self.pageScrollVw.frame.size.height+200 + 60);
    
    addNavigationBar(languageSelectedStringForKey(@"Transactions Details"), NAV_LEFT_BACK, NAV_RIGHT_SLIDE, self);
    [AppDelegate sharedAppDelegate].classType=PAGE_TRANSACTIONS_DETAILS;
    
    
    self.pageScrollVw.maindelegate=self;
    toolbar = [[UIToolbar alloc] init];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    [super viewDidLoad];
    self.txtMemoContent.delegate = self;
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillDisappear:(BOOL)animated
{
    isDisappear=YES;
    [super viewWillDisappear:animated];
}

-(void)changeLangusge
{
    self.lblMemoText.text=languageSelectedStringForKey(@"Memo Text");
    self.lblExpenseCategoryText.text=languageSelectedStringForKey(@"Expense Categories");
    self.lblTransactionDate.text=languageSelectedStringForKey(@"Transaction Date Time");
    self.lblPostedTime.text=languageSelectedStringForKey(@"Posted Date Time");
    self.lblCityText.text=languageSelectedStringForKey(@"City");
    self.lblBalanceAtText.text=languageSelectedStringForKey(@"Balance at Transaction");
    self.lblHoldAmountText.text=languageSelectedStringForKey(@"Hold Amount");
    self.lblExpCatAddFirst.text=languageSelectedStringForKey(@"Add");
    self.lblExpCatAddSecond.text=languageSelectedStringForKey(@"Add");
    self.lblExpCatAddThird.text=languageSelectedStringForKey(@"Add");
    [self.btnUpdate setTitle:languageSelectedStringForKey(@"Update") forState:UIControlStateNormal];
}
-(void)viewWillAppear:(BOOL)animated
{
    self.lblExpCatAddFirst.tag=777;
    self.lblExpCatAddSecond.tag=777;
    self.lblExpCatAddThird.tag=777;
    
//    self.btnAddMemo.backgroundColor =
    
    uniqueid1=0;
    uniqueid2=0;
    uniqueid3=0;
    MemoUniqueId=0;
    
    [self changeLangusge];
    
    isDisappear=NO;
//    NavigationBarStyle();
    [AppDelegate sharedAppDelegate].classType=PAGE_TRANSACTIONS_DETAILS;
    indexExpCat=0;
    
    self.viewPopUpAddMemo.hidden = YES;

    if (trnOBJ.transactionType==Setteled_txn)
    {
        isSatteled=NO;
    }else
    {
        isSatteled=YES;
    }
    
    if (![trnOBJ.COREAUTH_TRANID isKindOfClass:[NSNull class]] && trnOBJ.COREAUTH_TRANID !=nil)
    {
        self.holdSpendView.hidden=NO;
    }else
    {
        self.holdSpendView.hidden=YES;
        self.pageScrollVw.contentSize = CGSizeMake(self.pageScrollVw.frame.size.width, self.pageScrollVw.frame.size.height+115 + 60);
    }
    [self satteledView];
    
     [self fillData];
    
    [self setMemo];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_lblUserName release];
    [_lblCardNumber release];
    [_lblStatus release];
    [_lblBalance release];
    [_pageScrollVw release];
    [_lblTrasactionDateTime release];
    [_lblPostedDateTime release];
    [_lblTrasactionType release];
    [_lblBalAtTrasaction release];
    [_lblHoldAmount release];
    [_txtMemo release];
    [_btnUpdate release];
    [_lblExpCatAddFirst release];
    [_lblExpCatAddSecond release];
    [_lblExpCatAddThird release];
    [_imgArrowExpCatFirst release];
    [_imgExpCatArrowSecond release];
    [_imgExpCatArrowThird release];
     
    [toolbar release];
    [_lblCityName release];
    [_topView release];
    [_bottumView release];
    [_mySubView release];
    [_lblLastTrasactionTime release];
    [_holdSpendView release];
    [_lblMemoText release];
    [_lblExpenseCategoryText release];
    [_lblTransactionDate release];
    [_lblPostedTime release];
    [_lblCityText release];
    [_lblBalanceAtText release];
    [_lblHoldAmountText release];
    
    cardDataObj=nil;
    expenseData=nil;
    MemoObj=nil;
    trnOBJ=nil;
    
    
    if (self.memoArray!=nil)
    {
        [self.memoArray removeAllObjects];
        [self.memoArray release];
        self.memoArray=nil;
    }
    
    if (self.expenseCategoryArray!=nil)
    {
        [self.expenseCategoryArray removeAllObjects];
        [expenseCategoryArray release];
        expenseCategoryArray=nil;
    }
    [_viewPopUpAddMemo release];
    [_btnAddMemoPopUpCancel release];
    [_btnAddMemoPopUpOk release];
    [super dealloc];
    
}
- (void)viewDidUnload {
    [self setLblUserName:nil];
    [self setLblCardNumber:nil];
    [self setLblStatus:nil];
    [self setLblBalance:nil];
    [self setPageScrollVw:nil];
    [self setLblTrasactionDateTime:nil];
    [self setLblPostedDateTime:nil];
    [self setLblTrasactionType:nil];
    [self setLblBalAtTrasaction:nil];
    [self setLblHoldAmount:nil];
    [self setTxtMemo:nil];
    [self setBtnUpdate:nil];
    [self setLblExpCatAddFirst:nil];
    [self setLblExpCatAddSecond:nil];
    [self setLblExpCatAddThird:nil];
    [self setImgArrowExpCatFirst:nil];
    [self setImgExpCatArrowSecond:nil];
    [self setImgExpCatArrowThird:nil];
    [self setLblCityName:nil];
    [self setTopView:nil];
    [self setBottumView:nil];
    [self setMySubView:nil];
    [self setLblLastTrasactionTime:nil];
    [self setHoldSpendView:nil];
    [self setLblMemoText:nil];
    [self setLblExpenseCategoryText:nil];
    [self setLblTransactionDate:nil];
    [self setLblPostedTime:nil];
    [self setLblCityText:nil];
    [self setLblBalanceAtText:nil];
    [self setLblHoldAmountText:nil];
    [self setViewPopUpAddMemo:nil];
    [self setBtnAddMemoPopUpCancel:nil];
    [self setBtnAddMemoPopUpOk:nil];
    [super viewDidUnload];
}

/**
 Calls when Add Memo button Touched
 */
- (IBAction)touchedBtnAddMemoPopUpOk:(id)sender
{
    NSString *strTextWithoutSpace = [self.txtMemoContent.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    

    if (strTextWithoutSpace.length > 0)
    {   
        [self addMemo];
    }
    else
    {
        showAlertScreen(nil, languageSelectedStringForKey(@"Memo cannot be empty"));
    }

}

- (IBAction)touchedBtnAddMemoPopUpCancel:(id)sender
{
//    [self.viewPopUpAddMemo removeFromSuperview];
    [self removePopupview];
}

- (IBAction)touchedBtnAddMemo:(id)sender
{
    
    popupView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    popupView.backgroundColor = [UIColor clearColor];
    
    [self.view addSubview:popupView];
    
    self.viewPopUpAddMemo.hidden = NO;
    self.viewPopUpAddMemo.center =popupView.center;
    self.viewPopUpAddMemo.layer.cornerRadius = 5;
    self.viewPopUpAddMemo.layer.masksToBounds = YES;
    self.viewPopUpAddMemo.layer.borderWidth = 2.0f;
    self.viewPopUpAddMemo.layer.borderColor = [UIColor colorWithRed:6.0/255.0 green:78.0/255.0 blue:100.0/255.0 alpha:0.7].CGColor;
    self.txtMemoContent.text = @"";
    [popupView addSubview:self.viewPopUpAddMemo];
    
}

//method called when update button clicked




- (IBAction)clickedBtnUpdate:(id)sender
{
    expenseCategoryCount=0;
    SucessCount=0;
   
        if (isMemoSet)
        {
            [self updateMemo];
        }
        else
        {
                
            if ([self.txtMemo.text length]>0)
            {
                [self addMemoOnly];
            }
            else
            {
                SucessCount++;
                [self updateExpenseCategories];

            }
        }
    
}


-(void)checkFirstCategory
{
    expenseCategoryCount++;
    if (self.lblExpCatAddFirst.tag!=777)
    {
        MemoDataClass *memoDataobj;
        if (uniqueid1!=0)
        {
            for (int i=0; i<[self.memoArray count]; i++)
            {
                memoDataobj=[self.memoArray objectAtIndex:i];
                if ([memoDataobj.UNIQUEID longLongValue] == uniqueid1)
                {
                    break;
                }
            }
            if ([memoDataobj.EXPCAT_VALUE_ID intValue] != self.lblExpCatAddFirst.tag )
            {
                desvcExpenseCategoryValueID=self.lblExpCatAddFirst.tag;
                [self updateExpenseCategory:uniqueid1:1];
            }else
            {
                SucessCount++;
                [self checkSecondCategory];

            }
            
        }else
        {
            [self addExpenseCategory:self.lblExpCatAddFirst.tag :1];
        }
    }else
    {
        SucessCount++;
        [self checkSecondCategory];
    }
}

-(void)checkSecondCategory
{
    expenseCategoryCount++;
    if (self.lblExpCatAddSecond.tag!=777)
    {
        MemoDataClass *memoDataobj;
        if (uniqueid2!=0)
        {
            for (int i=0; i<[self.memoArray count]; i++)
            {
                memoDataobj=[self.memoArray objectAtIndex:i];
                if ([memoDataobj.UNIQUEID longLongValue] == uniqueid2)
                {
                    break;
                }
            }
            if ([memoDataobj.EXPCAT_VALUE_ID intValue] != self.lblExpCatAddSecond.tag )
            {
                desvcExpenseCategoryValueID=self.lblExpCatAddSecond.tag;
                [self updateExpenseCategory:uniqueid2:2];
            }else
            {
                SucessCount++;
                [self checkThirdCategory];
            }
        }else
        {
            [self addExpenseCategory:self.lblExpCatAddSecond.tag :2];
        }
    }else
    {
        SucessCount++;
        [self checkThirdCategory];
    }
}


-(void)checkThirdCategory
{
    expenseCategoryCount++;
    if (self.lblExpCatAddThird.tag!=777)
    {
        MemoDataClass *memoDataobj;
        if (uniqueid3!=0)
        {
            for (int i=0; i<[self.memoArray count]; i++)
            {
                memoDataobj=[self.memoArray objectAtIndex:i];
                if ([memoDataobj.UNIQUEID longLongValue] == uniqueid3)
                {
                    break;
                }
            }
            if ([memoDataobj.EXPCAT_VALUE_ID intValue] != self.lblExpCatAddThird.tag )
            {
                desvcExpenseCategoryValueID=self.lblExpCatAddThird.tag;
                [self updateExpenseCategory:uniqueid3 :3];
            }else
            {
                showAlertWithOkButton(nil, SuccessMessage, 0, self);
               [[AppDelegate sharedAppDelegate] removeLoadingView];
            }

        }else
        {
            [self addExpenseCategory:self.lblExpCatAddThird.tag :3];
        }
    }else
    {
        SucessCount++;
        
        if (SucessCount==4)
        {
            showAlertWithOkButton(nil, SuccessMessage, 0, self);
            
        }else if(SucessCount>0 && SucessCount<4)
        {
            showAlertWithOkButton(nil, PartiallyMessage, 0, self);
        }else
        {
            showAlertWithOkButton(nil, FailureMessage, 0, self);
        }

        [[AppDelegate sharedAppDelegate] removeLoadingView];
    }
}

-(void)checkForExpenseCat :(int)value :(int)pos
{
    switch (pos)
    {
        case 1:
            [self addExpenseCategory:value :pos];
            break;
        case 2:
        {
            if (cat1==1)
            {
                if (cat2==2)
                {
                    [self addExpenseCategory:value :3];
                }else if (cat2==3)
                {
                    [self addExpenseCategory:value :2];
                }else
                {
                     cat2=2;
                    [self addExpenseCategory:value :2];
                }
            }else if (cat1==2)
            {
                if (cat2==1)
                {
                    [self addExpenseCategory:value :3];
                }else if (cat2==3)
                {
                    [self addExpenseCategory:value :1];
                }else
                {
                     cat2=1;
                    [self addExpenseCategory:value :1];
                }
            }else if (cat1==3)
            {
                if (cat2==1)
                {
                    [self addExpenseCategory:value :2];
                }else if (cat2==2)
                {
                    [self addExpenseCategory:value :1];
                }else
                {
                    cat2=1;
                    [self addExpenseCategory:value :1];
                }
            }

        }
        break;
        case 3:
        {
            if (cat1==1)
            {
                if (cat2==2)
                {
                    [self addExpenseCategory:value :3];
                }else if (cat2==3)
                {
                    [self addExpenseCategory:value :2];
                }else
                {
                     cat2=2;
                    [self addExpenseCategory:value :2];
                }
            }else if (cat1==2)
            {
                if (cat2==1)
                {
                    [self addExpenseCategory:value :3];
                }else if (cat2==3)
                {
                    [self addExpenseCategory:value :1];
                }else
                {
                     cat2=1;
                    [self addExpenseCategory:value :1];
                }
            }else if (cat1==3)
            {
                if (cat2==1)
                {
                    [self addExpenseCategory:value :2];
                }else if (cat2==2)
                {
                    [self addExpenseCategory:value :1];
                }else
                {
                    cat2=1;
                    [self addExpenseCategory:value :1];
                }
            }
        }
        default:
            break;
    }
}
//method use for add expense category 
-(void)addExpenseCategory :(int)Value :(int)pos
{
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=AddMemo;
    
    switch (pos) {
        case 1:
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=%@&deCIAPrimaryAccountNumber=%@&deCIAFirstName=&deCIALastName=&deCIAMemoType=&deCIACardNumber=&deMemoReason=&deMemoTranID=%@&deCIAMemoMessage=&deIVRSource=%@&desvcExpenseCategoryValue1=%d&desvcExpenseCategoryValue2=&desvcExpenseCategoryValue3=&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.CLIENTID,cardDataObj.CARDNUMBER,trnOBJ.SettledTxnTranId,[SystemConfiguration sharedSystemConfig].deIVRSource,Value] ServiceName:svcCIAMemoAdd];
            break;
        case 2:
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=%@&deCIAPrimaryAccountNumber=%@&deCIAFirstName=&deCIALastName=&deCIAMemoType=&deCIACardNumber=&deMemoReason=&deMemoTranID=%@&deCIAMemoMessage=&deIVRSource=%@&desvcExpenseCategoryValue1=&desvcExpenseCategoryValue2=%d&desvcExpenseCategoryValue3=&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.CLIENTID,cardDataObj.CARDNUMBER,trnOBJ.SettledTxnTranId,[SystemConfiguration sharedSystemConfig].deIVRSource,Value] ServiceName:svcCIAMemoAdd];
            break;

        case 3:
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=%@&deCIAPrimaryAccountNumber=%@&deCIAFirstName=&deCIALastName=&deCIAMemoType=&deCIACardNumber=&deMemoReason=&deMemoTranID=%@&deCIAMemoMessage=&deIVRSource=%@&desvcExpenseCategoryValue1=&desvcExpenseCategoryValue2=&desvcExpenseCategoryValue3=%d&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.CLIENTID,cardDataObj.CARDNUMBER,trnOBJ.SettledTxnTranId,[SystemConfiguration sharedSystemConfig].deIVRSource,Value] ServiceName:svcCIAMemoAdd];
            break;
            
        default:
            break;
    }
    
    [DataReq release];
}
//method use for update expense category 
-(void)updateExpenseCategory :(long)uniqueId :(int)cateType
{
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    MemoDataClass *memoDataobj;
    
    
    for (int i=0; i<[self.memoArray count]; i++)
    {
        memoDataobj=[self.memoArray objectAtIndex:i];
        if ([memoDataobj.UNIQUEID longLongValue] == uniqueId)
        {
            break;
        }
    }
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=UpdateMemo;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAUniqueId=%@&deCIAAccountNumber=%@&deCIAMemoMessage=%@&deMemoReason=%@&deMemoTranID=%@&deSetFlagValue_BankAct=1&desvcExpenseCategoryValueID=%d&desvcExpenseCategoryType=%d&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,memoDataobj.UNIQUEID,cardDataObj.ACCOUNTNUMBER,memoDataobj.COMMENT,[NSString stringWithFormat:@"%@",checkISNullStrings(memoDataobj.MemoReason)?@"":memoDataobj.MemoReason],memoDataobj.MemoTranID,desvcExpenseCategoryValueID,cateType,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCIAMemoUpdate];
    
    [DataReq release];
}


-(void)updateExpenseCategories
{
    RequestID=Update_Expense_Categories;
    
    [self checkFirstCategory];
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self removePopupview];
}
//method use for fill data 
-(void) fillData
{
    
    self.lblUserName.text = ConvertDateFormatemmddyyyy(trnOBJ.SettledTxnTranTime);

    self.lblCardNumber.text =[NSString stringWithFormat:@"%@",checkISNullStrings(trnOBJ.description)?@"":trnOBJ.Transaction_Description];
    
    if (trnOBJ.transactionType==Outstanding_txn)
    {
        self.lblStatus.text =@"(Pending)";
        self.lblStatus.hidden=NO;
    }else
    {
        self.lblStatus.hidden=YES;
        
    }
    
    
    self.lblStatus.textColor = [UIColor redColor];
    
    self.lblBalance.text = [NSString stringWithFormat:@"%@", displayCurrency(ChangeTocurrency(trnOBJ.Transaction_Amount))];
       

    self.lblTrasactionDateTime.text =trnOBJ.SettledTxnTranTime;
   
    self.lblPostedDateTime.text = trnOBJ.SettledTxnPostTime;
    
    self.lblTrasactionType.text = trnOBJ.TypeOfTran;
    
    self.lblBalAtTrasaction.text =(trnOBJ.transactionType==Outstanding_txn?@"":[NSString stringWithFormat:@"%@",displayCurrency(ChangeTocurrency(trnOBJ.Current_Balance))]);
    
    self.lblHoldAmount.text =[NSString stringWithFormat:@"%@",displayCurrency( ChangeTocurrency(trnOBJ.HeldAmount))];
    
    self.lblCityName.text =(checkISNullStrings(trnOBJ.MerchantCity)?@"" :trnOBJ.MerchantCity);
    
    self.lblTransactionDescription.text =(checkISNullStrings(trnOBJ.Transaction_Description)?@"" :trnOBJ.Transaction_Description);
   
}
//method use for set memo
-(void)setMemo
{
    cat1=0;
    cat2=0;
    self.txtMemo.text = @"";
        self.lblExpCatAddFirst.tag=777;
        self.lblExpCatAddSecond.tag=777;
        self.lblExpCatAddThird.tag=777;
        self.lblExpCatAddFirst.text=@"Add";
        self.lblExpCatAddSecond.text=@"Add";
        self.lblExpCatAddThird.text=@"Add";
        self.lblLastTrasactionTime.text=[NSString stringWithFormat:@"%@",languageSelectedStringForKey(@"Last updated : ")];
        
        isMemoSet=NO;
        
        
        for (int i=0; i<[self.memoArray count]; i++)
        {
            MemoDataClass *memo=[self.memoArray objectAtIndex:i];
            
            if ([memo.CATEGORY_LABEL isEqualToString:@"MEMO"])
            {
                if (!isMemoSet)
                {
                    if (!checkISNullStrings(memo.COMMENT))
                    {
                        self.txtMemo.text=(checkISNullStrings(memo.COMMENT)?@"":memo.COMMENT);
                        
                        MemoUniqueId=[memo.UNIQUEID longLongValue];
                        
                        isMemoSet=YES;
                        
                        self.lblLastTrasactionTime.text=[NSString stringWithFormat:@"%@%@ %@%@",languageSelectedStringForKey(@"Last updated : "),checkISNullStrings(memo.Captured_By)?@"":memo.Captured_By,checkISNullStrings(memo.CREATIONDATE)?@"":memo.CREATIONDATE,checkISNullStrings(memo.CREATIONTIME)?@"":ConvertFromTimeStamp(memo.CREATIONTIME)];
                    }
                }
            }
            else
            {
                if (self.lblExpCatAddFirst.tag==777)
                {
                    if ([memo.CATEGORY_TYPE intValue]==1)
                    {
                        self.lblExpCatAddFirst.text=removeFirstSpaces(memo.EXPCAT_VALUE);
                        self.lblExpCatAddFirst.tag=[memo.EXPCAT_VALUE_ID intValue];
                        cat1=[memo.CATEGORY_TYPE intValue];
                        uniqueid1=[memo.UNIQUEID longLongValue];
                    }
                }
                if (self.lblExpCatAddSecond.tag==777)
                {
                    if ([memo.CATEGORY_TYPE intValue]==2)
                    {
                    self.lblExpCatAddSecond.text=removeFirstSpaces(memo.EXPCAT_VALUE);
                    self.lblExpCatAddSecond.tag=[memo.EXPCAT_VALUE_ID intValue];
                    
                    uniqueid2=[memo.UNIQUEID longLongValue];
                    
                    cat2=[memo.CATEGORY_TYPE intValue];
                    }
                }
                if (self.lblExpCatAddThird.tag==777)
                {
                    if ([memo.CATEGORY_TYPE intValue]==3)
                    {
                    self.lblExpCatAddThird.text=removeFirstSpaces(memo.EXPCAT_VALUE);
                    self.lblExpCatAddThird.tag=[memo.EXPCAT_VALUE_ID intValue];
                    uniqueid3=[memo.UNIQUEID longLongValue];
                    }
                }
            }
        }
    [[AppDelegate sharedAppDelegate]removeLoadingView];
}

// Method to Remove AddMemo PopUp view From Super View
-(void) removeAddMemoPopupView
{
    if ([self.viewPopUpAddMemo isDescendantOfView:self.view]) {
        [self.viewPopUpAddMemo removeFromSuperview];
    }
}


//method use for getting response from server
-(void)getResponce:(id)jsonData
{
    switch (RequestID) {
        case GetMemo:
        {
                if (!self.memoArray)
                {
                    self.memoArray=[[NSMutableArray alloc]init];
                }else
                {
                    [self.memoArray removeAllObjects];
                }
            
            if ([jsonData isKindOfClass:[NSArray class]])
            {
                 self.memoArray=jsonData;
            }
            
            [self setMemo];
        }
            break;
            
            case Update_Memo:
        {
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                LoginResponceDataClass *data=(LoginResponceDataClass *)jsonData;
                if (data.Error_Code==0)
                {
                    [self updateExpenseCategories];
                    [[AppDelegate sharedAppDelegate]addloadingView];
                }
                else
                {
                    SucessCount++;
                    [self updateExpenseCategories];
                }
            }
        }
            break;
            case GetExpense:
        {
            if ([jsonData isKindOfClass:[NSArray class]])
            {
               self.expenseCategoryArray=jsonData;
            }
            
            if (trnOBJ.MemoFlag==1)
            {
                [self getMemoData];
            }
            [[AppDelegate sharedAppDelegate]addloadingView];
        }
            break;
            case Add_Memo:
        {
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                
                LoginResponceDataClass  *loginData = (LoginResponceDataClass *)jsonData;
                
                showAlertScreen(nil, loginData.ErrorMsg);
                if (loginData.Error_Found == NO)
                {
                    [self removePopupview];
                    [self getMemoData];
                    [[AppDelegate sharedAppDelegate]addloadingView];
                }
            }
            
        }break;
            
            case Update_Expense_Categories:
        {
            if (expenseCategoryCount==1)
            {
                LoginResponceDataClass *data=(LoginResponceDataClass *)jsonData;
                if (data.Error_Code==0)
                {
                    [self checkSecondCategory];
                }
                else
                {
                    SucessCount++;
                    [self checkSecondCategory];
                }
                
                
            }else if (expenseCategoryCount==2)
            {
                LoginResponceDataClass *data=(LoginResponceDataClass *)jsonData;
                if (data.Error_Code==0)
                {
                    [self checkThirdCategory];
                }
                else
                {
                    SucessCount++;
                    [self checkThirdCategory];
                }
                
            }else if (expenseCategoryCount==3)
            {
                if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
                {
                    LoginResponceDataClass  *loginData = (LoginResponceDataClass *)jsonData;
                    
                    if (loginData.Error_Code==0)
                    {
                        
                    }
                    else
                    {
                        SucessCount++;
                    }
                }
                [[AppDelegate sharedAppDelegate]removeLoadingView];
                if (SucessCount==4)
                {
                    showAlertWithOkButton(nil, SuccessMessage, 0, self);
                    
                }else if(SucessCount>0 && SucessCount<4)
                {
                    showAlertWithOkButton(nil, PartiallyMessage, 0, self);
                }else
                {
                  showAlertWithOkButton(nil, FailureMessage, 0, self);
                }
            }
        }break;
            
            case Add_Memo_Only:
        {
            if ([jsonData isKindOfClass:[LoginResponceDataClass class]])
            {
                
                LoginResponceDataClass  *loginData = (LoginResponceDataClass *)jsonData;
                
                if (loginData.Error_Code==0)
                {
                    [self updateExpenseCategories];
                }
                else
                {
                    SucessCount++;
                    [self updateExpenseCategories];
                }
            }
        }
            break;
        default:
            break;
    }
}
#pragma mark - Alert view delegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [[AppDelegate sharedAppDelegate] addloadingView];
    [self getMemoData];
}
//method use for update memo
-(void)updateMemo
{
    
    RequestID=Update_Memo;
    
    MemoDataClass *memoDataobj;
    
    for (int i=0; i<[self.memoArray count]; i++)
    {
        memoDataobj=[self.memoArray objectAtIndex:i];
        if ([memoDataobj.UNIQUEID longLongValue] == MemoUniqueId)
        {
            break;
        }
    }
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    int memoFlag;
    
    if (self.txtMemo.text.length==0)
    {
        memoFlag=2;
        
        [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
        [SystemConfiguration sharedSystemConfig].dbbServiceName=UpdateMemo;
        
        [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAUniqueId=%@&deCIAAccountNumber=%@&deCIAMemoMessage=MEMO&deMemoReason=&deMemoTranID=%@&deSetFlagValue_BankAct=%d&desvcExpenseCategoryValueID=&desvcExpenseCategoryType=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,memoDataobj.UNIQUEID,memoDataobj.ACCOUNTNUMBER,memoDataobj.MemoTranID,memoFlag,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCIAMemoUpdate];
    }
    else
    {
        memoFlag=1;
        
        if ([memoDataobj.COMMENT isEqualToString:self.txtMemo.text])
        {
            SucessCount++;
            [self updateExpenseCategories];
            
        }else
        {
            [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
            [SystemConfiguration sharedSystemConfig].dbbServiceName=UpdateMemo;
            
            [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAUniqueId=%@&deCIAAccountNumber=%@&deCIAMemoMessage=%@&deMemoReason=%@&deMemoTranID=%@&deSetFlagValue_BankAct=%d&desvcExpenseCategoryValueID=&desvcExpenseCategoryType=&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,memoDataobj.UNIQUEID,memoDataobj.ACCOUNTNUMBER,[NSString stringWithFormat:@"%@",checkISNullStrings(self.txtMemo.text)?@"MEMO":self.txtMemo.text],[NSString stringWithFormat:@"%@",checkISNullStrings(memoDataobj.MemoReason)?@"":memoDataobj.MemoReason],memoDataobj.MemoTranID,memoFlag,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCIAMemoUpdate];
        }

    }
    
    [DataReq release];
    
}


//method use for add memo
-(void)addMemo
{
    
    RequestID=Add_Memo;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=AddMemo;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=%@&deCIAPrimaryAccountNumber=%@&deCIAFirstName=&deCIALastName=&deCIAMemoType=&deCIACardNumber=&deMemoReason=10&deMemoTranID=%@&deCIAMemoMessage=%@&deIVRSource=%@&desvcExpenseCategoryValue1=%@&desvcExpenseCategoryValue2=%@&desvcExpenseCategoryValue3=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.CLIENTID,cardDataObj.CARDNUMBER,trnOBJ.SettledTxnTranId,[NSString stringWithFormat:@"%@",checkISNullStrings(self.txtMemoContent.text)?@"":self.txtMemoContent.text],[SystemConfiguration sharedSystemConfig].deIVRSource,@"",@"",@""] ServiceName:svcCIAMemoAdd];
    
    [DataReq release];

}

-(void)addMemoOnly
{
    
    RequestID=Add_Memo_Only;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=AddMemo;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=%@&deCIAPrimaryAccountNumber=%@&deCIAFirstName=&deCIALastName=&deCIAMemoType=&deCIACardNumber=&deMemoReason=10&deMemoTranID=%@&deCIAMemoMessage=%@&deIVRSource=%@&desvcExpenseCategoryValue1=&desvcExpenseCategoryValue2=&desvcExpenseCategoryValue3=&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.CLIENTID,cardDataObj.CARDNUMBER,trnOBJ.SettledTxnTranId,[NSString stringWithFormat:@"%@",checkISNullStrings(self.txtMemo.text)?@"":self.txtMemo.text],[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCIAMemoAdd];
    
    [DataReq release];
    
}

//method to get data of memo
-(void)getMemoData
{

    if (self.memoArray!=nil)
    {
        [self.memoArray removeAllObjects];
        [self.memoArray release];
        self.memoArray = nil;
    }
 
    
    self.lblExpCatAddFirst.tag=777;
    self.lblExpCatAddSecond.tag=777;
    self.lblExpCatAddThird.tag=777;
    self.lblExpCatAddFirst.text=@"Add";
    self.lblExpCatAddSecond.text=@"Add";
    self.lblExpCatAddThird.text=@"Add";
    uniqueid1=0;
    uniqueid2=0;
    uniqueid3=0;
    
    isMemoSet=NO;

    
    RequestID=GetMemo;
    
    [[AppDelegate sharedAppDelegate] addloadingView];
    
    DataParsingClass *DataReq=[[DataParsingClass alloc] init];
    DataReq.Datadelegate=self;
    
    
    [SystemConfiguration sharedSystemConfig].dbbSystemExtLogin=@"1";
    [SystemConfiguration sharedSystemConfig].dbbServiceName=GetMEmoREcord;
    
    [DataReq SendRequest:API_DOMAIN Parameter:[NSString stringWithFormat:@"dbbSystemExtLogin=%@&user=%@&password=%@&dbbServiceName=%@&deCIAClientID=%@&deCIAPrimaryAccountNumber=%@&deCIACreationDateFrom=&deCIACreationDateTo=&deTCIVRNOOFTRANSACTIONS=&deMemoUserId=%@&deMemoTranID=%@&deIVRSource=%@&deDBBServiceApiLevel=&deDBBServiceAppID=",[SystemConfiguration sharedSystemConfig].dbbSystemExtLogin,[UserDetailClass sharedUser].strUserId,[UserDetailClass sharedUser].StrPassword, [SystemConfiguration sharedSystemConfig].dbbServiceName,cardDataObj.CLIENTID,cardDataObj.ACCOUNTNUMBER,[UserDetailClass sharedUser].strUserId,trnOBJ.SettledTxnTranId,[SystemConfiguration sharedSystemConfig].deIVRSource] ServiceName:svcCIAMemoView];
    
    [DataReq release];
}


// set page in previouse position
-(void) setOfset{
    //[self.pageScrollVw setContentSize:CGSizeMake(self.pageScrollVw.frame.size.width,self.pageScrollVw.frame.size.height+270)];
    
    [self.txtMemo resignFirstResponder];
    
}
//method to remove popup view
-(void) removePopupview
{
    if (popupView) {
        [popupView removeFromSuperview];
        popupView= nil;
    }
    switch (expCatAddtype) {
        case EXP_CAT_ADD_FIRST:
        {
            self.imgArrowExpCatFirst.frame = CGRectMake(self.imgArrowExpCatFirst.frame.origin.x, self.imgArrowExpCatFirst.frame.origin.y, 9, 13);
            self.imgArrowExpCatFirst.image = [UIImage imageNamed:@"imgStatusInactive.png"];
        }
            break;
        case EXP_CAT_ADD_SECOND:{
            self.imgExpCatArrowSecond.frame = CGRectMake(self.imgExpCatArrowSecond.frame.origin.x, self.imgExpCatArrowSecond.frame.origin.y, 9, 13);
        
            self.imgExpCatArrowSecond.image = [UIImage imageNamed:@"imgStatusInactive.png"];
        }
            break;
        case EXP_CAT_ADD_THIRD:
        {
            self.imgExpCatArrowThird.frame = CGRectMake(self.imgExpCatArrowThird.frame.origin.x, self.imgExpCatArrowThird.frame.origin.y, 9, 13);
        
            self.imgExpCatArrowThird.image = [UIImage imageNamed:@"imgStatusInactive.png"];
        }
            break;
        default:
            break;
    }
}
//method to remove change Status view
-(void)removeChangeStatusView
{
    [self removePopupview];
}

-(void)selectQuetionview:(NSString *)question SelectedIndex:(int) index
{
    [self removePopupview];
    indexExpCat = index;
    switch (expCatAddtype)
    {
        case EXP_CAT_ADD_FIRST:
        {
            self.lblExpCatAddFirst.text =removeFirstSpaces(question);
            self.lblExpCatAddFirst.tag=index;
            
        }
            break;
        case EXP_CAT_ADD_SECOND:
        {
            self.lblExpCatAddSecond.text =removeFirstSpaces(question);
            self.lblExpCatAddSecond.tag=index;
        }
            break;
        case EXP_CAT_ADD_THIRD:
        {
            self.lblExpCatAddThird.text = removeFirstSpaces(question);
            self.lblExpCatAddThird.tag=index;
        }
            break;

        default:
            break;
    }
    
    [[AppDelegate sharedAppDelegate]removeLoadingView];
}

#pragma -mark UITextField Method

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self setOfset];
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}

-(BOOL) textViewShouldEndEditing:(UITextView *)textView
{
    if ([textView isEqual:self.txtMemoContent]) {
        self.viewPopUpAddMemo.center = self.view.center;
    }
    return YES;
}

-(BOOL) textViewShouldBeginEditing:(UITextView *)textView
{
  
    
    if([textView isEqual:self.txtMemo]){
        
    }
    if ([textView isEqual:self.txtMemoContent]) {
        [self.viewPopUpAddMemo setFrame:CGRectMake(self.viewPopUpAddMemo.frame.origin.x, self.viewPopUpAddMemo.frame.origin.y - 100, self.viewPopUpAddMemo.frame.size.width, self.viewPopUpAddMemo.frame.size.height)];
    }
    NSLog(@"TextView started Editing");

    
    return YES;
    
}

-(void) openPopupViewAtAddBtn :(NSMutableArray *)catArray :(NSString *)title
{
    popupView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    popupView.backgroundColor = [UIColor clearColor];
    
    [self.view addSubview:popupView];
    
    PopUpView *popvw = [[PopUpView alloc] initWithExpenceCategory:popupView.frame Delegate:self SelectedQue:title Array: catArray];
    [popupView addSubview:popvw];
    
    [popvw release];

}
-(int)checkExpCatIndex:(NSString *)str{
    
    if ([str isEqualToString:@"Food"])
    {
        return 0;
    }
    else if ([str isEqualToString:@"Hotel"])
    {
        return 1;
    }
    else if ([str isEqualToString:@"Travel"])
    {
        return 2;
    }
    else{
        return 0;
    }
    
}
- (IBAction)clickedExpcatAddFirstBtn:(id)sender {
    
    if ([ self.expenseCategoryArray count]>=1)
    {
        
        ExpenseCategoryData *expCatObj=[self.expenseCategoryArray objectAtIndex:0];
        if ([expCatObj.SubCatArray count]==0)
        {
            showAlertScreen(nil, languageSelectedStringForKey(@"Sorry !!! There is no Expense category available for this Business."));
        }else
        {
            expCatAddtype = EXP_CAT_ADD_FIRST;
            indexExpCat = [self checkExpCatIndex:self.lblExpCatAddFirst.text];
            [self openPopupViewAtAddBtn:expCatObj.SubCatArray :expCatObj.CATEGORY_LABEL];
            
            self.imgArrowExpCatFirst.frame = CGRectMake(self.imgArrowExpCatFirst.frame.origin.x, self.imgArrowExpCatFirst.frame.origin.y, 13, 9);
            self.imgArrowExpCatFirst.image = [UIImage imageNamed:@"imgStatusActive.png"];
      }
        
    }else
    {
        showAlertScreen(nil, languageSelectedStringForKey(@"Sorry !!! There is no Expense category available for this Business."));
    }
    

}

- (IBAction)clickedExpcatAddSecondBtn:(id)sender
{
    if ([ self.expenseCategoryArray count]>=2)
    {
        
        ExpenseCategoryData *expCatObj=[self.expenseCategoryArray objectAtIndex:1];
        if ([expCatObj.SubCatArray count]==0)
        {
            showAlertScreen(nil, languageSelectedStringForKey(@"Sorry !!! There is no Expense category available for this Business."));
        }else
        {
            expCatAddtype = EXP_CAT_ADD_SECOND;
            indexExpCat = [self checkExpCatIndex:self.lblExpCatAddSecond.text];
            [self openPopupViewAtAddBtn:expCatObj.SubCatArray:expCatObj.CATEGORY_LABEL];
            self.imgExpCatArrowSecond.frame = CGRectMake(self.imgExpCatArrowSecond.frame.origin.x, self.imgExpCatArrowSecond.frame.origin.y, 13, 9);
            self.imgExpCatArrowSecond.image = [UIImage imageNamed:@"imgStatusActive.png"];        }
        
    }else
    {
        showAlertScreen(nil, languageSelectedStringForKey(@"Sorry !!! There is no Expense category available for this Business."));
    }
    
}

- (IBAction)clickedExpcatAddThirdBtn:(id)sender
{
    if ([ self.expenseCategoryArray count]>=3)
    {
        
        ExpenseCategoryData *expCatObj=[self.expenseCategoryArray objectAtIndex:2];
        if ([expCatObj.SubCatArray count]==0)
        {
            showAlertScreen(nil, languageSelectedStringForKey(@"Sorry !!! There is no Expense category available for this Business."));
        }else
        {
            expCatAddtype = EXP_CAT_ADD_THIRD;
            indexExpCat = [self checkExpCatIndex:self.lblExpCatAddThird.text];
            [self openPopupViewAtAddBtn :expCatObj.SubCatArray:expCatObj.CATEGORY_LABEL];
            self.imgExpCatArrowThird.frame = CGRectMake(self.imgExpCatArrowThird.frame.origin.x, self.imgExpCatArrowThird.frame.origin.y, 13, 9);
            self.imgExpCatArrowThird.image = [UIImage imageNamed:@"imgStatusActive.png"];
        }
        
    }else
    {
        showAlertScreen(nil, languageSelectedStringForKey(@"Sorry !!! There is no Expense category available for this Business."));
    }
}
- (void)keyboardWillShow:(NSNotification *)notification
{
    if(isDisappear)
    {
        return;
    }
    toolbar.hidden=NO;//UIKeyboardFrameEndUserInfoKey
	CGPoint beginCentre = [[[notification userInfo] valueForKey:@"UIKeyboardCenterBeginUserInfoKey"] CGPointValue];
    
	CGPoint endCentre = [[[notification userInfo] valueForKey:@"UIKeyboardCenterEndUserInfoKey"] CGPointValue];
	CGRect keyboardBounds = [[[notification userInfo] valueForKey:@"UIKeyboardBoundsUserInfoKey"] CGRectValue];
	UIViewAnimationCurve animationCurve = [[[notification userInfo] valueForKey:UIKeyboardAnimationCurveUserInfoKey] intValue];
	NSTimeInterval animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
	
    //0,0,self.view.bounds.size.width,44
    toolbar.frame = CGRectMake(0,480,320,44);
    toolbar.barStyle = UIBarStyleBlackOpaque ;
    toolbar.tintColor = [UIColor darkGrayColor];
    
    //  UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"doneType"] style:UIBarButtonItemStylePlain target:self action:@selector(dismissKeyboard)];
	UIBarButtonItem *doneButton= [[UIBarButtonItem alloc]
                                  initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(dismissKeyboard)];
    
    if (nil == toolbar) {
		
		if(nil == toolbar) {
            
            [self.navigationController.view addSubview:toolbar];
			toolbar.frame = CGRectMake(beginCentre.x - (keyboardBounds.size.width/2),
                                           beginCentre.y - (keyboardBounds.size.height/2) - toolbar.frame.size.height,
                                           toolbar.frame.size.width,
                                           toolbar.frame.size.height);
			
            
            // [self.navigationController.view addSubview:toolbar];
		}
	}
    [toolbar setItems:[NSArray arrayWithObjects:doneButton,nil]];
    [self.view.window  addSubview:toolbar];
	[UIView beginAnimations:@"RS_showKeyboardAnimation" context:nil];
	[UIView setAnimationCurve:animationCurve];
	[UIView setAnimationDuration:animationDuration];
	
	toolbar.alpha = 1.0;
	toolbar.frame = CGRectMake(endCentre.x - (keyboardBounds.size.width/2),
                                   endCentre.y - (keyboardBounds.size.height/2) - toolbar.frame.size.height - self.view.frame.origin.y,
                                   toolbar.frame.size.width,
                                   toolbar.frame.size.height);
	[UIView commitAnimations];
	
	keyboardToolbarShouldHide = YES;
    
    [self performSelector:@selector(resizeFrame) withObject:nil afterDelay:0.3];
    
}

-(void)dismissKeyboard
{
    [self setOfset];
    [self.txtMemo resignFirstResponder];
    [self.txtMemoContent resignFirstResponder];
}
-(void)resizeFrame
{
//    faceBookTextImage.frame = CGRectMake(CGRectGetMinX(faceBookTextImage.frame), CGRectGetMinY(faceBookTextImage.frame), faceBookTextImage.frame.size.width,CGRectGetMinY(toolbar.frame)-CGRectGetMinY(faceBookTextImage.frame)-SIZE_PADDING_DEFAULT-NAVIGATIONBAR_HEIGHT-STATUSBAR_HEIGHT);
//    txtFacebook.frame=CGRectMake(CGRectGetMinX(faceBookTextImage.frame), CGRectGetMinY(faceBookTextImage.frame), faceBookTextImage.frame.size.width, faceBookTextImage.frame.size.height);
}

- (void)keyboardWillHide:(NSNotification *)notification
{
//    faceBookTextImage.frame = CGRectMake(CGRectGetMinX(faceBookTextImage.frame), CGRectGetMinY(faceBookTextImage.frame), faceBookTextImage.frame.size.width,CGRectGetMinY(locationImage.frame)-CGRectGetMinY(faceBookTextImage.frame)-SIZE_PADDING_DEFAULT);
//    txtFacebook.frame=CGRectMake(CGRectGetMinX(faceBookTextImage.frame), CGRectGetMinY(faceBookTextImage.frame), faceBookTextImage.frame.size.width, faceBookTextImage.frame.size.height);
    
	if (nil == toolbar || !keyboardToolbarShouldHide) {
		return;
	}
	
	CGPoint endCentre = [[[notification userInfo] valueForKey:@"UIKeyboardCenterEndUserInfoKey"] CGPointValue];
	CGRect keyboardBounds = [[[notification userInfo] valueForKey:@"UIKeyboardBoundsUserInfoKey"] CGRectValue];
	UIViewAnimationCurve animationCurve = [[[notification userInfo] valueForKey:UIKeyboardAnimationCurveUserInfoKey] intValue];
	NSTimeInterval animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
	
	[UIView beginAnimations:@"RS_hideKeyboardAnimation" context:nil];
	[UIView setAnimationCurve:animationCurve];
	[UIView setAnimationDuration:animationDuration];
	
	toolbar.hidden=YES;
	toolbar.alpha = 0.0;
	toolbar.frame = CGRectMake(endCentre.x - (keyboardBounds.size.width/2),
                                   endCentre.y - (keyboardBounds.size.height/2) - toolbar.frame.size.height,
                                   toolbar.frame.size.width,
                                   toolbar.frame.size.height);
	
	[UIView commitAnimations];
}

@end
