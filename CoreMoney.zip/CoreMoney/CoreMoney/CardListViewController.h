//
//  CardListViewController.h


// Class for displaying the Card Lists.

#import <UIKit/UIKit.h>
#import "DataParsingClass.h"
#import "PopUpView.h"

@interface CardListViewController : SwipeViewController<DataParsingDelegate>
{
    
    int selectedIndex;
    
    BusinessPageDetail *BusinessPageObject;
    
    
    UIView *statusSelectView;
    
    int RequestId,newCardStatus, oldCardStatus;
    newCardOrder *card_Order_Obj;
    UserProfileDataClass *userDetailObj;
    
    ReplaceCardData  *Replace;
}
@property (retain, nonatomic) IBOutlet UITableView *tblCardList;
@property int selectedIndex;
@property (retain, nonatomic) IBOutlet UIView *myCardListView;

@end
