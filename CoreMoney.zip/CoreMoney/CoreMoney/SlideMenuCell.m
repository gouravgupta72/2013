//
//  SlideMenuCell.m
// Class to design Slide menu cell.
#import "SlideMenuCell.h"

@implementation SlideMenuCell
@synthesize lblTitle,imgMenu,imgColorView,lblValue;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        // Initialization code
        imgMenu=[[UIImageView alloc] initWithFrame:CGRectMake(SIZE_PADDING_DEFAULT, 7, getWidth(30), getHeight(30))];
        [self addSubview:imgMenu];
        
        lblTitle=createLabel(@"", CGRectMake(CGRectGetMaxX(imgMenu.frame)+10, 7, getWidth(170), getHeight(30)));
        lblTitle.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
        lblTitle.shadowOffset = CGSizeMake(0,1);
        lblTitle.font = [UIFont systemFontOfSize:16];
        lblTitle.textAlignment = UITextAlignmentLeft;
        lblTitle.textColor =UI_COLOR_TEXT_LIGHT;
        [self addSubview:lblTitle];
        
        imgColorView=[[UIImageView alloc] initWithFrame:CGRectMake(240, 7, getWidth(6), getHeight(30))];
        [self addSubview:imgColorView];
        imgColorView.hidden=YES;
        
        lblValue=createLabel(@"0", CGRectMake(225, 7, getWidth(30), getHeight(30)));
        lblValue.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
        lblTitle.shadowOffset = CGSizeMake(0,1);
        lblValue.font = [UIFont systemFontOfSize:16];
        lblValue.textAlignment = UITextAlignmentRight;
        lblValue.textColor =UI_COLOR_TEXT_LIGHT;
        [self addSubview:lblValue];
        lblValue.hidden=YES;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)dealloc
{
    [lblTitle release];
    [lblValue release];
    [imgColorView release];
    [imgMenu release];
    [lblTitle release];
    [super dealloc];
}
@end
