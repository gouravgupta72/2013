//
//  lowBalanceSearchDataClass.m
//  CoreMoney
//class use for low Balance Search Data


#import "lowBalanceSearchDataClass.h"

@implementation lowBalanceSearchDataClass
@synthesize  ResErrorMsg, ACCOUNT_ACCT_ID, BA_ACCT_ID, SCHEDULE_TYPE,ResErrorCode, ResCode,AMOUNT, ThresholdAmount,ISACTIVE;

-(void)dealloc
{
    self.ResErrorMsg=nil;
    self.ACCOUNT_ACCT_ID=nil;
    self.BA_ACCT_ID=nil;
    self.SCHEDULE_TYPE=nil;
    [super dealloc];
}
@end
